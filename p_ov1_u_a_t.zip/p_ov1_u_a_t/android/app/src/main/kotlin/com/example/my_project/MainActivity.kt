package com.playon.app.enduser

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
