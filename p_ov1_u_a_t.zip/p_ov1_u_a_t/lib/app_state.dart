import 'package:shared_preferences/shared_preferences.dart';
import 'flutter_flow/lat_lng.dart';

class FFAppState {
  static final FFAppState _instance = FFAppState._internal();

  factory FFAppState() {
    return _instance;
  }

  FFAppState._internal() {
    initializePersistedState();
  }

  Future initializePersistedState() async {
    prefs = await SharedPreferences.getInstance();
    _localLanguageStore =
        prefs.getStringList('ff_localLanguageStore') ?? _localLanguageStore;
    _localLanguageListStore =
        prefs.getStringList('ff_localLanguageListStore') ??
            _localLanguageListStore;
    _localLanguageStoreString =
        prefs.getString('ff_localLanguageStoreString') ??
            _localLanguageStoreString;
    _localLanguageStoreStringVer =
        prefs.getString('ff_localLanguageStoreStringVer') ??
            _localLanguageStoreStringVer;
    _poGlobalValues =
        prefs.getStringList('ff_poGlobalValues') ?? _poGlobalValues;
    _poRegisterOptionSelected =
        prefs.getString('ff_poRegisterOptionSelected') ??
            _poRegisterOptionSelected;
    _attributeIntKey =
        prefs.getStringList('ff_attributeIntKey') ?? _attributeIntKey;
    _attributeIntValue =
        prefs.getStringList('ff_attributeIntValue')?.map(int.parse).toList() ??
            _attributeIntValue;
    _attributeColorKey =
        prefs.getStringList('ff_attributeColorKey') ?? _attributeColorKey;
    _attributeColorValue =
        prefs.getStringList('ff_attributeColorValue') ?? _attributeColorValue;
    _arrayCountries =
        prefs.getStringList('ff_arrayCountries') ?? _arrayCountries;
    _sessionRefreshToken =
        prefs.getString('ff_sessionRefreshToken') ?? _sessionRefreshToken;
    _sessionToken = prefs.getString('ff_sessionToken') ?? _sessionToken;
    _sessionPasswordChangeRequired =
        prefs.getString('ff_sessionPasswordChangeRequired') ??
            _sessionPasswordChangeRequired;
    _sessionPasswordLastUpdatedInstant =
        prefs.getString('ff_sessionPasswordLastUpdatedInstant') ??
            _sessionPasswordLastUpdatedInstant;
    _sessionLastLoginInstant = prefs.getString('ff_sessionLastLoginInstant') ??
        _sessionLastLoginInstant;
    _sessionActive = prefs.getString('ff_sessionActive') ?? _sessionActive;
    _sessionVerified =
        prefs.getString('ff_sessionVerified') ?? _sessionVerified;
    _sessionUsernameStatus =
        prefs.getString('ff_sessionUsernameStatus') ?? _sessionUsernameStatus;
    _applicationId = prefs.getString('ff_applicationId') ?? _applicationId;
    _sessionLoginId = prefs.getString('ff_sessionLoginId') ?? _sessionLoginId;
    _settings = prefs.getStringList('ff_settings') ?? _settings;
    _cTeamName = prefs.getString('ff_cTeamName') ?? _cTeamName;
    _lastName = prefs.getString('ff_lastName') ?? _lastName;
    _cEventName = prefs.getString('ff_cEventName') ?? _cEventName;
    _firstName = prefs.getString('ff_firstName') ?? _firstName;
    _date = prefs.getString('ff_date') ?? _date;
    _month = prefs.getString('ff_month') ?? _month;
    _year = prefs.getString('ff_year') ?? _year;
  }

  late SharedPreferences prefs;

  List<String> _localLanguageStore = [];
  List<String> get localLanguageStore => _localLanguageStore;
  set localLanguageStore(List<String> _value) {
    _localLanguageStore = _value;
    prefs.setStringList('ff_localLanguageStore', _value);
  }

  void addToLocalLanguageStore(String _value) {
    _localLanguageStore.add(_value);
    prefs.setStringList('ff_localLanguageStore', _localLanguageStore);
  }

  void removeFromLocalLanguageStore(String _value) {
    _localLanguageStore.remove(_value);
    prefs.setStringList('ff_localLanguageStore', _localLanguageStore);
  }

  List<String> _localLanguageListStore = [];
  List<String> get localLanguageListStore => _localLanguageListStore;
  set localLanguageListStore(List<String> _value) {
    _localLanguageListStore = _value;
    prefs.setStringList('ff_localLanguageListStore', _value);
  }

  void addToLocalLanguageListStore(String _value) {
    _localLanguageListStore.add(_value);
    prefs.setStringList('ff_localLanguageListStore', _localLanguageListStore);
  }

  void removeFromLocalLanguageListStore(String _value) {
    _localLanguageListStore.remove(_value);
    prefs.setStringList('ff_localLanguageListStore', _localLanguageListStore);
  }

  String _localLanguageStoreString = '';
  String get localLanguageStoreString => _localLanguageStoreString;
  set localLanguageStoreString(String _value) {
    _localLanguageStoreString = _value;
    prefs.setString('ff_localLanguageStoreString', _value);
  }

  String _localLanguageStoreStringVer = '';
  String get localLanguageStoreStringVer => _localLanguageStoreStringVer;
  set localLanguageStoreStringVer(String _value) {
    _localLanguageStoreStringVer = _value;
    prefs.setString('ff_localLanguageStoreStringVer', _value);
  }

  String currentLanguage = '';

  List<String> _poGlobalValues = [];
  List<String> get poGlobalValues => _poGlobalValues;
  set poGlobalValues(List<String> _value) {
    _poGlobalValues = _value;
    prefs.setStringList('ff_poGlobalValues', _value);
  }

  void addToPoGlobalValues(String _value) {
    _poGlobalValues.add(_value);
    prefs.setStringList('ff_poGlobalValues', _poGlobalValues);
  }

  void removeFromPoGlobalValues(String _value) {
    _poGlobalValues.remove(_value);
    prefs.setStringList('ff_poGlobalValues', _poGlobalValues);
  }

  String _poRegisterOptionSelected = '';
  String get poRegisterOptionSelected => _poRegisterOptionSelected;
  set poRegisterOptionSelected(String _value) {
    _poRegisterOptionSelected = _value;
    prefs.setString('ff_poRegisterOptionSelected', _value);
  }

  bool MainButtonsVisible = false;

  bool isPortrait = false;

  String businessDetails = '';

  bool msgVisible = false;

  String teamName = '';

  String gameEvent = '';

  String currentVideo = '';

  bool showVideo = false;

  List<String> _attributeIntKey = ['AppHeaderHeight', 'AppNavBarHeight'];
  List<String> get attributeIntKey => _attributeIntKey;
  set attributeIntKey(List<String> _value) {
    _attributeIntKey = _value;
    prefs.setStringList('ff_attributeIntKey', _value);
  }

  void addToAttributeIntKey(String _value) {
    _attributeIntKey.add(_value);
    prefs.setStringList('ff_attributeIntKey', _attributeIntKey);
  }

  void removeFromAttributeIntKey(String _value) {
    _attributeIntKey.remove(_value);
    prefs.setStringList('ff_attributeIntKey', _attributeIntKey);
  }

  List<int> _attributeIntValue = [6, 8];
  List<int> get attributeIntValue => _attributeIntValue;
  set attributeIntValue(List<int> _value) {
    _attributeIntValue = _value;
    prefs.setStringList(
        'ff_attributeIntValue', _value.map((x) => x.toString()).toList());
  }

  void addToAttributeIntValue(int _value) {
    _attributeIntValue.add(_value);
    prefs.setStringList('ff_attributeIntValue',
        _attributeIntValue.map((x) => x.toString()).toList());
  }

  void removeFromAttributeIntValue(int _value) {
    _attributeIntValue.remove(_value);
    prefs.setStringList('ff_attributeIntValue',
        _attributeIntValue.map((x) => x.toString()).toList());
  }

  List<String> _attributeColorKey = [];
  List<String> get attributeColorKey => _attributeColorKey;
  set attributeColorKey(List<String> _value) {
    _attributeColorKey = _value;
    prefs.setStringList('ff_attributeColorKey', _value);
  }

  void addToAttributeColorKey(String _value) {
    _attributeColorKey.add(_value);
    prefs.setStringList('ff_attributeColorKey', _attributeColorKey);
  }

  void removeFromAttributeColorKey(String _value) {
    _attributeColorKey.remove(_value);
    prefs.setStringList('ff_attributeColorKey', _attributeColorKey);
  }

  List<String> _attributeColorValue = [];
  List<String> get attributeColorValue => _attributeColorValue;
  set attributeColorValue(List<String> _value) {
    _attributeColorValue = _value;
    prefs.setStringList('ff_attributeColorValue', _value);
  }

  void addToAttributeColorValue(String _value) {
    _attributeColorValue.add(_value);
    prefs.setStringList('ff_attributeColorValue', _attributeColorValue);
  }

  void removeFromAttributeColorValue(String _value) {
    _attributeColorValue.remove(_value);
    prefs.setStringList('ff_attributeColorValue', _attributeColorValue);
  }

  int roleSelected = 0;

  List<String> _arrayCountries = [];
  List<String> get arrayCountries => _arrayCountries;
  set arrayCountries(List<String> _value) {
    _arrayCountries = _value;
    prefs.setStringList('ff_arrayCountries', _value);
  }

  void addToArrayCountries(String _value) {
    _arrayCountries.add(_value);
    prefs.setStringList('ff_arrayCountries', _arrayCountries);
  }

  void removeFromArrayCountries(String _value) {
    _arrayCountries.remove(_value);
    prefs.setStringList('ff_arrayCountries', _arrayCountries);
  }

  String _sessionRefreshToken = '';
  String get sessionRefreshToken => _sessionRefreshToken;
  set sessionRefreshToken(String _value) {
    _sessionRefreshToken = _value;
    prefs.setString('ff_sessionRefreshToken', _value);
  }

  String _sessionToken = '';
  String get sessionToken => _sessionToken;
  set sessionToken(String _value) {
    _sessionToken = _value;
    prefs.setString('ff_sessionToken', _value);
  }

  String _sessionPasswordChangeRequired = '';
  String get sessionPasswordChangeRequired => _sessionPasswordChangeRequired;
  set sessionPasswordChangeRequired(String _value) {
    _sessionPasswordChangeRequired = _value;
    prefs.setString('ff_sessionPasswordChangeRequired', _value);
  }

  String _sessionPasswordLastUpdatedInstant = '';
  String get sessionPasswordLastUpdatedInstant =>
      _sessionPasswordLastUpdatedInstant;
  set sessionPasswordLastUpdatedInstant(String _value) {
    _sessionPasswordLastUpdatedInstant = _value;
    prefs.setString('ff_sessionPasswordLastUpdatedInstant', _value);
  }

  String _sessionLastLoginInstant = '';
  String get sessionLastLoginInstant => _sessionLastLoginInstant;
  set sessionLastLoginInstant(String _value) {
    _sessionLastLoginInstant = _value;
    prefs.setString('ff_sessionLastLoginInstant', _value);
  }

  String _sessionActive = '';
  String get sessionActive => _sessionActive;
  set sessionActive(String _value) {
    _sessionActive = _value;
    prefs.setString('ff_sessionActive', _value);
  }

  String _sessionVerified = '';
  String get sessionVerified => _sessionVerified;
  set sessionVerified(String _value) {
    _sessionVerified = _value;
    prefs.setString('ff_sessionVerified', _value);
  }

  String _sessionUsernameStatus = '';
  String get sessionUsernameStatus => _sessionUsernameStatus;
  set sessionUsernameStatus(String _value) {
    _sessionUsernameStatus = _value;
    prefs.setString('ff_sessionUsernameStatus', _value);
  }

  String _applicationId = '919c2e73-a8a6-4d9d-b739-5b2dc1990ff8';
  String get applicationId => _applicationId;
  set applicationId(String _value) {
    _applicationId = _value;
    prefs.setString('ff_applicationId', _value);
  }

  String _sessionLoginId = '';
  String get sessionLoginId => _sessionLoginId;
  set sessionLoginId(String _value) {
    _sessionLoginId = _value;
    prefs.setString('ff_sessionLoginId', _value);
  }

  List<String> _settings = ['#330033'];
  List<String> get settings => _settings;
  set settings(List<String> _value) {
    _settings = _value;
    prefs.setStringList('ff_settings', _value);
  }

  void addToSettings(String _value) {
    _settings.add(_value);
    prefs.setStringList('ff_settings', _settings);
  }

  void removeFromSettings(String _value) {
    _settings.remove(_value);
    prefs.setStringList('ff_settings', _settings);
  }

  bool navPopDisabled = false;

  String getTeamName = '';

  int getAgeLocalState = 0;

  String getEvent = '';

  String _cTeamName = '';
  String get cTeamName => _cTeamName;
  set cTeamName(String _value) {
    _cTeamName = _value;
    prefs.setString('ff_cTeamName', _value);
  }

  String _lastName = '';
  String get lastName => _lastName;
  set lastName(String _value) {
    _lastName = _value;
    prefs.setString('ff_lastName', _value);
  }

  String _cEventName = '';
  String get cEventName => _cEventName;
  set cEventName(String _value) {
    _cEventName = _value;
    prefs.setString('ff_cEventName', _value);
  }

  String _firstName = '';
  String get firstName => _firstName;
  set firstName(String _value) {
    _firstName = _value;
    prefs.setString('ff_firstName', _value);
  }

  String _date = '';
  String get date => _date;
  set date(String _value) {
    _date = _value;
    prefs.setString('ff_date', _value);
  }

  String _month = '';
  String get month => _month;
  set month(String _value) {
    _month = _value;
    prefs.setString('ff_month', _value);
  }

  String _year = '';
  String get year => _year;
  set year(String _value) {
    _year = _value;
    prefs.setString('ff_year', _value);
  }

  String organizationname = '';

  String orgaddress = '';

  String orgdescription = '';

  String contactfirstname = '';

  String contactlastname = '';

  String contacttitle = '';

  String contactemail = '';

  int contactmobileno = 0;

  int contactphoneno = 0;

  String industryname = '';

  String otherindustry = '';

  String orgname = '';

  String orgtype = '';

  String charitywebsite = '';

  int charitynumber = 0;

  String orggoals = '';

  String bestdescribes = '';

  String orglogo = '';

  bool confirmorg = false;

  String mobileNumber = '';

  String phonenumber = '';

  String getemailaddress = '';

  String selectedEventName = '';

  List<String> eventname = [];

  String user = '';

  String contactextension = '';

  String uploadimgname = '';

  int wronganswers = 0;

  String quizid = '';

  List<String> assignquiz = [];

  String startdate1 = '';

  String enddate1 = '';

  String startdate2 = '';

  String enddate2 = '';

  String startdate3 = '';

  String enddate3 = '';

  DateTime? date1;

  DateTime? date2;

  DateTime? date3;

  DateTime? date4;

  DateTime? date5;

  DateTime? date6;

  DateTime? basicdate;

  bool useroradmin = false;

  String quiztype = '';

  String otpnumber = '';
}

LatLng? _latLngFromString(String? val) {
  if (val == null) {
    return null;
  }
  final split = val.split(',');
  final lat = double.parse(split.first);
  final lng = double.parse(split.last);
  return LatLng(lat, lng);
}
