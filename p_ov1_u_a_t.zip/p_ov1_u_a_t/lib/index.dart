// Export pages
export 'user_login_register/user_login_register_widget.dart'
    show UserLoginRegisterWidget;
export 'router/router_widget.dart' show RouterWidget;
export 'register_role_select/register_role_select_widget.dart'
    show RegisterRoleSelectWidget;
export 'player_role_select/player_role_select_widget.dart'
    show PlayerRoleSelectWidget;
export 'blank_template_page/blank_template_page_widget.dart'
    show BlankTemplatePageWidget;
export 'user_register/user_register_widget.dart' show UserRegisterWidget;
export 'register_player_photo/register_player_photo_widget.dart'
    show RegisterPlayerPhotoWidget;
export 'register_captain_01/register_captain01_widget.dart'
    show RegisterCaptain01Widget;
export 'register_captain_00/register_captain00_widget.dart'
    show RegisterCaptain00Widget;
export 'register_captain_02/register_captain02_widget.dart'
    show RegisterCaptain02Widget;
export 'register_captain_03/register_captain03_widget.dart'
    show RegisterCaptain03Widget;
export 'register_captain_04/register_captain04_widget.dart'
    show RegisterCaptain04Widget;
export 'register_captain_05/register_captain05_widget.dart'
    show RegisterCaptain05Widget;
export 'register_captain_06/register_captain06_widget.dart'
    show RegisterCaptain06Widget;
export 'register_captain_07/register_captain07_widget.dart'
    show RegisterCaptain07Widget;
export 'register_captain_08/register_captain08_widget.dart'
    show RegisterCaptain08Widget;
export 'dashboard_family/dashboard_family_widget.dart'
    show DashboardFamilyWidget;
export 'register_family_acc_00/register_family_acc00_widget.dart'
    show RegisterFamilyAcc00Widget;
export 'dashboard_fan/dashboard_fan_widget.dart' show DashboardFanWidget;
export 'register_charity_00/register_charity00_widget.dart'
    show RegisterCharity00Widget;
export 'register_family_acc_01/register_family_acc01_widget.dart'
    show RegisterFamilyAcc01Widget;
export 'register_charity_01/register_charity01_widget.dart'
    show RegisterCharity01Widget;
export 'register_charity_02/register_charity02_widget.dart'
    show RegisterCharity02Widget;
export 'register_charity_03/register_charity03_widget.dart'
    show RegisterCharity03Widget;
export 'register_charity_05/register_charity05_widget.dart'
    show RegisterCharity05Widget;
export 'register_charity_04/register_charity04_widget.dart'
    show RegisterCharity04Widget;
export 'createteam/createteam_widget.dart' show CreateteamWidget;
export 'referee_reg_list/referee_reg_list_widget.dart'
    show RefereeRegListWidget;
export 'dashboard_charity/dashboard_charity_widget.dart'
    show DashboardCharityWidget;
export 'captain_my_teams/captain_my_teams_widget.dart'
    show CaptainMyTeamsWidget;
export 'register_volunteer_00/register_volunteer00_widget.dart'
    show RegisterVolunteer00Widget;
export 'register_volunteer_01/register_volunteer01_widget.dart'
    show RegisterVolunteer01Widget;
export 'register_volunteer_02/register_volunteer02_widget.dart'
    show RegisterVolunteer02Widget;
export 'register_volunteer_03/register_volunteer03_widget.dart'
    show RegisterVolunteer03Widget;
export 'register_volunteer_04/register_volunteer04_widget.dart'
    show RegisterVolunteer04Widget;
export 'register_volunteer_05/register_volunteer05_widget.dart'
    show RegisterVolunteer05Widget;
export 'register_volunteer_06/register_volunteer06_widget.dart'
    show RegisterVolunteer06Widget;
export 'register_volunteer_07/register_volunteer07_widget.dart'
    show RegisterVolunteer07Widget;
export 'register_referee_05/register_referee05_widget.dart'
    show RegisterReferee05Widget;
export 'register_volunteer_08/register_volunteer08_widget.dart'
    show RegisterVolunteer08Widget;
export 'register_volunteer_09/register_volunteer09_widget.dart'
    show RegisterVolunteer09Widget;
export 'family_account_02/family_account02_widget.dart'
    show FamilyAccount02Widget;
export 'referee_management_01/referee_management01_widget.dart'
    show RefereeManagement01Widget;
export 'register_player_00/register_player00_widget.dart'
    show RegisterPlayer00Widget;
export 'register_player_01/register_player01_widget.dart'
    show RegisterPlayer01Widget;
export 'register_player_02/register_player02_widget.dart'
    show RegisterPlayer02Widget;
export 'register_player_04/register_player04_widget.dart'
    show RegisterPlayer04Widget;
export 'register_player_03/register_player03_widget.dart'
    show RegisterPlayer03Widget;
export 'register_player_05/register_player05_widget.dart'
    show RegisterPlayer05Widget;
export 'register_player_06/register_player06_widget.dart'
    show RegisterPlayer06Widget;
export 'register_player_07/register_player07_widget.dart'
    show RegisterPlayer07Widget;
export 'register_referee_00/register_referee00_widget.dart'
    show RegisterReferee00Widget;
export 'register_referee_01/register_referee01_widget.dart'
    show RegisterReferee01Widget;
export 'register_referee_02/register_referee02_widget.dart'
    show RegisterReferee02Widget;
export 'register_referee_03/register_referee03_widget.dart'
    show RegisterReferee03Widget;
export 'register_referee_04/register_referee04_widget.dart'
    show RegisterReferee04Widget;
export 'register_referee_06/register_referee06_widget.dart'
    show RegisterReferee06Widget;
export 'captain_profile/captain_profile_widget.dart' show CaptainProfileWidget;
export 'register_free_agent_00/register_free_agent00_widget.dart'
    show RegisterFreeAgent00Widget;
export 'register_free_agent_03/register_free_agent03_widget.dart'
    show RegisterFreeAgent03Widget;
export 'register_free_agent_01/register_free_agent01_widget.dart'
    show RegisterFreeAgent01Widget;
export 'register_free_agent_02/register_free_agent02_widget.dart'
    show RegisterFreeAgent02Widget;
export 'register_free_agent_05/register_free_agent05_widget.dart'
    show RegisterFreeAgent05Widget;
export 'register_free_agent_04/register_free_agent04_widget.dart'
    show RegisterFreeAgent04Widget;
export 'register_free_agent_06/register_free_agent06_widget.dart'
    show RegisterFreeAgent06Widget;
export 'register_free_agent_07/register_free_agent07_widget.dart'
    show RegisterFreeAgent07Widget;
export 'dashboard_captain/dashboard_captain_widget.dart'
    show DashboardCaptainWidget;
export 'player_profile/player_profile_widget.dart' show PlayerProfileWidget;
export 'register_business_partner_00/register_business_partner00_widget.dart'
    show RegisterBusinessPartner00Widget;
export 'register_business_partner_01/register_business_partner01_widget.dart'
    show RegisterBusinessPartner01Widget;
export 'register_business_partner_02/register_business_partner02_widget.dart'
    show RegisterBusinessPartner02Widget;
export 'register_business_parter_4a/register_business_parter4a_widget.dart'
    show RegisterBusinessParter4aWidget;
export 'register_business_partner_03/register_business_partner03_widget.dart'
    show RegisterBusinessPartner03Widget;
export 'register_business_partner_04/register_business_partner04_widget.dart'
    show RegisterBusinessPartner04Widget;
export 'manage_division_list/manage_division_list_widget.dart'
    show ManageDivisionListWidget;
export 'register_business_partner_05/register_business_partner05_widget.dart'
    show RegisterBusinessPartner05Widget;
export 'captain_invitation_01/captain_invitation01_widget.dart'
    show CaptainInvitation01Widget;
export 'manage_event_list/manage_event_list_widget.dart'
    show ManageEventListWidget;
export 'add_event/add_event_widget.dart' show AddEventWidget;
export 'dashboard_referee/dashboard_referee_widget.dart'
    show DashboardRefereeWidget;
export 'dashboard_free_agent/dashboard_free_agent_widget.dart'
    show DashboardFreeAgentWidget;
export 'playerregister_copy/playerregister_copy_widget.dart'
    show PlayerregisterCopyWidget;
export 'free_agent_profile/free_agent_profile_widget.dart'
    show FreeAgentProfileWidget;
export 'captain_invitation_02/captain_invitation02_widget.dart'
    show CaptainInvitation02Widget;
export 'register_business_partner_06/register_business_partner06_widget.dart'
    show RegisterBusinessPartner06Widget;
export 'business_registration_coupon/business_registration_coupon_widget.dart'
    show BusinessRegistrationCouponWidget;
export 'dashboard_player/dashboard_player_widget.dart'
    show DashboardPlayerWidget;
export 'volunteer_profile/volunteer_profile_widget.dart'
    show VolunteerProfileWidget;
export 'businessprofile/businessprofile_widget.dart' show BusinessprofileWidget;
export 'dashboard_business_partner/dashboard_business_partner_widget.dart'
    show DashboardBusinessPartnerWidget;
export 'dashboard_volunteer/dashboard_volunteer_widget.dart'
    show DashboardVolunteerWidget;
export 'manage_events_business_partner/manage_events_business_partner_widget.dart'
    show ManageEventsBusinessPartnerWidget;
export 'dashboard_admin/dashboard_admin_widget.dart' show DashboardAdminWidget;
export 'captain_invitation_03/captain_invitation03_widget.dart'
    show CaptainInvitation03Widget;
export 'add_division/add_division_widget.dart' show AddDivisionWidget;
export 'referee_profile/referee_profile_widget.dart' show RefereeProfileWidget;
export 'edit_event/edit_event_widget.dart' show EditEventWidget;
export 'register_fan_00/register_fan00_widget.dart' show RegisterFan00Widget;
export 'register_fan_01/register_fan01_widget.dart' show RegisterFan01Widget;
export 'register_fan_02/register_fan02_widget.dart' show RegisterFan02Widget;
export 'manage_user_list/manage_user_list_widget.dart'
    show ManageUserListWidget;
export 'contactus/contactus_widget.dart' show ContactusWidget;
export 'add_user_business_partner/add_user_business_partner_widget.dart'
    show AddUserBusinessPartnerWidget;
export 'businesspartnerquiz/businesspartnerquiz_widget.dart'
    show BusinesspartnerquizWidget;
export 'listinguser_business_partner/listinguser_business_partner_widget.dart'
    show ListinguserBusinessPartnerWidget;
export 'quiz_score_bp/quiz_score_bp_widget.dart' show QuizScoreBpWidget;
export 'assign_quiz_to_user/assign_quiz_to_user_widget.dart'
    show AssignQuizToUserWidget;
export 'bp_quiz_view/bp_quiz_view_widget.dart' show BpQuizViewWidget;
export 'assignquiz/assignquiz_widget.dart' show AssignquizWidget;
export 'select_quiz/select_quiz_widget.dart' show SelectQuizWidget;
export 'otp_phone/otp_phone_widget.dart' show OtpPhoneWidget;
export 'verifyotp/verifyotp_widget.dart' show VerifyotpWidget;
export 'user_login_withotp/user_login_withotp_widget.dart'
    show UserLoginWithotpWidget;
