import '../blank_template_page/blank_template_page_widget.dart';
import '../components/app_bar_row_logo_widget.dart';
import '../dashboard_admin/dashboard_admin_widget.dart';
import '../flutter_flow/flutter_flow_language_selector.dart';
import '../flutter_flow/flutter_flow_theme.dart';
import '../flutter_flow/flutter_flow_util.dart';
import '../flutter_flow/flutter_flow_widgets.dart';
import '../player_role_select/player_role_select_widget.dart';
import '../register_business_partner_00/register_business_partner00_widget.dart';
import '../register_charity_00/register_charity00_widget.dart';
import '../register_fan_00/register_fan00_widget.dart';
import '../register_referee_00/register_referee00_widget.dart';
import '../register_volunteer_00/register_volunteer00_widget.dart';
import '../user_login_register/user_login_register_widget.dart';
import '../user_register/user_register_widget.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:google_fonts/google_fonts.dart';

class RegisterRoleSelectWidget extends StatefulWidget {
  const RegisterRoleSelectWidget({Key? key}) : super(key: key);

  @override
  _RegisterRoleSelectWidgetState createState() =>
      _RegisterRoleSelectWidgetState();
}

class _RegisterRoleSelectWidgetState extends State<RegisterRoleSelectWidget> {
  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    // On page load action.
    SchedulerBinding.instance.addPostFrameCallback((_) async {
      setState(() => FFAppState().navPopDisabled = true);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: scaffoldKey,
      appBar: AppBar(
        backgroundColor: Color(0xFF274078),
        automaticallyImplyLeading: true,
        leading: Row(
          mainAxisSize: MainAxisSize.max,
          children: [
            Expanded(
              child: AppBarRowLogoWidget(),
            ),
          ],
        ),
        title: Align(
          alignment: AlignmentDirectional(-1, 0),
          child: Row(
            mainAxisSize: MainAxisSize.max,
            mainAxisAlignment: MainAxisAlignment.end,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              FFButtonWidget(
                onPressed: () async {
                  await Navigator.push(
                    context,
                    PageTransition(
                      type: PageTransitionType.rightToLeft,
                      duration: Duration(milliseconds: 50),
                      reverseDuration: Duration(milliseconds: 50),
                      child: BlankTemplatePageWidget(),
                    ),
                  );
                },
                text: FFLocalizations.of(context).getText(
                  'rle15ine' /* TestPage */,
                ),
                options: FFButtonOptions(
                  width: 130,
                  height: 40,
                  color: FlutterFlowTheme.of(context).primaryColor,
                  textStyle: FlutterFlowTheme.of(context).subtitle2.override(
                        fontFamily: 'Poppins',
                        color: Colors.white,
                      ),
                  borderSide: BorderSide(
                    color: Colors.transparent,
                    width: 1,
                  ),
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
              Padding(
                padding: EdgeInsetsDirectional.fromSTEB(10, 10, 10, 10),
                child: FFButtonWidget(
                  onPressed: () async {
                    await Navigator.push(
                      context,
                      PageTransition(
                        type: PageTransitionType.rightToLeft,
                        duration: Duration(milliseconds: 0),
                        reverseDuration: Duration(milliseconds: 0),
                        child: DashboardAdminWidget(),
                      ),
                    );
                  },
                  text: FFLocalizations.of(context).getText(
                    'pyp6s99o' /* Admin */,
                  ),
                  options: FFButtonOptions(
                    width: 80,
                    height: 40,
                    color: Colors.white,
                    textStyle: FlutterFlowTheme.of(context).subtitle2.override(
                          fontFamily: 'Poppins',
                          color: Colors.black,
                        ),
                    borderSide: BorderSide(
                      color: Colors.transparent,
                      width: 1,
                    ),
                    borderRadius: BorderRadius.circular(8),
                  ),
                ),
              ),
              FlutterFlowLanguageSelector(
                width: 100,
                height: 40,
                backgroundColor: FlutterFlowTheme.of(context).tertiaryColor,
                borderColor: Color(0xFF262D34),
                dropdownIconColor: Color(0xFF14181B),
                borderRadius: 8,
                textStyle: TextStyle(
                  color: FlutterFlowTheme.of(context).black,
                  fontWeight: FontWeight.normal,
                  fontSize: 13,
                ),
                hideFlags: true,
                flagSize: 24,
                flagTextGap: 8,
                currentLanguage: FFLocalizations.of(context).languageCode,
                languages: FFLocalizations.languages(),
                onChanged: (lang) => setAppLanguage(context, lang),
              ),
              Padding(
                padding: EdgeInsetsDirectional.fromSTEB(5, 5, 0, 5),
                child: FFButtonWidget(
                  onPressed: () async {
                    await Navigator.push(
                      context,
                      PageTransition(
                        type: PageTransitionType.rightToLeft,
                        duration: Duration(milliseconds: 50),
                        reverseDuration: Duration(milliseconds: 50),
                        child: UserLoginRegisterWidget(),
                      ),
                    );
                  },
                  text: FFLocalizations.of(context).getText(
                    'wu148olp' /* Login */,
                  ),
                  icon: Icon(
                    Icons.login,
                    color: Color(0xFFFFC107),
                    size: 15,
                  ),
                  options: FFButtonOptions(
                    width: 90,
                    height: 40,
                    color: FlutterFlowTheme.of(context).primaryColor,
                    textStyle: FlutterFlowTheme.of(context).subtitle2.override(
                          fontFamily: 'Poppins',
                          color: Colors.white,
                          fontSize: 14,
                        ),
                    borderSide: BorderSide(
                      color: Colors.transparent,
                      width: 1,
                    ),
                    borderRadius: BorderRadius.circular(4),
                  ),
                ),
              ),
            ],
          ),
        ),
        actions: [
          Row(
            mainAxisSize: MainAxisSize.max,
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [],
          ),
        ],
        centerTitle: true,
        elevation: 12,
      ),
      backgroundColor: Color(0xFF274078),
      drawer: Drawer(
        elevation: 16,
        child: Column(
          mainAxisSize: MainAxisSize.max,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              width: MediaQuery.of(context).size.width,
              height: MediaQuery.of(context).size.height * 1,
              constraints: BoxConstraints(
                maxWidth: MediaQuery.of(context).size.width,
                maxHeight: MediaQuery.of(context).size.height * 1,
              ),
              decoration: BoxDecoration(
                color: Color(0xFFD6D6D6),
                shape: BoxShape.rectangle,
              ),
              child: Column(
                mainAxisSize: MainAxisSize.max,
                children: [
                  Padding(
                    padding: EdgeInsetsDirectional.fromSTEB(0, 10, 0, 10),
                    child: Text(
                      FFLocalizations.of(context).getText(
                        'h4i4j3qr' /* Menu */,
                      ),
                      style: FlutterFlowTheme.of(context).title1,
                    ),
                  ),
                  ListTile(
                    title: Text(
                      FFLocalizations.of(context).getText(
                        'ckyqz4hx' /* PlayOn! Store */,
                      ),
                      style: FlutterFlowTheme.of(context).title3,
                    ),
                    subtitle: Text(
                      FFLocalizations.of(context).getText(
                        'vt1xt49n' /* Go to the PlayOn! Store */,
                      ),
                      style: FlutterFlowTheme.of(context).subtitle2,
                    ),
                    trailing: Icon(
                      Icons.arrow_forward_ios,
                      color: Color(0xFF303030),
                      size: 20,
                    ),
                    tileColor: Color(0xFFF5F5F5),
                    dense: false,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
      body: SafeArea(
        child: Align(
          alignment: AlignmentDirectional(0, -1),
          child: Container(
            width: 1200,
            height: MediaQuery.of(context).size.height * 0.84,
            decoration: BoxDecoration(),
            child: Visibility(
              visible: !FFAppState().MainButtonsVisible,
              child: Align(
                alignment: AlignmentDirectional(0, 0),
                child: SingleChildScrollView(
                  child: Column(
                    mainAxisSize: MainAxisSize.max,
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Wrap(
                        spacing: 0,
                        runSpacing: 0,
                        alignment: WrapAlignment.center,
                        crossAxisAlignment: WrapCrossAlignment.start,
                        direction: Axis.horizontal,
                        runAlignment: WrapAlignment.start,
                        verticalDirection: VerticalDirection.down,
                        clipBehavior: Clip.none,
                        children: [
                          Wrap(
                            spacing: 0,
                            runSpacing: 0,
                            alignment: WrapAlignment.start,
                            crossAxisAlignment: WrapCrossAlignment.start,
                            direction: Axis.horizontal,
                            runAlignment: WrapAlignment.start,
                            verticalDirection: VerticalDirection.down,
                            clipBehavior: Clip.none,
                            children: [
                              Wrap(
                                spacing: 0,
                                runSpacing: 0,
                                alignment: WrapAlignment.start,
                                crossAxisAlignment: WrapCrossAlignment.start,
                                direction: Axis.horizontal,
                                runAlignment: WrapAlignment.start,
                                verticalDirection: VerticalDirection.down,
                                clipBehavior: Clip.none,
                                children: [
                                  Padding(
                                    padding: EdgeInsetsDirectional.fromSTEB(
                                        10, 10, 10, 10),
                                    child: FFButtonWidget(
                                      onPressed: () async {
                                        setState(() =>
                                            FFAppState().roleSelected = 6);
                                        await Navigator.push(
                                          context,
                                          PageTransition(
                                            type:
                                                PageTransitionType.rightToLeft,
                                            duration:
                                                Duration(milliseconds: 50),
                                            reverseDuration:
                                                Duration(milliseconds: 50),
                                            child: RegisterVolunteer00Widget(),
                                          ),
                                        );
                                      },
                                      text: FFLocalizations.of(context).getText(
                                        'us0825w7' /* Volunteer */,
                                      ),
                                      options: FFButtonOptions(
                                        width: 180,
                                        height: 60,
                                        color: Colors.white,
                                        textStyle: FlutterFlowTheme.of(context)
                                            .subtitle2
                                            .override(
                                              fontFamily: 'Poppins',
                                              color: Color(0xFF274078),
                                            ),
                                        borderSide: BorderSide(
                                          color: Colors.transparent,
                                          width: 1,
                                        ),
                                        borderRadius: BorderRadius.circular(4),
                                      ),
                                    ),
                                  ),
                                  Padding(
                                    padding: EdgeInsetsDirectional.fromSTEB(
                                        10, 10, 10, 10),
                                    child: FFButtonWidget(
                                      onPressed: () async {
                                        setState(() =>
                                            FFAppState().roleSelected = 5);
                                        await Navigator.push(
                                          context,
                                          PageTransition(
                                            type:
                                                PageTransitionType.rightToLeft,
                                            duration:
                                                Duration(milliseconds: 50),
                                            reverseDuration:
                                                Duration(milliseconds: 50),
                                            child: RegisterReferee00Widget(),
                                          ),
                                        );
                                      },
                                      text: FFLocalizations.of(context).getText(
                                        'wp7rwqso' /* Referee */,
                                      ),
                                      options: FFButtonOptions(
                                        width: 180,
                                        height: 60,
                                        color: Colors.white,
                                        textStyle: FlutterFlowTheme.of(context)
                                            .subtitle2
                                            .override(
                                              fontFamily: 'Poppins',
                                              color: Color(0xFF274078),
                                            ),
                                        borderSide: BorderSide(
                                          color: Colors.transparent,
                                          width: 1,
                                        ),
                                        borderRadius: BorderRadius.circular(4),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                              Wrap(
                                spacing: 0,
                                runSpacing: 0,
                                alignment: WrapAlignment.start,
                                crossAxisAlignment: WrapCrossAlignment.start,
                                direction: Axis.horizontal,
                                runAlignment: WrapAlignment.start,
                                verticalDirection: VerticalDirection.down,
                                clipBehavior: Clip.none,
                                children: [
                                  Padding(
                                    padding: EdgeInsetsDirectional.fromSTEB(
                                        10, 10, 10, 10),
                                    child: FFButtonWidget(
                                      onPressed: () async {
                                        setState(() =>
                                            FFAppState().navPopDisabled = true);
                                        await Navigator.push(
                                          context,
                                          PageTransition(
                                            type:
                                                PageTransitionType.rightToLeft,
                                            duration:
                                                Duration(milliseconds: 50),
                                            reverseDuration:
                                                Duration(milliseconds: 50),
                                            child: PlayerRoleSelectWidget(),
                                          ),
                                        );
                                      },
                                      text: FFLocalizations.of(context).getText(
                                        'v21hqvtt' /* Player
 */
                                        ,
                                      ),
                                      options: FFButtonOptions(
                                        width: 180,
                                        height: 60,
                                        color: Colors.white,
                                        textStyle: FlutterFlowTheme.of(context)
                                            .subtitle2
                                            .override(
                                              fontFamily: 'Poppins',
                                              color: Color(0xFF274078),
                                            ),
                                        borderSide: BorderSide(
                                          color: Colors.transparent,
                                          width: 1,
                                        ),
                                        borderRadius: BorderRadius.circular(4),
                                      ),
                                    ),
                                  ),
                                  Padding(
                                    padding: EdgeInsetsDirectional.fromSTEB(
                                        10, 10, 10, 10),
                                    child: FFButtonWidget(
                                      onPressed: () async {
                                        setState(() =>
                                            FFAppState().roleSelected = 9);
                                        await Navigator.push(
                                          context,
                                          PageTransition(
                                            type:
                                                PageTransitionType.rightToLeft,
                                            duration: Duration(milliseconds: 0),
                                            reverseDuration:
                                                Duration(milliseconds: 0),
                                            child: RegisterFan00Widget(),
                                          ),
                                        );
                                      },
                                      text: FFLocalizations.of(context).getText(
                                        '8lipcebv' /* Fan */,
                                      ),
                                      options: FFButtonOptions(
                                        width: 180,
                                        height: 60,
                                        color: Colors.white,
                                        textStyle: FlutterFlowTheme.of(context)
                                            .subtitle2
                                            .override(
                                              fontFamily: 'Poppins',
                                              color: Color(0xFF274078),
                                            ),
                                        borderSide: BorderSide(
                                          color: Colors.transparent,
                                          width: 1,
                                        ),
                                        borderRadius: BorderRadius.circular(4),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                          Visibility(
                            visible: responsiveVisibility(
                              context: context,
                              phone: false,
                              tabletLandscape: false,
                            ),
                            child: Container(
                              width: MediaQuery.of(context).size.width,
                              height: 100,
                              decoration: BoxDecoration(),
                            ),
                          ),
                          Wrap(
                            spacing: 0,
                            runSpacing: 0,
                            alignment: WrapAlignment.start,
                            crossAxisAlignment: WrapCrossAlignment.start,
                            direction: Axis.horizontal,
                            runAlignment: WrapAlignment.start,
                            verticalDirection: VerticalDirection.down,
                            clipBehavior: Clip.none,
                            children: [
                              Wrap(
                                spacing: 0,
                                runSpacing: 0,
                                alignment: WrapAlignment.start,
                                crossAxisAlignment: WrapCrossAlignment.start,
                                direction: Axis.horizontal,
                                runAlignment: WrapAlignment.start,
                                verticalDirection: VerticalDirection.down,
                                clipBehavior: Clip.none,
                                children: [
                                  Padding(
                                    padding: EdgeInsetsDirectional.fromSTEB(
                                        10, 10, 10, 10),
                                    child: FFButtonWidget(
                                      onPressed: () async {
                                        setState(() =>
                                            FFAppState().roleSelected = 8);
                                        await Navigator.push(
                                          context,
                                          PageTransition(
                                            type:
                                                PageTransitionType.rightToLeft,
                                            duration:
                                                Duration(milliseconds: 50),
                                            reverseDuration:
                                                Duration(milliseconds: 50),
                                            child: RegisterCharity00Widget(),
                                          ),
                                        );
                                      },
                                      text: FFLocalizations.of(context).getText(
                                        '6a2gz8ok' /* Charity */,
                                      ),
                                      options: FFButtonOptions(
                                        width: 180,
                                        height: 60,
                                        color: Colors.white,
                                        textStyle: FlutterFlowTheme.of(context)
                                            .subtitle2
                                            .override(
                                              fontFamily: 'Poppins',
                                              color: Color(0xFF274078),
                                            ),
                                        borderSide: BorderSide(
                                          color: Colors.transparent,
                                          width: 1,
                                        ),
                                        borderRadius: BorderRadius.circular(4),
                                      ),
                                    ),
                                  ),
                                  Padding(
                                    padding: EdgeInsetsDirectional.fromSTEB(
                                        10, 10, 10, 10),
                                    child: FFButtonWidget(
                                      onPressed: () async {
                                        setState(() =>
                                            FFAppState().roleSelected = 10);
                                        await Navigator.push(
                                          context,
                                          PageTransition(
                                            type:
                                                PageTransitionType.rightToLeft,
                                            duration:
                                                Duration(milliseconds: 50),
                                            reverseDuration:
                                                Duration(milliseconds: 50),
                                            child: UserRegisterWidget(
                                              poRegType: 'HostMuncipality',
                                            ),
                                          ),
                                        );
                                      },
                                      text: FFLocalizations.of(context).getText(
                                        '39gayaay' /* Host Muncipality */,
                                      ),
                                      options: FFButtonOptions(
                                        width: 180,
                                        height: 60,
                                        color: Colors.white,
                                        textStyle: FlutterFlowTheme.of(context)
                                            .subtitle2
                                            .override(
                                              fontFamily: 'Poppins',
                                              color: Color(0xFF274078),
                                            ),
                                        borderSide: BorderSide(
                                          color: Colors.transparent,
                                          width: 1,
                                        ),
                                        borderRadius: BorderRadius.circular(4),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                              Wrap(
                                spacing: 0,
                                runSpacing: 0,
                                alignment: WrapAlignment.start,
                                crossAxisAlignment: WrapCrossAlignment.start,
                                direction: Axis.horizontal,
                                runAlignment: WrapAlignment.start,
                                verticalDirection: VerticalDirection.down,
                                clipBehavior: Clip.none,
                                children: [
                                  Padding(
                                    padding: EdgeInsetsDirectional.fromSTEB(
                                        10, 10, 10, 10),
                                    child: FFButtonWidget(
                                      onPressed: () async {
                                        setState(() =>
                                            FFAppState().roleSelected = 7);
                                        await Navigator.push(
                                          context,
                                          PageTransition(
                                            type:
                                                PageTransitionType.rightToLeft,
                                            duration:
                                                Duration(milliseconds: 50),
                                            reverseDuration:
                                                Duration(milliseconds: 50),
                                            child:
                                                RegisterBusinessPartner00Widget(
                                              poRegType: 'BusinessPartner',
                                            ),
                                          ),
                                        );
                                      },
                                      text: FFLocalizations.of(context).getText(
                                        'rvllwshs' /* Business Partner */,
                                      ),
                                      options: FFButtonOptions(
                                        width: 180,
                                        height: 60,
                                        color: Colors.white,
                                        textStyle: FlutterFlowTheme.of(context)
                                            .subtitle2
                                            .override(
                                              fontFamily: 'Poppins',
                                              color: Color(0xFF274078),
                                            ),
                                        borderSide: BorderSide(
                                          color: Colors.transparent,
                                          width: 1,
                                        ),
                                        borderRadius: BorderRadius.circular(4),
                                      ),
                                    ),
                                  ),
                                  Padding(
                                    padding: EdgeInsetsDirectional.fromSTEB(
                                        10, 10, 10, 10),
                                    child: FFButtonWidget(
                                      onPressed: () async {
                                        setState(() =>
                                            FFAppState().roleSelected = 11);
                                        await Navigator.push(
                                          context,
                                          PageTransition(
                                            type:
                                                PageTransitionType.rightToLeft,
                                            duration: Duration(milliseconds: 0),
                                            reverseDuration:
                                                Duration(milliseconds: 0),
                                            child: BlankTemplatePageWidget(),
                                          ),
                                        );
                                      },
                                      text: FFLocalizations.of(context).getText(
                                        'lnmvn35w' /* Vendor */,
                                      ),
                                      options: FFButtonOptions(
                                        width: 180,
                                        height: 60,
                                        color: Colors.white,
                                        textStyle: FlutterFlowTheme.of(context)
                                            .subtitle2
                                            .override(
                                              fontFamily: 'Poppins',
                                              color: Color(0xFF274078),
                                            ),
                                        borderSide: BorderSide(
                                          color: Colors.transparent,
                                          width: 1,
                                        ),
                                        borderRadius: BorderRadius.circular(4),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
