import '../backend/api_requests/api_calls.dart';
import '../components/app_header_widget.dart';
import '../components/menu_widget.dart';
import '../dashboard_business_partner/dashboard_business_partner_widget.dart';
import '../flutter_flow/flutter_flow_theme.dart';
import '../flutter_flow/flutter_flow_util.dart';
import '../flutter_flow/flutter_flow_widgets.dart';
import '../custom_code/widgets/index.dart' as custom_widgets;
import '../flutter_flow/custom_functions.dart' as functions;
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:google_fonts/google_fonts.dart';

class BusinesspartnerquizWidget extends StatefulWidget {
  const BusinesspartnerquizWidget({Key? key}) : super(key: key);

  @override
  _BusinesspartnerquizWidgetState createState() =>
      _BusinesspartnerquizWidgetState();
}

class _BusinesspartnerquizWidgetState extends State<BusinesspartnerquizWidget> {
  ApiCallResponse? apiResult;
  ApiCallResponse? apiResulti8j;
  ApiCallResponse? apiResultvalid;
  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    // On page load action.
    SchedulerBinding.instance.addPostFrameCallback((_) async {
      setState(() => FFAppState().wronganswers = 0);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: scaffoldKey,
      backgroundColor: FlutterFlowTheme.of(context).customColor1,
      drawer: Container(
        width: 250,
        child: Drawer(
          elevation: 16,
          child: MenuWidget(),
        ),
      ),
      body: SafeArea(
        child: GestureDetector(
          onTap: () => FocusScope.of(context).unfocus(),
          child: Column(
            mainAxisSize: MainAxisSize.max,
            children: [
              AppHeaderWidget(),
              Container(
                width: 1000,
                height: MediaQuery.of(context).size.height * 0.84,
                decoration: BoxDecoration(
                  color: FlutterFlowTheme.of(context).secondaryBackground,
                ),
                child: SingleChildScrollView(
                  child: Column(
                    mainAxisSize: MainAxisSize.max,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Padding(
                        padding: EdgeInsetsDirectional.fromSTEB(10, 10, 10, 10),
                        child: Text(
                          FFLocalizations.of(context).getText(
                            'kjj6auxc' /* Training Certification Test */,
                          ),
                          style:
                              FlutterFlowTheme.of(context).bodyText1.override(
                                    fontFamily: 'Poppins',
                                    fontSize: 20,
                                    fontWeight: FontWeight.w600,
                                  ),
                        ),
                      ),
                      Padding(
                        padding: EdgeInsetsDirectional.fromSTEB(20, 0, 20, 10),
                        child: Container(
                          width: MediaQuery.of(context).size.width,
                          decoration: BoxDecoration(
                            color: FlutterFlowTheme.of(context)
                                .secondaryBackground,
                          ),
                          child: Padding(
                            padding:
                                EdgeInsetsDirectional.fromSTEB(5, 0, 5, 10),
                            child: Text(
                              FFLocalizations.of(context).getText(
                                'ww93ij1y' /* In this module you will be req... */,
                              ),
                              textAlign: TextAlign.start,
                              style: FlutterFlowTheme.of(context)
                                  .bodyText1
                                  .override(
                                    fontFamily: 'Poppins',
                                    fontSize: 14,
                                  ),
                            ),
                          ),
                        ),
                      ),
                      Padding(
                        padding: EdgeInsetsDirectional.fromSTEB(20, 0, 20, 0),
                        child: Container(
                          width: MediaQuery.of(context).size.width,
                          decoration: BoxDecoration(
                            color: FlutterFlowTheme.of(context)
                                .secondaryBackground,
                          ),
                          child: FutureBuilder<ApiCallResponse>(
                            future: QuizbpCall.call(
                              refreshToken: FFAppState().sessionRefreshToken,
                              formstep: 'get',
                            ),
                            builder: (context, snapshot) {
                              // Customize what your widget looks like when it's loading.
                              if (!snapshot.hasData) {
                                return Center(
                                  child: SizedBox(
                                    width: 50,
                                    height: 50,
                                    child: SpinKitHourGlass(
                                      color: Color(0xFFFFC107),
                                      size: 50,
                                    ),
                                  ),
                                );
                              }
                              final columnQuizbpResponse = snapshot.data!;
                              return Builder(
                                builder: (context) {
                                  final question = getJsonField(
                                    columnQuizbpResponse.jsonBody,
                                    r'''$[*]''',
                                  ).toList();
                                  return SingleChildScrollView(
                                    child: Column(
                                      mainAxisSize: MainAxisSize.max,
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: List.generate(question.length,
                                          (questionIndex) {
                                        final questionItem =
                                            question[questionIndex];
                                        return Visibility(
                                          visible: functions
                                                  .stringtoint(getJsonField(
                                                questionItem,
                                                r'''$..qid''',
                                              ).toString()) <
                                              6,
                                          child: Column(
                                            mainAxisSize: MainAxisSize.max,
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            children: [
                                              Padding(
                                                padding: EdgeInsetsDirectional
                                                    .fromSTEB(5, 5, 5, 5),
                                                child: Text(
                                                  '${getJsonField(
                                                    questionItem,
                                                    r'''$..qid''',
                                                  ).toString()}, ${getJsonField(
                                                    questionItem,
                                                    r'''$..question''',
                                                  ).toString()}',
                                                  style: FlutterFlowTheme.of(
                                                          context)
                                                      .bodyText1,
                                                ),
                                              ),
                                              Padding(
                                                padding: EdgeInsetsDirectional
                                                    .fromSTEB(5, 5, 5, 5),
                                                child: FutureBuilder<
                                                    ApiCallResponse>(
                                                  future: QuizbpCall.call(
                                                    refreshToken: FFAppState()
                                                        .sessionRefreshToken,
                                                    formstep: 'image',
                                                    type: getJsonField(
                                                      questionItem,
                                                      r'''$..image''',
                                                    ).toString(),
                                                  ),
                                                  builder: (context, snapshot) {
                                                    // Customize what your widget looks like when it's loading.
                                                    if (!snapshot.hasData) {
                                                      return Center(
                                                        child: SizedBox(
                                                          width: 50,
                                                          height: 50,
                                                          child:
                                                              SpinKitHourGlass(
                                                            color: Color(
                                                                0xFFFFC107),
                                                            size: 50,
                                                          ),
                                                        ),
                                                      );
                                                    }
                                                    final base64ImageQuizbpResponse =
                                                        snapshot.data!;
                                                    return Container(
                                                      width: 300,
                                                      height: 200,
                                                      child: custom_widgets
                                                          .Base64Image(
                                                        width: 300,
                                                        height: 200,
                                                        base64: getJsonField(
                                                          base64ImageQuizbpResponse
                                                              .jsonBody,
                                                          r'''$..data''',
                                                        ).toString(),
                                                      ),
                                                    );
                                                  },
                                                ),
                                              ),
                                              Builder(
                                                builder: (context) {
                                                  final answer = getJsonField(
                                                    questionItem,
                                                    r'''$..json_agg''',
                                                  ).toList();
                                                  return Column(
                                                    mainAxisSize:
                                                        MainAxisSize.max,
                                                    crossAxisAlignment:
                                                        CrossAxisAlignment
                                                            .start,
                                                    children: List.generate(
                                                        answer.length,
                                                        (answerIndex) {
                                                      final answerItem =
                                                          answer[answerIndex];
                                                      return Column(
                                                        mainAxisSize:
                                                            MainAxisSize.max,
                                                        crossAxisAlignment:
                                                            CrossAxisAlignment
                                                                .start,
                                                        children: [
                                                          if (functions
                                                                  .stringtoint(
                                                                      getJsonField(
                                                                questionItem,
                                                                r'''$..detailsaid''',
                                                              ).toString()) !=
                                                              functions
                                                                  .stringtoint(
                                                                      getJsonField(
                                                                answerItem,
                                                                r'''$..aid''',
                                                              ).toString()))
                                                            Padding(
                                                              padding:
                                                                  EdgeInsetsDirectional
                                                                      .fromSTEB(
                                                                          10,
                                                                          5,
                                                                          0,
                                                                          5),
                                                              child: InkWell(
                                                                onTap:
                                                                    () async {
                                                                  apiResult =
                                                                      await QuizbpCall
                                                                          .call(
                                                                    refreshToken:
                                                                        FFAppState()
                                                                            .sessionRefreshToken,
                                                                    i1: getJsonField(
                                                                      questionItem,
                                                                      r'''$..qid''',
                                                                    ).toString(),
                                                                    i2: getJsonField(
                                                                      answerItem,
                                                                      r'''$..aid''',
                                                                    ).toString(),
                                                                    formstep:
                                                                        'update',
                                                                  );

                                                                  setState(
                                                                      () {});
                                                                },
                                                                child:
                                                                    Container(
                                                                  decoration:
                                                                      BoxDecoration(
                                                                    color: FlutterFlowTheme.of(
                                                                            context)
                                                                        .tertiaryColor,
                                                                    borderRadius:
                                                                        BorderRadius.circular(
                                                                            10),
                                                                  ),
                                                                  child:
                                                                      Padding(
                                                                    padding: EdgeInsetsDirectional
                                                                        .fromSTEB(
                                                                            5,
                                                                            5,
                                                                            5,
                                                                            5),
                                                                    child: Text(
                                                                      getJsonField(
                                                                        answerItem,
                                                                        r'''$..answer''',
                                                                      ).toString(),
                                                                      textAlign:
                                                                          TextAlign
                                                                              .end,
                                                                      style: FlutterFlowTheme.of(
                                                                              context)
                                                                          .bodyText1
                                                                          .override(
                                                                            fontFamily:
                                                                                'Poppins',
                                                                            color:
                                                                                FlutterFlowTheme.of(context).black,
                                                                          ),
                                                                    ),
                                                                  ),
                                                                ),
                                                              ),
                                                            ),
                                                          if (functions
                                                                  .stringtoint(
                                                                      getJsonField(
                                                                questionItem,
                                                                r'''$..detailsaid''',
                                                              ).toString()) ==
                                                              getJsonField(
                                                                answerItem,
                                                                r'''$..aid''',
                                                              ))
                                                            Padding(
                                                              padding:
                                                                  EdgeInsetsDirectional
                                                                      .fromSTEB(
                                                                          10,
                                                                          5,
                                                                          0,
                                                                          5),
                                                              child: Container(
                                                                decoration:
                                                                    BoxDecoration(
                                                                  color: Color(
                                                                      0xFFFFFF00),
                                                                  borderRadius:
                                                                      BorderRadius
                                                                          .circular(
                                                                              10),
                                                                ),
                                                                child: Padding(
                                                                  padding: EdgeInsetsDirectional
                                                                      .fromSTEB(
                                                                          5,
                                                                          5,
                                                                          5,
                                                                          5),
                                                                  child: Text(
                                                                    getJsonField(
                                                                      answerItem,
                                                                      r'''$..answer''',
                                                                    ).toString(),
                                                                    textAlign:
                                                                        TextAlign
                                                                            .end,
                                                                    style: FlutterFlowTheme.of(
                                                                            context)
                                                                        .bodyText1
                                                                        .override(
                                                                          fontFamily:
                                                                              'Poppins',
                                                                          color:
                                                                              FlutterFlowTheme.of(context).black,
                                                                        ),
                                                                  ),
                                                                ),
                                                              ),
                                                            ),
                                                        ],
                                                      );
                                                    }),
                                                  );
                                                },
                                              ),
                                            ],
                                          ),
                                        );
                                      }),
                                    ),
                                  );
                                },
                              );
                            },
                          ),
                        ),
                      ),
                      if ((FFAppState().wronganswers == 1) &&
                          responsiveVisibility(
                            context: context,
                            phone: false,
                            tablet: false,
                            tabletLandscape: false,
                            desktop: false,
                          ))
                        Padding(
                          padding:
                              EdgeInsetsDirectional.fromSTEB(10, 10, 10, 10),
                          child: Container(
                            decoration: BoxDecoration(
                              color:
                                  FlutterFlowTheme.of(context).secondaryColor,
                            ),
                            child: Padding(
                              padding:
                                  EdgeInsetsDirectional.fromSTEB(5, 5, 5, 5),
                              child: Row(
                                mainAxisSize: MainAxisSize.max,
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Text(
                                    FFLocalizations.of(context).getText(
                                      'u8vpru5u' /* Your score is */,
                                    ),
                                    style: FlutterFlowTheme.of(context)
                                        .bodyText1
                                        .override(
                                          fontFamily: 'Poppins',
                                          color: FlutterFlowTheme.of(context)
                                              .black,
                                        ),
                                  ),
                                  Text(
                                    getJsonField(
                                      (apiResultvalid?.jsonBody ?? ''),
                                      r'''$..count''',
                                    ).toString(),
                                    style: FlutterFlowTheme.of(context)
                                        .bodyText1
                                        .override(
                                          fontFamily: 'Poppins',
                                          color: FlutterFlowTheme.of(context)
                                              .black,
                                        ),
                                  ),
                                  Text(
                                    FFLocalizations.of(context).getText(
                                      'cf33blvs' /* /5 and wrong answers are */,
                                    ),
                                    style: FlutterFlowTheme.of(context)
                                        .bodyText1
                                        .override(
                                          fontFamily: 'Poppins',
                                          color: FlutterFlowTheme.of(context)
                                              .black,
                                        ),
                                  ),
                                  Text(
                                    getJsonField(
                                      (apiResultvalid?.jsonBody ?? ''),
                                      r'''$..wronganswers''',
                                    ).toString(),
                                    style: FlutterFlowTheme.of(context)
                                        .bodyText1
                                        .override(
                                          fontFamily: 'Poppins',
                                          color: FlutterFlowTheme.of(context)
                                              .black,
                                        ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                      Wrap(
                        spacing: 0,
                        runSpacing: 0,
                        alignment: WrapAlignment.start,
                        crossAxisAlignment: WrapCrossAlignment.start,
                        direction: Axis.horizontal,
                        runAlignment: WrapAlignment.start,
                        verticalDirection: VerticalDirection.down,
                        clipBehavior: Clip.none,
                        children: [
                          Padding(
                            padding:
                                EdgeInsetsDirectional.fromSTEB(20, 20, 20, 20),
                            child: FFButtonWidget(
                              onPressed: () async {
                                Navigator.pop(context);
                              },
                              text: FFLocalizations.of(context).getText(
                                'sqftj923' /* Back */,
                              ),
                              options: FFButtonOptions(
                                width: 130,
                                height: 40,
                                color:
                                    FlutterFlowTheme.of(context).customColor1,
                                textStyle: FlutterFlowTheme.of(context)
                                    .subtitle2
                                    .override(
                                      fontFamily: 'Poppins',
                                      color: FlutterFlowTheme.of(context)
                                          .tertiaryColor,
                                    ),
                                borderSide: BorderSide(
                                  color: FlutterFlowTheme.of(context)
                                      .tertiaryColor,
                                  width: 1,
                                ),
                                borderRadius: BorderRadius.circular(40),
                              ),
                            ),
                          ),
                          Padding(
                            padding:
                                EdgeInsetsDirectional.fromSTEB(20, 20, 20, 20),
                            child: FFButtonWidget(
                              onPressed: () async {
                                var _shouldSetState = false;
                                apiResultvalid = await QuizbpCall.call(
                                  refreshToken:
                                      FFAppState().sessionRefreshToken,
                                  formstep: 'Validate',
                                );
                                _shouldSetState = true;
                                if (!(apiResultvalid?.succeeded ?? true)) {
                                  await showDialog(
                                    context: context,
                                    builder: (alertDialogContext) {
                                      return AlertDialog(
                                        content: Text('Compleate the quiz'),
                                        actions: [
                                          TextButton(
                                            onPressed: () => Navigator.pop(
                                                alertDialogContext),
                                            child: Text('Ok'),
                                          ),
                                        ],
                                      );
                                    },
                                  );
                                  if (_shouldSetState) setState(() {});
                                  return;
                                }
                                apiResulti8j = await QuizbpCall.call(
                                  refreshToken:
                                      FFAppState().sessionRefreshToken,
                                  formstep: 'get1',
                                  type: dateTimeFormat(
                                      'd/M/y', getCurrentTimestamp),
                                );
                                _shouldSetState = true;
                                setState(() => FFAppState().wronganswers = 1);
                                await showDialog(
                                  context: context,
                                  builder: (alertDialogContext) {
                                    return AlertDialog(
                                      content: Text('Thank you'),
                                      actions: [
                                        TextButton(
                                          onPressed: () =>
                                              Navigator.pop(alertDialogContext),
                                          child: Text('Ok'),
                                        ),
                                      ],
                                    );
                                  },
                                );
                                await Navigator.push(
                                  context,
                                  PageTransition(
                                    type: PageTransitionType.rightToLeft,
                                    duration: Duration(milliseconds: 50),
                                    reverseDuration: Duration(milliseconds: 50),
                                    child: DashboardBusinessPartnerWidget(),
                                  ),
                                );
                                if (_shouldSetState) setState(() {});
                              },
                              text: FFLocalizations.of(context).getText(
                                'fd3e4rq7' /* Submit */,
                              ),
                              options: FFButtonOptions(
                                width: 130,
                                height: 40,
                                color:
                                    FlutterFlowTheme.of(context).tertiaryColor,
                                textStyle: FlutterFlowTheme.of(context)
                                    .subtitle2
                                    .override(
                                      fontFamily: 'Poppins',
                                      color: FlutterFlowTheme.of(context)
                                          .customColor1,
                                    ),
                                borderSide: BorderSide(
                                  color: FlutterFlowTheme.of(context)
                                      .tertiaryColor,
                                  width: 1,
                                ),
                                borderRadius: BorderRadius.circular(40),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
