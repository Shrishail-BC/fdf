import '../backend/api_requests/api_calls.dart';
import '../components/app_bar_row_logo_widget.dart';
import '../flutter_flow/flutter_flow_drop_down.dart';
import '../flutter_flow/flutter_flow_theme.dart';
import '../flutter_flow/flutter_flow_util.dart';
import '../flutter_flow/flutter_flow_widgets.dart';
import '../custom_code/widgets/index.dart' as custom_widgets;
import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:google_fonts/google_fonts.dart';

class RegisterPlayerPhotoWidget extends StatefulWidget {
  const RegisterPlayerPhotoWidget({
    Key? key,
    this.poRegType,
  }) : super(key: key);

  final String? poRegType;

  @override
  _RegisterPlayerPhotoWidgetState createState() =>
      _RegisterPlayerPhotoWidgetState();
}

class _RegisterPlayerPhotoWidgetState extends State<RegisterPlayerPhotoWidget> {
  String? dropDownLanguageValue;
  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: scaffoldKey,
      appBar: AppBar(
        backgroundColor: Color(0xFF274078),
        automaticallyImplyLeading: true,
        leading: Row(
          mainAxisSize: MainAxisSize.max,
          children: [
            Expanded(
              child: AppBarRowLogoWidget(),
            ),
          ],
        ),
        title: Row(
          mainAxisSize: MainAxisSize.max,
          mainAxisAlignment: MainAxisAlignment.end,
          children: [
            Padding(
              padding: EdgeInsetsDirectional.fromSTEB(5, 5, 0, 5),
              child: FlutterFlowDropDown(
                initialOption: dropDownLanguageValue ??=
                    FFLocalizations.of(context).getText(
                  'qmhqboqg' /* en_US */,
                ),
                options: [
                  FFLocalizations.of(context).getText(
                    'g7fkuh41' /* en_US */,
                  ),
                  FFLocalizations.of(context).getText(
                    'fwpn969h' /* fr_FR */,
                  ),
                  FFLocalizations.of(context).getText(
                    'ramq5q80' /* es_ES */,
                  )
                ],
                onChanged: (val) => setState(() => dropDownLanguageValue = val),
                width: 80,
                height: 40,
                textStyle: FlutterFlowTheme.of(context).bodyText1.override(
                      fontFamily: 'Poppins',
                      color: Colors.black,
                      fontSize: 12,
                    ),
                fillColor: Colors.white,
                elevation: 2,
                borderColor: Colors.transparent,
                borderWidth: 0,
                borderRadius: 4,
                margin: EdgeInsetsDirectional.fromSTEB(6, 4, 2, 4),
                hidesUnderline: true,
              ),
            ),
            Padding(
              padding: EdgeInsetsDirectional.fromSTEB(5, 5, 0, 5),
              child: FFButtonWidget(
                onPressed: () async {
                  await launchURL('https://shop.playon.ca');
                },
                text: FFLocalizations.of(context).getText(
                  '8m83okz6' /* Login */,
                ),
                icon: Icon(
                  Icons.login,
                  color: Color(0xFFFFC107),
                  size: 15,
                ),
                options: FFButtonOptions(
                  width: 90,
                  height: 40,
                  color: FlutterFlowTheme.of(context).primaryColor,
                  textStyle: FlutterFlowTheme.of(context).subtitle2.override(
                        fontFamily: 'Poppins',
                        color: Colors.white,
                        fontSize: 14,
                      ),
                  borderSide: BorderSide(
                    color: Colors.transparent,
                    width: 1,
                  ),
                  borderRadius: BorderRadius.circular(4),
                ),
              ),
            ),
          ],
        ),
        actions: [
          Row(
            mainAxisSize: MainAxisSize.max,
            children: [
              Padding(
                padding: EdgeInsetsDirectional.fromSTEB(5, 5, 0, 5),
                child: custom_widgets.OrientationBasedButton(
                  width: 100,
                  height: 48,
                  buttonText: 'Store',
                  icon: Icon(
                    Icons.shopping_cart_outlined,
                    color: Color(0xFFFFC107),
                    size: 22,
                  ),
                  textSize: 14.0,
                  url: 'https://shop.playon.ca',
                  buttonColor: Colors.transparent,
                  buttonTextColor: FlutterFlowTheme.of(context).tertiaryColor,
                  hideInMobile: true,
                  borderColor: Colors.transparent,
                  borderRadius: 4.0,
                  borderWidth: 0.0,
                  elevation: 4.0,
                  textFont: 'Roboto',
                  fontWeight: 0,
                ),
              ),
            ],
          ),
        ],
        centerTitle: true,
        elevation: 12,
      ),
      backgroundColor: Color(0xFF274078),
      body: SafeArea(
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.max,
            children: [
              Align(
                alignment: AlignmentDirectional(0, 0),
                child: Padding(
                  padding: EdgeInsetsDirectional.fromSTEB(20, 0, 20, 0),
                  child: FutureBuilder<ApiCallResponse>(
                    future: GetEventsMetaDataCall.call(),
                    builder: (context, snapshot) {
                      // Customize what your widget looks like when it's loading.
                      if (!snapshot.hasData) {
                        return Center(
                          child: SizedBox(
                            width: 50,
                            height: 50,
                            child: SpinKitHourGlass(
                              color: Color(0xFFFFC107),
                              size: 50,
                            ),
                          ),
                        );
                      }
                      final columnMainContentGetEventsMetaDataResponse =
                          snapshot.data!;
                      return SingleChildScrollView(
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Padding(
                              padding:
                                  EdgeInsetsDirectional.fromSTEB(0, 40, 0, 0),
                              child: custom_widgets.ImagePickerWidget(
                                width: 400,
                                height: 300,
                                textColor: Colors.black,
                                buttonBackground: Colors.white,
                                galleryText: 'Gallery',
                                cameraText: 'Camera',
                                clearText: 'Clear',
                                saveText: 'Save',
                              ),
                            ),
                          ],
                        ),
                      );
                    },
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
