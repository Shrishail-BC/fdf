import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:timeago/timeago.dart' as timeago;
import 'lat_lng.dart';
import 'place.dart';

String getTranslation(
  String objectName,
  dynamic poLanguage,
  String currentLanguage,
) {
  // Add your function code here!
  try {
    String key = "na";
    String langValue = "na";
    final Map vmLangMap = Map();
    final List languageList = List.filled(1, 0);

    if (currentLanguage.isEmpty) {
      currentLanguage = "en_US";
    }
    if (objectName.isEmpty) {
      objectName = "Blank";
      return "Blank";
    }

    int id;
    int counter = 0;
    // List listLangValues;
    if (vmLangMap.isEmpty) {
      poLanguage[0].forEach((k, v) {
        if (counter > 3) {
          languageList.add(k.toString().toLowerCase());
        }
        counter++;
        //print('{ key: $k, value: $v }');
      });

      for (var langElement in poLanguage) {
        List listLangValues = new List.filled(1, 0);
//    for (var subElement in langElement) {
        id = langElement["Id"];
        key = langElement["Key"].toString().toLowerCase();
        //     langValue = langElement[currentLanguage];
        counter = 0;
        langElement.forEach((k, v) {
          if (counter > 3) {
            listLangValues.add(v);
          }
          counter++;
          //print('{ key: $k, value: $v }');
        });

        if (listLangValues.isNotEmpty && key.isNotEmpty) {
          vmLangMap[key] = listLangValues;
        }

        //vmLangMap.putIfAbsent(key, () => listLangValues);
        //vmLangMap.putIfAbsent(key, () => listLangValues);
//   }
      }
    }

    List langList = vmLangMap[objectName.toLowerCase()];
    if (langList.isEmpty) {
      return "Blank";
    }

    langValue = langList[languageList.indexOf(currentLanguage.toLowerCase())];

    if (langValue.isEmpty) {
      return "Blank";
    }

    return langValue;
  } catch (e) {
    return "Error";
  }
}

String loadLanguage(
  dynamic poLanguage,
  List<String> localLanguageStore,
  List<String> localLanguageListStore,
) {
  // Add your function code here!
  if (localLanguageStore.isNotEmpty) {
    return "Already Loaded";
  }
  Map vmLangMap;
  vmLangMap = localLanguageStore.asMap();

  String key = "na";
  String langValue = "na";
  String currentLanguage = "en_US";

  List languageList;
  List listLanguageValues;
  int id;
  int counter = 0;
  List listLangValues;

  vmLangMap = new Map();

  languageList = new List.filled(1, 0);
  poLanguage[0].forEach((k, v) {
    if (counter > 1) {
      languageList.add(k);
    }
    counter++;
    //print('{ key: $k, value: $v }');
  });

  for (var langElement in poLanguage) {
    listLangValues = new List.filled(1, 0);
//    for (var subElement in langElement) {
    id = langElement["Id"];
    key = langElement["Key"];
    langValue = langElement[currentLanguage];
    counter = 0;
    langElement.forEach((k, v) {
      if (counter > 1) {
        listLangValues.add(v);
      }
      counter++;
      //print('{ key: $k, value: $v }');
    });
    if (listLangValues.isNotEmpty && key.isNotEmpty) {
      vmLangMap[key] = listLangValues;
    }
    //vmLangMap.putIfAbsent(key, () => listLangValues);
    //vmLangMap.putIfAbsent(key, () => listLangValues);
//   }
  }
  // langValue = vmLangMap[key].languageList.indexOf(currentLanguage);
  //return localLanguage;
  localLanguageListStore[0] = languageList.toString();
  localLanguageStore[0] = vmLangMap.toString();

  return "none";
}

bool returnFalse() {
  // Add your function code here!
  return false;
}

bool returnTrue() {
  // Add your function code here!
  return true;
}

bool isMobile() {
  // Add your function code here!
  return true;

  // return 0 if mobile
  // return 1 if desktop
}

bool isDesktop() {
  // Add your function code here!
  return false;

  // return 0 if mobile
  // return 1 if desktop
}

String saveLoadLanguageToStorage(
  dynamic poLanguage,
  String localLanguageStoreString,
  String localLanguageStoreStringVer,
  String poLanguageVer,
) {
  String returnVar = " ";
  if (localLanguageStoreString.isNotEmpty &&
      localLanguageStoreString == poLanguageVer) {
    final returnVar = "no change";
  } else if (localLanguageStoreString.isEmpty) {
    localLanguageStoreString = poLanguage.toString();
    localLanguageStoreStringVer = poLanguageVer.toString();
  }
  return returnVar;
}

String? returnBooleanToString(bool inputBool) {
  // Add your function code here!
  return "> " + inputBool.toString();
}

String? returnString(String input) {
  // Add your function code here!
  if (input.isEmpty || input == "null") {
    return " ";
  }
  return input;
}

bool toogleValue(bool value) {
  return value ? false : true;
}

dynamic normaliseJSON(dynamic dataJSON) {
  // Add your function code here!

  List x = new List.filled(1, 0);
  for (var element in dataJSON) {
    Map map = new Map();
    map = element["json"];
    x.add(map);
//    print('*** element:' + map.toString());
  }
  ;
  return x;
}

String? jsonToString(dynamic dataJSON) {
  // Add your function code here!
//  print(normaliseJSON(dataJson).toString());
  return normaliseJSON(dataJSON).toString();
}

String? videoToString(String? videoURL) {
  // Add your function code here!
  return videoToString.toString();
}

int getAttributeInt(
  String key,
  List<String> keyList,
  List<int> valueList,
) {
  // Add your function code here!
  return (valueList[keyList.indexOf(key)]);
}

List<String>? getCountries() {
  // Add your function code here!
  List<String> countries = [
    "Canada",
    "USA",
    "Afghanistan",
    "Albania",
    "Algeria",
    "Andorra",
    "Angola",
    "Antigua And Barbuda",
    "Argentina",
    "Armenia",
    "Australia",
    "Austria",
    "Azerbaijan",
    "Bahamas The",
    "Bahrain",
    "Bangladesh",
    "Barbados",
    "Belarus",
    "Belgium",
    "Belize",
    "Benin",
    "Bhutan",
    "Bolivia",
    "Bosnia and Herzegovina",
    "Botswana",
    "Brazil",
    "Brunei",
    "Bulgaria",
    "Burkina Faso",
    "Burundi",
    "Cambodia",
    "Cameroon",
    "Cape Verde",
    "Central African Republic",
    "Chad",
    "Chile",
    "China",
    "Colombia",
    "Comoros",
    "Congo",
    "Costa Rica",
    "Cote D'Ivoire (Ivory Coast)",
    "Croatia",
    "Cuba",
    "Cyprus",
    "Czech Republic",
    "Democratic Republic of the Congo",
    "Denmark",
    "Djibouti",
    "Dominica",
    "Dominican Republic",
    "East Timor",
    "Ecuador",
    "Egypt",
    "El Salvador",
    "Equatorial Guinea",
    "Eritrea",
    "Estonia",
    "Ethiopia",
    "Fiji Islands",
    "Finland",
    "France",
    "Gabon",
    "Gambia The",
    "Georgia",
    "Germany",
    "Ghana",
    "Greece",
    "Grenada",
    "Guatemala",
    "Guinea",
    "Guinea-Bissau",
    "Guyana",
    "Haiti",
    "Honduras",
    "Hungary",
    "Iceland",
    "India",
    "Indonesia",
    "Iran",
    "Iraq",
    "Ireland",
    "Israel",
    "Italy",
    "Jamaica",
    "Japan",
    "Jordan",
    "Kazakhstan",
    "Kenya",
    "Kiribati",
    "Kuwait",
    "Kyrgyzstan",
    "Laos",
    "Latvia",
    "Lebanon",
    "Lesotho",
    "Liberia",
    "Libya",
    "Liechtenstein",
    "Lithuania",
    "Luxembourg",
    "Macedonia",
    "Madagascar",
    "Malawi",
    "Malaysia",
    "Maldives",
    "Mali",
    "Malta",
    "Mauritania",
    "Mauritius",
    "Mexico",
    "Micronesia",
    "Moldova",
    "Mongolia",
    "Montenegro",
    "Morocco",
    "Mozambique",
    "Myanmar",
    "Namibia",
    "Nauru",
    "Nepal",
    "Netherlands",
    "New Zealand",
    "Nicaragua",
    "Niger",
    "Nigeria",
    "North Korea",
    "Norway",
    "Oman",
    "Pakistan",
    "Palau",
    "Panama",
    "Papua new Guinea",
    "Paraguay",
    "Peru",
    "Philippines",
    "Poland",
    "Portugal",
    "Qatar",
    "Romania",
    "Russia",
    "Rwanda",
    "Saint Kitts And Nevis",
    "Saint Lucia",
    "Saint Vincent And The Grenadines",
    "Samoa",
    "San Marino",
    "Sao Tome and Principe",
    "Saudi Arabia",
    "Senegal",
    "Serbia",
    "Seychelles",
    "Sierra Leone",
    "Singapore",
    "Slovakia",
    "Slovenia",
    "Solomon Islands",
    "Somalia",
    "South Africa",
    "South Korea",
    "South Sudan",
    "Spain",
    "Sri Lanka",
    "Sudan",
    "Suriname",
    "Swaziland",
    "Sweden",
    "Switzerland",
    "Syria",
    "Taiwan",
    "Tajikistan",
    "Tanzania",
    "Thailand",
    "Togo",
    "Tonga",
    "Trinidad And Tobago",
    "Tunisia",
    "Turkey",
    "Turkmenistan",
    "Tuvalu",
    "Uganda",
    "Ukraine",
    "United Arab Emirates",
    "United Kingdom",
    "Uruguay",
    "Uzbekistan",
    "Vanuatu",
    "Venezuela",
    "Vietnam",
    "Yemen",
    "Zambia",
    "Zimbabwe"
  ];
  return countries;
}

List<String>? getStates(
  String country,
  dynamic countryStateList,
) {
  List<String> states = [];
  for (var langElement in countryStateList) {
    if (langElement["country"].toString() == country) {
      states = List<String>.from(langElement["states"] as List);
      break;
    }
  }
  ;
  return states;
}

dynamic getSetting(String? parameter) {
  // Add your function code here!
  return "#330033";
}

List<String>? getYears() {
  // Add your function code here!
  List<String> years = [];
  var dateParse = DateTime.parse(DateTime.now().toString());
  var startYear = dateParse.year - 83;
  for (var i = startYear; i <= startYear + 80; i++) {
    years.add(i.toString());
  }
  return years;
}

String? getConcatenateDate(
  String? day,
  String? month,
  String? year,
) {
  // Add your function code here!
  var montharr = [
    "January",
    "February",
    "March",
    "April",
    "May",
    "June",
    "July",
    "August",
    "September",
    "October",
    "November",
    "December"
  ];
  int monthNum = 0;
  for (int i = 0; i < montharr.length; i++) {
    if (montharr[i] == month) {
      monthNum = i + 1;
      break;
    }
  }
  return '$year-$monthNum-$day';
}

bool compareStrings(
  String string1,
  String string2,
) {
  return string1.toLowerCase() == string2.toLowerCase() ? true : false;
  // Add your function code here!
}

int getAgeCustomFn(
  String year,
  String month,
  String day,
) {
  // Add your function code here!
  final Map<String, String> monthVal = {
    'January': '01',
    'February': '02',
    'March': '03',
    'April': '04',
    'May': '05',
    'June': '06',
    'July': '07',
    'August': '08',
    'September': '09',
    'October': '10',
    'November': '11',
    'December': '12'
  };
  String startDay = year;
  var dateNow = new DateTime.now();
  var givenDate = year + '-' + month + '-' + day;
  var givenDateFormat = DateTime.parse(givenDate);
  var diff = dateNow.difference(givenDateFormat);
  var value = ((diff.inDays) / 365).round();
  print(givenDate);
  print('year');
  print(year);
  print('month');
  print(month);
  print('day');
  print(day);
  print('returnubgAgeValue');
  print(value);
  return value;
}

bool isEmail(String email) {
  // Add your function code here!

  bool emailValid = RegExp(
          r"^[a-zA-Z0-9.a-zA-Z0-9.!#$%&'*+-/=?^_`{|}~]+@[a-zA-Z0-9]+\.[a-zA-Z]+")
      .hasMatch(email);

  return emailValid;
}

bool validatePassword(String data) {
  // Add your function code here!
  RegExp regex = RegExp(r'^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9]).{8,}$');
//        RegExp(r'^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[!@#\$&*~]).{8,}$');
  if (data.isEmpty) {
    return false;
  } else {
    if (!regex.hasMatch(data)) {
      return false;
    } else {
      return true;
    }
  }
}

String notreturnnull(String value) {
  if (value == 'null') {
    return ('');
  } else {
    return value;
  }
}

String loginLogoutBottonText(String refreshToken) {
  // Add your function code here!
  if (refreshToken.isEmpty) {
    return "Sign in";
  } else {
    return "Sign out";
  }
}

bool comparetwovalues(
  String value1,
  List<String> value2,
) {
  if (value2.contains(value1)) {
    return true;
  } else {
    return false;
  }
  // Add your function code here!
}

bool count(String? value1) {
  if (value1 == "1") {
    return true;
  } else {
    return false;
  }
}

String count1(String? value1) {
  if (value1 == "1") {
    return "1";
  } else if (value1 == "0") {
    return "0";
  } else {
    return "2";
  }
}

int jsonLength(dynamic data) {
  return data.length;
}

String jsonString(String text) {
  // Add your function code here!
  return text.replaceAll('\n', '\\n').replaceAll('"', '\\"');
}

String stringswitct(
  String value1,
  String value2,
) {
  if (value1 == '1') {
    return value2;
  } else {
    return value1;
  }
}

bool visibilityforimagewidget(String? value1) {
  if (value1 != '') {
    return true;
  } else {
    return false;
  }
}

int stringtoint(String value1) {
  final stringtoint = int.parse(value1);
  return stringtoint;
}

List<int> date() {
  // Add your function code here!
  List<int> date = [
    1,
    2,
    3,
    4,
    5,
    6,
    7,
    8,
    9,
    10,
    11,
    12,
    13,
    14,
    15,
    16,
    17,
    18,
    19,
    20,
    21,
    22,
    23,
    24,
    25,
    26,
    27,
    28,
    29,
    30,
    31
  ];
  return date;
}

List<int> months() {
  List<int> months = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12];
  return months;
}

List<int> time() {
  List<int> time = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12];
  return time;
}

bool arraycontains(
  List<String> value1,
  String value2,
) {
  for (String element in value1) {
    if (element == value2) {
      return true;
    }
  }
  return false;
}

String joinstring(List<String> value1) {
  List<String> servicesList = value1;
  return servicesList.join(",");
}

List<String> splitarray(String value1) {
  return value1.split(',');
}

DateTime stringintotimestamp(String value1) {
  return DateTime.parse(value1);
}

String arrayvalue(
  String value1,
  int value2,
) {
  List<String> array = value1.split(',');
  return array[value2];
}
