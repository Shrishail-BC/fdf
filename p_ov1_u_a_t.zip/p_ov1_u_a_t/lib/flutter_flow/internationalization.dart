import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart';

class FFLocalizations {
  FFLocalizations(this.locale);

  final Locale locale;

  static FFLocalizations of(BuildContext context) =>
      Localizations.of<FFLocalizations>(context, FFLocalizations)!;

  static List<String> languages() => ['en', 'fr', 'es'];

  String get languageCode => locale.toString();
  int get languageIndex => languages().contains(languageCode)
      ? languages().indexOf(languageCode)
      : 0;

  String getText(String key) =>
      (kTranslationsMap[key] ?? {})[locale.toString()] ?? '';

  String getVariableText({
    String? enText = '',
    String? frText = '',
    String? esText = '',
  }) =>
      [enText, frText, esText][languageIndex] ?? '';
}

class FFLocalizationsDelegate extends LocalizationsDelegate<FFLocalizations> {
  const FFLocalizationsDelegate();

  @override
  bool isSupported(Locale locale) =>
      FFLocalizations.languages().contains(locale.toString());

  @override
  Future<FFLocalizations> load(Locale locale) =>
      SynchronousFuture<FFLocalizations>(FFLocalizations(locale));

  @override
  bool shouldReload(FFLocalizationsDelegate old) => false;
}

Locale createLocale(String language) => language.contains('_')
    ? Locale.fromSubtags(
        languageCode: language.split('_').first,
        scriptCode: language.split('_').last,
      )
    : Locale(language);

final kTranslationsMap = <Map<String, Map<String, String>>>[
  // User_LoginRegister
  {
    'tb3z9nvb': {
      'en': 'Welcome to Play On!',
      'es': '¡Bienvenido a Jugar!',
      'fr': 'Bienvenue sur Jouez !',
    },
    '6ce52h7r': {
      'en':
          'Experience the world\'s largest Street Tournament and Sports Festival',
      'es':
          'Experimente el torneo callejero y festival deportivo más grande del mundo',
      'fr':
          'Découvrez le plus grand tournoi de rue et festival sportif au monde',
    },
    '78id3gxb': {
      'en': 'Login',
      'es': 'Acceso',
      'fr': 'Connexion',
    },
    'ap1a297k': {
      'en': 'Login Email Id',
      'es': 'ID de correo electrónico de inicio de sesión',
      'fr': 'Identifiant de connexion',
    },
    'yjzq9zx5': {
      'en': 'Your email id',
      'es': 'su identificación de correo electrónico',
      'fr': 'Votre identifiant de messagerie',
    },
    'um7h86fc': {
      'en': 'Password',
      'es': 'Clave',
      'fr': 'Mot de passe',
    },
    'ezvtiacy': {
      'en': 'Password',
      'es': 'Clave',
      'fr': 'Mot de passe',
    },
    'rwnpjpyx': {
      'en': 'Login',
      'es': 'Acceso',
      'fr': 'Connexion',
    },
    '0lskhttp': {
      'en': 'Login to your existing Play On! account',
      'es': '¡Inicie sesión en su Play On! cuenta',
      'fr': 'Connectez-vous à votre compte Play On ! Compte',
    },
    'q4a88gy2': {
      'en': 'Forgot Password',
      'es': 'Has olvidado tu contraseña',
      'fr': 'Mot de passe oublié',
    },
    'nhgw74hk': {
      'en': 'Test Login',
      'es': 'Inicio de sesión de prueba',
      'fr': 'Connexion d\'essai',
    },
    'tjhptuwm': {
      'en': 'Mandatory Field',
      'es': 'Campo obligatorio',
      'fr': 'Champ obligatoire',
    },
    'wwjv5o57': {
      'en': 'Field is required',
      'es': 'Se requiere campo',
      'fr': 'Champ requis',
    },
    'v7zwtdt1': {
      'en': 'Field is required',
      'es': 'Se requiere campo',
      'fr': 'Champ requis',
    },
    'v8mg0637': {
      'en': 'Field is required',
      'es': 'Se requiere campo',
      'fr': 'Champ requis',
    },
    'hxu5f62e': {
      'en': 'Register',
      'es': 'Registro',
      'fr': 'S\'inscrire',
    },
    'mz4qnkgy': {
      'en': 'Email',
      'es': 'Correo electrónico',
      'fr': 'E-mail',
    },
    'd8tu8kwd': {
      'en': 'Your email id',
      'es': 'su identificación de correo electrónico',
      'fr': 'Votre identifiant de messagerie',
    },
    '1clyikc9': {
      'en': 'Password',
      'es': 'Clave',
      'fr': 'Mot de passe',
    },
    'mrdha1bs': {
      'en': 'Password',
      'es': 'Clave',
      'fr': 'Mot de passe',
    },
    'i5widend': {
      'en': 'Confirm Password',
      'es': 'Confirmar contraseña',
      'fr': 'Confirmez le mot de passe',
    },
    'mfxeeukv': {
      'en': 'Confirm Password',
      'es': 'Confirmar contraseña',
      'fr': 'Confirmez le mot de passe',
    },
    'sp9lq0e0': {
      'en': 'Register',
      'es': 'Registro',
      'fr': 'S\'inscrire',
    },
    'i7y9nz08': {
      'en': 'Register for a new Play On! account',
      'es': 'Regístrese para un nuevo Play On! cuenta',
      'fr': 'Inscrivez-vous pour un nouveau Play On! Compte',
    },
    'lu8ick85': {
      'en': 'Enter a valid Email address',
      'es': 'Introduzca una dirección de correo electrónico válida',
      'fr': 'Entrez une adresse mail valide',
    },
    'ytb9ujxz': {
      'en':
          'Minimum: 8 characters, 1 Upper case, 1 number or special character',
      'es': 'Mínimo: 8 caracteres, 1 mayúscula, 1 número o carácter especial',
      'fr':
          'Minimum : 8 caractères, 1 majuscule, 1 chiffre ou caractère spécial',
    },
    '70uogio2': {
      'en': 'Confirm Pasword',
      'es': 'Confirmar contraseña',
      'fr': 'Confirmer pasword',
    },
    'neq9pg31': {
      'en': 'You can register for different roles, click on them to learn more',
      'es':
          'Puede registrarse para diferentes roles, haga clic en ellos para obtener más información.',
      'fr':
          'Vous pouvez vous inscrire à différents rôles, cliquez dessus pour en savoir plus',
    },
    'mz4a1zgw': {
      'en': 'Fan',
      'es': 'Admirador',
      'fr': 'Ventilateur',
    },
    'xgu0w7ao': {
      'en': 'Player\n',
      'es': 'Jugador',
      'fr': 'Joueur',
    },
    'v936njii': {
      'en': 'Volunteer',
      'es': 'Voluntario',
      'fr': 'Bénévole',
    },
    'ufa8hspv': {
      'en': 'Referee',
      'es': 'Árbitro',
      'fr': 'Arbitre',
    },
    'cl3b31f7': {
      'en': 'Charity',
      'es': 'Caridad',
      'fr': 'Charité',
    },
    'ci26w2vj': {
      'en': 'Host Muncipality',
      'es': 'Municipio anfitrión',
      'fr': 'Municipalité hôte',
    },
    'vt7wsdeb': {
      'en': 'Business Partner',
      'es': 'Socio de negocios',
      'fr': 'Associé',
    },
    'eglsq5hu': {
      'en': 'Vendor',
      'es': 'Vendedor',
      'fr': 'Vendeur',
    },
    '6da0capr': {
      'en': 'Home',
      'es': 'Hogar',
      'fr': 'Maison',
    },
  },
  // Router
  {
    'zemjutf7': {
      'en': 'GETTING STARTED',
      'es': '',
      'fr': '',
    },
    'zxlx5bjy': {
      'en': 'Home',
      'es': '',
      'fr': '',
    },
  },
  // Register_RoleSelect
  {
    'us0825w7': {
      'en': 'Volunteer',
      'es': 'Voluntario',
      'fr': 'Bénévole',
    },
    'wp7rwqso': {
      'en': 'Referee',
      'es': 'Árbitro',
      'fr': 'Arbitre',
    },
    'v21hqvtt': {
      'en': 'Player\n',
      'es': 'Jugador',
      'fr': 'Joueur',
    },
    '8lipcebv': {
      'en': 'Fan',
      'es': 'Admirador',
      'fr': 'Ventilateur',
    },
    '6a2gz8ok': {
      'en': 'Charity',
      'es': 'Caridad',
      'fr': 'Charité',
    },
    '39gayaay': {
      'en': 'Host Muncipality',
      'es': 'Municipio anfitrión',
      'fr': 'Municipalité hôte',
    },
    'rvllwshs': {
      'en': 'Business Partner',
      'es': 'Socio de negocios',
      'fr': 'Associé',
    },
    'lnmvn35w': {
      'en': 'Vendor',
      'es': 'Vendedor',
      'fr': 'Vendeur',
    },
    'rle15ine': {
      'en': 'TestPage',
      'es': 'Página de prueba',
      'fr': 'Page de test',
    },
    'pyp6s99o': {
      'en': 'Admin',
      'es': 'Administración',
      'fr': 'Administrateur',
    },
    'wu148olp': {
      'en': 'Login',
      'es': 'Acceso',
      'fr': 'Connexion',
    },
    'h4i4j3qr': {
      'en': 'Menu',
      'es': 'Menú',
      'fr': 'Menu',
    },
    'ckyqz4hx': {
      'en': 'PlayOn! Store',
      'es': '¡Juega! Tienda',
      'fr': 'Jouer sur! Magasin',
    },
    'vt1xt49n': {
      'en': 'Go to the PlayOn! Store',
      'es': '¡Ve al PlayOn! Tienda',
      'fr': 'Rendez-vous sur PlayOn! Magasin',
    },
    '6ay0c4zy': {
      'en': 'Register',
      'es': 'Registro',
      'fr': 'S\'inscrire',
    },
  },
  // Player_RoleSelect
  {
    'n04pm7w8': {
      'en': 'Login',
      'es': 'Acceso',
      'fr': 'Connexion',
    },
    'oribg2vu': {
      'en': 'Menu',
      'es': 'Menú',
      'fr': 'Menu',
    },
    'tw0bmy9d': {
      'en': 'PlayOn! Store',
      'es': '¡Juega! Tienda',
      'fr': 'Jouer sur! Boutique',
    },
    '89f5sikf': {
      'en': 'Go to the PlayOn! Store',
      'es': '¡Ve al PlayOn! Tienda',
      'fr': 'Rendez-vous sur PlayOn! Boutique',
    },
    'c1mnk8zl': {
      'en': 'Team Captain',
      'es': '',
      'fr': '',
    },
    'pux6e7jx': {
      'en':
          'A team captain organizes the team and invites other players to join.',
      'es': '',
      'fr': '',
    },
    'cxhcou9a': {
      'en': 'Team Player',
      'es': '',
      'fr': '',
    },
    'qqwitxwf': {
      'en': 'A team player joins a team organized by a team captain. ',
      'es': '',
      'fr': '',
    },
    'td9r7ash': {
      'en': 'Free Agent',
      'es': '',
      'fr': '',
    },
    'lyiett25': {
      'en': 'Available to be picked up by an existing team. ',
      'es': '',
      'fr': '',
    },
    'tsi8tjol': {
      'en': 'Family Account',
      'es': '',
      'fr': '',
    },
    '3tldxu4n': {
      'en':
          'Parents who manage a child\'s account. Can register multiple children in one family.',
      'es': '',
      'fr': '',
    },
    'nvq75itd': {
      'en': 'Register',
      'es': '',
      'fr': '',
    },
  },
  // Blank_TemplatePage
  {
    'gxy3uriq': {
      'en': 'Canada',
      'es': '',
      'fr': '',
    },
    'd29un5qv': {
      'en': 'Option 1',
      'es': '',
      'fr': '',
    },
    '9fb73g70': {
      'en': 'Please select...',
      'es': '',
      'fr': '',
    },
    '428335e5': {
      'en': 'Please select...',
      'es': '',
      'fr': '',
    },
    'p0uhnokt': {
      'en': 'Please select...',
      'es': '',
      'fr': '',
    },
    'ix9uq7em': {
      'en': 'Button',
      'es': '',
      'fr': '',
    },
    'h5iaxqps': {
      'en': 'Hello World',
      'es': '',
      'fr': '',
    },
    'a2vghr09': {
      'en': 'Home',
      'es': '',
      'fr': '',
    },
  },
  // User_Register
  {
    'hyuh99qi': {
      'en': 'You are almost there!',
      'es': '¡Ya casi has llegado!',
      'fr': 'Tu es presque là!',
    },
    'i6d6fifx': {
      'en':
          'Experience the world\'s largest Street Tournament and Sports Festival',
      'es':
          'Experimente el torneo callejero y festival deportivo más grande del mundo',
      'fr':
          'Découvrez le plus grand tournoi de rue et festival sportif au monde',
    },
    'u1ox94vi': {
      'en': 'Create Your Play On! Account',
      'es': 'Crea tu Play On! Cuenta',
      'fr': 'Créez votre Play On ! Compte',
    },
    'yjlwizq5': {
      'en': 'Email Id',
      'es': 'Acceso',
      'fr': 'Connexion',
    },
    'lrqm59xj': {
      'en': 'Enter your email address',
      'es': 'Ingrese su identificación de correo electrónico',
      'fr': 'Entrez votre identifiant de messagerie',
    },
    'sym2mcs9': {
      'en': 'Password',
      'es': 'Contraseña',
      'fr': 'Mot de passe',
    },
    '90q6439l': {
      'en': 'Min 1 Upper case, 1 lower case, 1 number',
      'es': 'Contraseña',
      'fr': 'Mot de passe',
    },
    'p082ilv5': {
      'en': 'Create account',
      'es': 'Registrarse',
      'fr': 'S&#39;inscrire',
    },
    'fa1ncm5m': {
      'en': 'Test Login',
      'es': 'Registrarse',
      'fr': 'S&#39;inscrire',
    },
    'rr6tn3iw': {
      'en': 'Field is required',
      'es': '',
      'fr': '',
    },
    'g30n0jlt': {
      'en': 'Minimum Length of 7 Characters',
      'es': '',
      'fr': '',
    },
    'mdgouf7q': {
      'en': 'Field is required',
      'es': '',
      'fr': '',
    },
    'laei86xx': {
      'en': 'Minimum Length of 8 Characters',
      'es': '',
      'fr': '',
    },
    '08lbt83x': {
      'en': 'Home',
      'es': '',
      'fr': '',
    },
  },
  // Register_PlayerPhoto
  {
    'qmhqboqg': {
      'en': 'en_US',
      'es': '',
      'fr': '',
    },
    'g7fkuh41': {
      'en': 'en_US',
      'es': '',
      'fr': '',
    },
    'fwpn969h': {
      'en': 'fr_FR',
      'es': '',
      'fr': '',
    },
    'ramq5q80': {
      'en': 'es_ES',
      'es': '',
      'fr': '',
    },
    '8m83okz6': {
      'en': 'Login',
      'es': '',
      'fr': '',
    },
    'eb01z4ev': {
      'en': 'Settings',
      'es': '',
      'fr': '',
    },
  },
  // Register_Captain_01
  {
    'qv2q2y2g': {
      'en': 'Menu',
      'es': 'Menú',
      'fr': 'Menu',
    },
    '5b2wlyhv': {
      'en': 'PlayOn! Store',
      'es': '¡Juega! Tienda',
      'fr': 'Jouer sur! Boutique',
    },
    'sybxlnl4': {
      'en': 'Go to the PlayOn! Store',
      'es': '¡Ve al PlayOn! Tienda',
      'fr': 'Rendez-vous sur PlayOn! Boutique',
    },
    '2aes9bqr': {
      'en': 'You are the Team Captain',
      'es': '',
      'fr': '',
    },
    'ocob710m': {
      'en': '1',
      'es': '',
      'fr': '',
    },
    'dfq33utl': {
      'en': '1',
      'es': '',
      'fr': '',
    },
    'uhqnfgec': {
      'en': 'Team Details',
      'es': '',
      'fr': '',
    },
    'xv5kbydp': {
      'en': '2',
      'es': '',
      'fr': '',
    },
    '16hlxav9': {
      'en': 'Your Details',
      'es': '',
      'fr': '',
    },
    'm2xht5g3': {
      'en': '3',
      'es': '',
      'fr': '',
    },
    'z1ayzcb1': {
      'en': 'Birthdate',
      'es': '',
      'fr': '',
    },
    'tjmmpzy1': {
      'en': '4',
      'es': '',
      'fr': '',
    },
    '0awawplx': {
      'en': 'Experience',
      'es': '',
      'fr': '',
    },
    'jqv2eie9': {
      'en': '5',
      'es': '',
      'fr': '',
    },
    't3resoc7': {
      'en': 'Players',
      'es': '',
      'fr': '',
    },
    'estvxg7g': {
      'en': '6',
      'es': '',
      'fr': '',
    },
    '79nqjpv5': {
      'en': 'Waiver',
      'es': '',
      'fr': '',
    },
    'ltg1jeme': {
      'en': '7',
      'es': '',
      'fr': '',
    },
    'c1bdelnc': {
      'en': 'Payment',
      'es': '',
      'fr': '',
    },
    'l7plrg0l': {
      'en': '8',
      'es': '',
      'fr': '',
    },
    'jmm1nqyh': {
      'en': 'Charity',
      'es': '',
      'fr': '',
    },
    'vtdstdoa': {
      'en': 'Team name',
      'es': '',
      'fr': '',
    },
    'ie24n3i9': {
      'en': 'Helpful hint:',
      'es': '',
      'fr': '',
    },
    'o8sn0n64': {
      'en':
          'Choose wisely! Inappropriate team names will be changed automatically.',
      'es': '',
      'fr': '',
    },
    'jnxqx5bd': {
      'en':
          'The first part of the name can be one word or two (i.e. an example of a city name with two words might be \"North Bay\")',
      'es': '',
      'fr': '',
    },
    'd4oacf77': {
      'en':
          'The second part of the team name can be one word or two (i.e. \"Maple Leafs\".)',
      'es': '',
      'fr': '',
    },
    'wkew14l2': {
      'en': 'Sudbury',
      'es': '',
      'fr': '',
    },
    'rldtv0br': {
      'en': 'Kingston',
      'es': '',
      'fr': '',
    },
    '3sh5i6ma': {
      'en': 'Ottawa',
      'es': '',
      'fr': '',
    },
    'ro4ciplm': {
      'en': 'Halifax',
      'es': '',
      'fr': '',
    },
    '5gvg1rpz': {
      'en': 'Newfoundland',
      'es': '',
      'fr': '',
    },
    'll7xl2n8': {
      'en': 'Prince Edward Island',
      'es': '',
      'fr': '',
    },
    'mg9224h8': {
      'en': 'New Brunswick',
      'es': '',
      'fr': '',
    },
    'h4054s8g': {
      'en': 'Montreal Area',
      'es': '',
      'fr': '',
    },
    'ellqeyym': {
      'en': 'London',
      'es': '',
      'fr': '',
    },
    'y4m7523s': {
      'en': 'Windsor',
      'es': '',
      'fr': '',
    },
    'l15o3q44': {
      'en': 'Barrie',
      'es': '',
      'fr': '',
    },
    'rb917pti': {
      'en': 'Hamilton',
      'es': '',
      'fr': '',
    },
    'qmulo6qm': {
      'en': 'Mississauga',
      'es': '',
      'fr': '',
    },
    '5dyxrels': {
      'en': 'Vaughan',
      'es': '',
      'fr': '',
    },
    'he4niaoq': {
      'en': 'Kitchener',
      'es': '',
      'fr': '',
    },
    'kinlofct': {
      'en': 'Oshawa',
      'es': '',
      'fr': '',
    },
    '4v9cjzpc': {
      'en': 'Vancouver Island',
      'es': '',
      'fr': '',
    },
    '0kfdqjyk': {
      'en': 'Kelowna',
      'es': '',
      'fr': '',
    },
    'cfp6cpkv': {
      'en': 'Calgary',
      'es': '',
      'fr': '',
    },
    '3abj4rdv': {
      'en': 'Fort McMurray',
      'es': '',
      'fr': '',
    },
    '6ha0qeuh': {
      'en': 'Lethbridge',
      'es': '',
      'fr': '',
    },
    'v5u3nomf': {
      'en': 'Edmonton',
      'es': '',
      'fr': '',
    },
    '7h11ltea': {
      'en': 'Saskatoon',
      'es': '',
      'fr': '',
    },
    'cbed1p24': {
      'en': 'Winnipeg',
      'es': '',
      'fr': '',
    },
    'zn2cwai0': {
      'en': 'Coquitlam',
      'es': '',
      'fr': '',
    },
    'i0bscu6l': {
      'en': 'Dawson Creek',
      'es': '',
      'fr': '',
    },
    'p1vhjqb5': {
      'en': 'Red Deer',
      'es': '',
      'fr': '',
    },
    '7kkkoba1': {
      'en': 'Brampton',
      'es': '',
      'fr': '',
    },
    'g61qyubd': {
      'en': 'Select one',
      'es': '',
      'fr': '',
    },
    't450jsml': {
      'en': 'Field is required',
      'es': '',
      'fr': '',
    },
    'wiqcs0d4': {
      'en': 'Back',
      'es': '',
      'fr': '',
    },
    '7fvhzyt1': {
      'en': 'Next',
      'es': '',
      'fr': '',
    },
    '83cqx8sq': {
      'en': 'Register',
      'es': '',
      'fr': '',
    },
  },
  // Register_Captain_00
  {
    'tnmkgb99': {
      'en': 'Menu',
      'es': '',
      'fr': '',
    },
    'd3jokfzd': {
      'en': 'PlayOn! Store',
      'es': '',
      'fr': '',
    },
    'a6l2cwdv': {
      'en': 'Go to the PlayOn! Store',
      'es': '',
      'fr': '',
    },
    'fr9rt3lz': {
      'en': 'To register as a Team Captain, you will need the following:',
      'es': '',
      'fr': '',
    },
    'c7ns84wi': {
      'en': '1',
      'es': '',
      'fr': '',
    },
    's8m59jxc': {
      'en': 'A Team Name',
      'es': '',
      'fr': '',
    },
    'pz2bqjrs': {
      'en': 'Decide on a unique team name',
      'es': '',
      'fr': '',
    },
    'emjxcsj0': {
      'en': '2',
      'es': '',
      'fr': '',
    },
    '8houpen9': {
      'en': '3 to 8 additional players that are committed to play',
      'es': '',
      'fr': '',
    },
    'sdzp2c9x': {
      'en': 'Teams must have between 4 and 9 players, including the goalie.',
      'es': '',
      'fr': '',
    },
    'xofbg8gt': {
      'en': '3',
      'es': '',
      'fr': '',
    },
    'kg1hkjxl': {
      'en': 'Email addresses for players you want to invite to your team.',
      'es': '',
      'fr': '',
    },
    'slf9ymz2': {
      'en': 'You can add or change players later.',
      'es': '',
      'fr': '',
    },
    'w48n3tqy': {
      'en': '4',
      'es': '',
      'fr': '',
    },
    'ok0pg8p3': {
      'en': 'Credit card for payment: Visa, MasterCard, or PayPal',
      'es': '',
      'fr': '',
    },
    'd4n64raz': {
      'en': 'Registration fees are non-refundable. ',
      'es': '',
      'fr': '',
    },
    'hn26uv2g': {
      'en': 'Back',
      'es': '',
      'fr': '',
    },
    '9m1db09c': {
      'en': 'Next',
      'es': '',
      'fr': '',
    },
    'k2kvha6b': {
      'en': 'Register',
      'es': '',
      'fr': '',
    },
  },
  // Register_Captain_02
  {
    '4ogxzl5g': {
      'en': 'Menu',
      'es': '',
      'fr': '',
    },
    'm4fmdjvi': {
      'en': 'PlayOn! Store',
      'es': '',
      'fr': '',
    },
    'yqxd3ckz': {
      'en': 'Go to the PlayOn! Store',
      'es': '',
      'fr': '',
    },
    '5hnml0up': {
      'en': 'You are the team captain',
      'es': '',
      'fr': '',
    },
    'yfosokm9': {
      'en': '2',
      'es': '',
      'fr': '',
    },
    'p4ug0czk': {
      'en': '1',
      'es': '',
      'fr': '',
    },
    'g783tpe3': {
      'en': 'Team Details',
      'es': '',
      'fr': '',
    },
    'iorzgz82': {
      'en': '2',
      'es': '',
      'fr': '',
    },
    'nlygbutv': {
      'en': 'Your Details',
      'es': '',
      'fr': '',
    },
    'mahdoa67': {
      'en': '3',
      'es': '',
      'fr': '',
    },
    'ohw1uaoi': {
      'en': 'Birthdate',
      'es': '',
      'fr': '',
    },
    '4lxbgqgb': {
      'en': '4',
      'es': '',
      'fr': '',
    },
    'x54o51ji': {
      'en': 'Experience',
      'es': '',
      'fr': '',
    },
    't1q5uml5': {
      'en': '5',
      'es': '',
      'fr': '',
    },
    'h63x19kq': {
      'en': 'Players',
      'es': '',
      'fr': '',
    },
    '5kiaoygt': {
      'en': '6',
      'es': '',
      'fr': '',
    },
    '5pq9pjp4': {
      'en': 'Waiver',
      'es': '',
      'fr': '',
    },
    'raognd8h': {
      'en': '7',
      'es': '',
      'fr': '',
    },
    'kdv7eslk': {
      'en': 'Payment',
      'es': '',
      'fr': '',
    },
    'f5u0hzw7': {
      'en': '8',
      'es': '',
      'fr': '',
    },
    'a01ybs9k': {
      'en': 'Charity',
      'es': '',
      'fr': '',
    },
    '3pfcpnvi': {
      'en': 'Your Team Name is:',
      'es': '',
      'fr': '',
    },
    '9v3ky32y': {
      'en': 'You are playing in:',
      'es': '',
      'fr': '',
    },
    'dsaqq9ed': {
      'en': 'First Name',
      'es': '',
      'fr': '',
    },
    'sckf64bh': {
      'en': 'Enter your first name',
      'es': '',
      'fr': '',
    },
    'eavhkxwv': {
      'en': 'Last Name',
      'es': '',
      'fr': '',
    },
    'tpeci8vu': {
      'en': 'Enter your last name',
      'es': '',
      'fr': '',
    },
    'nqlw3a7b': {
      'en': 'Mobile Number',
      'es': '',
      'fr': '',
    },
    'nnb1y1rg': {
      'en': 'Enter your mobile number',
      'es': '',
      'fr': '',
    },
    '3x3dq5rf': {
      'en': 'Email Address',
      'es': '',
      'fr': '',
    },
    't4lts20v': {
      'en': 'Enter your email address',
      'es': '',
      'fr': '',
    },
    'q6d0ogse': {
      'en': 'Address',
      'es': '',
      'fr': '',
    },
    'exzxpdk6': {
      'en': 'Street address or SP.O. Box',
      'es': '',
      'fr': '',
    },
    'gz18gspw': {
      'en': '',
      'es': '',
      'fr': '',
    },
    'wgeasmms': {
      'en': 'Country',
      'es': '',
      'fr': '',
    },
    '22dpgs1x': {
      'en': 'Option 1',
      'es': '',
      'fr': '',
    },
    '4o0un3zp': {
      'en': 'Please select...',
      'es': '',
      'fr': '',
    },
    'ro4xmpld': {
      'en': 'State',
      'es': '',
      'fr': '',
    },
    'j02p1p3c': {
      'en': 'Province',
      'es': '',
      'fr': '',
    },
    'qmqje8bm': {
      'en': 'Option 1',
      'es': '',
      'fr': '',
    },
    'u5nzy7vf': {
      'en': 'Please select...',
      'es': '',
      'fr': '',
    },
    'wcmk8zzx': {
      'en': 'City',
      'es': '',
      'fr': '',
    },
    'o99ez1qb': {
      'en': 'Option 1',
      'es': '',
      'fr': '',
    },
    'jvc7je0e': {
      'en': 'Please select...',
      'es': '',
      'fr': '',
    },
    'vbqlrd7h': {
      'en': 'Zip  Code',
      'es': '',
      'fr': '',
    },
    'ynwouvkn': {
      'en': 'Enter your zip  code',
      'es': '',
      'fr': '',
    },
    'zt6tkopr': {
      'en': 'Postal Code',
      'es': '',
      'fr': '',
    },
    '9pl9a2k1': {
      'en': 'A1A 1A1',
      'es': '',
      'fr': '',
    },
    'j4a8hw6s': {
      'en': 'Jersey Number',
      'es': '',
      'fr': '',
    },
    'by0hap7i': {
      'en': 'Jersey number',
      'es': '',
      'fr': '',
    },
    '62a6mws9': {
      'en': 'Gender',
      'es': '',
      'fr': '',
    },
    'f424pk12': {
      'en': 'Male',
      'es': '',
      'fr': '',
    },
    '6weeh042': {
      'en': 'Female',
      'es': '',
      'fr': '',
    },
    'p8mftjpg': {
      'en': 'Neither',
      'es': '',
      'fr': '',
    },
    'zci9wax9': {
      'en': 'Select one',
      'es': '',
      'fr': '',
    },
    'ngevy7v6': {
      'en': 'Field is required',
      'es': '',
      'fr': '',
    },
    'm4ae9q2a': {
      'en': 'Field is required',
      'es': '',
      'fr': '',
    },
    'dzoula03': {
      'en': 'Field is required',
      'es': '',
      'fr': '',
    },
    'xzt2v10h': {
      'en': 'Field is required',
      'es': '',
      'fr': '',
    },
    'sdyfy1em': {
      'en': 'Field is required',
      'es': '',
      'fr': '',
    },
    '9qa8n2d0': {
      'en': 'Field is required',
      'es': '',
      'fr': '',
    },
    'imvc674j': {
      'en': 'Field is required',
      'es': '',
      'fr': '',
    },
    'mtidrut9': {
      'en': 'Field is required',
      'es': '',
      'fr': '',
    },
    'tlvv0hmk': {
      'en': 'Field is required',
      'es': '',
      'fr': '',
    },
    '4brorgjj': {
      'en': 'Back',
      'es': '',
      'fr': '',
    },
    'ef5r8mf2': {
      'en': 'Next',
      'es': '',
      'fr': '',
    },
    'dogfebuv': {
      'en': 'Register',
      'es': '',
      'fr': '',
    },
  },
  // Register_Captain_03
  {
    '0dalppi7': {
      'en': 'Menu',
      'es': '',
      'fr': '',
    },
    'ndw9k1r9': {
      'en': 'PlayOn! Store',
      'es': '',
      'fr': '',
    },
    'omzbsols': {
      'en': 'Go to the PlayOn! Store',
      'es': '',
      'fr': '',
    },
    'l6jdh847': {
      'en': 'You are the team captain',
      'es': '',
      'fr': '',
    },
    'fgwd68cu': {
      'en': '3',
      'es': '',
      'fr': '',
    },
    't12na3eq': {
      'en': '1',
      'es': '',
      'fr': '',
    },
    'gqa41wzs': {
      'en': 'Team Details',
      'es': '',
      'fr': '',
    },
    '4fxvv2zd': {
      'en': '2',
      'es': '',
      'fr': '',
    },
    'ujfjcbsm': {
      'en': 'Your Details',
      'es': '',
      'fr': '',
    },
    'sn8t0lwu': {
      'en': '3',
      'es': '',
      'fr': '',
    },
    'qre38eda': {
      'en': 'Birthdate',
      'es': '',
      'fr': '',
    },
    'xfiuli3r': {
      'en': '4',
      'es': '',
      'fr': '',
    },
    'pxb1sdd8': {
      'en': 'Experience',
      'es': '',
      'fr': '',
    },
    't0dlq10x': {
      'en': '5',
      'es': '',
      'fr': '',
    },
    'dx0qkdb9': {
      'en': 'Players',
      'es': '',
      'fr': '',
    },
    'oyz33roc': {
      'en': '6',
      'es': '',
      'fr': '',
    },
    'e5xuitij': {
      'en': 'Waiver',
      'es': '',
      'fr': '',
    },
    't7hhof51': {
      'en': '7',
      'es': '',
      'fr': '',
    },
    '7shogf07': {
      'en': 'Payment',
      'es': '',
      'fr': '',
    },
    'd2v4smsc': {
      'en': '8',
      'es': '',
      'fr': '',
    },
    'kthgqa5x': {
      'en': 'Charity',
      'es': '',
      'fr': '',
    },
    'drria7t5': {
      'en': 'Your Team Name is:',
      'es': '',
      'fr': '',
    },
    'qsxmr0ar': {
      'en': 'You are playing in:',
      'es': '',
      'fr': '',
    },
    'qmw5mb5z': {
      'en': 'Your BirthDate',
      'es': '',
      'fr': '',
    },
    '922pyr2y': {
      'en': '1',
      'es': '',
      'fr': '',
    },
    'h7gmaodd': {
      'en': '2',
      'es': '',
      'fr': '',
    },
    'ljy8bk56': {
      'en': '3',
      'es': '',
      'fr': '',
    },
    'pkd83q5u': {
      'en': '4',
      'es': '',
      'fr': '',
    },
    'n3zmayqz': {
      'en': '5',
      'es': '',
      'fr': '',
    },
    'nz6bqw8v': {
      'en': '6',
      'es': '',
      'fr': '',
    },
    '3nggg30q': {
      'en': '7',
      'es': '',
      'fr': '',
    },
    'gtxm7rm1': {
      'en': '8',
      'es': '',
      'fr': '',
    },
    '64grbtwt': {
      'en': '9',
      'es': '',
      'fr': '',
    },
    'i2a5az3s': {
      'en': '10',
      'es': '',
      'fr': '',
    },
    '6dd1s56u': {
      'en': '11',
      'es': '',
      'fr': '',
    },
    'cjr9p39o': {
      'en': '12',
      'es': '',
      'fr': '',
    },
    'ckgm8pq3': {
      'en': '13',
      'es': '',
      'fr': '',
    },
    'vqkpavx2': {
      'en': '14',
      'es': '',
      'fr': '',
    },
    't81um025': {
      'en': '15',
      'es': '',
      'fr': '',
    },
    '8s0qjmy9': {
      'en': '16',
      'es': '',
      'fr': '',
    },
    'ihljifcy': {
      'en': '17',
      'es': '',
      'fr': '',
    },
    'hqyr83za': {
      'en': '18',
      'es': '',
      'fr': '',
    },
    '2fv4y51e': {
      'en': '19',
      'es': '',
      'fr': '',
    },
    '4w2yp5yj': {
      'en': '20',
      'es': '',
      'fr': '',
    },
    '2kp2et64': {
      'en': '21',
      'es': '',
      'fr': '',
    },
    'dxwzou3z': {
      'en': '22',
      'es': '',
      'fr': '',
    },
    'g3lalf37': {
      'en': '23',
      'es': '',
      'fr': '',
    },
    'uhll3nlq': {
      'en': '24',
      'es': '',
      'fr': '',
    },
    '11spoy19': {
      'en': '25',
      'es': '',
      'fr': '',
    },
    'z5qgtxju': {
      'en': '26',
      'es': '',
      'fr': '',
    },
    'vd6z8r94': {
      'en': '27',
      'es': '',
      'fr': '',
    },
    'da788oih': {
      'en': '28',
      'es': '',
      'fr': '',
    },
    'an798v72': {
      'en': '29',
      'es': '',
      'fr': '',
    },
    'md2qyk6e': {
      'en': '30',
      'es': '',
      'fr': '',
    },
    'vi8zitgx': {
      'en': '31',
      'es': '',
      'fr': '',
    },
    '2cmeu4mv': {
      'en': 'Day',
      'es': '',
      'fr': '',
    },
    '3l5c04td': {
      'en': 'January',
      'es': '',
      'fr': '',
    },
    '5faz4ju0': {
      'en': 'February',
      'es': '',
      'fr': '',
    },
    'h9rt7s2i': {
      'en': 'March',
      'es': '',
      'fr': '',
    },
    'aj6aki0e': {
      'en': 'April',
      'es': '',
      'fr': '',
    },
    'wwbtkmfy': {
      'en': 'May',
      'es': '',
      'fr': '',
    },
    '1bfvy0kl': {
      'en': 'June',
      'es': '',
      'fr': '',
    },
    'jirrr5sl': {
      'en': 'July',
      'es': '',
      'fr': '',
    },
    'gqgiexb2': {
      'en': 'August',
      'es': '',
      'fr': '',
    },
    'nm6awv3n': {
      'en': 'September',
      'es': '',
      'fr': '',
    },
    'sv11llfp': {
      'en': 'October',
      'es': '',
      'fr': '',
    },
    '3vttv8pr': {
      'en': 'November',
      'es': '',
      'fr': '',
    },
    'q8qf5o68': {
      'en': 'December',
      'es': '',
      'fr': '',
    },
    'g5s28a57': {
      'en': 'Month',
      'es': '',
      'fr': '',
    },
    'kr82x1o4': {
      'en': '1995',
      'es': '',
      'fr': '',
    },
    'o48hl09y': {
      'en': 'Year',
      'es': '',
      'fr': '',
    },
    'qrl9xxe7': {
      'en': 'I certify that this birthdate is correct',
      'es': '',
      'fr': '',
    },
    '7o3qyh44': {
      'en':
          'I understand my division will be assigned based on the birth year of the oldest player in the team',
      'es': '',
      'fr': '',
    },
    'a4zx6bxq': {
      'en':
          'I acknowledge that I may be required to show proof of age at any time during the event',
      'es': '',
      'fr': '',
    },
    'cql6jrj4': {
      'en': 'Back',
      'es': '',
      'fr': '',
    },
    'eg4ll1xd': {
      'en': 'Next',
      'es': '',
      'fr': '',
    },
    '0h6ag95e': {
      'en': 'Register',
      'es': '',
      'fr': '',
    },
  },
  // Register_Captain_04
  {
    '2ufcf8b9': {
      'en': 'Menu',
      'es': '',
      'fr': '',
    },
    'u9rj2f38': {
      'en': 'PlayOn! Store',
      'es': '',
      'fr': '',
    },
    '51z7q5tq': {
      'en': 'Go to the PlayOn! Store',
      'es': '',
      'fr': '',
    },
    '7efi1g3l': {
      'en': 'You are the team captain',
      'es': '',
      'fr': '',
    },
    '1aad37af': {
      'en': '4',
      'es': '',
      'fr': '',
    },
    '980qlf3j': {
      'en': '1',
      'es': '',
      'fr': '',
    },
    '1ithl3h9': {
      'en': 'Team Details',
      'es': '',
      'fr': '',
    },
    'isb30l13': {
      'en': '2',
      'es': '',
      'fr': '',
    },
    'g9hbezly': {
      'en': 'Your Details',
      'es': '',
      'fr': '',
    },
    'jusd2unx': {
      'en': '3',
      'es': '',
      'fr': '',
    },
    'x1plihxf': {
      'en': 'Birthdate',
      'es': '',
      'fr': '',
    },
    'c9bustbc': {
      'en': '4',
      'es': '',
      'fr': '',
    },
    'nnfqlqnt': {
      'en': 'Experience',
      'es': '',
      'fr': '',
    },
    '5fdsyy99': {
      'en': '5',
      'es': '',
      'fr': '',
    },
    'inzf0rnh': {
      'en': 'Players',
      'es': '',
      'fr': '',
    },
    'cmtpcve0': {
      'en': '6',
      'es': '',
      'fr': '',
    },
    '86stioal': {
      'en': 'Waiver',
      'es': '',
      'fr': '',
    },
    'wom5olys': {
      'en': '7',
      'es': '',
      'fr': '',
    },
    'e5t28dqf': {
      'en': 'Payment',
      'es': '',
      'fr': '',
    },
    'yrb4fuj5': {
      'en': '8',
      'es': '',
      'fr': '',
    },
    'ccankrnq': {
      'en': 'Charity',
      'es': '',
      'fr': '',
    },
    'zso64o46': {
      'en': 'Your Team Name is:',
      'es': '',
      'fr': '',
    },
    '0drkk5gk': {
      'en': 'You are playing in:',
      'es': '',
      'fr': '',
    },
    '6b1aw5ca': {
      'en': 'Ice Hockey Experience',
      'es': '',
      'fr': '',
    },
    'eptumifs': {
      'en': 'Yes',
      'es': '',
      'fr': '',
    },
    'gjav3ric': {
      'en': 'No',
      'es': '',
      'fr': '',
    },
    'u2b4zx7b': {
      'en': 'Select one',
      'es': '',
      'fr': '',
    },
    'q7w6srop': {
      'en': 'Your last team',
      'es': '',
      'fr': '',
    },
    '8a2g51fh': {
      'en': 'Pond Hockey only',
      'es': '',
      'fr': '',
    },
    'zlm39i9r': {
      'en': 'House/Local/Recreational League',
      'es': '',
      'fr': '',
    },
    'v9t251w4': {
      'en': 'AE/MD',
      'es': '',
      'fr': '',
    },
    'zjoobec2': {
      'en': 'A',
      'es': '',
      'fr': '',
    },
    'pl0yvxuk': {
      'en': 'AA',
      'es': '',
      'fr': '',
    },
    '03id9nd2': {
      'en': 'AAA',
      'es': '',
      'fr': '',
    },
    'w2d0fx29': {
      'en': 'Junior A/CHL',
      'es': '',
      'fr': '',
    },
    'mz94peoo': {
      'en': 'Junior B/C/D',
      'es': '',
      'fr': '',
    },
    'ww645tsg': {
      'en': 'College/University',
      'es': '',
      'fr': '',
    },
    'egkn62xe': {
      'en': 'Professional (Europe, AHL, NHL or other)',
      'es': '',
      'fr': '',
    },
    'qynlh4rt': {
      'en': 'Select one',
      'es': '',
      'fr': '',
    },
    'q6de0hls': {
      'en': 'Yes',
      'es': '',
      'fr': '',
    },
    't2xhms6v': {
      'en': 'No',
      'es': '',
      'fr': '',
    },
    'khcj1fue': {
      'en': 'Select one',
      'es': '',
      'fr': '',
    },
    '8grylvtv': {
      'en': 'Ball Hockey Experience',
      'es': '',
      'fr': '',
    },
    '5rcnfydl': {
      'en': 'Yes',
      'es': '',
      'fr': '',
    },
    'btwrn1j0': {
      'en': 'No',
      'es': '',
      'fr': '',
    },
    'itgq0549': {
      'en': 'Select one',
      'es': '',
      'fr': '',
    },
    'cssh7dew': {
      'en': 'Your last team',
      'es': '',
      'fr': '',
    },
    'sum8wrbw': {
      'en': 'Street Hockey only / Play On!',
      'es': '',
      'fr': '',
    },
    'dkls1egk': {
      'en': 'Minor Ball Hockey League​',
      'es': '',
      'fr': '',
    },
    '4xgrdf51': {
      'en': 'Provincial Ball Hockey Tournament​',
      'es': '',
      'fr': '',
    },
    '5sb2xstd': {
      'en': 'Competitive DEK Hockey (common in Quebec and USA)​',
      'es': '',
      'fr': '',
    },
    'qg8cgul3': {
      'en': 'National / International Tournament (NBHF, CBHA, or ISBHF)',
      'es': '',
      'fr': '',
    },
    '1zo8cczu': {
      'en': 'Redwood Cup',
      'es': '',
      'fr': '',
    },
    'iqt15cfj': {
      'en': 'Select one',
      'es': '',
      'fr': '',
    },
    'vm4m2fp5': {
      'en': 'Yes',
      'es': '',
      'fr': '',
    },
    'q48eaie6': {
      'en': 'No',
      'es': '',
      'fr': '',
    },
    'l9732dks': {
      'en': 'Select one',
      'es': '',
      'fr': '',
    },
    '8ic8f5xu': {
      'en': 'Back',
      'es': '',
      'fr': '',
    },
    '8e8uylh8': {
      'en': 'Next',
      'es': '',
      'fr': '',
    },
    'ml6arzxc': {
      'en': 'Register',
      'es': '',
      'fr': '',
    },
  },
  // Register_Captain_05
  {
    '8v35gwu3': {
      'en': 'Menu',
      'es': '',
      'fr': '',
    },
    'vsqbv019': {
      'en': 'PlayOn! Store',
      'es': '',
      'fr': '',
    },
    'ibw9290z': {
      'en': 'Go to the PlayOn! Store',
      'es': '',
      'fr': '',
    },
    '90zj0xi7': {
      'en': 'You are the team captain',
      'es': '',
      'fr': '',
    },
    'wqkojnlk': {
      'en': '5',
      'es': '',
      'fr': '',
    },
    '2v3iwt7e': {
      'en': '1',
      'es': '',
      'fr': '',
    },
    '1py0dy0w': {
      'en': 'Team Details',
      'es': '',
      'fr': '',
    },
    'emw6o2g9': {
      'en': '2',
      'es': '',
      'fr': '',
    },
    'dcx4atym': {
      'en': 'Your Details',
      'es': '',
      'fr': '',
    },
    'w7miigow': {
      'en': '3',
      'es': '',
      'fr': '',
    },
    'kjit5els': {
      'en': 'Birthdate',
      'es': '',
      'fr': '',
    },
    'gi0tjjg2': {
      'en': '4',
      'es': '',
      'fr': '',
    },
    'nsvcv1k2': {
      'en': 'Experience',
      'es': '',
      'fr': '',
    },
    '23240s7a': {
      'en': '5',
      'es': '',
      'fr': '',
    },
    '1x45xawv': {
      'en': 'Players',
      'es': '',
      'fr': '',
    },
    '64duu5jx': {
      'en': '6',
      'es': '',
      'fr': '',
    },
    'v7ihmw6v': {
      'en': 'Waiver',
      'es': '',
      'fr': '',
    },
    'ehi1zwdy': {
      'en': '7',
      'es': '',
      'fr': '',
    },
    'k1ezljsk': {
      'en': 'Payment',
      'es': '',
      'fr': '',
    },
    'vqystjvn': {
      'en': '8',
      'es': '',
      'fr': '',
    },
    'mvkxikfq': {
      'en': 'Charity',
      'es': '',
      'fr': '',
    },
    'wrr4v80k': {
      'en': 'Your Team Name is:',
      'es': '',
      'fr': '',
    },
    'u8c7s3gt': {
      'en': 'You are playing in:',
      'es': '',
      'fr': '',
    },
    '5ks0w5vf': {
      'en':
          'Your team must have a minute of 4 players and a maximum of 9 players, including the goalie.\nYou may add or change players before the event registration deadline.\nYou must invite a minimum of 3 additional players to continue.',
      'es': '',
      'fr': '',
    },
    'mu237zyv': {
      'en': 'Invite above players',
      'es': '',
      'fr': '',
    },
    'b4m0q70m': {
      'en': 'Back',
      'es': '',
      'fr': '',
    },
    'uin53d0z': {
      'en': 'Next',
      'es': '',
      'fr': '',
    },
    '5ecji2oi': {
      'en': 'Register',
      'es': '',
      'fr': '',
    },
  },
  // Register_Captain_06
  {
    'h20kl19g': {
      'en': 'Menu',
      'es': '',
      'fr': '',
    },
    '0m2b4yxy': {
      'en': 'PlayOn! Store',
      'es': '',
      'fr': '',
    },
    'owjlh8qa': {
      'en': 'Go to the PlayOn! Store',
      'es': '',
      'fr': '',
    },
    'dv0xe9cy': {
      'en': 'You are the team captain',
      'es': '',
      'fr': '',
    },
    'q1zv050i': {
      'en': '6',
      'es': '',
      'fr': '',
    },
    't75xgb3j': {
      'en': '1',
      'es': '',
      'fr': '',
    },
    'v09g38kz': {
      'en': 'Team Details',
      'es': '',
      'fr': '',
    },
    '0m1sdg0d': {
      'en': '2',
      'es': '',
      'fr': '',
    },
    '1641q6d9': {
      'en': 'Your Details',
      'es': '',
      'fr': '',
    },
    'je109etf': {
      'en': '3',
      'es': '',
      'fr': '',
    },
    '9o6wetxn': {
      'en': 'Birthdate',
      'es': '',
      'fr': '',
    },
    'dzvb3ecf': {
      'en': '4',
      'es': '',
      'fr': '',
    },
    'qthmubgk': {
      'en': 'Experience',
      'es': '',
      'fr': '',
    },
    '1mm713ba': {
      'en': '5',
      'es': '',
      'fr': '',
    },
    'na7qd4c8': {
      'en': 'Players',
      'es': '',
      'fr': '',
    },
    'lmmpb4ej': {
      'en': '6',
      'es': '',
      'fr': '',
    },
    'yw45vr62': {
      'en': 'Waiver',
      'es': '',
      'fr': '',
    },
    'qexguc68': {
      'en': '7',
      'es': '',
      'fr': '',
    },
    'c73uf375': {
      'en': 'Payment',
      'es': '',
      'fr': '',
    },
    'smw8zjoi': {
      'en': '8',
      'es': '',
      'fr': '',
    },
    'gxhnzbfa': {
      'en': 'Charity',
      'es': '',
      'fr': '',
    },
    '7vr1kkgl': {
      'en': 'Your Team Name is:',
      'es': '',
      'fr': '',
    },
    'qq4pphxk': {
      'en': 'Your playing in:',
      'es': '',
      'fr': '',
    },
    'pjwvodpz': {
      'en': 'WAIVER, RELEASE AND INDEMNIFICATION:',
      'es': '',
      'fr': '',
    },
    'huu9me3c': {
      'en':
          'Every player, and his/her parent or guardian (if the player is under 18) must read. execute, and deliver this waiver to tournament organizers prior to the commencement of the tournament. in consideration of the right and opportunity to participate in the play On! street hockey tournament conducted by the not for profit organization play On! Canada (POC),and its licensed affiliates, the undersigned hereby acknowledges and agrees as follows: I (who am the participant\'s parent or legal guardian if the participant is under 18 year old) hereby consent to the use without compensation, of my/his/her name  and/or likeness, biographical material and/or voice in publicity and advertising concerning the play On! tournament by PPOC and/or any playOn! tournament partners or sponsored in any and all media and/or promotion and throughout the world. in addition, the undersigned (on behalf of the participant if the participant is under 18 years of age) forever generally and completely release and discharge and shall indemnify and hold harmless Play On! Canada and its employees, directors, officers, agents, sponsors, partners and licensees and each other party affiliated with play On! Canada and each of its owners, agents, directors, officers, employees, sponsors and partners(collectively, \"Event Organizers\") against and from any and all claims and demands of every kind and nature whatsoever, for damages or injuries ,actual or consequential, past, present or future, raising out of or in any   way related to the Play On! street hockey  tournament, including but not limited to any claims of injury from participating in OR observing the tournament, the loss of personal property by theft to otherwise during the tournament, any publicity related to the tournament, or any prizes   awarded. The undersigned acknowledges that of its own free will he/she has chosen to participate in the tournament and related activities. I understand and acknowledge that the aforementioned activities carry with them a high level of risk of injury  and additional hazards related thereto. i certify that i am  aware kof ,and accept, these increased risks and that i am mentally and physically prepared for the risks associated with the play On! street hockey tournament. This general release shall further apply to all unknown, unanticipated, unsuspected, and undisclosed claims, demands, liabilities, actions or causes of action, in law, equality or otherwise.  This Waiver shall bind heirs, personal representatives, and successors of the undersigned, and inure to the benefit of the Event Organizers.',
      'es': '',
      'fr': '',
    },
    '2v3t7su6': {
      'en':
          'I HAVE READ AND UNDERSTAND THE TERMS OF THE ABOVE AGREEMENT, WILL COMPLY WITH TERMS HERE OF AND ACKNOWLEDGE THAT BY SIGNIG THIS FORM I AM GIVING UP LEGAL RIGHTS.',
      'es': '',
      'fr': '',
    },
    'y0h69u1h': {
      'en': 'Date Of Birth',
      'es': '',
      'fr': '',
    },
    'qn03l2pb': {
      'en': ':',
      'es': '',
      'fr': '',
    },
    'r2x9jlj2': {
      'en': ' / ',
      'es': '',
      'fr': '',
    },
    'akzhurck': {
      'en': ' / ',
      'es': '',
      'fr': '',
    },
    'qo32t73h': {
      'en': 'Player Name',
      'es': '',
      'fr': '',
    },
    'ihiut9h3': {
      'en': ':',
      'es': '',
      'fr': '',
    },
    'xxy1uxx6': {
      'en': 'Event Location(City) ',
      'es': '',
      'fr': '',
    },
    '55n6iz0z': {
      'en': ':',
      'es': '',
      'fr': '',
    },
    'v4kp96l6': {
      'en': 'Team Name',
      'es': '',
      'fr': '',
    },
    '9s171k68': {
      'en': ':',
      'es': '',
      'fr': '',
    },
    'qrmza90o': {
      'en': 'Signature',
      'es': '',
      'fr': '',
    },
    'qfum65s1': {
      'en': 'Parent Name',
      'es': '',
      'fr': '',
    },
    '5wjz7w4v': {
      'en': 'Enter your parent name',
      'es': '',
      'fr': '',
    },
    'u66uc1d6': {
      'en': 'Parent Email  Address',
      'es': '',
      'fr': '',
    },
    'y28jv3c3': {
      'en': 'Enter your email address',
      'es': '',
      'fr': '',
    },
    '5qi9tf41': {
      'en': 'Sent waiver details to parent',
      'es': '',
      'fr': '',
    },
    'l0l22s9i': {
      'en': 'Back',
      'es': '',
      'fr': '',
    },
    'ekp7aicr': {
      'en': 'Next',
      'es': '',
      'fr': '',
    },
    'o0fxoprs': {
      'en': 'Register',
      'es': '',
      'fr': '',
    },
  },
  // Register_Captain_07
  {
    'bfkvftd7': {
      'en': 'Menu',
      'es': 'Menú',
      'fr': 'Menu',
    },
    'xqjpqe8z': {
      'en': 'PlayOn! Store',
      'es': '¡Juega! Tienda',
      'fr': 'Jouer sur! Boutique',
    },
    'ft5rp564': {
      'en': 'Go to the PlayOn! Store',
      'es': '¡Ve al PlayOn! Tienda',
      'fr': 'Rendez-vous sur PlayOn! Boutique',
    },
    'bqoid69e': {
      'en': 'You are the team captain',
      'es': '',
      'fr': '',
    },
    '4nqwfzxk': {
      'en': '7',
      'es': '',
      'fr': '',
    },
    'f5ygyw41': {
      'en': '1',
      'es': '',
      'fr': '',
    },
    'p972duhl': {
      'en': 'Team Details',
      'es': '',
      'fr': '',
    },
    'c5wvgsz1': {
      'en': '2',
      'es': '',
      'fr': '',
    },
    'vh8p8omf': {
      'en': 'Your Details',
      'es': '',
      'fr': '',
    },
    'qaf1vnb0': {
      'en': '3',
      'es': '',
      'fr': '',
    },
    'wbzd80je': {
      'en': 'Birthdate',
      'es': '',
      'fr': '',
    },
    'xxo0d6kr': {
      'en': '4',
      'es': '',
      'fr': '',
    },
    'iqsg7hok': {
      'en': 'Experience',
      'es': '',
      'fr': '',
    },
    '9plqe5fb': {
      'en': '5',
      'es': '',
      'fr': '',
    },
    'e5zllwsf': {
      'en': 'Players',
      'es': '',
      'fr': '',
    },
    'lqsiq0oa': {
      'en': '6',
      'es': '',
      'fr': '',
    },
    'nit74fd0': {
      'en': 'Waiver',
      'es': '',
      'fr': '',
    },
    'msqw8e80': {
      'en': '7',
      'es': '',
      'fr': '',
    },
    'ayaj4hbj': {
      'en': 'Payment',
      'es': '',
      'fr': '',
    },
    'lo4tbngs': {
      'en': '8',
      'es': '',
      'fr': '',
    },
    '59sszpli': {
      'en': 'Charity',
      'es': '',
      'fr': '',
    },
    '1fjaqtm7': {
      'en': 'Your Team Name is:',
      'es': '',
      'fr': '',
    },
    'fy5qck51': {
      'en': 'You are playing in:',
      'es': '',
      'fr': '',
    },
    'tqvjync6': {
      'en': 'Captain Registration Fee:',
      'es': '',
      'fr': '',
    },
    '1k8dk23i': {
      'en': '\$59.00',
      'es': '',
      'fr': '',
    },
    'i5efy6eg': {
      'en': 'Tax:',
      'es': '',
      'fr': '',
    },
    'k5haepbc': {
      'en': '\$4.99',
      'es': '',
      'fr': '',
    },
    'wmxljet6': {
      'en': 'Total Fee:',
      'es': '',
      'fr': '',
    },
    'vn6ar6nx': {
      'en': '\$63.99',
      'es': '',
      'fr': '',
    },
    '4hlgq3x3': {
      'en': 'Are you certain you have 3 or more additional players?',
      'es': '',
      'fr': '',
    },
    'resyoy6z': {
      'en':
          'By paying your fees, you confirm that you will have a team for this event.',
      'es': '',
      'fr': '',
    },
    'gapd5spr': {
      'en':
          'Team players can be added or changed any time before the registration deadline.',
      'es': '',
      'fr': '',
    },
    'tovsd0o6': {
      'en': 'Participation fees are not refundable under any circumstances.',
      'es': '',
      'fr': '',
    },
    'sb4434j7': {
      'en':
          'I understand and agree to the policies. We are committed to playing!',
      'es': '',
      'fr': '',
    },
    '475kinx3': {
      'en': 'Back',
      'es': '',
      'fr': '',
    },
    'rox7rufq': {
      'en': 'Next',
      'es': '',
      'fr': '',
    },
    'b9tbzenp': {
      'en': 'Register',
      'es': '',
      'fr': '',
    },
  },
  // Register_Captain_08
  {
    'j75vg42d': {
      'en': 'Menu',
      'es': 'Menú',
      'fr': 'Menu',
    },
    'xtq5vhl6': {
      'en': 'PlayOn! Store',
      'es': '¡Juega! Tienda',
      'fr': 'Jouer sur! Boutique',
    },
    '78940z0x': {
      'en': 'Go to the PlayOn! Store',
      'es': '¡Ve al PlayOn! Tienda',
      'fr': 'Rendez-vous sur PlayOn! Boutique',
    },
    '17u2c161': {
      'en': 'You are the team captain',
      'es': '',
      'fr': '',
    },
    'ryn3gvaz': {
      'en': '8',
      'es': '',
      'fr': '',
    },
    'l7bgd16n': {
      'en': '1',
      'es': '',
      'fr': '',
    },
    'r1h60e23': {
      'en': 'Team Details',
      'es': '',
      'fr': '',
    },
    'fvfsz7gi': {
      'en': '2',
      'es': '',
      'fr': '',
    },
    'm8o3yyv1': {
      'en': 'Your Details',
      'es': '',
      'fr': '',
    },
    'vxn08xc8': {
      'en': '3',
      'es': '',
      'fr': '',
    },
    'mml79oe1': {
      'en': 'Birthdate',
      'es': '',
      'fr': '',
    },
    'r9y2s6eu': {
      'en': '4',
      'es': '',
      'fr': '',
    },
    'ekbbtoxr': {
      'en': 'Experience',
      'es': '',
      'fr': '',
    },
    'srzhts85': {
      'en': '5',
      'es': '',
      'fr': '',
    },
    'tec4dfj7': {
      'en': 'Players',
      'es': '',
      'fr': '',
    },
    '3wzxdsrc': {
      'en': '6',
      'es': '',
      'fr': '',
    },
    'o2r6wyvn': {
      'en': 'Waiver',
      'es': '',
      'fr': '',
    },
    'gmnz3x2a': {
      'en': '7',
      'es': '',
      'fr': '',
    },
    'n7yis3b3': {
      'en': 'Payment',
      'es': '',
      'fr': '',
    },
    'hjjkj7hs': {
      'en': '8',
      'es': '',
      'fr': '',
    },
    '84511vz5': {
      'en': 'Charity',
      'es': '',
      'fr': '',
    },
    'pet91b8f': {
      'en': 'Your Team Name is:',
      'es': '',
      'fr': '',
    },
    '3zfydbjj': {
      'en': 'You are playing in:',
      'es': '',
      'fr': '',
    },
    '5pr6qoke': {
      'en': 'Charity-1',
      'es': '',
      'fr': '',
    },
    'n2gpsas6': {
      'en': 'Other',
      'es': '',
      'fr': '',
    },
    '628xod79': {
      'en': 'Select one',
      'es': '',
      'fr': '',
    },
    '8ux4wq7u': {
      'en': 'Enter contact name',
      'es': '',
      'fr': '',
    },
    '3rr9zu2k': {
      'en': 'Enter your name charity name',
      'es': '',
      'fr': '',
    },
    'vw9jtco2': {
      'en': 'Enter your email address',
      'es': '',
      'fr': '',
    },
    'h4pegwa8': {
      'en': 'Send Email',
      'es': '',
      'fr': '',
    },
    'wvmrgznb': {
      'en': 'Go to Dashboard',
      'es': '',
      'fr': '',
    },
    'u3smx62w': {
      'en': 'Register',
      'es': '',
      'fr': '',
    },
  },
  // Dashboard_Family
  {
    '4w95lsyc': {
      'en': 'Login',
      'es': '',
      'fr': '',
    },
    'dj5ko50z': {
      'en': 'Menu',
      'es': 'Menú',
      'fr': 'Menu',
    },
    'uug140r5': {
      'en': 'PlayOn! Store',
      'es': '¡Juega! Tienda',
      'fr': 'Jouer sur! Boutique',
    },
    '16us9nk0': {
      'en': 'Go to the PlayOn! Store',
      'es': '¡Ve al PlayOn! Tienda',
      'fr': 'Rendez-vous sur PlayOn! Boutique',
    },
    '9v01xew0': {
      'en': 'You have 5 notifications.',
      'es': '',
      'fr': '',
    },
    '0o9iuw3s': {
      'en': ' Click here ',
      'es': '',
      'fr': '',
    },
    'epiokamw': {
      'en': 'My Team(s)',
      'es': '',
      'fr': '',
    },
    '3okirjsx': {
      'en': 'My Profile',
      'es': '',
      'fr': '',
    },
    '3bz3w5uv': {
      'en': 'My Fans',
      'es': '',
      'fr': '',
    },
    'jsc9ejdl': {
      'en': 'My Donations',
      'es': '',
      'fr': '',
    },
    'qq8aw0tp': {
      'en': 'My Schedule',
      'es': '',
      'fr': '',
    },
    'hz65utvb': {
      'en': 'My Stats',
      'es': '',
      'fr': '',
    },
    'wz4v8y3f': {
      'en': 'My Rewards',
      'es': '',
      'fr': '',
    },
    '7ryt2sqa': {
      'en': 'My Invitations',
      'es': '',
      'fr': '',
    },
    'ef1xjaq8': {
      'en': 'Manage Members',
      'es': '',
      'fr': '',
    },
    'c7foyoss': {
      'en': 'Register',
      'es': '',
      'fr': '',
    },
  },
  // Register_FamilyAcc_00
  {
    '2f989qil': {
      'en': 'Menu',
      'es': 'Menú',
      'fr': 'Menu',
    },
    'w2ehgxm3': {
      'en': 'PlayOn! Store',
      'es': '¡Juega! Tienda',
      'fr': 'Jouer sur! Boutique',
    },
    '314r3uty': {
      'en': 'Go to the PlayOn! Store',
      'es': '¡Ve al PlayOn! Tienda',
      'fr': 'Rendez-vous sur PlayOn! Boutique',
    },
    'tqncje2v': {
      'en': 'Family Account',
      'es': '',
      'fr': '',
    },
    '148nlu9i': {
      'en': 'Parent Information',
      'es': '',
      'fr': '',
    },
    'iyrjj0n0': {
      'en': 'First Name',
      'es': '',
      'fr': '',
    },
    'ghg4lqmx': {
      'en': 'Enter your first name',
      'es': '',
      'fr': '',
    },
    '6msav223': {
      'en': 'Last Name',
      'es': '',
      'fr': '',
    },
    '8praom71': {
      'en': 'Enter your last name',
      'es': '',
      'fr': '',
    },
    'p7wok1b3': {
      'en': 'Mobile Number',
      'es': '',
      'fr': '',
    },
    'tb0o126g': {
      'en': 'Enter mobile number',
      'es': '',
      'fr': '',
    },
    '02yxosa1': {
      'en': 'Email address',
      'es': '',
      'fr': '',
    },
    'bh9rdx9w': {
      'en': 'Enter your email address',
      'es': '',
      'fr': '',
    },
    'z3sdoj7f': {
      'en': 'Address',
      'es': '',
      'fr': '',
    },
    '548fmk8s': {
      'en': 'Enter your address details',
      'es': '',
      'fr': '',
    },
    'eqmorbdd': {
      'en': 'Enter your address details',
      'es': '',
      'fr': '',
    },
    '0pzrl9su': {
      'en': 'Country',
      'es': '',
      'fr': '',
    },
    'uqwrx769': {
      'en': 'Canada',
      'es': '',
      'fr': '',
    },
    'qlg47kue': {
      'en': 'USA',
      'es': '',
      'fr': '',
    },
    '8k5sbz9v': {
      'en': 'Please select...',
      'es': '',
      'fr': '',
    },
    'bpmad5oo': {
      'en': 'Province/State',
      'es': '',
      'fr': '',
    },
    'ggga4j5x': {
      'en': 'Option 1',
      'es': '',
      'fr': '',
    },
    'r40pr4q9': {
      'en': 'Please select...',
      'es': '',
      'fr': '',
    },
    'ldb7n5m2': {
      'en': 'City',
      'es': '',
      'fr': '',
    },
    'hls3nccx': {
      'en': 'Enter your city name',
      'es': '',
      'fr': '',
    },
    '95csze7k': {
      'en': 'Postal Code',
      'es': '',
      'fr': '',
    },
    'b972fzoe': {
      'en': 'Enter your postal code',
      'es': '',
      'fr': '',
    },
    'ep3cbbbd': {
      'en': 'Back',
      'es': '',
      'fr': '',
    },
    'dndz4n77': {
      'en': 'Next',
      'es': '',
      'fr': '',
    },
    'ek45egvl': {
      'en': 'Register',
      'es': '',
      'fr': '',
    },
  },
  // Dashboard_Fan
  {
    'fh7xz79g': {
      'en': 'My Rewards',
      'es': '',
      'fr': '',
    },
    '57y1ho0b': {
      'en': 'My Profile',
      'es': '',
      'fr': '',
    },
    'byxqh8bh': {
      'en': 'Home',
      'es': '',
      'fr': '',
    },
  },
  // Register_Charity_00
  {
    'mu2kvuie': {
      'en': 'Welcome Message',
      'es': '',
      'fr': '',
    },
    'e825taq1': {
      'en':
          'Please take a moment to watch this explainer video prior to beginning this process',
      'es': '',
      'fr': '',
    },
    '5828n0f8': {
      'en': 'Watch Online',
      'es': '',
      'fr': '',
    },
    'wx9fbb2k': {
      'en': 'Back',
      'es': '',
      'fr': '',
    },
    '5rp3xl6t': {
      'en': 'Next',
      'es': '',
      'fr': '',
    },
    'ghuftieo': {
      'en': 'Home',
      'es': '',
      'fr': '',
    },
  },
  // Register_FamilyAcc_01
  {
    'ec8r5c06': {
      'en': 'Menu',
      'es': 'Menú',
      'fr': 'Menu',
    },
    '50v2y986': {
      'en': 'PlayOn! Store',
      'es': '¡Juega! Tienda',
      'fr': 'Jouer sur! Boutique',
    },
    'gl4krhm6': {
      'en': 'Go to the PlayOn! Store',
      'es': '¡Ve al PlayOn! Tienda',
      'fr': 'Rendez-vous sur PlayOn! Boutique',
    },
    '091pa86c': {
      'en': 'Family Account',
      'es': '',
      'fr': '',
    },
    'wgpaw3co': {
      'en': 'You have 5 notifications.',
      'es': '',
      'fr': '',
    },
    'oimzkhtr': {
      'en': ' Click here ',
      'es': '',
      'fr': '',
    },
    '62l7rjwi': {
      'en': 'Family Members',
      'es': '',
      'fr': '',
    },
    't6niyfcu': {
      'en': 'Elijah',
      'es': '',
      'fr': '',
    },
    'uvawr2yn': {
      'en': 'Charlotte',
      'es': '',
      'fr': '',
    },
    'ac86soj1': {
      'en': 'My Profile',
      'es': '',
      'fr': '',
    },
    'bx0cxhc9': {
      'en': 'My Rewards',
      'es': '',
      'fr': '',
    },
    'dajxof2n': {
      'en': 'Register',
      'es': '',
      'fr': '',
    },
  },
  // Register_Charity_01
  {
    '1m7xfq4e': {
      'en': 'Charity Registration',
      'es': 'Registro de caridad',
      'fr': 'Enregistrement d&#39;organisme de bienfaisance',
    },
    'k0uiyuz5': {
      'en': 'Nominate or Register A Fundraising Benificiary',
      'es': 'Designe o registre un beneficiario de recaudación de fondos',
      'fr': 'Nommez ou inscrivez un bénéficiaire de la collecte de fonds',
    },
    '9756ji4m': {
      'en': 'Create a new account',
      'es': 'Crea una cuenta nueva',
      'fr': 'Créer un nouveau compte',
    },
    'dlhsne41': {
      'en': 'Enter email id',
      'es': '',
      'fr': '',
    },
    'eb9aifn5': {
      'en': '****',
      'es': '****',
      'fr': '****',
    },
    '3qraxyhl': {
      'en': '****',
      'es': '****',
      'fr': '****',
    },
    'ih34fpe9': {
      'en': 'Back',
      'es': 'atrás',
      'fr': 'Retour',
    },
    '8y68w9b2': {
      'en': 'Next',
      'es': 'próximo',
      'fr': 'Suivant',
    },
    '1x87kfyd': {
      'en': 'Home',
      'es': '',
      'fr': '',
    },
  },
  // Register_Charity_02
  {
    '0s9sm8bj': {
      'en': 'Charity  Registration',
      'es': '',
      'fr': '',
    },
    'jkwtcu7e': {
      'en': '1',
      'es': '',
      'fr': '',
    },
    'yg9rvndk': {
      'en': '1',
      'es': '',
      'fr': '',
    },
    '9aevxoe2': {
      'en': 'Organization Details',
      'es': '',
      'fr': '',
    },
    'fzv2jti1': {
      'en': '2',
      'es': '',
      'fr': '',
    },
    'oqmovsbt': {
      'en': 'Contact Details',
      'es': '',
      'fr': '',
    },
    'n6bvxsj7': {
      'en': '3',
      'es': '',
      'fr': '',
    },
    '213baq7v': {
      'en': 'Event Selection',
      'es': '',
      'fr': '',
    },
    'rv6u2t0w': {
      'en': '4',
      'es': '',
      'fr': '',
    },
    'w8t9sa7k': {
      'en': 'Waiver & Confirmation',
      'es': '',
      'fr': '',
    },
    'ql685j98': {
      'en': '   Enter a value',
      'es': '',
      'fr': '',
    },
    '2mrpghp2': {
      'en': 'Play On!',
      'es': '',
      'fr': '',
    },
    'edpwyfx6': {
      'en': 'Please select...',
      'es': '',
      'fr': '',
    },
    'bef44y5x': {
      'en': '0001',
      'es': '',
      'fr': '',
    },
    '9tf2seqt': {
      'en': '',
      'es': '',
      'fr': '',
    },
    'ypnzwkk1': {
      'en': 'Enter a value',
      'es': '',
      'fr': '',
    },
    'tx3a8jit': {
      'en': 'Option 1',
      'es': '',
      'fr': '',
    },
    '67cyb82u': {
      'en': 'Please select...',
      'es': '',
      'fr': '',
    },
    '9hu7o9re': {
      'en': 'Choose File',
      'es': '',
      'fr': '',
    },
    'uhnup3ks': {
      'en': 'Back',
      'es': '',
      'fr': '',
    },
    'k4e4h4o9': {
      'en': 'Next',
      'es': '',
      'fr': '',
    },
    'ac7dujrn': {
      'en': 'Field is required',
      'es': '',
      'fr': '',
    },
    '1toe9ej7': {
      'en': 'Field is required',
      'es': '',
      'fr': '',
    },
    '4doojgnw': {
      'en': 'Field is required',
      'es': '',
      'fr': '',
    },
    't3o5h2tn': {
      'en': 'Field is required',
      'es': '',
      'fr': '',
    },
    'nc9qouyn': {
      'en': 'Field is required',
      'es': '',
      'fr': '',
    },
    'cz5d6sct': {
      'en': 'Field is required',
      'es': '',
      'fr': '',
    },
    'p8msaom6': {
      'en': 'Home',
      'es': '',
      'fr': '',
    },
  },
  // Register_Charity_03
  {
    'wz5m14q2': {
      'en': 'Charity Registration',
      'es': 'Registro de caridad',
      'fr': 'Enregistrement d&#39;organisme de bienfaisance',
    },
    'ntfb1ird': {
      'en': '1',
      'es': '1',
      'fr': '1',
    },
    '2n3fp345': {
      'en': 'Organization Details',
      'es': 'Detalles de la organización',
      'fr': 'Détails de l&#39;organisation',
    },
    'm8oajvar': {
      'en': '2',
      'es': '2',
      'fr': '2',
    },
    '0wcwm7yo': {
      'en': 'Contact Details',
      'es': 'Detalles de contacto',
      'fr': 'Détails du contact',
    },
    'ek3eon8m': {
      'en': '3',
      'es': '3',
      'fr': '3',
    },
    'ffwj2t2w': {
      'en': 'Event Selection',
      'es': 'Selección de eventos',
      'fr': 'Sélection d&#39;événement',
    },
    '7kqyvhv3': {
      'en': '4',
      'es': '4',
      'fr': '4',
    },
    '1rjhyqsu': {
      'en': 'Waiver & Confirmation',
      'es': 'Renuncia y Confirmación',
      'fr': 'Renonciation et confirmation',
    },
    '343ieao0': {
      'en': '2',
      'es': '',
      'fr': '',
    },
    'a7tk8rd9': {
      'en': 'Contact Information',
      'es': 'Información del contacto',
      'fr': 'Coordonnées',
    },
    '20usyn2z': {
      'en': 'Enter first name',
      'es': 'Ingrese el nombre',
      'fr': 'Entrez votre prénom',
    },
    '2p7zs3w3': {
      'en': ' Enter last name',
      'es': 'Introduzca el apellido',
      'fr': 'Entrer le nom de famille',
    },
    '58p7kp14': {
      'en': 'Enter a value',
      'es': 'Introduce un valor',
      'fr': 'Entrez une valeur',
    },
    'db8kg2i1': {
      'en': ' Enter email address',
      'es': 'Introducir la dirección de correo electrónico',
      'fr': 'Entrer l&#39;adresse e-mail',
    },
    'r6pvpx06': {
      'en': ' Enter a value',
      'es': 'Introduce un valor',
      'fr': 'Entrez une valeur',
    },
    '962l4b8i': {
      'en': ' Extn',
      'es': 'Ext.',
      'fr': 'Poste',
    },
    'rg6cuc1h': {
      'en': 'Enter a value',
      'es': 'Introduce un valor',
      'fr': 'Entrez une valeur',
    },
    'j82xl95j': {
      'en': 'Organization Address',
      'es': 'Dirección de la organización',
      'fr': 'Adresse de l&#39;organisation',
    },
    '1a9k3f3e': {
      'en': 'Enter value',
      'es': 'Introducir valor',
      'fr': 'Entrez la valeur',
    },
    'zswe65b7': {
      'en': 'Canada',
      'es': 'Canadá',
      'fr': 'Canada',
    },
    'p3ivl7l3': {
      'en': 'Please select...',
      'es': 'Por favor selecciona...',
      'fr': 'Veuillez sélectionner...',
    },
    'amuh8aik': {
      'en': 'Alberta',
      'es': '',
      'fr': '',
    },
    '0mvrxyn6': {
      'en': 'Please select...',
      'es': '',
      'fr': '',
    },
    '6x53w3zi': {
      'en': ' TOJOJO',
      'es': 'Introduzca el apellido',
      'fr': 'Entrer le nom de famille',
    },
    'xfsqmh43': {
      'en': 'Back',
      'es': 'atrás',
      'fr': 'Retour',
    },
    'n56brcwc': {
      'en': 'Next',
      'es': 'próximo',
      'fr': 'Suivant',
    },
    't910ehky': {
      'en': 'Home',
      'es': '',
      'fr': '',
    },
  },
  // Register_Charity_05
  {
    '3qv3klw3': {
      'en': 'Charity Registration',
      'es': '',
      'fr': '',
    },
    'b9cs5r38': {
      'en': '1',
      'es': '',
      'fr': '',
    },
    'rf37obi5': {
      'en': 'Organization Details',
      'es': '',
      'fr': '',
    },
    'sykxjy4c': {
      'en': '2',
      'es': '',
      'fr': '',
    },
    '199ynla5': {
      'en': 'Contact Details',
      'es': '',
      'fr': '',
    },
    'ck2yq57g': {
      'en': '3',
      'es': '',
      'fr': '',
    },
    'y93yc9ls': {
      'en': 'Event Selection',
      'es': '',
      'fr': '',
    },
    '7e85dwxs': {
      'en': '4',
      'es': '',
      'fr': '',
    },
    'hzcqgjgf': {
      'en': 'Waiver & Confirmation',
      'es': '',
      'fr': '',
    },
    'a749es5h': {
      'en': '4',
      'es': '',
      'fr': '',
    },
    'd274790h': {
      'en': 'Your Team Name is:',
      'es': '',
      'fr': '',
    },
    'eanrgq6e': {
      'en': 'London Giants (pending approval)',
      'es': '',
      'fr': '',
    },
    '55xoc7s6': {
      'en': 'Your playing in:',
      'es': '',
      'fr': '',
    },
    'p7mshq75': {
      'en': 'Event 1',
      'es': '',
      'fr': '',
    },
    '1ajlkn5c': {
      'en': 'WAIVER, RELEASE AND INDEMNIFICATION:',
      'es': '',
      'fr': '',
    },
    '0mktfy5j': {
      'en':
          'Every player, and his/her parent or guardian (if the player is under 18) must read. execute, and deliver this waiver to tournament organizers prior to the commencement of the tournament. in consideration of the right and opportunity to participate in the play On! street hockey tournament conducted by the not for profit organization play On! Canada (POC),and its licensed affiliates, the undersigned hereby acknowledges and agrees as follows: I (who am the participant\'s parent or legal guardian if the participant is under 18 year old) hereby consent to the use without compensation, of my/his/her name  and/or likeness, biographical material and/or voice in publicity and advertising concerning the play On! tournament by PPOC and/or any playOn! tournament partners or sponsored in any and all media and/or promotion and throughout the world. in addition, the undersigned (on behalf of the participant if the participant is under 18 years of age) forever generally and completely release and discharge and shall indemnify and hold harmless Play On! Canada and its employees, directors, officers, agents, sponsors, partners and licensees and each other party affiliated with play On! Canada and each of its owners, agents, directors, officers, employees, sponsors and partners(collectively, \"Event Organizers\") against and from any and all claims and demands of every kind and nature whatsoever, for damages or injuries ,actual or consequential, past, present or future, raising out of or in any   way related to the Play On! street hockey  tournament, including but not limited to any claims of injury from participating in OR observing the tournament, the loss of personal property by theft to otherwise during the tournament, any publicity related to the tournament, or any prizes   awarded. The undersigned acknowledges that of its own free will he/she has chosen to participate in the tournament and related activities. I understand and acknowledge that the aforementioned activities carry with them a high level of risk of injury  and additional hazards related thereto. i certify that i am  aware kof ,and accept, these increased risks and that i am mentally and physically prepared for the risks associated with the play On! street hockey tournament. This general release shall further apply to all unknown, unanticipated, unsuspected, and undisclosed claims, demands, liabilities, actions or causes of action, in law, equality or otherwise.  This Waiver shall bind heirs, personal representatives, and successors of the undersigned, and inure to the benefit of the Event Organizers.',
      'es': '',
      'fr': '',
    },
    '8hysqyae': {
      'en':
          'I HAVE READ AND UNDERSTAND THE TERMS OF THE ABOVE AGREEMENT, WILL COMPLY WITH TERMS HERE OF AND ACKNOWLEDGE THAT BY SIGNIG THIS FORM I AM GIVING UP LEGAL RIGHTS.',
      'es': '',
      'fr': '',
    },
    'rsuxa0bd': {
      'en': 'Date Of Birth',
      'es': '',
      'fr': '',
    },
    'pqn6p5ru': {
      'en': '1',
      'es': '',
      'fr': '',
    },
    '1vpveqmu': {
      'en': '2',
      'es': '',
      'fr': '',
    },
    'h6wktfit': {
      'en': '3',
      'es': '',
      'fr': '',
    },
    'a53kp64x': {
      'en': '4',
      'es': '',
      'fr': '',
    },
    '0h4swt5w': {
      'en': '5',
      'es': '',
      'fr': '',
    },
    'fduo21c7': {
      'en': '6',
      'es': '',
      'fr': '',
    },
    'de7rve6p': {
      'en': '7',
      'es': '',
      'fr': '',
    },
    'ju23xc01': {
      'en': '8',
      'es': '',
      'fr': '',
    },
    'y8ax68p1': {
      'en': '9',
      'es': '',
      'fr': '',
    },
    'lpzk9bul': {
      'en': '10',
      'es': '',
      'fr': '',
    },
    'vpts18m4': {
      'en': '11',
      'es': '',
      'fr': '',
    },
    'q5lo8igx': {
      'en': '12',
      'es': '',
      'fr': '',
    },
    '5z8yg0mf': {
      'en': '13',
      'es': '',
      'fr': '',
    },
    'im199wi5': {
      'en': '14',
      'es': '',
      'fr': '',
    },
    'xksm9fr2': {
      'en': '15',
      'es': '',
      'fr': '',
    },
    'zx7jp0pc': {
      'en': '16',
      'es': '',
      'fr': '',
    },
    'umkey7u8': {
      'en': '17',
      'es': '',
      'fr': '',
    },
    '00yl1331': {
      'en': '18',
      'es': '',
      'fr': '',
    },
    'd6ncvqzu': {
      'en': '19',
      'es': '',
      'fr': '',
    },
    '5l49hltz': {
      'en': '20',
      'es': '',
      'fr': '',
    },
    'pe2zwgzj': {
      'en': '21',
      'es': '',
      'fr': '',
    },
    'gkllrwxk': {
      'en': '22',
      'es': '',
      'fr': '',
    },
    'oecxiysu': {
      'en': '23',
      'es': '',
      'fr': '',
    },
    'dirin6tb': {
      'en': '24',
      'es': '',
      'fr': '',
    },
    '3wk13vv7': {
      'en': '25',
      'es': '',
      'fr': '',
    },
    '63kqxfxv': {
      'en': '26',
      'es': '',
      'fr': '',
    },
    'f49fmaeb': {
      'en': '27',
      'es': '',
      'fr': '',
    },
    '59xuvesk': {
      'en': '28',
      'es': '',
      'fr': '',
    },
    '1td0zjba': {
      'en': '29',
      'es': '',
      'fr': '',
    },
    'ps5fmpj3': {
      'en': '30',
      'es': '',
      'fr': '',
    },
    'ononfdd5': {
      'en': '31',
      'es': '',
      'fr': '',
    },
    'qhqizwb1': {
      'en': 'Day',
      'es': '',
      'fr': '',
    },
    '8osuq8mg': {
      'en': 'January',
      'es': '',
      'fr': '',
    },
    '49vin15x': {
      'en': 'February',
      'es': '',
      'fr': '',
    },
    'scm5vdnm': {
      'en': 'March',
      'es': '',
      'fr': '',
    },
    '1h0y8tto': {
      'en': 'April',
      'es': '',
      'fr': '',
    },
    '2bdgrrcw': {
      'en': 'May',
      'es': '',
      'fr': '',
    },
    'grxd78mx': {
      'en': 'June',
      'es': '',
      'fr': '',
    },
    '5dcr2gqp': {
      'en': 'July',
      'es': '',
      'fr': '',
    },
    '3dcv8erc': {
      'en': 'August',
      'es': '',
      'fr': '',
    },
    'efi00379': {
      'en': 'September',
      'es': '',
      'fr': '',
    },
    '5k72v9qy': {
      'en': 'October',
      'es': '',
      'fr': '',
    },
    'edalvqi3': {
      'en': 'November',
      'es': '',
      'fr': '',
    },
    '3unukx77': {
      'en': 'December',
      'es': '',
      'fr': '',
    },
    '33z6gh34': {
      'en': 'Month',
      'es': '',
      'fr': '',
    },
    'tavzdm9i': {
      'en': '1995',
      'es': '',
      'fr': '',
    },
    '1nd5nb5v': {
      'en': 'Year',
      'es': '',
      'fr': '',
    },
    '3kx8soy6': {
      'en': 'Age of participant',
      'es': '',
      'fr': '',
    },
    'jl2h8wye': {
      'en': 'Event Location(City) ',
      'es': '',
      'fr': '',
    },
    '1mdttgzj': {
      'en': 'Canada',
      'es': '',
      'fr': '',
    },
    'v7hs88yl': {
      'en': 'Please Select ',
      'es': '',
      'fr': '',
    },
    '67grrinj': {
      'en': 'Team Name',
      'es': '',
      'fr': '',
    },
    'vadnjp91': {
      'en': 'Signature',
      'es': '',
      'fr': '',
    },
    'ca089djn': {
      'en': 'Back',
      'es': '',
      'fr': '',
    },
    'q9voixzp': {
      'en': 'Next',
      'es': '',
      'fr': '',
    },
    'mmomz8yq': {
      'en': 'Home',
      'es': '',
      'fr': '',
    },
  },
  // Register_Charity_04
  {
    '4ojyf10u': {
      'en': 'Charity Registration',
      'es': '',
      'fr': '',
    },
    'gz23ek9l': {
      'en': '1',
      'es': '',
      'fr': '',
    },
    'qp5xq56i': {
      'en': 'Organization Details',
      'es': '',
      'fr': '',
    },
    '5o3zl8nh': {
      'en': '2',
      'es': '',
      'fr': '',
    },
    'gd9lnahf': {
      'en': 'Contact Details',
      'es': '',
      'fr': '',
    },
    'iovmsyjl': {
      'en': '3',
      'es': '',
      'fr': '',
    },
    'y8gbyrcc': {
      'en': 'Event Selection',
      'es': '',
      'fr': '',
    },
    'e2czcrnh': {
      'en': '4',
      'es': '',
      'fr': '',
    },
    'gacmrvvd': {
      'en': 'Waiver & Confirmation',
      'es': '',
      'fr': '',
    },
    '2ib9dzw6': {
      'en': '3',
      'es': '',
      'fr': '',
    },
    'jb4pd2vw': {
      'en': 'Alberta',
      'es': '',
      'fr': '',
    },
    'rg1dj30b': {
      'en': 'Please select...',
      'es': '',
      'fr': '',
    },
    's7s829yf': {
      'en': 'Alberta',
      'es': '',
      'fr': '',
    },
    'utflqlle': {
      'en': 'Please select...',
      'es': '',
      'fr': '',
    },
    '6vc5rwid': {
      'en': 'Alberta',
      'es': '',
      'fr': '',
    },
    'jz3rrol4': {
      'en': 'Please select...',
      'es': '',
      'fr': '',
    },
    'kuiw1mu3': {
      'en': 'Back',
      'es': '',
      'fr': '',
    },
    'xwcqtnif': {
      'en': 'Next',
      'es': '',
      'fr': '',
    },
    '7set3w6k': {
      'en': 'Home',
      'es': '',
      'fr': '',
    },
  },
  // Createteam
  {
    'ynda5v9g': {
      'en': 'Login',
      'es': 'Acceso',
      'fr': 'Connexion',
    },
    'jt8gwwwa': {
      'en': 'Menu',
      'es': 'Menú',
      'fr': 'Menu',
    },
    'dus6ilro': {
      'en': 'PlayOn! Store',
      'es': '¡Juega! Tienda',
      'fr': 'Jouer sur! Boutique',
    },
    '70gzjp2w': {
      'en': 'Go to the PlayOn! Store',
      'es': '¡Ve al PlayOn! Tienda',
      'fr': 'Rendez-vous sur PlayOn! Boutique',
    },
    'jqd55p2t': {
      'en': 'Select a family member whom you want to register as captaion',
      'es': '',
      'fr': '',
    },
    'k4l618i3': {
      'en': 'Members',
      'es': '',
      'fr': '',
    },
    'iyg2hogo': {
      'en': 'Member  1 :  Liam   24  1998  Male',
      'es': '',
      'fr': '',
    },
    'ow78uks7': {
      'en': 'Member  2 :  Emma   19  2003  Female',
      'es': '',
      'fr': '',
    },
    '3xfzn9p7': {
      'en': 'Member  3:  Charlotte   22  2022  Female',
      'es': '',
      'fr': '',
    },
    'dbh7ctsq': {
      'en': 'Member  4:  Oliver   26  1996  Male',
      'es': '',
      'fr': '',
    },
    '0r58texf': {
      'en': 'Member  5 :  Elijah   24  1998  Male',
      'es': '',
      'fr': '',
    },
    'nvljaw70': {
      'en': 'Back',
      'es': '',
      'fr': '',
    },
    'f6vdewbx': {
      'en': 'Continue',
      'es': '',
      'fr': '',
    },
    'boxwj9at': {
      'en': 'Register',
      'es': '',
      'fr': '',
    },
  },
  // Referee_RegList
  {
    'eres4gyk': {
      'en': 'Login',
      'es': 'Acceso',
      'fr': 'Connexion',
    },
    'lcgd6eyg': {
      'en': 'Menu',
      'es': 'Menú',
      'fr': 'Menu',
    },
    '3p9966j3': {
      'en': 'PlayOn! Store',
      'es': '¡Juega! Tienda',
      'fr': 'Jouer sur! Boutique',
    },
    'a3vme0sn': {
      'en': 'Go to the PlayOn! Store',
      'es': '¡Ve al PlayOn! Tienda',
      'fr': 'Rendez-vous sur PlayOn! Boutique',
    },
    'rrzg3w2e': {
      'en': 'Referee Management',
      'es': '',
      'fr': '',
    },
    'jlxcpypk': {
      'en': 'List of Registered Referees',
      'es': '',
      'fr': '',
    },
    '2ta8oo6r': {
      'en': 'Back',
      'es': '',
      'fr': '',
    },
    '45hliou8': {
      'en': 'Next',
      'es': '',
      'fr': '',
    },
    'dw785g5m': {
      'en': 'Register',
      'es': '',
      'fr': '',
    },
  },
  // Dashboard_Charity
  {
    'a0hm1nx3': {
      'en': 'Login',
      'es': '',
      'fr': '',
    },
    'a9em8zqn': {
      'en': 'Menu',
      'es': 'Menú',
      'fr': 'Menu',
    },
    'gsa41jd4': {
      'en': 'PlayOn! Store',
      'es': '¡Juega! Tienda',
      'fr': 'Jouer sur! Boutique',
    },
    'p784l53j': {
      'en': 'Go to the PlayOn! Store',
      'es': '¡Ve al PlayOn! Tienda',
      'fr': 'Rendez-vous sur PlayOn! Boutique',
    },
    'o3zs9918': {
      'en': 'My Profile',
      'es': '',
      'fr': '',
    },
    '2gh9xyqc': {
      'en': 'Register',
      'es': '',
      'fr': '',
    },
  },
  // Captain_MyTeams
  {
    '7s3iumzh': {
      'en': 'Login',
      'es': '',
      'fr': '',
    },
    'yux1mym6': {
      'en': 'Menu',
      'es': 'Menú',
      'fr': 'Menu',
    },
    'djpe8ibe': {
      'en': 'PlayOn! Store',
      'es': '¡Juega! Tienda',
      'fr': 'Jouer sur! Boutique',
    },
    'nfos0ati': {
      'en': 'Go to the PlayOn! Store',
      'es': '¡Ve al PlayOn! Tienda',
      'fr': 'Rendez-vous sur PlayOn! Boutique',
    },
    '1jb0txno': {
      'en': 'My Teams',
      'es': '',
      'fr': '',
    },
    'e0o7t5sn': {
      'en': 'Active Teams',
      'es': '',
      'fr': '',
    },
    'd0isppon': {
      'en': 'Create Team',
      'es': '',
      'fr': '',
    },
    '2ykzbusk': {
      'en': 'Invite Players',
      'es': '',
      'fr': '',
    },
    'dg1eahtd': {
      'en': 'Invite Fans',
      'es': '',
      'fr': '',
    },
    'z3j0u8g8': {
      'en': 'Create Team',
      'es': '',
      'fr': '',
    },
    'zixii7ea': {
      'en': 'Team History',
      'es': '',
      'fr': '',
    },
    '1fsv5x8p': {
      'en': 'Tab View 2',
      'es': '',
      'fr': '',
    },
    'afkowu7n': {
      'en': 'Cancel',
      'es': '',
      'fr': '',
    },
    'd7fy3gz2': {
      'en': 'Register',
      'es': '',
      'fr': '',
    },
  },
  // Register_Volunteer_00
  {
    'lz2byjrb': {
      'en': 'Menu',
      'es': 'Menú',
      'fr': 'Menu',
    },
    '2t6swagv': {
      'en': 'PlayOn! Store',
      'es': '¡Juega! Tienda',
      'fr': 'Jouer sur! Boutique',
    },
    'jgufn2p1': {
      'en': 'Go to the PlayOn! Store',
      'es': '¡Ve al PlayOn! Tienda',
      'fr': 'Rendez-vous sur PlayOn! Boutique',
    },
    'gicbdqii': {
      'en': 'Volunteer Registration',
      'es': '',
      'fr': '',
    },
    'n1on68vt': {
      'en':
          'As Play On! Canada continues to work towards brining Play On! back to communities across the country in this year, we want to keep you, or fans, up-to-date on our progress.\n\nBy completing this form you are advising us your availability and interests as Volunteer so that you can be one of the first in line to be involved when we return...bigger and better than ever',
      'es': '',
      'fr': '',
    },
    'px3nhcog': {
      'en': 'Watch Online',
      'es': '',
      'fr': '',
    },
    'limmkace': {
      'en': 'Back',
      'es': '',
      'fr': '',
    },
    '4hksjhx3': {
      'en': 'Next',
      'es': '',
      'fr': '',
    },
    'safnyvoc': {
      'en': 'Register',
      'es': '',
      'fr': '',
    },
  },
  // Register_Volunteer_01
  {
    'edd0imct': {
      'en': 'Menu',
      'es': 'Menú',
      'fr': 'Menu',
    },
    'tbe56nyt': {
      'en': 'PlayOn! Store',
      'es': '¡Juega! Tienda',
      'fr': 'Jouer sur! Boutique',
    },
    'y2yerz19': {
      'en': 'Go to the PlayOn! Store',
      'es': '¡Ve al PlayOn! Tienda',
      'fr': 'Rendez-vous sur PlayOn! Boutique',
    },
    'i73ysdlq': {
      'en': 'Volunteer Registration',
      'es': '',
      'fr': '',
    },
    'gytqg1ni': {
      'en': '1',
      'es': '',
      'fr': '',
    },
    '9ilzoaxc': {
      'en': '1',
      'es': '',
      'fr': '',
    },
    '3cx7thaa': {
      'en': 'Personal Information',
      'es': '',
      'fr': '',
    },
    'az1ipdig': {
      'en': '2',
      'es': '',
      'fr': '',
    },
    '495aylxa': {
      'en': 'Expression of Interest',
      'es': '',
      'fr': '',
    },
    '1mm8s4lu': {
      'en': '3',
      'es': '',
      'fr': '',
    },
    'jyfi25c7': {
      'en': 'Skills and Certifications',
      'es': '',
      'fr': '',
    },
    'g5rjmqwh': {
      'en': '4',
      'es': '',
      'fr': '',
    },
    'vp9cf7vh': {
      'en': 'Pre Events Details',
      'es': '',
      'fr': '',
    },
    'ghxeijtd': {
      'en': '5',
      'es': '',
      'fr': '',
    },
    'xmkmhbaq': {
      'en': 'Event Selection',
      'es': '',
      'fr': '',
    },
    'lvj8sfsh': {
      'en': '6',
      'es': '',
      'fr': '',
    },
    '6gk46nby': {
      'en': 'Availability',
      'es': '',
      'fr': '',
    },
    'qqp0aikj': {
      'en': '7',
      'es': '',
      'fr': '',
    },
    'pf9x02oe': {
      'en': 'Wavier',
      'es': '',
      'fr': '',
    },
    '2n30kmgz': {
      'en': '8',
      'es': '',
      'fr': '',
    },
    '1g5lj0sh': {
      'en': 'Payment',
      'es': '',
      'fr': '',
    },
    '0g1ce7bc': {
      'en': '9',
      'es': '',
      'fr': '',
    },
    'kord4goy': {
      'en': 'Confirmation',
      'es': '',
      'fr': '',
    },
    '9b2kv3ht': {
      'en': 'Enter your first name',
      'es': '',
      'fr': '',
    },
    'ogvuk29r': {
      'en': 'Enter your last name',
      'es': '',
      'fr': '',
    },
    'v9xxp8it': {
      'en': 'Enter mobile number',
      'es': '',
      'fr': '',
    },
    'p8gkmzsu': {
      'en': 'Enter your email address',
      'es': '',
      'fr': '',
    },
    'mnxxywh5': {
      'en': 'Enter your address details',
      'es': '',
      'fr': '',
    },
    'vp1sin5d': {
      'en': 'Enter your address details',
      'es': '',
      'fr': '',
    },
    'ayz0d097': {
      'en': 'Enter your city details',
      'es': '',
      'fr': '',
    },
    '7lt1dcdg': {
      'en': 'Canada',
      'es': '',
      'fr': '',
    },
    '5pokgox3': {
      'en': 'USA',
      'es': '',
      'fr': '',
    },
    '2tb2c4k2': {
      'en': 'Select one',
      'es': '',
      'fr': '',
    },
    'y58vy6m2': {
      'en': 'Canada',
      'es': '',
      'fr': '',
    },
    '99ev9bqg': {
      'en': 'USA',
      'es': '',
      'fr': '',
    },
    'xtp25zrw': {
      'en': 'Other',
      'es': '',
      'fr': '',
    },
    'fwfqf10a': {
      'en': 'Select one',
      'es': '',
      'fr': '',
    },
    '283kvsfz': {
      'en': 'A1A 1A1',
      'es': '',
      'fr': '',
    },
    '85twqy8d': {
      'en': 'Back',
      'es': '',
      'fr': '',
    },
    'jdxndc4g': {
      'en': 'Next',
      'es': '',
      'fr': '',
    },
    'rzhs1j9q': {
      'en': 'Register',
      'es': '',
      'fr': '',
    },
  },
  // Register_Volunteer_02
  {
    'vbzk8g9a': {
      'en': 'Menu',
      'es': 'Menú',
      'fr': 'Menu',
    },
    '5eg1j2qa': {
      'en': 'PlayOn! Store',
      'es': '¡Juega! Tienda',
      'fr': 'Jouer sur! Boutique',
    },
    't6w1lqh7': {
      'en': 'Go to the PlayOn! Store',
      'es': '¡Ve al PlayOn! Tienda',
      'fr': 'Rendez-vous sur PlayOn! Boutique',
    },
    'pmunkeul': {
      'en': 'Volunteer Registration',
      'es': '',
      'fr': '',
    },
    '3wme1jgb': {
      'en': '2',
      'es': '',
      'fr': '',
    },
    'ut2yoq3l': {
      'en': '1',
      'es': '',
      'fr': '',
    },
    'tq145wid': {
      'en': 'Personal Information',
      'es': '',
      'fr': '',
    },
    'g8nybt5u': {
      'en': '2',
      'es': '',
      'fr': '',
    },
    'r0yf7art': {
      'en': 'Expression of Interest',
      'es': '',
      'fr': '',
    },
    'xe776fnz': {
      'en': '3',
      'es': '',
      'fr': '',
    },
    'q2o9q5zv': {
      'en': 'Skills and Certifications',
      'es': '',
      'fr': '',
    },
    'ufard0ze': {
      'en': '4',
      'es': '',
      'fr': '',
    },
    'z9x5hl9i': {
      'en': 'Pre Events Details',
      'es': '',
      'fr': '',
    },
    'xv7avmx5': {
      'en': '5',
      'es': '',
      'fr': '',
    },
    '2cpk78o9': {
      'en': 'Event Selection',
      'es': '',
      'fr': '',
    },
    'idrqdsnj': {
      'en': '6',
      'es': '',
      'fr': '',
    },
    'kk863qfb': {
      'en': 'Availability',
      'es': '',
      'fr': '',
    },
    'jjy56wro': {
      'en': '7',
      'es': '',
      'fr': '',
    },
    'ad0zocsc': {
      'en': 'Wavier',
      'es': '',
      'fr': '',
    },
    'p6wnpdki': {
      'en': '8',
      'es': '',
      'fr': '',
    },
    '88lfar75': {
      'en': 'Payment',
      'es': '',
      'fr': '',
    },
    '2fw6cqyh': {
      'en': '9',
      'es': '',
      'fr': '',
    },
    'bvupmbae': {
      'en': 'Confirmation',
      'es': '',
      'fr': '',
    },
    'n8jd5xh3': {
      'en': 'Your answer',
      'es': '',
      'fr': '',
    },
    'eqle6bq4': {
      'en': 'Yes',
      'es': '',
      'fr': '',
    },
    'qx26ko4x': {
      'en': 'No',
      'es': '',
      'fr': '',
    },
    'ommo4csf': {
      'en': 'Select one',
      'es': '',
      'fr': '',
    },
    'j63wq3m1': {
      'en': 'Your answer',
      'es': '',
      'fr': '',
    },
    'xzvkztfk': {
      'en':
          'Plesae tell us the top 3 areas that you would like to volunteer in',
      'es': '',
      'fr': '',
    },
    '89szawz8': {
      'en': 'Administration',
      'es': '',
      'fr': '',
    },
    's1pokw0w': {
      'en': 'Ambassador Program',
      'es': '',
      'fr': '',
    },
    'r9qkktw2': {
      'en': 'Graphic Design',
      'es': '',
      'fr': '',
    },
    'dyfciqqw': {
      'en': 'Logistics',
      'es': '',
      'fr': '',
    },
    'my3y0gqy': {
      'en': 'Marketing',
      'es': '',
      'fr': '',
    },
    '37e5nf32': {
      'en': 'Operations',
      'es': '',
      'fr': '',
    },
    'ww7jf5kw': {
      'en': 'Photography',
      'es': '',
      'fr': '',
    },
    'zuy041q0': {
      'en': 'Referee',
      'es': '',
      'fr': '',
    },
    'yfyvudug': {
      'en': 'Registration',
      'es': '',
      'fr': '',
    },
    'kj5c5174': {
      'en': 'Social Media',
      'es': '',
      'fr': '',
    },
    'k72v756l': {
      'en': 'Sport Operations',
      'es': '',
      'fr': '',
    },
    'ihudnyg7': {
      'en': 'Volunteer Services',
      'es': '',
      'fr': '',
    },
    'k9nzhy7n': {
      'en': 'Reference 1',
      'es': '',
      'fr': '',
    },
    'ueo3mt67': {
      'en': 'Enter first name',
      'es': '',
      'fr': '',
    },
    'heesw0eq': {
      'en': 'Enter last name',
      'es': '',
      'fr': '',
    },
    '3i25k63w': {
      'en': 'Enter contact information',
      'es': '',
      'fr': '',
    },
    'r992rhjp': {
      'en': 'Enter email address',
      'es': '',
      'fr': '',
    },
    '5x4d97qj': {
      'en': 'Enter a value',
      'es': '',
      'fr': '',
    },
    'cd8f256q': {
      'en': 'Reference 2',
      'es': '',
      'fr': '',
    },
    'bm453z2p': {
      'en': 'Enter first name',
      'es': '',
      'fr': '',
    },
    'k1awv7hi': {
      'en': 'Enter last name',
      'es': '',
      'fr': '',
    },
    'hjwzel31': {
      'en': 'Enter contact information',
      'es': '',
      'fr': '',
    },
    't61ruau4': {
      'en': 'Enter email address',
      'es': '',
      'fr': '',
    },
    'dchd6e7z': {
      'en': 'Enter a value',
      'es': '',
      'fr': '',
    },
    'ndpvck99': {
      'en': 'Back',
      'es': '',
      'fr': '',
    },
    'isi87isa': {
      'en': 'Next',
      'es': '',
      'fr': '',
    },
    'u3s6iwvt': {
      'en': 'Register',
      'es': '',
      'fr': '',
    },
  },
  // Register_Volunteer_03
  {
    'g683mdv3': {
      'en': 'Menu',
      'es': 'Menú',
      'fr': 'Menu',
    },
    'n0yol41b': {
      'en': 'PlayOn! Store',
      'es': '¡Juega! Tienda',
      'fr': 'Jouer sur! Boutique',
    },
    'ljjeyk1z': {
      'en': 'Go to the PlayOn! Store',
      'es': '¡Ve al PlayOn! Tienda',
      'fr': 'Rendez-vous sur PlayOn! Boutique',
    },
    'p8y6xvhb': {
      'en': 'Volunteer Registration',
      'es': '',
      'fr': '',
    },
    'vcuguziz': {
      'en': '3',
      'es': '',
      'fr': '',
    },
    '5ez8i4ic': {
      'en': '1',
      'es': '',
      'fr': '',
    },
    'b3pr849y': {
      'en': 'Personal Information',
      'es': '',
      'fr': '',
    },
    '0k6ms0uk': {
      'en': '2',
      'es': '',
      'fr': '',
    },
    'a0ijgwc2': {
      'en': 'Expression of Interest',
      'es': '',
      'fr': '',
    },
    'o671cb2y': {
      'en': '3',
      'es': '',
      'fr': '',
    },
    'efqvj1tr': {
      'en': 'Skills and Certifications',
      'es': '',
      'fr': '',
    },
    'goyqj5h7': {
      'en': '4',
      'es': '',
      'fr': '',
    },
    'bcn9iuwz': {
      'en': 'Pre Events Details',
      'es': '',
      'fr': '',
    },
    'okp9025k': {
      'en': '5',
      'es': '',
      'fr': '',
    },
    'd1nspbaw': {
      'en': 'Event Selection',
      'es': '',
      'fr': '',
    },
    '656g8so9': {
      'en': '6',
      'es': '',
      'fr': '',
    },
    'j6k64pjo': {
      'en': 'Availability',
      'es': '',
      'fr': '',
    },
    'unwcoonr': {
      'en': '7',
      'es': '',
      'fr': '',
    },
    'fci58kb0': {
      'en': 'Wavier',
      'es': '',
      'fr': '',
    },
    'm8pn26si': {
      'en': '8',
      'es': '',
      'fr': '',
    },
    'p52ts6op': {
      'en': 'Payment',
      'es': '',
      'fr': '',
    },
    'v3w7uc4w': {
      'en': '9',
      'es': '',
      'fr': '',
    },
    'lzu0o3dq': {
      'en': 'Confirmation',
      'es': '',
      'fr': '',
    },
    'oggynjdq': {
      'en': 'Enter your answer',
      'es': '',
      'fr': '',
    },
    '1grarry4': {
      'en': 'Enter your answer',
      'es': '',
      'fr': '',
    },
    '57d7tlbi': {
      'en': 'Pre-Event promotions',
      'es': '',
      'fr': '',
    },
    '9mrhzwwu': {
      'en': 'Registration',
      'es': '',
      'fr': '',
    },
    'kdbh4rhf': {
      'en': 'Check In',
      'es': '',
      'fr': '',
    },
    'uqh1c3p2': {
      'en': 'Marketing',
      'es': '',
      'fr': '',
    },
    'cx199sfl': {
      'en': 'Social Media',
      'es': '',
      'fr': '',
    },
    '592uepwx': {
      'en': 'Administration',
      'es': '',
      'fr': '',
    },
    '2zu2czqe': {
      'en': 'Scoreboard',
      'es': '',
      'fr': '',
    },
    '36mbxow6': {
      'en': 'Rink Monitor',
      'es': '',
      'fr': '',
    },
    'uj9z93m2': {
      'en': 'Time keeping',
      'es': '',
      'fr': '',
    },
    '1zwa3e57': {
      'en': 'Referee Assistant',
      'es': '',
      'fr': '',
    },
    '7hjklgwv': {
      'en': 'Green Team',
      'es': '',
      'fr': '',
    },
    '3c5r5xw9': {
      'en': 'Traffic Control',
      'es': '',
      'fr': '',
    },
    't4dcmhwl': {
      'en': 'Security',
      'es': '',
      'fr': '',
    },
    '10es6rdo': {
      'en': 'Thirst bench',
      'es': '',
      'fr': '',
    },
    'wp1djurq': {
      'en': 'Event Set up',
      'es': '',
      'fr': '',
    },
    'mhneau1h': {
      'en': 'Event tear down',
      'es': '',
      'fr': '',
    },
    'lb15n5vn': {
      'en': 'Runner',
      'es': '',
      'fr': '',
    },
    'gpttlpgp': {
      'en': 'Prizing',
      'es': '',
      'fr': '',
    },
    'sv9gvszo': {
      'en': 'Photography',
      'es': '',
      'fr': '',
    },
    '2vkslstj': {
      'en': 'Champtionship t-shirts',
      'es': '',
      'fr': '',
    },
    'xsllkhnz': {
      'en': 'Awards presentation',
      'es': '',
      'fr': '',
    },
    '7hkhnws5': {
      'en': 'National Anthem',
      'es': '',
      'fr': '',
    },
    '6cunmnn0': {
      'en': 'Vendor management',
      'es': '',
      'fr': '',
    },
    'g7yh1m8v': {
      'en': 'Referee',
      'es': '',
      'fr': '',
    },
    'sps16xoo': {
      'en': 'Select one',
      'es': '',
      'fr': '',
    },
    'i5x7w75y': {
      'en': 'Back',
      'es': '',
      'fr': '',
    },
    'c5cugw2p': {
      'en': 'Next',
      'es': '',
      'fr': '',
    },
    'c06mmqc5': {
      'en': 'Register',
      'es': '',
      'fr': '',
    },
  },
  // Register_Volunteer_04
  {
    'z67j9jlq': {
      'en': 'Menu',
      'es': 'Menú',
      'fr': 'Menu',
    },
    'kljzmpl6': {
      'en': 'PlayOn! Store',
      'es': '¡Juega! Tienda',
      'fr': 'Jouer sur! Boutique',
    },
    '0y72p9qi': {
      'en': 'Go to the PlayOn! Store',
      'es': '¡Ve al PlayOn! Tienda',
      'fr': 'Rendez-vous sur PlayOn! Boutique',
    },
    '9kllv8aq': {
      'en': 'Volunteer Registration',
      'es': '',
      'fr': '',
    },
    'epr6kgu7': {
      'en': '4',
      'es': '',
      'fr': '',
    },
    'dc951rpc': {
      'en': '1',
      'es': '',
      'fr': '',
    },
    'vafukvvn': {
      'en': 'Personal Information',
      'es': '',
      'fr': '',
    },
    'pexvyfpc': {
      'en': '2',
      'es': '',
      'fr': '',
    },
    'ekjjbx4z': {
      'en': 'Expression of Interest',
      'es': '',
      'fr': '',
    },
    'xf6a1l8h': {
      'en': '3',
      'es': '',
      'fr': '',
    },
    'f11qmlza': {
      'en': 'Skills and Certifications',
      'es': '',
      'fr': '',
    },
    'xybq2ext': {
      'en': '4',
      'es': '',
      'fr': '',
    },
    'bvftj1g4': {
      'en': 'Pre Events Details',
      'es': '',
      'fr': '',
    },
    'imw0wira': {
      'en': '5',
      'es': '',
      'fr': '',
    },
    'vkoi5y5w': {
      'en': 'Event Selection',
      'es': '',
      'fr': '',
    },
    'btev0hnb': {
      'en': '6',
      'es': '',
      'fr': '',
    },
    'f8mhsvvu': {
      'en': 'Availability',
      'es': '',
      'fr': '',
    },
    'owhmfgn0': {
      'en': '7',
      'es': '',
      'fr': '',
    },
    'v4q1fyb6': {
      'en': 'Wavier',
      'es': '',
      'fr': '',
    },
    'xsq1zh60': {
      'en': '8',
      'es': '',
      'fr': '',
    },
    '5mjft3lk': {
      'en': 'Payment',
      'es': '',
      'fr': '',
    },
    'g89e9rr0': {
      'en': '9',
      'es': '',
      'fr': '',
    },
    'am3lw6t9': {
      'en': 'Confirmation',
      'es': '',
      'fr': '',
    },
    'ccrbj3na': {
      'en': 'Yes',
      'es': '',
      'fr': '',
    },
    'ouo2fgom': {
      'en': 'No',
      'es': '',
      'fr': '',
    },
    '0ngg026s': {
      'en': 'Select one',
      'es': '',
      'fr': '',
    },
    'k5a9ad1l': {
      'en': 'Yes',
      'es': '',
      'fr': '',
    },
    'r3osrbbg': {
      'en': 'No',
      'es': '',
      'fr': '',
    },
    'a4wqtsb1': {
      'en': 'May be',
      'es': '',
      'fr': '',
    },
    'wgujmyhr': {
      'en': 'Select one',
      'es': '',
      'fr': '',
    },
    'zibu7jp1': {
      'en': 'Enter your answer',
      'es': '',
      'fr': '',
    },
    '2wm8navz': {
      'en': 'Enter your answer',
      'es': '',
      'fr': '',
    },
    '5lkoyj8h': {
      'en': 'Enter your answer',
      'es': '',
      'fr': '',
    },
    '7okdryik': {
      'en': 'Back',
      'es': '',
      'fr': '',
    },
    'bynr0p6t': {
      'en': 'Next',
      'es': '',
      'fr': '',
    },
    '8sx8en28': {
      'en': 'Register',
      'es': '',
      'fr': '',
    },
  },
  // Register_Volunteer_05
  {
    'vs4x2sea': {
      'en': 'Menu',
      'es': 'Menú',
      'fr': 'Menu',
    },
    '8214iyf6': {
      'en': 'PlayOn! Store',
      'es': '¡Juega! Tienda',
      'fr': 'Jouer sur! Boutique',
    },
    '6ogid8i2': {
      'en': 'Go to the PlayOn! Store',
      'es': '¡Ve al PlayOn! Tienda',
      'fr': 'Rendez-vous sur PlayOn! Boutique',
    },
    'c3t6tgeh': {
      'en': 'Volunteer Registration',
      'es': '',
      'fr': '',
    },
    'qcr6b51t': {
      'en': '5',
      'es': '',
      'fr': '',
    },
    'zxi8zn20': {
      'en': '1',
      'es': '',
      'fr': '',
    },
    '6i3nlttd': {
      'en': 'Personal Information',
      'es': '',
      'fr': '',
    },
    'wgqsjt1z': {
      'en': '2',
      'es': '',
      'fr': '',
    },
    'bagc122w': {
      'en': 'Expression of Interest',
      'es': '',
      'fr': '',
    },
    'lpay26ax': {
      'en': '3',
      'es': '',
      'fr': '',
    },
    'xvsqoxy6': {
      'en': 'Skills and Certifications',
      'es': '',
      'fr': '',
    },
    'dn6ae2i2': {
      'en': '4',
      'es': '',
      'fr': '',
    },
    'rbp2rzxw': {
      'en': 'Pre Events Details',
      'es': '',
      'fr': '',
    },
    '3709ouzw': {
      'en': '5',
      'es': '',
      'fr': '',
    },
    'rm1ed2g9': {
      'en': 'Event Selection',
      'es': '',
      'fr': '',
    },
    'baiulhuc': {
      'en': '6',
      'es': '',
      'fr': '',
    },
    'b1h2glaw': {
      'en': 'Availability',
      'es': '',
      'fr': '',
    },
    'df3m7k7d': {
      'en': '7',
      'es': '',
      'fr': '',
    },
    'd1fva691': {
      'en': 'Wavier',
      'es': '',
      'fr': '',
    },
    'lwzw78np': {
      'en': '8',
      'es': '',
      'fr': '',
    },
    'yiqjdh1t': {
      'en': 'Payment',
      'es': '',
      'fr': '',
    },
    'cdp8kdbo': {
      'en': '9',
      'es': '',
      'fr': '',
    },
    'ycz56on9': {
      'en': 'Confirmation',
      'es': '',
      'fr': '',
    },
    'eu3xpone': {
      'en': 'Please confirm your availability for the selected events',
      'es': '',
      'fr': '',
    },
    'kfxcweeu': {
      'en': 'Back',
      'es': '',
      'fr': '',
    },
    'thzbctfk': {
      'en': 'Next',
      'es': '',
      'fr': '',
    },
    's0ruwk6r': {
      'en': 'Register',
      'es': '',
      'fr': '',
    },
  },
  // Register_Volunteer_06
  {
    '042e4hmq': {
      'en': 'Menu',
      'es': 'Menú',
      'fr': 'Menu',
    },
    '1swltqtw': {
      'en': 'PlayOn! Store',
      'es': '¡Juega! Tienda',
      'fr': 'Jouer sur! Boutique',
    },
    'xh3ejil3': {
      'en': 'Go to the PlayOn! Store',
      'es': '¡Ve al PlayOn! Tienda',
      'fr': 'Rendez-vous sur PlayOn! Boutique',
    },
    'lx0rokyh': {
      'en': 'Volunteer Registration',
      'es': '',
      'fr': '',
    },
    'k3nkbraa': {
      'en': '6',
      'es': '',
      'fr': '',
    },
    '0o44c8vy': {
      'en': '1',
      'es': '',
      'fr': '',
    },
    'yexls2qd': {
      'en': 'Personal Information',
      'es': '',
      'fr': '',
    },
    'x8zt7fod': {
      'en': '2',
      'es': '',
      'fr': '',
    },
    'ykglmemz': {
      'en': 'Expression of Interest',
      'es': '',
      'fr': '',
    },
    'a9w5343b': {
      'en': '3',
      'es': '',
      'fr': '',
    },
    '3la2wy5q': {
      'en': 'Skills and Certifications',
      'es': '',
      'fr': '',
    },
    'ks8z4a4z': {
      'en': '4',
      'es': '',
      'fr': '',
    },
    'j0aohrtk': {
      'en': 'Pre Events Details',
      'es': '',
      'fr': '',
    },
    'aye73n9b': {
      'en': '5',
      'es': '',
      'fr': '',
    },
    '6ostnyyy': {
      'en': 'Event Selection',
      'es': '',
      'fr': '',
    },
    '3pl3jusj': {
      'en': '6',
      'es': '',
      'fr': '',
    },
    'sivk9weh': {
      'en': 'Availability',
      'es': '',
      'fr': '',
    },
    'g6tnn3gw': {
      'en': '7',
      'es': '',
      'fr': '',
    },
    '5xtptvcg': {
      'en': 'Wavier',
      'es': '',
      'fr': '',
    },
    'mj9q4hnn': {
      'en': '8',
      'es': '',
      'fr': '',
    },
    'bbju1i03': {
      'en': 'Payment',
      'es': '',
      'fr': '',
    },
    'ucea1qly': {
      'en': '9',
      'es': '',
      'fr': '',
    },
    'n0rqavtt': {
      'en': 'Confirmation',
      'es': '',
      'fr': '',
    },
    'as7p4pr3': {
      'en': 'Back',
      'es': '',
      'fr': '',
    },
    'auc3a624': {
      'en': 'Next',
      'es': '',
      'fr': '',
    },
    'a1ajf4il': {
      'en': 'Register',
      'es': '',
      'fr': '',
    },
  },
  // Register_Volunteer_07
  {
    '3vngbcng': {
      'en': 'Menu',
      'es': 'Menú',
      'fr': 'Menu',
    },
    'zlglvss5': {
      'en': 'PlayOn! Store',
      'es': '¡Juega! Tienda',
      'fr': 'Jouer sur! Boutique',
    },
    'af08473n': {
      'en': 'Go to the PlayOn! Store',
      'es': '¡Ve al PlayOn! Tienda',
      'fr': 'Rendez-vous sur PlayOn! Boutique',
    },
    'upp3hd38': {
      'en': 'Volunteer Registration',
      'es': '',
      'fr': '',
    },
    '3clpiibn': {
      'en': '7',
      'es': '',
      'fr': '',
    },
    'd268lbbn': {
      'en': '1',
      'es': '',
      'fr': '',
    },
    'ony6prfp': {
      'en': 'Personal Information',
      'es': '',
      'fr': '',
    },
    'fp93f5q1': {
      'en': '2',
      'es': '',
      'fr': '',
    },
    'j5ff8u7o': {
      'en': 'Expression of Interest',
      'es': '',
      'fr': '',
    },
    'wocsr3z7': {
      'en': '3',
      'es': '',
      'fr': '',
    },
    '2qkwbgh2': {
      'en': 'Skills and Certifications',
      'es': '',
      'fr': '',
    },
    'rfxqqbe6': {
      'en': '4',
      'es': '',
      'fr': '',
    },
    'bdahb19z': {
      'en': 'Pre Events Details',
      'es': '',
      'fr': '',
    },
    'yeh8el3x': {
      'en': '5',
      'es': '',
      'fr': '',
    },
    'phkd2skg': {
      'en': 'Event Selection',
      'es': '',
      'fr': '',
    },
    'qvvt4e4j': {
      'en': '6',
      'es': '',
      'fr': '',
    },
    'l8r4qk1x': {
      'en': 'Availability',
      'es': '',
      'fr': '',
    },
    'f7mg0t64': {
      'en': '7',
      'es': '',
      'fr': '',
    },
    '6wlksx4l': {
      'en': 'Wavier',
      'es': '',
      'fr': '',
    },
    '7pl5aj6z': {
      'en': '8',
      'es': '',
      'fr': '',
    },
    'f3sjc9wk': {
      'en': 'Payment',
      'es': '',
      'fr': '',
    },
    'tssp6nef': {
      'en': '9',
      'es': '',
      'fr': '',
    },
    '4bvnocjd': {
      'en': 'Confirmation',
      'es': '',
      'fr': '',
    },
    '3o4547qm': {
      'en': 'WAIVER, RELEASE AND INDEMNIFICATION:',
      'es': '',
      'fr': '',
    },
    '51ousn8c': {
      'en':
          'Every player, and his/her parent or guardian (if the player is under 18) must read. execute, and deliver this waiver to tournament organizers prior to the commencement of the tournament. in consideration of the right and opportunity to participate in the play On! street hockey tournament conducted by the not for profit organization play On! Canada (POC),and its licensed affiliates, the undersigned hereby acknowledges and agrees as follows: I (who am the participant\'s parent or legal guardian if the participant is under 18 year old) hereby consent to the use without compensation, of my/his/her name  and/or likeness, biographical material and/or voice in publicity and advertising concerning the play On! tournament by PPOC and/or any playOn! tournament partners or sponsored in any and all media and/or promotion and throughout the world. in addition, the undersigned (on behalf of the participant if the participant is under 18 years of age) forever generally and completely release and discharge and shall indemnify and hold harmless Play On! Canada and its employees, directors, officers, agents, sponsors, partners and licensees and each other party affiliated with play On! Canada and each of its owners, agents, directors, officers, employees, sponsors and partners(collectively, \"Event Organizers\") against and from any and all claims and demands of every kind and nature whatsoever, for damages or injuries ,actual or consequential, past, present or future, raising out of or in any   way related to the Play On! street hockey  tournament, including but not limited to any claims of injury from participating in OR observing the tournament, the loss of personal property by theft to otherwise during the tournament, any publicity related to the tournament, or any prizes   awarded. The undersigned acknowledges that of its own free will he/she has chosen to participate in the tournament and related activities. I understand and acknowledge that the aforementioned activities carry with them a high level of risk of injury  and additional hazards related thereto. i certify that i am  aware kof ,and accept, these increased risks and that i am mentally and physically prepared for the risks associated with the play On! street hockey tournament. This general release shall further apply to all unknown, unanticipated, unsuspected, and undisclosed claims, demands, liabilities, actions or causes of action, in law, equality or otherwise.  This Waiver shall bind heirs, personal representatives, and successors of the undersigned, and inure to the benefit of the Event Organizers.',
      'es': '',
      'fr': '',
    },
    'h07b5nmq': {
      'en':
          'I HAVE READ AND UNDERSTAND THE TERMS OF THE ABOVE AGREEMENT, WILL COMPLY WITH TERMS HERE OF AND ACKNOWLEDGE THAT BY SIGNIG THIS FORM I AM GIVING UP LEGAL RIGHTS.',
      'es': '',
      'fr': '',
    },
    'hx37oc69': {
      'en': 'Date Of Birth',
      'es': '',
      'fr': '',
    },
    '1zo5adgg': {
      'en': '1',
      'es': '',
      'fr': '',
    },
    'inlhqi3l': {
      'en': '2',
      'es': '',
      'fr': '',
    },
    'v61tykjq': {
      'en': '3',
      'es': '',
      'fr': '',
    },
    'jduq4j1g': {
      'en': '4',
      'es': '',
      'fr': '',
    },
    'tvuntw5o': {
      'en': '5',
      'es': '',
      'fr': '',
    },
    'x9oxltgi': {
      'en': '6',
      'es': '',
      'fr': '',
    },
    'xs59004j': {
      'en': '7',
      'es': '',
      'fr': '',
    },
    's5dl5nuy': {
      'en': '8',
      'es': '',
      'fr': '',
    },
    '5fcsube5': {
      'en': '9',
      'es': '',
      'fr': '',
    },
    '2yxyuakv': {
      'en': '10',
      'es': '',
      'fr': '',
    },
    'u87al1wu': {
      'en': '11',
      'es': '',
      'fr': '',
    },
    'i4jmjl90': {
      'en': '12',
      'es': '',
      'fr': '',
    },
    'zszgupfc': {
      'en': '13',
      'es': '',
      'fr': '',
    },
    'vb1citfb': {
      'en': '14',
      'es': '',
      'fr': '',
    },
    'u7lt8w03': {
      'en': '15',
      'es': '',
      'fr': '',
    },
    '10jxpmof': {
      'en': '16',
      'es': '',
      'fr': '',
    },
    'r76uk8tv': {
      'en': '17',
      'es': '',
      'fr': '',
    },
    'h67xw6q7': {
      'en': '18',
      'es': '',
      'fr': '',
    },
    'mz2tcyll': {
      'en': '19',
      'es': '',
      'fr': '',
    },
    's79if879': {
      'en': '20',
      'es': '',
      'fr': '',
    },
    '0m7az2mp': {
      'en': '21',
      'es': '',
      'fr': '',
    },
    'v73hwus0': {
      'en': '22',
      'es': '',
      'fr': '',
    },
    'xnfxvt0l': {
      'en': '23',
      'es': '',
      'fr': '',
    },
    '17knc0fh': {
      'en': '24',
      'es': '',
      'fr': '',
    },
    'xrj3cz83': {
      'en': '25',
      'es': '',
      'fr': '',
    },
    '488wfl71': {
      'en': '26',
      'es': '',
      'fr': '',
    },
    '8gv508ur': {
      'en': '27',
      'es': '',
      'fr': '',
    },
    'nbwc4o3r': {
      'en': '28',
      'es': '',
      'fr': '',
    },
    '6uiq977n': {
      'en': '29',
      'es': '',
      'fr': '',
    },
    'dw93w9em': {
      'en': '30',
      'es': '',
      'fr': '',
    },
    'gkq6mt43': {
      'en': '31',
      'es': '',
      'fr': '',
    },
    'hik0l9e2': {
      'en': 'Day',
      'es': '',
      'fr': '',
    },
    'qwfj6olh': {
      'en': 'January',
      'es': '',
      'fr': '',
    },
    '5yfl2fig': {
      'en': 'February',
      'es': '',
      'fr': '',
    },
    '2j3sq77c': {
      'en': 'March',
      'es': '',
      'fr': '',
    },
    'ww2p1sq2': {
      'en': 'April',
      'es': '',
      'fr': '',
    },
    'yb1u8dpe': {
      'en': 'May',
      'es': '',
      'fr': '',
    },
    'wefnlt57': {
      'en': 'June',
      'es': '',
      'fr': '',
    },
    '3numnuu6': {
      'en': 'July',
      'es': '',
      'fr': '',
    },
    'slw65a6i': {
      'en': 'August',
      'es': '',
      'fr': '',
    },
    'r31bwea6': {
      'en': 'September',
      'es': '',
      'fr': '',
    },
    '8luf1652': {
      'en': 'October',
      'es': '',
      'fr': '',
    },
    'b2504264': {
      'en': 'November',
      'es': '',
      'fr': '',
    },
    'q1a59kvj': {
      'en': 'December',
      'es': '',
      'fr': '',
    },
    'd9u848nb': {
      'en': 'Month',
      'es': '',
      'fr': '',
    },
    'bhuy5bw0': {
      'en': '1995',
      'es': '',
      'fr': '',
    },
    'xn1rvaee': {
      'en': 'Year',
      'es': '',
      'fr': '',
    },
    'uaxfui0e': {
      'en': 'Age of participant',
      'es': '',
      'fr': '',
    },
    'temoki4e': {
      'en': 'Event Location(City) ',
      'es': '',
      'fr': '',
    },
    'jwveycni': {
      'en': 'Ottawa',
      'es': '',
      'fr': '',
    },
    'h0lz4bfy': {
      'en': 'Please Select ',
      'es': '',
      'fr': '',
    },
    'kytx82lw': {
      'en': 'Team Name',
      'es': '',
      'fr': '',
    },
    'jx1iz36o': {
      'en': 'Signature',
      'es': '',
      'fr': '',
    },
    'l2pj4b8z': {
      'en': 'Back',
      'es': '',
      'fr': '',
    },
    'ds16qzy1': {
      'en': 'Next',
      'es': '',
      'fr': '',
    },
    'vatbw12b': {
      'en': 'Register',
      'es': '',
      'fr': '',
    },
  },
  // Register_Referee_05
  {
    '7bhu9rfq': {
      'en': 'Menu',
      'es': 'Menú',
      'fr': 'Menu',
    },
    'u7ryybqa': {
      'en': 'PlayOn! Store',
      'es': '¡Juega! Tienda',
      'fr': 'Jouer sur! Boutique',
    },
    'aozy5eqy': {
      'en': 'Go to the PlayOn! Store',
      'es': '¡Ve al PlayOn! Tienda',
      'fr': 'Rendez-vous sur PlayOn! Boutique',
    },
    'c3swq26l': {
      'en': 'Referee Registration',
      'es': '',
      'fr': '',
    },
    '10niooqs': {
      'en': '5',
      'es': '',
      'fr': '',
    },
    'h1v68koo': {
      'en': 'Referee Registration',
      'es': '',
      'fr': '',
    },
    'k6dm9sqa': {
      'en': '1',
      'es': '',
      'fr': '',
    },
    's7wa2mck': {
      'en': 'Basic Details',
      'es': '',
      'fr': '',
    },
    'cg1n5tw4': {
      'en': '2',
      'es': '',
      'fr': '',
    },
    'deg0mpn5': {
      'en': 'Experience',
      'es': '',
      'fr': '',
    },
    '2pdkuc90': {
      'en': '3',
      'es': '',
      'fr': '',
    },
    'c4y1xesx': {
      'en': 'References',
      'es': '',
      'fr': '',
    },
    '2kjrgh8g': {
      'en': '4',
      'es': '',
      'fr': '',
    },
    '1jdtvf8s': {
      'en': 'Event\nSelection',
      'es': '',
      'fr': '',
    },
    'pqjb8ezr': {
      'en': '5',
      'es': '',
      'fr': '',
    },
    'twigdkk3': {
      'en': 'Availability',
      'es': '',
      'fr': '',
    },
    'grmajfm8': {
      'en': '6',
      'es': '',
      'fr': '',
    },
    'yeg7ngck': {
      'en': 'Waiver',
      'es': '',
      'fr': '',
    },
    'd2lwbex8': {
      'en': '7',
      'es': '',
      'fr': '',
    },
    'gvs7lqwi': {
      'en': 'Payment Details',
      'es': '',
      'fr': '',
    },
    'jmkf3y93': {
      'en': 'Your Team Name is:',
      'es': '',
      'fr': '',
    },
    'r5nsqfn3': {
      'en': 'London Giants (pending approval)',
      'es': '',
      'fr': '',
    },
    'xovj72vq': {
      'en': 'Your playing in:',
      'es': '',
      'fr': '',
    },
    'z04k1dqx': {
      'en': 'Event 1',
      'es': '',
      'fr': '',
    },
    'ohxf82px': {
      'en': 'WAIVER, RELEASE AND INDEMNIFICATION:',
      'es': '',
      'fr': '',
    },
    '5cmdce1z': {
      'en':
          'Every player, and his/her parent or guardian (if the player is under 18) must read. execute, and deliver this waiver to tournament organizers prior to the commencement of the tournament. in consideration of the right and opportunity to participate in the play On! street hockey tournament conducted by the not for profit organization play On! Canada (POC),and its licensed affiliates, the undersigned hereby acknowledges and agrees as follows: I (who am the participant\'s parent or legal guardian if the participant is under 18 year old) hereby consent to the use without compensation, of my/his/her name  and/or likeness, biographical material and/or voice in publicity and advertising concerning the play On! tournament by PPOC and/or any playOn! tournament partners or sponsored in any and all media and/or promotion and throughout the world. in addition, the undersigned (on behalf of the participant if the participant is under 18 years of age) forever generally and completely release and discharge and shall indemnify and hold harmless Play On! Canada and its employees, directors, officers, agents, sponsors, partners and licensees and each other party affiliated with play On! Canada and each of its owners, agents, directors, officers, employees, sponsors and partners(collectively, \"Event Organizers\") against and from any and all claims and demands of every kind and nature whatsoever, for damages or injuries ,actual or consequential, past, present or future, raising out of or in any   way related to the Play On! street hockey  tournament, including but not limited to any claims of injury from participating in OR observing the tournament, the loss of personal property by theft to otherwise during the tournament, any publicity related to the tournament, or any prizes   awarded. The undersigned acknowledges that of its own free will he/she has chosen to participate in the tournament and related activities. I understand and acknowledge that the aforementioned activities carry with them a high level of risk of injury  and additional hazards related thereto. i certify that i am  aware kof ,and accept, these increased risks and that i am mentally and physically prepared for the risks associated with the play On! street hockey tournament. This general release shall further apply to all unknown, unanticipated, unsuspected, and undisclosed claims, demands, liabilities, actions or causes of action, in law, equality or otherwise.  This Waiver shall bind heirs, personal representatives, and successors of the undersigned, and inure to the benefit of the Event Organizers.',
      'es': '',
      'fr': '',
    },
    'yv20966e': {
      'en':
          'I HAVE READ AND UNDERSTAND THE TERMS OF THE ABOVE AGREEMENT, WILL COMPLY WITH TERMS HERE OF AND ACKNOWLEDGE THAT BY SIGNIG THIS FORM I AM GIVING UP LEGAL RIGHTS.',
      'es': '',
      'fr': '',
    },
    'k45xlq96': {
      'en': 'Date Of Birth',
      'es': '',
      'fr': '',
    },
    'y61upib4': {
      'en': '1',
      'es': '',
      'fr': '',
    },
    'yhk090f3': {
      'en': '2',
      'es': '',
      'fr': '',
    },
    'qn7irml5': {
      'en': '3',
      'es': '',
      'fr': '',
    },
    'bubx4sdf': {
      'en': '4',
      'es': '',
      'fr': '',
    },
    'cbakdhb9': {
      'en': '5',
      'es': '',
      'fr': '',
    },
    'dzm0w131': {
      'en': '6',
      'es': '',
      'fr': '',
    },
    'l6prrp9w': {
      'en': '7',
      'es': '',
      'fr': '',
    },
    'zlo3otf8': {
      'en': '8',
      'es': '',
      'fr': '',
    },
    's6ao51y1': {
      'en': '9',
      'es': '',
      'fr': '',
    },
    '973e4lim': {
      'en': '10',
      'es': '',
      'fr': '',
    },
    'oyi8vip3': {
      'en': '11',
      'es': '',
      'fr': '',
    },
    'avkl0b9e': {
      'en': '12',
      'es': '',
      'fr': '',
    },
    '16gtb7uh': {
      'en': '13',
      'es': '',
      'fr': '',
    },
    'vw2g08b7': {
      'en': '14',
      'es': '',
      'fr': '',
    },
    '1tc1e2gr': {
      'en': '15',
      'es': '',
      'fr': '',
    },
    'pxcgwsve': {
      'en': '16',
      'es': '',
      'fr': '',
    },
    'n913y4p2': {
      'en': '17',
      'es': '',
      'fr': '',
    },
    'm9sd4k2s': {
      'en': '18',
      'es': '',
      'fr': '',
    },
    'ec8jo43s': {
      'en': '19',
      'es': '',
      'fr': '',
    },
    'pyb7ooh4': {
      'en': '20',
      'es': '',
      'fr': '',
    },
    'gjyn392n': {
      'en': '21',
      'es': '',
      'fr': '',
    },
    'ak29blcd': {
      'en': '22',
      'es': '',
      'fr': '',
    },
    'l6r20a30': {
      'en': '23',
      'es': '',
      'fr': '',
    },
    'oyi84d29': {
      'en': '24',
      'es': '',
      'fr': '',
    },
    'rd3fhsfc': {
      'en': '25',
      'es': '',
      'fr': '',
    },
    'h2wg655y': {
      'en': '26',
      'es': '',
      'fr': '',
    },
    'w28jj3ne': {
      'en': '27',
      'es': '',
      'fr': '',
    },
    '9d7rc594': {
      'en': '28',
      'es': '',
      'fr': '',
    },
    'r7xkblma': {
      'en': '29',
      'es': '',
      'fr': '',
    },
    'vcepgo0d': {
      'en': '30',
      'es': '',
      'fr': '',
    },
    'kovw1zgt': {
      'en': '31',
      'es': '',
      'fr': '',
    },
    'rlpscaw8': {
      'en': 'Day',
      'es': '',
      'fr': '',
    },
    'ceaj64t4': {
      'en': 'January',
      'es': '',
      'fr': '',
    },
    'orvvsm1z': {
      'en': 'February',
      'es': '',
      'fr': '',
    },
    'fv2b7yj8': {
      'en': 'March',
      'es': '',
      'fr': '',
    },
    'pptlg8yt': {
      'en': 'April',
      'es': '',
      'fr': '',
    },
    '73i2w2ny': {
      'en': 'May',
      'es': '',
      'fr': '',
    },
    'iwu9wmxv': {
      'en': 'June',
      'es': '',
      'fr': '',
    },
    '6rwofcsu': {
      'en': 'July',
      'es': '',
      'fr': '',
    },
    'fgllxkee': {
      'en': 'August',
      'es': '',
      'fr': '',
    },
    'utyv44z3': {
      'en': 'September',
      'es': '',
      'fr': '',
    },
    'l4ro2y1l': {
      'en': 'October',
      'es': '',
      'fr': '',
    },
    '0941zj4q': {
      'en': 'November',
      'es': '',
      'fr': '',
    },
    '6tdjwmxs': {
      'en': 'December',
      'es': '',
      'fr': '',
    },
    '6sprzmno': {
      'en': 'Month',
      'es': '',
      'fr': '',
    },
    'cqjazvyo': {
      'en': '1995',
      'es': '',
      'fr': '',
    },
    'uchcg72k': {
      'en': 'Year',
      'es': '',
      'fr': '',
    },
    '4o9kpcbh': {
      'en': 'Age of participant',
      'es': '',
      'fr': '',
    },
    'bjayy8u8': {
      'en': 'Event Location(City) ',
      'es': '',
      'fr': '',
    },
    'brjevcjp': {
      'en': 'January',
      'es': '',
      'fr': '',
    },
    '0sunpbfq': {
      'en': 'Please Select ',
      'es': '',
      'fr': '',
    },
    'crf5fkak': {
      'en': 'Team Name',
      'es': '',
      'fr': '',
    },
    't165iac4': {
      'en': 'Signature',
      'es': '',
      'fr': '',
    },
    'f1q0x3tj': {
      'en': 'Back',
      'es': '',
      'fr': '',
    },
    'jjxpwuay': {
      'en': 'Next',
      'es': '',
      'fr': '',
    },
    'b9gn348n': {
      'en': 'Register',
      'es': '',
      'fr': '',
    },
  },
  // Register_Volunteer_08
  {
    'y8xqm8rg': {
      'en': 'Menu',
      'es': 'Menú',
      'fr': 'Menu',
    },
    'hoa93cxw': {
      'en': 'PlayOn! Store',
      'es': '¡Juega! Tienda',
      'fr': 'Jouer sur! Boutique',
    },
    '7hzzon8u': {
      'en': 'Go to the PlayOn! Store',
      'es': '¡Ve al PlayOn! Tienda',
      'fr': 'Rendez-vous sur PlayOn! Boutique',
    },
    '4sa6d29n': {
      'en': 'Volunteer Registration',
      'es': '',
      'fr': '',
    },
    'ctc9i90k': {
      'en': '8',
      'es': '',
      'fr': '',
    },
    'ime4tv83': {
      'en': '1',
      'es': '',
      'fr': '',
    },
    '4lgbvsis': {
      'en': 'Personal Information',
      'es': '',
      'fr': '',
    },
    '38vtnmi0': {
      'en': '2',
      'es': '',
      'fr': '',
    },
    '20hwn1zy': {
      'en': 'Expression of Interest',
      'es': '',
      'fr': '',
    },
    'xmdtjrbs': {
      'en': '3',
      'es': '',
      'fr': '',
    },
    '63cpoahm': {
      'en': 'Skills and Certifications',
      'es': '',
      'fr': '',
    },
    'jnc8dt35': {
      'en': '4',
      'es': '',
      'fr': '',
    },
    'o53ltxuv': {
      'en': 'Pre Events Details',
      'es': '',
      'fr': '',
    },
    'zw1lg8mw': {
      'en': '5',
      'es': '',
      'fr': '',
    },
    'z23oi4li': {
      'en': 'Event Selection',
      'es': '',
      'fr': '',
    },
    '4uwaxd9a': {
      'en': '6',
      'es': '',
      'fr': '',
    },
    '2k3v6xti': {
      'en': 'Availability',
      'es': '',
      'fr': '',
    },
    '4ly7np4o': {
      'en': '7',
      'es': '',
      'fr': '',
    },
    '63wmaa8m': {
      'en': 'Wavier',
      'es': '',
      'fr': '',
    },
    'wv99asht': {
      'en': '8',
      'es': '',
      'fr': '',
    },
    'lxvcuhli': {
      'en': 'Payment',
      'es': '',
      'fr': '',
    },
    'avvuqxom': {
      'en': '9',
      'es': '',
      'fr': '',
    },
    'a1ljb7x0': {
      'en': 'Confirmation',
      'es': '',
      'fr': '',
    },
    '8dp581z0': {
      'en': 'Captain Registration Fee',
      'es': '',
      'fr': '',
    },
    '6nyw0ymx': {
      'en': '\$59',
      'es': '',
      'fr': '',
    },
    'kreusovu': {
      'en': 'Tax',
      'es': '',
      'fr': '',
    },
    'mihi87sx': {
      'en': '\$4.99',
      'es': '',
      'fr': '',
    },
    'bj5xs73g': {
      'en':
          'Are you certain you will have a team of at least 3 or more committed players',
      'es': '',
      'fr': '',
    },
    'xl4qjq3z': {
      'en':
          'By paying your fees you confirm that you will have a team for this event',
      'es': '',
      'fr': '',
    },
    'qyg9f9l9': {
      'en':
          'Players can be added or changes at any time until the event is scheduled. However, participation fees are not refundable under any circumstances',
      'es': '',
      'fr': '',
    },
    'qoc69q2v': {
      'en': 'I understand, we committed to playing!',
      'es': '',
      'fr': '',
    },
    'ra4gpkig': {
      'en': 'Back',
      'es': '',
      'fr': '',
    },
    'ng8n6xbf': {
      'en': 'Next',
      'es': '',
      'fr': '',
    },
    'yvygfe2x': {
      'en': 'Register',
      'es': '',
      'fr': '',
    },
  },
  // Register_Volunteer_09
  {
    'bprfe4kj': {
      'en': 'Login',
      'es': 'Acceso',
      'fr': 'Connexion',
    },
    '5xuznx13': {
      'en': 'Menu',
      'es': 'Menú',
      'fr': 'Menu',
    },
    'oz4dwmrm': {
      'en': 'PlayOn! Store',
      'es': '¡Juega! Tienda',
      'fr': 'Jouer sur! Boutique',
    },
    '0uxmdu29': {
      'en': 'Go to the PlayOn! Store',
      'es': '¡Ve al PlayOn! Tienda',
      'fr': 'Rendez-vous sur PlayOn! Boutique',
    },
    'cklul9xm': {
      'en': 'Volunteer Registration',
      'es': '',
      'fr': '',
    },
    'n32y4ry7': {
      'en': '9',
      'es': '',
      'fr': '',
    },
    '023eka51': {
      'en': '1',
      'es': '',
      'fr': '',
    },
    'a4p3c7c4': {
      'en': 'Personal Information',
      'es': '',
      'fr': '',
    },
    '1f1yf5gj': {
      'en': '2',
      'es': '',
      'fr': '',
    },
    '6bs817fe': {
      'en': 'Expression of Interest',
      'es': '',
      'fr': '',
    },
    '2jmedguu': {
      'en': '3',
      'es': '',
      'fr': '',
    },
    'f3iuerh7': {
      'en': 'Skills and Certifications',
      'es': '',
      'fr': '',
    },
    'ekt8f10j': {
      'en': '4',
      'es': '',
      'fr': '',
    },
    'sd60fu8o': {
      'en': 'Pre Events Details',
      'es': '',
      'fr': '',
    },
    '7rqcascb': {
      'en': '5',
      'es': '',
      'fr': '',
    },
    'u9u0hpx7': {
      'en': 'Event Selection',
      'es': '',
      'fr': '',
    },
    'g9uo6d0l': {
      'en': '6',
      'es': '',
      'fr': '',
    },
    'jcanmxjd': {
      'en': 'Availability',
      'es': '',
      'fr': '',
    },
    'nwczh011': {
      'en': '7',
      'es': '',
      'fr': '',
    },
    'gsa3hr0x': {
      'en': 'Wavier',
      'es': '',
      'fr': '',
    },
    'u8bhsouj': {
      'en': '8',
      'es': '',
      'fr': '',
    },
    'c8gncz3j': {
      'en': 'Payment',
      'es': '',
      'fr': '',
    },
    'zt1wo2ti': {
      'en': '9',
      'es': '',
      'fr': '',
    },
    'dmuo5zgl': {
      'en': 'Confirmation',
      'es': '',
      'fr': '',
    },
    'zgiwo38g': {
      'en': 'Please confirm your availability for the selected events',
      'es': '',
      'fr': '',
    },
    'pxbuez4y': {
      'en': 'Select Apparel Size for yourself',
      'es': '',
      'fr': '',
    },
    'qfout768': {
      'en': 'Male',
      'es': '',
      'fr': '',
    },
    'rr2h5dhh': {
      'en': 'Female',
      'es': '',
      'fr': '',
    },
    'twl882u0': {
      'en': 'Please select...',
      'es': '',
      'fr': '',
    },
    '0yombtqe': {
      'en': 'Select size ',
      'es': '',
      'fr': '',
    },
    'p63276hu': {
      'en': 'S',
      'es': '',
      'fr': '',
    },
    'p2hjdq9y': {
      'en': 'M',
      'es': '',
      'fr': '',
    },
    'xtulxnkm': {
      'en': 'L',
      'es': '',
      'fr': '',
    },
    'u15zlvhb': {
      'en': 'XL',
      'es': '',
      'fr': '',
    },
    'ro7eewwt': {
      'en': 'XXL',
      'es': '',
      'fr': '',
    },
    '6sybq84d': {
      'en': 'XXXL',
      'es': '',
      'fr': '',
    },
    'n9d5kfpe': {
      'en': 'Confirm',
      'es': '',
      'fr': '',
    },
    '5hfgi04e': {
      'en': 'Back',
      'es': '',
      'fr': '',
    },
    'tqc0ae92': {
      'en': 'Next',
      'es': '',
      'fr': '',
    },
    'p0zolagu': {
      'en': 'Register',
      'es': '',
      'fr': '',
    },
  },
  // Family_Account_02
  {
    'y6n2njix': {
      'en': 'Login',
      'es': 'Acceso',
      'fr': 'Connexion',
    },
    't3jjtndy': {
      'en': 'Menu',
      'es': 'Menú',
      'fr': 'Menu',
    },
    'bv3w6l8y': {
      'en': 'PlayOn! Store',
      'es': '¡Juega! Tienda',
      'fr': 'Jouer sur! Boutique',
    },
    'ltsvehen': {
      'en': 'Go to the PlayOn! Store',
      'es': '¡Ve al PlayOn! Tienda',
      'fr': 'Rendez-vous sur PlayOn! Boutique',
    },
    'kb6pchq6': {
      'en': 'Family Account',
      'es': '',
      'fr': '',
    },
    '5as2mbqk': {
      'en': 'Back',
      'es': '',
      'fr': '',
    },
    'o0q31yuy': {
      'en': 'Next',
      'es': '',
      'fr': '',
    },
    'eb36vxnq': {
      'en': 'Register',
      'es': '',
      'fr': '',
    },
  },
  // Referee_Management_01
  {
    'qw4k4oh5': {
      'en': 'en_US',
      'es': 'es_ES',
      'fr': 'fr_US',
    },
    'a6un4vev': {
      'en': 'en_US',
      'es': 'es_US',
      'fr': 'fr_US',
    },
    'dqf2d0o9': {
      'en': 'fr_FR',
      'es': 'fr_FR',
      'fr': 'F RFR',
    },
    '5g7aodao': {
      'en': 'es_ES',
      'es': 'es_ES',
      'fr': 'es_ES',
    },
    'qviax00g': {
      'en': 'Login',
      'es': 'Acceso',
      'fr': 'Connexion',
    },
    'icu8n6bc': {
      'en': 'Menu',
      'es': 'Menú',
      'fr': 'Menu',
    },
    'kqhg06c1': {
      'en': 'PlayOn! Store',
      'es': '¡Juega! Tienda',
      'fr': 'Jouer sur! Boutique',
    },
    'uzeum5uf': {
      'en': 'Go to the PlayOn! Store',
      'es': '¡Ve al PlayOn! Tienda',
      'fr': 'Rendez-vous sur PlayOn! Boutique',
    },
    'wroxovnc': {
      'en': 'Referee Management',
      'es': '',
      'fr': '',
    },
    'jngxhpgp': {
      'en': 'John',
      'es': '',
      'fr': '',
    },
    '6y8h58tr': {
      'en': 'Doe',
      'es': '',
      'fr': '',
    },
    'pga32jqv': {
      'en': 'Male',
      'es': '',
      'fr': '',
    },
    'eg9vv249': {
      'en': '453673266354',
      'es': '',
      'fr': '',
    },
    'uxtbfaja': {
      'en': 'John@gmail.com',
      'es': '',
      'fr': '',
    },
    'c2wbvoyn': {
      'en': '9751 34 Ave NW, Edmonton, AB T6E 5X9, Canada',
      'es': '',
      'fr': '',
    },
    '6uxoxe3m': {
      'en': 'Reference Details',
      'es': '',
      'fr': '',
    },
    'dlc8uda0': {
      'en': 'John',
      'es': '',
      'fr': '',
    },
    '20x7vfaq': {
      'en': 'Doe',
      'es': '',
      'fr': '',
    },
    'w63e0gk8': {
      'en': '235467654',
      'es': '',
      'fr': '',
    },
    '7jydwu35': {
      'en': 'John@gmail.com',
      'es': '',
      'fr': '',
    },
    '2zhonauq': {
      'en': '9751 34 Ave NW, Edmonton, AB T6E 5X9, Canada',
      'es': '',
      'fr': '',
    },
    '6q7hzc25': {
      'en': 'Event Details',
      'es': '',
      'fr': '',
    },
    '91oxd5fi': {
      'en': 'Experience Details',
      'es': '',
      'fr': '',
    },
    'nom35pmv': {
      'en': 'Yes',
      'es': '',
      'fr': '',
    },
    'rzw2b9l9': {
      'en': 'Yes',
      'es': '',
      'fr': '',
    },
    '6jx08sjt': {
      'en': 'Yes ',
      'es': '',
      'fr': '',
    },
    'huaed817': {
      'en': '2nd Level',
      'es': '',
      'fr': '',
    },
    'i5t2agbm': {
      'en': 'No',
      'es': '',
      'fr': '',
    },
    'refcolgi': {
      'en': 'Yes ',
      'es': '',
      'fr': '',
    },
    'isuvk6cy': {
      'en': '2nd Level',
      'es': '',
      'fr': '',
    },
    'nm5jmhnt': {
      'en': 'Yes ',
      'es': '',
      'fr': '',
    },
    'zs9paqd6': {
      'en': '4th Level',
      'es': '',
      'fr': '',
    },
    'skaqa1lt': {
      'en': 'No',
      'es': '',
      'fr': '',
    },
    '2pf87t7c': {
      'en': 'No',
      'es': '',
      'fr': '',
    },
    'kmawdkr5': {
      'en': 'No',
      'es': '',
      'fr': '',
    },
    '1it7ia9p': {
      'en': 'Action :',
      'es': '',
      'fr': '',
    },
    'ldvcg1ln': {
      'en': 'Yes',
      'es': '',
      'fr': '',
    },
    '1gwa9r2k': {
      'en': '40%',
      'es': '',
      'fr': '',
    },
    'qyxb679t': {
      'en': '1',
      'es': '',
      'fr': '',
    },
    'v9jzf8eo': {
      'en': '2',
      'es': '',
      'fr': '',
    },
    'mvuxsu3q': {
      'en': '3',
      'es': '',
      'fr': '',
    },
    'jebr9vdz': {
      'en': '4',
      'es': '',
      'fr': '',
    },
    'pob8g3kr': {
      'en': 'Please select...',
      'es': '',
      'fr': '',
    },
    '077w2vn6': {
      'en': 'Back',
      'es': '',
      'fr': '',
    },
    'uzt5g23j': {
      'en': 'Next',
      'es': '',
      'fr': '',
    },
    'efrukrdo': {
      'en': 'Home',
      'es': '',
      'fr': '',
    },
  },
  // Register_Player_00
  {
    'pgorq3q0': {
      'en': 'To register as a Player, you will need:',
      'es': '',
      'fr': '',
    },
    '4l9b8jg6': {
      'en':
          '1) If your team has not been created yet, you will have to wait for an invitation to join the team',
      'es': '',
      'fr': '',
    },
    'bbo84mgo': {
      'en': '2) Your profile will remain private and limited to your team',
      'es': '',
      'fr': '',
    },
    'oaasyyqc': {
      'en':
          '3) You will need to pay or join a team via Credit Card for payment: Visa, MasterCard or Paypal',
      'es': '',
      'fr': '',
    },
    'e6gjwd1q': {
      'en': '4) Your division will be assigned based on your team\'s',
      'es': '',
      'fr': '',
    },
    'k7x3rsl7': {
      'en': 'a) Gender',
      'es': '',
      'fr': '',
    },
    'p2uh0afa': {
      'en': 'b) Age',
      'es': '',
      'fr': '',
    },
    'ibvjehnf': {
      'en': 'c) Skill Level* (if necessary)',
      'es': '',
      'fr': '',
    },
    'dnkhgohr': {
      'en':
          '*Skill level will only be considered if, after gender segregation, an age division exceeds 16 teams',
      'es': '',
      'fr': '',
    },
    '0mmpo20c': {
      'en':
          'Skill level will be assigned by algorithm based on the infomation each player on your team provides during  this registration process',
      'es': '',
      'fr': '',
    },
    'qkbtefdl': {
      'en':
          'You will be held responsible for the integrity of the information you submit as part of this process and your captain will be held responsible for the integrity of all information submitted by all members of the team',
      'es': '',
      'fr': '',
    },
    'xzxyrv69': {
      'en':
          '5) Any team that submits false information will be disqualified without refund or rewards given',
      'es': '',
      'fr': '',
    },
    'uvj1g2x2': {
      'en': 'Back',
      'es': '',
      'fr': '',
    },
    'v7slkc4v': {
      'en': 'Next',
      'es': '',
      'fr': '',
    },
    '1by7k1qa': {
      'en': 'Register',
      'es': '',
      'fr': '',
    },
  },
  // Register_Player_01
  {
    '4okcak1a': {
      'en': 'You are the Team Player',
      'es': '',
      'fr': '',
    },
    '67gpnyxd': {
      'en': '1',
      'es': '',
      'fr': '',
    },
    'wxkrwwo2': {
      'en': 'Select Team',
      'es': '',
      'fr': '',
    },
    '93vn5sko': {
      'en': '2',
      'es': '',
      'fr': '',
    },
    'l8bt2i41': {
      'en': 'Your Details',
      'es': '',
      'fr': '',
    },
    'btr9y24x': {
      'en': '3',
      'es': '',
      'fr': '',
    },
    '2qwfh16l': {
      'en': 'Experience',
      'es': '',
      'fr': '',
    },
    '7cgsd2w3': {
      'en': '4',
      'es': '',
      'fr': '',
    },
    'j5pyvlhd': {
      'en': 'Birthdate',
      'es': '',
      'fr': '',
    },
    '3twlg4pi': {
      'en': '5',
      'es': '',
      'fr': '',
    },
    'x2na970k': {
      'en': 'Waiver',
      'es': '',
      'fr': '',
    },
    'wn0r4xmo': {
      'en': '6',
      'es': '',
      'fr': '',
    },
    'ixdid99z': {
      'en': 'Payment',
      'es': '',
      'fr': '',
    },
    'h73xwgpe': {
      'en': '7',
      'es': '',
      'fr': '',
    },
    'ozllrh76': {
      'en': 'Fans',
      'es': '',
      'fr': '',
    },
    'zrdojuqe': {
      'en': '1',
      'es': '',
      'fr': '',
    },
    'pstv0zdd': {
      'en': 'Please select one team for an event',
      'es': '',
      'fr': '',
    },
    '7y6p9vas': {
      'en': 'Back',
      'es': '',
      'fr': '',
    },
    '9wl4emoi': {
      'en': 'Next',
      'es': '',
      'fr': '',
    },
    'oy13xdsn': {
      'en': 'Register',
      'es': '',
      'fr': '',
    },
  },
  // Register_Player_02
  {
    'qr9u99uz': {
      'en': 'You are the Team Player',
      'es': '',
      'fr': '',
    },
    'nkijmliv': {
      'en': '1',
      'es': '',
      'fr': '',
    },
    'z9nxsxj5': {
      'en': 'Select Team',
      'es': '',
      'fr': '',
    },
    '8p5g169k': {
      'en': '2',
      'es': '',
      'fr': '',
    },
    '3qvqqtwa': {
      'en': 'Your Details',
      'es': '',
      'fr': '',
    },
    'g98fuxti': {
      'en': '3',
      'es': '',
      'fr': '',
    },
    'gnm8dyas': {
      'en': 'Experience',
      'es': '',
      'fr': '',
    },
    '91t968px': {
      'en': '4',
      'es': '',
      'fr': '',
    },
    'pijbxcdg': {
      'en': 'Birthdate',
      'es': '',
      'fr': '',
    },
    'l6a7e51j': {
      'en': '5',
      'es': '',
      'fr': '',
    },
    'mk04litx': {
      'en': 'Waiver',
      'es': '',
      'fr': '',
    },
    '9j99vi0w': {
      'en': '6',
      'es': '',
      'fr': '',
    },
    '0q6g2xu3': {
      'en': 'Payment',
      'es': '',
      'fr': '',
    },
    'rm587mfg': {
      'en': '7',
      'es': '',
      'fr': '',
    },
    'f4d7d0fx': {
      'en': 'Fans',
      'es': '',
      'fr': '',
    },
    'w4q95ac0': {
      'en': '2',
      'es': '',
      'fr': '',
    },
    'lpt5dv86': {
      'en': 'Your Team Name is:',
      'es': '',
      'fr': '',
    },
    'ianqgmxy': {
      'en': 'You are playing in:',
      'es': '',
      'fr': '',
    },
    'lexq8z30': {
      'en': 'First Name',
      'es': '',
      'fr': '',
    },
    '4ie8rywj': {
      'en': 'Enter your first name',
      'es': '',
      'fr': '',
    },
    'ja64sj0g': {
      'en': 'Last Name',
      'es': '',
      'fr': '',
    },
    'ogoq2g9i': {
      'en': 'Enter your last name',
      'es': '',
      'fr': '',
    },
    'dz6udpgu': {
      'en': 'Mobile Number',
      'es': '',
      'fr': '',
    },
    '7xej0amy': {
      'en': 'Enter your mobile number',
      'es': '',
      'fr': '',
    },
    '8thh04ev': {
      'en': 'Email address',
      'es': '',
      'fr': '',
    },
    'h5p66rrx': {
      'en': 'Enter your email address',
      'es': '',
      'fr': '',
    },
    'aewlnadt': {
      'en': 'Address',
      'es': '',
      'fr': '',
    },
    'qh9hdtpt': {
      'en': 'Street address or SP.O. Box',
      'es': '',
      'fr': '',
    },
    'bwcknfxz': {
      'en': '',
      'es': '',
      'fr': '',
    },
    'w04vub77': {
      'en': 'Country',
      'es': '',
      'fr': '',
    },
    'wavgk7hc': {
      'en': 'Option 1',
      'es': '',
      'fr': '',
    },
    'a53jc6uy': {
      'en': 'Please select...',
      'es': '',
      'fr': '',
    },
    'omaig1tb': {
      'en': 'State',
      'es': '',
      'fr': '',
    },
    'n1v90ezb': {
      'en': 'Province',
      'es': '',
      'fr': '',
    },
    'mvym9v94': {
      'en': 'Option 1',
      'es': '',
      'fr': '',
    },
    'bs9xkq8t': {
      'en': 'Please select...',
      'es': '',
      'fr': '',
    },
    'xmo85hgh': {
      'en': 'City',
      'es': '',
      'fr': '',
    },
    '7i60m7fn': {
      'en': 'Option 1',
      'es': '',
      'fr': '',
    },
    'lvako9m9': {
      'en': 'Please select...',
      'es': '',
      'fr': '',
    },
    'wtjja2wh': {
      'en': 'Zip  Code',
      'es': '',
      'fr': '',
    },
    'mppy46h5': {
      'en': 'Enter your zip  code',
      'es': '',
      'fr': '',
    },
    '7i5wvvhp': {
      'en': 'Postal Code',
      'es': '',
      'fr': '',
    },
    'gahslm10': {
      'en': 'A1A 1A1',
      'es': '',
      'fr': '',
    },
    '8m8rsvvk': {
      'en': 'Jersey Number',
      'es': '',
      'fr': '',
    },
    'y8356xpk': {
      'en': 'Jersey number',
      'es': '',
      'fr': '',
    },
    '4s5sjj7y': {
      'en': 'Gender',
      'es': '',
      'fr': '',
    },
    'hmwxvtqk': {
      'en': 'Male',
      'es': '',
      'fr': '',
    },
    '2qq97123': {
      'en': 'Female',
      'es': '',
      'fr': '',
    },
    'a2ixe8oo': {
      'en': 'Neither',
      'es': '',
      'fr': '',
    },
    '3mmsstao': {
      'en': 'Select one',
      'es': '',
      'fr': '',
    },
    'q18yfxco': {
      'en': 'Back',
      'es': '',
      'fr': '',
    },
    'd6c7n0xh': {
      'en': 'Next',
      'es': '',
      'fr': '',
    },
    'g31nrnkf': {
      'en': 'Register',
      'es': '',
      'fr': '',
    },
  },
  // Register_Player_04
  {
    '1c4to1kd': {
      'en': 'You are the Team Player',
      'es': '',
      'fr': '',
    },
    'hlf6936s': {
      'en': '1',
      'es': '',
      'fr': '',
    },
    'zcqahn96': {
      'en': 'Select Team',
      'es': '',
      'fr': '',
    },
    'f56t9zp6': {
      'en': '2',
      'es': '',
      'fr': '',
    },
    'dl1yg8vp': {
      'en': 'Your Details',
      'es': '',
      'fr': '',
    },
    'tra0w2sh': {
      'en': '3',
      'es': '',
      'fr': '',
    },
    'mhr52zur': {
      'en': 'Experience',
      'es': '',
      'fr': '',
    },
    '5dc2lqd2': {
      'en': '4',
      'es': '',
      'fr': '',
    },
    'cvfv7l25': {
      'en': 'Birthdate',
      'es': '',
      'fr': '',
    },
    'm6crqyyk': {
      'en': '5',
      'es': '',
      'fr': '',
    },
    'pog0g006': {
      'en': 'Waiver',
      'es': '',
      'fr': '',
    },
    'nb2a5hh8': {
      'en': '6',
      'es': '',
      'fr': '',
    },
    'w0gr0lnj': {
      'en': 'Payment',
      'es': '',
      'fr': '',
    },
    '8sdi764s': {
      'en': '7',
      'es': '',
      'fr': '',
    },
    '160tvsz0': {
      'en': 'Fans',
      'es': '',
      'fr': '',
    },
    'onlecgbi': {
      'en': '4',
      'es': '',
      'fr': '',
    },
    'vblgts18': {
      'en': 'Your Team Name is :',
      'es': '',
      'fr': '',
    },
    'lw43y2nc': {
      'en': 'Your playing in :',
      'es': '',
      'fr': '',
    },
    'nlrmdlnz': {
      'en': 'Your BirthDate',
      'es': '',
      'fr': '',
    },
    'zdaobs2w': {
      'en': '01',
      'es': '',
      'fr': '',
    },
    '3j41snb1': {
      'en': '02',
      'es': '',
      'fr': '',
    },
    'urg641ha': {
      'en': '03',
      'es': '',
      'fr': '',
    },
    '02ikbwm6': {
      'en': '04',
      'es': '',
      'fr': '',
    },
    'da1c1ol4': {
      'en': '05',
      'es': '',
      'fr': '',
    },
    'extxb88p': {
      'en': '06',
      'es': '',
      'fr': '',
    },
    '1pxa3dui': {
      'en': '07',
      'es': '',
      'fr': '',
    },
    'qyif0blb': {
      'en': '08',
      'es': '',
      'fr': '',
    },
    'qbgwi69v': {
      'en': '09',
      'es': '',
      'fr': '',
    },
    'mg5gcxbd': {
      'en': '10',
      'es': '',
      'fr': '',
    },
    'tyw66mvv': {
      'en': '11',
      'es': '',
      'fr': '',
    },
    'boqug89x': {
      'en': '12',
      'es': '',
      'fr': '',
    },
    'dgcogqti': {
      'en': '13',
      'es': '',
      'fr': '',
    },
    '9t27gga9': {
      'en': '14',
      'es': '',
      'fr': '',
    },
    'szm2mmli': {
      'en': '15',
      'es': '',
      'fr': '',
    },
    'vbvkspwn': {
      'en': '16',
      'es': '',
      'fr': '',
    },
    'iwju9t7t': {
      'en': '17',
      'es': '',
      'fr': '',
    },
    'vshdrk8z': {
      'en': '18',
      'es': '',
      'fr': '',
    },
    'g55x7b6c': {
      'en': '19',
      'es': '',
      'fr': '',
    },
    'btxjd4zo': {
      'en': '20',
      'es': '',
      'fr': '',
    },
    'siw1gzo7': {
      'en': '21',
      'es': '',
      'fr': '',
    },
    'mbxkchyt': {
      'en': '22',
      'es': '',
      'fr': '',
    },
    'pzo1nh0w': {
      'en': '23',
      'es': '',
      'fr': '',
    },
    'qk48fwit': {
      'en': '24',
      'es': '',
      'fr': '',
    },
    'yohe2p15': {
      'en': '25',
      'es': '',
      'fr': '',
    },
    'auf7zikn': {
      'en': '26',
      'es': '',
      'fr': '',
    },
    'vq56rfek': {
      'en': '27',
      'es': '',
      'fr': '',
    },
    'xt7sxwv2': {
      'en': '28',
      'es': '',
      'fr': '',
    },
    'ivou3d9b': {
      'en': '29',
      'es': '',
      'fr': '',
    },
    'zuan9a0o': {
      'en': '30',
      'es': '',
      'fr': '',
    },
    'cfgmaixm': {
      'en': '31',
      'es': '',
      'fr': '',
    },
    'v0cudw23': {
      'en': 'Day',
      'es': '',
      'fr': '',
    },
    'dnfsdhbx': {
      'en': 'January',
      'es': '',
      'fr': '',
    },
    '6fxjwtxj': {
      'en': 'February',
      'es': '',
      'fr': '',
    },
    'q3fsjiy2': {
      'en': 'March',
      'es': '',
      'fr': '',
    },
    'j4tnfxqo': {
      'en': 'April',
      'es': '',
      'fr': '',
    },
    'df2hqa9t': {
      'en': 'May',
      'es': '',
      'fr': '',
    },
    'blhjgxep': {
      'en': 'June',
      'es': '',
      'fr': '',
    },
    '9zfg06zz': {
      'en': 'July',
      'es': '',
      'fr': '',
    },
    'jf4aan1e': {
      'en': 'August',
      'es': '',
      'fr': '',
    },
    'erhqhe8e': {
      'en': 'September',
      'es': '',
      'fr': '',
    },
    'ft8tbv9x': {
      'en': 'October',
      'es': '',
      'fr': '',
    },
    'tsh48jvp': {
      'en': 'November',
      'es': '',
      'fr': '',
    },
    '32fjmc9o': {
      'en': 'December',
      'es': '',
      'fr': '',
    },
    'lpkigtkh': {
      'en': 'Month',
      'es': '',
      'fr': '',
    },
    'w8p46q1n': {
      'en': 'Year',
      'es': '',
      'fr': '',
    },
    'gtsp20xr': {
      'en': 'I certify that this birthdate is correct',
      'es': '',
      'fr': '',
    },
    'wb05kt1c': {
      'en':
          'I understand my division will be assigned based on the birth year of the oldest player in the team',
      'es': '',
      'fr': '',
    },
    '9oojag3a': {
      'en':
          'I acknowledge that I may be required to show proof of age at any time during the event',
      'es': '',
      'fr': '',
    },
    'lr79tgvn': {
      'en': 'Back',
      'es': '',
      'fr': '',
    },
    'em0afbeb': {
      'en': 'Next',
      'es': '',
      'fr': '',
    },
    'r4z49y70': {
      'en': 'Player Name',
      'es': '',
      'fr': '',
    },
    'p213tim1': {
      'en': ':',
      'es': '',
      'fr': '',
    },
    'hft164l3': {
      'en': 'Register',
      'es': '',
      'fr': '',
    },
  },
  // Register_Player_03
  {
    'iiqzffz0': {
      'en': 'You are the Team Player',
      'es': '',
      'fr': '',
    },
    'l30jbzmy': {
      'en': '1',
      'es': '',
      'fr': '',
    },
    '98rdolxd': {
      'en': 'Select Team',
      'es': '',
      'fr': '',
    },
    '2b297vtc': {
      'en': '2',
      'es': '',
      'fr': '',
    },
    'mzzi56m1': {
      'en': 'Your Details',
      'es': '',
      'fr': '',
    },
    'xe8g4vie': {
      'en': '3',
      'es': '',
      'fr': '',
    },
    '0304lz7m': {
      'en': 'Experience',
      'es': '',
      'fr': '',
    },
    'za7p8qpj': {
      'en': '4',
      'es': '',
      'fr': '',
    },
    'kt5ui4st': {
      'en': 'Birthdate',
      'es': '',
      'fr': '',
    },
    '66ppyv8e': {
      'en': '5',
      'es': '',
      'fr': '',
    },
    '1mwvxt58': {
      'en': 'Waiver',
      'es': '',
      'fr': '',
    },
    'cpn6p25n': {
      'en': '6',
      'es': '',
      'fr': '',
    },
    'ni5bm0ew': {
      'en': 'Payment',
      'es': '',
      'fr': '',
    },
    '95itimdk': {
      'en': '7',
      'es': '',
      'fr': '',
    },
    'qoi2u9qh': {
      'en': 'Fans',
      'es': '',
      'fr': '',
    },
    '7178ckh5': {
      'en': '3',
      'es': '',
      'fr': '',
    },
    'j4ydy94t': {
      'en': 'Your Team Name is :',
      'es': '',
      'fr': '',
    },
    's7pg0p08': {
      'en': 'Your playing in :',
      'es': '',
      'fr': '',
    },
    'k9221d6u': {
      'en': 'Ice Hockey Experience',
      'es': '',
      'fr': '',
    },
    '0iqfzram': {
      'en': 'Yes',
      'es': '',
      'fr': '',
    },
    'im6ydiwi': {
      'en': 'No',
      'es': '',
      'fr': '',
    },
    '2rujmy8v': {
      'en': 'Select one',
      'es': '',
      'fr': '',
    },
    'es5y3ov7': {
      'en': 'Your last team',
      'es': '',
      'fr': '',
    },
    'g5qcog2d': {
      'en': 'Pond Hockey only',
      'es': '',
      'fr': '',
    },
    'gpjyxlrw': {
      'en': 'House/Local/Recreational League',
      'es': '',
      'fr': '',
    },
    'lvmuljeo': {
      'en': 'AE/MD',
      'es': '',
      'fr': '',
    },
    'kti0glfy': {
      'en': 'A',
      'es': '',
      'fr': '',
    },
    'znvdkumt': {
      'en': 'AA',
      'es': '',
      'fr': '',
    },
    '9n0zrna6': {
      'en': 'AAA',
      'es': '',
      'fr': '',
    },
    'm2upt5sq': {
      'en': 'Junior A/CHL',
      'es': '',
      'fr': '',
    },
    'ihloau7g': {
      'en': 'Junior B/C/D',
      'es': '',
      'fr': '',
    },
    'dvkt32on': {
      'en': 'College/University',
      'es': '',
      'fr': '',
    },
    'ua4slbh4': {
      'en': 'Professional (Europe, AHL, NHL or other)',
      'es': '',
      'fr': '',
    },
    'rs8bz3ev': {
      'en': 'Select one',
      'es': '',
      'fr': '',
    },
    'fdf8yuer': {
      'en': 'Yes',
      'es': '',
      'fr': '',
    },
    'cp56ou6e': {
      'en': 'No',
      'es': '',
      'fr': '',
    },
    'umxzg4if': {
      'en': 'Select one',
      'es': '',
      'fr': '',
    },
    'vy4nprus': {
      'en': 'Ball Hockey Experience',
      'es': '',
      'fr': '',
    },
    'n6r7y7o8': {
      'en': 'Yes',
      'es': '',
      'fr': '',
    },
    'p3a603cc': {
      'en': 'No',
      'es': '',
      'fr': '',
    },
    'caad2xrg': {
      'en': 'Select one',
      'es': '',
      'fr': '',
    },
    'walteeli': {
      'en': 'Your last team',
      'es': '',
      'fr': '',
    },
    '1xv7knsp': {
      'en': 'Street Hockey only / Play On!',
      'es': '',
      'fr': '',
    },
    'r3z57gtu': {
      'en': 'Minor Ball Hockey League​',
      'es': '',
      'fr': '',
    },
    'ekhy1kj2': {
      'en': 'Provincial Ball Hockey Tournament​',
      'es': '',
      'fr': '',
    },
    'dn4q3txq': {
      'en': 'Competitive DEK Hockey (common in Quebec and USA)​',
      'es': '',
      'fr': '',
    },
    'tcppq474': {
      'en': 'National / International Tournament (NBHF, CBHA, or ISBHF)',
      'es': '',
      'fr': '',
    },
    'f2ans8bc': {
      'en': 'Redwood Cup',
      'es': '',
      'fr': '',
    },
    'q7cr205v': {
      'en': 'Select one',
      'es': '',
      'fr': '',
    },
    '1uu96m2m': {
      'en': 'Yes',
      'es': '',
      'fr': '',
    },
    '6qappeqh': {
      'en': 'No',
      'es': '',
      'fr': '',
    },
    'dpahybba': {
      'en': 'Select one',
      'es': '',
      'fr': '',
    },
    '64ks6qra': {
      'en': 'Back',
      'es': '',
      'fr': '',
    },
    'zh2amxh0': {
      'en': 'Next',
      'es': '',
      'fr': '',
    },
    'r0xhaum9': {
      'en': 'Register',
      'es': '',
      'fr': '',
    },
  },
  // Register_Player_05
  {
    'p66wh4a6': {
      'en': 'You are the Team Player',
      'es': '',
      'fr': '',
    },
    'bqywcutl': {
      'en': '1',
      'es': '',
      'fr': '',
    },
    '0zu65hwv': {
      'en': 'Select Team',
      'es': '',
      'fr': '',
    },
    'atjp5f7j': {
      'en': '2',
      'es': '',
      'fr': '',
    },
    'ir1hrkls': {
      'en': 'Your Details',
      'es': '',
      'fr': '',
    },
    'vwl5q1w4': {
      'en': '3',
      'es': '',
      'fr': '',
    },
    '7r4zdbiy': {
      'en': 'Experience',
      'es': '',
      'fr': '',
    },
    'me8yglj9': {
      'en': '4',
      'es': '',
      'fr': '',
    },
    'vfghyqv6': {
      'en': 'Birthdate',
      'es': '',
      'fr': '',
    },
    'rq18fzk2': {
      'en': '5',
      'es': '',
      'fr': '',
    },
    'woouegye': {
      'en': 'Waiver',
      'es': '',
      'fr': '',
    },
    'sye5krt3': {
      'en': '6',
      'es': '',
      'fr': '',
    },
    '5xsxadh0': {
      'en': 'Payment',
      'es': '',
      'fr': '',
    },
    'g2cntn3y': {
      'en': '7',
      'es': '',
      'fr': '',
    },
    'kz7cswb5': {
      'en': 'Fans',
      'es': '',
      'fr': '',
    },
    'yy3rfq48': {
      'en': '5',
      'es': '',
      'fr': '',
    },
    'emq0d0xk': {
      'en': 'Your Team Name is :',
      'es': '',
      'fr': '',
    },
    'p7ufq7aa': {
      'en': 'Your playing in :',
      'es': '',
      'fr': '',
    },
    '5igkxdjv': {
      'en': 'WAIVER, RELEASE AND INDEMNIFICATION:',
      'es': '',
      'fr': '',
    },
    'slzrg61l': {
      'en':
          'Every player, and his/her parent or guardian (if the player is under 18) must read. execute, and deliver this waiver to tournament organizers prior to the commencement of the tournament. in consideration of the right and opportunity to participate in the play On! street hockey tournament conducted by the not for profit organization play On! Canada (POC),and its licensed affiliates, the undersigned hereby acknowledges and agrees as follows: I (who am the participant\'s parent or legal guardian if the participant is under 18 year old) hereby consent to the use without compensation, of my/his/her name  and/or likeness, biographical material and/or voice in publicity and advertising concerning the play On! tournament by PPOC and/or any playOn! tournament partners or sponsored in any and all media and/or promotion and throughout the world. in addition, the undersigned (on behalf of the participant if the participant is under 18 years of age) forever generally and completely release and discharge and shall indemnify and hold harmless Play On! Canada and its employees, directors, officers, agents, sponsors, partners and licensees and each other party affiliated with play On! Canada and each of its owners, agents, directors, officers, employees, sponsors and partners(collectively, \"Event Organizers\") against and from any and all claims and demands of every kind and nature whatsoever, for damages or injuries ,actual or consequential, past, present or future, raising out of or in any   way related to the Play On! street hockey  tournament, including but not limited to any claims of injury from participating in OR observing the tournament, the loss of personal property by theft to otherwise during the tournament, any publicity related to the tournament, or any prizes   awarded. The undersigned acknowledges that of its own free will he/she has chosen to participate in the tournament and related activities. I understand and acknowledge that the aforementioned activities carry with them a high level of risk of injury  and additional hazards related thereto. i certify that i am  aware kof ,and accept, these increased risks and that i am mentally and physically prepared for the risks associated with the play On! street hockey tournament. This general release shall further apply to all unknown, unanticipated, unsuspected, and undisclosed claims, demands, liabilities, actions or causes of action, in law, equality or otherwise.  This Waiver shall bind heirs, personal representatives, and successors of the undersigned, and inure to the benefit of the Event Organizers.',
      'es': '',
      'fr': '',
    },
    '3f6m7a5o': {
      'en':
          'I HAVE READ AND UNDERSTAND THE TERMS OF THE ABOVE AGREEMENT, WILL COMPLY WITH TERMS HERE OF AND ACKNOWLEDGE THAT BY SIGNIG THIS FORM I AM GIVING UP LEGAL RIGHTS.',
      'es': '',
      'fr': '',
    },
    'wwcctokc': {
      'en': 'Date Of Birth',
      'es': '',
      'fr': '',
    },
    'oyrjmnnl': {
      'en': ':',
      'es': '',
      'fr': '',
    },
    '79ighh6i': {
      'en': ' / ',
      'es': '',
      'fr': '',
    },
    'vrbu7h3p': {
      'en': ' / ',
      'es': '',
      'fr': '',
    },
    'zz18ftml': {
      'en': 'Player Name',
      'es': '',
      'fr': '',
    },
    'fd7lwz8q': {
      'en': ':',
      'es': '',
      'fr': '',
    },
    's05cv6gq': {
      'en': 'Event Location(City) ',
      'es': '',
      'fr': '',
    },
    'gp4ybtpn': {
      'en': ':',
      'es': '',
      'fr': '',
    },
    '1zqtjo43': {
      'en': 'Team Name',
      'es': '',
      'fr': '',
    },
    'vnv1xh1u': {
      'en': ':',
      'es': '',
      'fr': '',
    },
    'lwr3xfq9': {
      'en': 'Signature',
      'es': '',
      'fr': '',
    },
    'svsvmi4e': {
      'en': 'Parent Name',
      'es': '',
      'fr': '',
    },
    'cni2xi0c': {
      'en': 'Enter your parent name',
      'es': '',
      'fr': '',
    },
    '7760v25v': {
      'en': 'Parent Email  Address',
      'es': '',
      'fr': '',
    },
    'njymyn6l': {
      'en': 'Enter your email address',
      'es': '',
      'fr': '',
    },
    'qynjo3a3': {
      'en': 'Sent waiver details to parent',
      'es': '',
      'fr': '',
    },
    'o585c49w': {
      'en': 'Back',
      'es': '',
      'fr': '',
    },
    'vp1v0c79': {
      'en': 'Next',
      'es': '',
      'fr': '',
    },
    'ceajqv7k': {
      'en': 'Register',
      'es': '',
      'fr': '',
    },
  },
  // Register_Player_06
  {
    'a7ywhiae': {
      'en': 'You are the Team Player',
      'es': '',
      'fr': '',
    },
    '5bmwtr0f': {
      'en': '1',
      'es': '',
      'fr': '',
    },
    '41nuys2t': {
      'en': 'Select Team',
      'es': '',
      'fr': '',
    },
    '6008u91n': {
      'en': '2',
      'es': '',
      'fr': '',
    },
    'iwvxupk4': {
      'en': 'Your Details',
      'es': '',
      'fr': '',
    },
    'wtg5h1xt': {
      'en': '3',
      'es': '',
      'fr': '',
    },
    'xfdr727j': {
      'en': 'Experience',
      'es': '',
      'fr': '',
    },
    '1xxedoj4': {
      'en': '4',
      'es': '',
      'fr': '',
    },
    '70g1e1om': {
      'en': 'Birthdate',
      'es': '',
      'fr': '',
    },
    'nerxk5cj': {
      'en': '5',
      'es': '',
      'fr': '',
    },
    'mo1wd5no': {
      'en': 'Waiver',
      'es': '',
      'fr': '',
    },
    'q8geukhw': {
      'en': '6',
      'es': '',
      'fr': '',
    },
    'vxfxkyzt': {
      'en': 'Payment',
      'es': '',
      'fr': '',
    },
    '8vicfkkv': {
      'en': '7',
      'es': '',
      'fr': '',
    },
    'vpwe436p': {
      'en': 'Fans',
      'es': '',
      'fr': '',
    },
    'wsxtbml8': {
      'en': '6',
      'es': '',
      'fr': '',
    },
    'gofy9vwj': {
      'en': 'Your Team Name is:',
      'es': '',
      'fr': '',
    },
    '214lf12p': {
      'en': 'Your playing in:',
      'es': '',
      'fr': '',
    },
    'hh9qwpqz': {
      'en': 'The individual Player Fee is',
      'es': '',
      'fr': '',
    },
    '6pcd6cao': {
      'en': 'Tax',
      'es': '',
      'fr': '',
    },
    'o2qesk1f': {
      'en':
          'By paying your fees you confirm that you will participate in this event. Please do not pay your registration fee unless you are certain that you will play, as participation fees are not refundable under any circumstances',
      'es': '',
      'fr': '',
    },
    'l85arip8': {
      'en': 'I understand, I am committed to playing!',
      'es': '',
      'fr': '',
    },
    'e8oq5mm5': {
      'en': 'Back',
      'es': '',
      'fr': '',
    },
    'os9fw7e4': {
      'en': 'Next',
      'es': '',
      'fr': '',
    },
    'qqlr3km2': {
      'en': 'Register',
      'es': '',
      'fr': '',
    },
  },
  // Register_Player_07
  {
    'dzkd8q28': {
      'en': 'You are the Team Player',
      'es': '',
      'fr': '',
    },
    'k35far2o': {
      'en': '7',
      'es': '',
      'fr': '',
    },
    'eg999655': {
      'en': '1',
      'es': '',
      'fr': '',
    },
    '4lr2db24': {
      'en': 'Select Team',
      'es': '',
      'fr': '',
    },
    'nb3xbfvr': {
      'en': '2',
      'es': '',
      'fr': '',
    },
    'zyuunxhr': {
      'en': 'Your Details',
      'es': '',
      'fr': '',
    },
    'rztjz0qt': {
      'en': '3',
      'es': '',
      'fr': '',
    },
    'm9sdxo7o': {
      'en': 'Experience',
      'es': '',
      'fr': '',
    },
    '5zut3kcd': {
      'en': '4',
      'es': '',
      'fr': '',
    },
    'r3gjxqh5': {
      'en': 'Birthdate',
      'es': '',
      'fr': '',
    },
    'agff6905': {
      'en': '5',
      'es': '',
      'fr': '',
    },
    'hnoxhphy': {
      'en': 'Waiver',
      'es': '',
      'fr': '',
    },
    'rx2ue0hv': {
      'en': '6',
      'es': '',
      'fr': '',
    },
    'bjnobnll': {
      'en': 'Payment',
      'es': '',
      'fr': '',
    },
    'u3er5q1y': {
      'en': '7',
      'es': '',
      'fr': '',
    },
    'lzo15rao': {
      'en': 'Fans',
      'es': '',
      'fr': '',
    },
    'jd6p3616': {
      'en': 'Your Team Name is:',
      'es': '',
      'fr': '',
    },
    '0tovltb8': {
      'en': 'Your playing in:',
      'es': '',
      'fr': '',
    },
    '7hm6w6di': {
      'en': '<Message once Payment is successful>',
      'es': '',
      'fr': '',
    },
    'n9v9zqf6': {
      'en':
          'Now, please allow us to explain an exciting new aspect of the Play On! program: Play for Pay&trade;.',
      'es': '',
      'fr': '',
    },
    'eq0wuk13': {
      'en': 'Please take 2 minutes to watch this animated video that explains',
      'es': '',
      'fr': '',
    },
    'evbh4nlu': {
      'en': 'Watch Online',
      'es': '',
      'fr': '',
    },
    'rnszpwls': {
      'en': 'Back',
      'es': '',
      'fr': '',
    },
    'g1obactc': {
      'en': 'Next',
      'es': '',
      'fr': '',
    },
    'toovxpbl': {
      'en': 'Register',
      'es': '',
      'fr': '',
    },
  },
  // Register_Referee_00
  {
    'e72pdhqu': {
      'en': 'Menu',
      'es': 'Menú',
      'fr': 'Menu',
    },
    'dgxm0okd': {
      'en': 'PlayOn! Store',
      'es': '¡Juega! Tienda',
      'fr': 'Jouer sur! Boutique',
    },
    'av4mjnjq': {
      'en': 'Go to the PlayOn! Store',
      'es': '¡Ve al PlayOn! Tienda',
      'fr': 'Rendez-vous sur PlayOn! Boutique',
    },
    'bztbpnqb': {
      'en': '\nReferee Registration',
      'es': 'Registro de árbitros',
      'fr': 'Inscription des arbitres',
    },
    '591fdnyl': {
      'en': '1',
      'es': '',
      'fr': '',
    },
    '5k48z9cp': {
      'en': 'Basic Details',
      'es': '',
      'fr': '',
    },
    't7hm5z2o': {
      'en': '2',
      'es': '',
      'fr': '',
    },
    'msco0iz3': {
      'en': 'Experience',
      'es': '',
      'fr': '',
    },
    'gdu68au2': {
      'en': '3',
      'es': '',
      'fr': '',
    },
    'suzghwqo': {
      'en': 'References',
      'es': '',
      'fr': '',
    },
    'i4xjpac4': {
      'en': '4',
      'es': '',
      'fr': '',
    },
    'o3oq29f2': {
      'en': 'Event\nSelection',
      'es': '',
      'fr': '',
    },
    'to42s1uw': {
      'en': '5',
      'es': '',
      'fr': '',
    },
    'y38hkd1p': {
      'en': 'Availability',
      'es': '',
      'fr': '',
    },
    '9wvmw8j7': {
      'en': '6',
      'es': '',
      'fr': '',
    },
    'v29v7a5p': {
      'en': 'Waiver',
      'es': '',
      'fr': '',
    },
    'x8g6cylb': {
      'en': '7',
      'es': '',
      'fr': '',
    },
    'xzqd24zy': {
      'en': 'Payment Details',
      'es': '',
      'fr': '',
    },
    'zu12fcps': {
      'en': '1',
      'es': '',
      'fr': '',
    },
    'cfn63clx': {
      'en': ' Enter your first name',
      'es': 'Ponga su primer nombre',
      'fr': 'Entrez votre prénom',
    },
    'ggzk4fcc': {
      'en': ' Enter your last name',
      'es': 'Ingrese su Apellido',
      'fr': 'Entrez votre nom de famille',
    },
    'rnsts7kw': {
      'en': ' Enter mobile number',
      'es': 'Ingrese el número de móvil',
      'fr': 'Entrez le numéro de portable',
    },
    'nwthh3sn': {
      'en': 'Enter your email id',
      'es': 'Ingrese su ID de correo electrónico',
      'fr': 'Entrez votre identifiant de messagerie',
    },
    '9pz7gf5j': {
      'en': 'Enter your address details',
      'es': 'Ingrese los detalles de su dirección',
      'fr': 'Entrez les détails de votre adresse',
    },
    '56woggn4': {
      'en': 'Enter your address details',
      'es': 'Ingrese los detalles de su dirección',
      'fr': 'Entrez les détails de votre adresse',
    },
    'xy82be5r': {
      'en': ' Enter your city details',
      'es': 'Introduce los datos de tu ciudad',
      'fr': 'Entrez les détails de votre ville',
    },
    '8ss8tlrn': {
      'en': 'British Columbia',
      'es': 'Columbia Británica',
      'fr': 'Colombie britannique',
    },
    'vmysawdw': {
      'en': 'Please select...',
      'es': 'Por favor selecciona...',
      'fr': 'Veuillez sélectionner...',
    },
    'tmjkaykw': {
      'en': 'Canada',
      'es': 'Canadá',
      'fr': 'Canada',
    },
    '5tvwdr7n': {
      'en': 'US',
      'es': 'nosotros',
      'fr': 'nous',
    },
    'ntgomja9': {
      'en': 'Please select...',
      'es': 'Por favor selecciona...',
      'fr': 'Veuillez sélectionner...',
    },
    'gh8qf7w0': {
      'en': '   Enter postal code',
      'es': 'Ingrese el código postal',
      'fr': 'Entrez le code postal',
    },
    'fogur944': {
      'en': 'Back',
      'es': 'atrás',
      'fr': 'Retour',
    },
    '2xtkumrz': {
      'en': 'Next',
      'es': 'próximo',
      'fr': 'Suivant',
    },
    'jphlscol': {
      'en': 'Register',
      'es': '',
      'fr': '',
    },
  },
  // Register_Referee_01
  {
    '7or5pj8d': {
      'en': 'Menu',
      'es': 'Menú',
      'fr': 'Menu',
    },
    'ia3fabrf': {
      'en': 'PlayOn! Store',
      'es': '¡Juega! Tienda',
      'fr': 'Jouer sur! Boutique',
    },
    'swjl0xvc': {
      'en': 'Go to the PlayOn! Store',
      'es': '¡Ve al PlayOn! Tienda',
      'fr': 'Rendez-vous sur PlayOn! Boutique',
    },
    '5d2yaqut': {
      'en': 'Referee Registration',
      'es': 'Registro de árbitros',
      'fr': 'Inscription des arbitres',
    },
    'ukiv6zic': {
      'en': '2',
      'es': '',
      'fr': '',
    },
    'tftrybq6': {
      'en': '1',
      'es': '',
      'fr': '',
    },
    'vf4q0lze': {
      'en': 'Basic Details',
      'es': '',
      'fr': '',
    },
    'zagjypcb': {
      'en': '2',
      'es': '',
      'fr': '',
    },
    'ts9ye8xl': {
      'en': 'Experience',
      'es': '',
      'fr': '',
    },
    '2s6cez7x': {
      'en': '3',
      'es': '',
      'fr': '',
    },
    'yu1ltbqw': {
      'en': 'References',
      'es': '',
      'fr': '',
    },
    'wuq5icix': {
      'en': '4',
      'es': '',
      'fr': '',
    },
    'km681mi6': {
      'en': 'Event\nSelection',
      'es': '',
      'fr': '',
    },
    '6k5ngdhv': {
      'en': '5',
      'es': '',
      'fr': '',
    },
    'vyqe0hie': {
      'en': 'Availability',
      'es': '',
      'fr': '',
    },
    '9lcxnmz7': {
      'en': '6',
      'es': '',
      'fr': '',
    },
    '1hun0so8': {
      'en': 'Waiver',
      'es': '',
      'fr': '',
    },
    'ssygs2f8': {
      'en': '7',
      'es': '',
      'fr': '',
    },
    '9ki9xjob': {
      'en': 'Payment Details',
      'es': '',
      'fr': '',
    },
    '38hxgxl5': {
      'en': 'Yes',
      'es': '',
      'fr': '',
    },
    'v9646laj': {
      'en': 'No',
      'es': '',
      'fr': '',
    },
    '4uxhjao0': {
      'en': 'Please select...',
      'es': '',
      'fr': '',
    },
    'yizv94kq': {
      'en': 'Youth',
      'es': 'Juventud',
      'fr': 'Jeunesse',
    },
    'p0jybqhq': {
      'en': 'Please select...',
      'es': 'Por favor selecciona...',
      'fr': 'Veuillez sélectionner...',
    },
    'ez9jb83v': {
      'en': 'Yes',
      'es': '',
      'fr': '',
    },
    'vdim8pfs': {
      'en': 'No',
      'es': '',
      'fr': '',
    },
    'mgglzapn': {
      'en': 'Please select...',
      'es': '',
      'fr': '',
    },
    '5n80oho7': {
      'en': 'Yes',
      'es': '',
      'fr': '',
    },
    'lb17f6qt': {
      'en': 'No',
      'es': '',
      'fr': '',
    },
    '0d4k1hii': {
      'en': 'Please select...',
      'es': '',
      'fr': '',
    },
    'kmcmsufx': {
      'en': 'Enter highest level',
      'es': 'Entrar en el nivel más alto',
      'fr': 'Entrez le niveau le plus élevé',
    },
    'jrk3jz0u': {
      'en': 'Yes',
      'es': '',
      'fr': '',
    },
    'b38brk5l': {
      'en': 'No',
      'es': '',
      'fr': '',
    },
    'xptmd1u1': {
      'en': 'Please select...',
      'es': '',
      'fr': '',
    },
    '9alhx7kx': {
      'en': 'Enter highest level',
      'es': 'Entrar en el nivel más alto',
      'fr': 'Entrez le niveau le plus élevé',
    },
    'yq5dyo3y': {
      'en': 'Yes',
      'es': '',
      'fr': '',
    },
    'z90dylr4': {
      'en': 'No',
      'es': '',
      'fr': '',
    },
    'v05cixwh': {
      'en': 'Please select...',
      'es': '',
      'fr': '',
    },
    '5i9ploqr': {
      'en': 'Enter highest level',
      'es': 'Entrar en el nivel más alto',
      'fr': 'Entrez le niveau le plus élevé',
    },
    'cmkk94t2': {
      'en': 'Yes',
      'es': '',
      'fr': '',
    },
    '6vraeb37': {
      'en': 'No',
      'es': '',
      'fr': '',
    },
    '8q0kbtdz': {
      'en': 'Please select...',
      'es': '',
      'fr': '',
    },
    'q8v6kz0n': {
      'en': 'Enter highest level',
      'es': 'Entrar en el nivel más alto',
      'fr': 'Entrez le niveau le plus élevé',
    },
    'hjrersvk': {
      'en': 'Yes',
      'es': '',
      'fr': '',
    },
    '7x7sxb70': {
      'en': 'No',
      'es': '',
      'fr': '',
    },
    'qdk8nggi': {
      'en': 'Please select...',
      'es': '',
      'fr': '',
    },
    'wg3k2vka': {
      'en': 'Enter highest level',
      'es': 'Entrar en el nivel más alto',
      'fr': 'Entrez le niveau le plus élevé',
    },
    '79r9fs0t': {
      'en': 'Yes',
      'es': '',
      'fr': '',
    },
    'eob0i5z9': {
      'en': 'No',
      'es': '',
      'fr': '',
    },
    'em3vvylf': {
      'en': 'Please select...',
      'es': '',
      'fr': '',
    },
    '9cw36167': {
      'en': 'Enter highest level',
      'es': 'Entrar en el nivel más alto',
      'fr': 'Entrez le niveau le plus élevé',
    },
    'cfyihlnk': {
      'en': 'Yes',
      'es': '',
      'fr': '',
    },
    'w4arrfz4': {
      'en': 'No',
      'es': '',
      'fr': '',
    },
    'ufxxi04t': {
      'en': 'Please select...',
      'es': '',
      'fr': '',
    },
    'jctaad13': {
      'en': 'Enter highest level',
      'es': 'Entrar en el nivel más alto',
      'fr': 'Entrez le niveau le plus élevé',
    },
    'mk5jzclg': {
      'en': 'Back',
      'es': 'atrás',
      'fr': 'Retour',
    },
    'v5zm75rx': {
      'en': 'Next',
      'es': 'próximo',
      'fr': 'Suivant',
    },
    'esntdplo': {
      'en': 'Register',
      'es': 'Registrarse',
      'fr': 'S&#39;inscrire',
    },
  },
  // Register_Referee_02
  {
    '2azspto1': {
      'en': 'Menu',
      'es': 'Menú',
      'fr': 'Menu',
    },
    'nk42tcu6': {
      'en': 'PlayOn! Store',
      'es': '¡Juega! Tienda',
      'fr': 'Jouer sur! Boutique',
    },
    '5nflomba': {
      'en': 'Go to the PlayOn! Store',
      'es': '¡Ve al PlayOn! Tienda',
      'fr': 'Rendez-vous sur PlayOn! Boutique',
    },
    'wba1v2q0': {
      'en': 'Referee Registration',
      'es': 'Registro de árbitros',
      'fr': 'Inscription des arbitres',
    },
    'cwjw938r': {
      'en': '3',
      'es': '',
      'fr': '',
    },
    'hgiufw2o': {
      'en': '1',
      'es': '',
      'fr': '',
    },
    'fqzsymgm': {
      'en': 'Basic Details',
      'es': '',
      'fr': '',
    },
    'q4wuzgjl': {
      'en': '2',
      'es': '',
      'fr': '',
    },
    'p067uxt2': {
      'en': 'Experience',
      'es': '',
      'fr': '',
    },
    'xtn1u95i': {
      'en': '3',
      'es': '',
      'fr': '',
    },
    'nsknbrlf': {
      'en': 'References',
      'es': '',
      'fr': '',
    },
    'ndhm5o94': {
      'en': '4',
      'es': '',
      'fr': '',
    },
    '4j80g595': {
      'en': 'Event\nSelection',
      'es': '',
      'fr': '',
    },
    'o0ayxscc': {
      'en': '5',
      'es': '',
      'fr': '',
    },
    'k9cckqzw': {
      'en': 'Availability',
      'es': '',
      'fr': '',
    },
    'un694ywc': {
      'en': '6',
      'es': '',
      'fr': '',
    },
    '4ud89lo1': {
      'en': 'Waiver',
      'es': '',
      'fr': '',
    },
    'ea7efkjh': {
      'en': '7',
      'es': '',
      'fr': '',
    },
    'gxo8wy1k': {
      'en': 'Payment Details',
      'es': '',
      'fr': '',
    },
    'nwufgjco': {
      'en': 'Reference 1',
      'es': 'Referencia 1',
      'fr': 'Référence 1',
    },
    '0wfot9ju': {
      'en': ' Enter first name',
      'es': 'Ingrese el nombre',
      'fr': 'Entrez votre prénom',
    },
    '7xveden6': {
      'en': 'Enter last name',
      'es': 'Introduzca el apellido',
      'fr': 'Entrer le nom de famille',
    },
    'n6yz1sn1': {
      'en': ' Enter contact information',
      'es': 'Ingrese la información de contacto',
      'fr': 'Entrez les informations de contact',
    },
    'jf19iojb': {
      'en': 'Enter email address',
      'es': 'Introducir la dirección de correo electrónico',
      'fr': 'Entrer l&#39;adresse e-mail',
    },
    '5qor906e': {
      'en': '   Enter a value',
      'es': 'Introduce un valor',
      'fr': 'Entrez une valeur',
    },
    'tqhjwxv7': {
      'en': 'Reference 2',
      'es': 'Referencia 2',
      'fr': 'Référence 2',
    },
    'vcm3gspp': {
      'en': 'Enter first name',
      'es': 'Ingrese el nombre',
      'fr': 'Entrez votre prénom',
    },
    'lo115afh': {
      'en': '   Enter last name',
      'es': 'Introduzca el apellido',
      'fr': 'Entrer le nom de famille',
    },
    'wntchb6x': {
      'en': ' Enter contact information',
      'es': 'Ingrese la información de contacto',
      'fr': 'Entrez les informations de contact',
    },
    'gfa93msz': {
      'en': ' Enter email address',
      'es': 'Introducir la dirección de correo electrónico',
      'fr': 'Entrer l&#39;adresse e-mail',
    },
    'omu96fxo': {
      'en': '   Enter a value',
      'es': 'Introduce un valor',
      'fr': 'Entrez une valeur',
    },
    '9wvrasai': {
      'en': 'Back',
      'es': 'atrás',
      'fr': 'Retour',
    },
    '5z60utd7': {
      'en': 'Next',
      'es': 'próximo',
      'fr': 'Suivant',
    },
    'txzwu5ee': {
      'en': 'Register',
      'es': '',
      'fr': '',
    },
  },
  // Register_Referee_03
  {
    '7uywt0pt': {
      'en': 'Menu',
      'es': 'Menú',
      'fr': 'Menu',
    },
    'r4lqmmw9': {
      'en': 'PlayOn! Store',
      'es': '¡Juega! Tienda',
      'fr': 'Jouer sur! Boutique',
    },
    'nv050y9d': {
      'en': 'Go to the PlayOn! Store',
      'es': '¡Ve al PlayOn! Tienda',
      'fr': 'Rendez-vous sur PlayOn! Boutique',
    },
    '6zcmqd02': {
      'en': 'Referee Registration',
      'es': 'Registro de árbitros',
      'fr': 'Inscription des arbitres',
    },
    'hzhax5sk': {
      'en': '1',
      'es': '',
      'fr': '',
    },
    'q77y61di': {
      'en': 'Basic Details',
      'es': '',
      'fr': '',
    },
    'r97ir4jt': {
      'en': '2',
      'es': '',
      'fr': '',
    },
    'mtf3fb2i': {
      'en': 'Experience',
      'es': '',
      'fr': '',
    },
    'gw69gf29': {
      'en': '3',
      'es': '',
      'fr': '',
    },
    'gzsul5dy': {
      'en': 'References',
      'es': '',
      'fr': '',
    },
    'j6bzg2jw': {
      'en': '4',
      'es': '',
      'fr': '',
    },
    '20t8f8v6': {
      'en': 'Event\nSelection',
      'es': '',
      'fr': '',
    },
    '81fpsb85': {
      'en': '5',
      'es': '',
      'fr': '',
    },
    'ox6kr1e9': {
      'en': 'Availability',
      'es': '',
      'fr': '',
    },
    '4guy5ihc': {
      'en': '6',
      'es': '',
      'fr': '',
    },
    'ycmvypv5': {
      'en': 'Waiver',
      'es': '',
      'fr': '',
    },
    'dkslaaf1': {
      'en': '7',
      'es': '',
      'fr': '',
    },
    'zcpbgt8w': {
      'en': 'Payment Details',
      'es': '',
      'fr': '',
    },
    '609gn4c8': {
      'en': '4',
      'es': '',
      'fr': '',
    },
    'cbidi7z7': {
      'en': 'Back',
      'es': 'atrás',
      'fr': 'Retour',
    },
    'nk4avnkk': {
      'en': 'Next',
      'es': 'próximo',
      'fr': 'Suivant',
    },
    'cgtxpqq7': {
      'en': 'Register',
      'es': '',
      'fr': '',
    },
  },
  // Register_Referee_04
  {
    'hzlnn7aw': {
      'en': 'Menu',
      'es': 'Menú',
      'fr': 'Menu',
    },
    'pps3pd16': {
      'en': 'PlayOn! Store',
      'es': '¡Juega! Tienda',
      'fr': 'Jouer sur! Boutique',
    },
    'rmnjnx8m': {
      'en': 'Go to the PlayOn! Store',
      'es': '¡Ve al PlayOn! Tienda',
      'fr': 'Rendez-vous sur PlayOn! Boutique',
    },
    '6pa07go5': {
      'en': 'Referee Registration',
      'es': 'Registro de árbitros',
      'fr': 'Inscription des arbitres',
    },
    'r8x62esk': {
      'en': '1',
      'es': '',
      'fr': '',
    },
    'fkqgozgu': {
      'en': 'Basic Details',
      'es': '',
      'fr': '',
    },
    'rcdqkpru': {
      'en': '2',
      'es': '',
      'fr': '',
    },
    'ltmbkgm9': {
      'en': 'Experience',
      'es': '',
      'fr': '',
    },
    'pezg8agd': {
      'en': '3',
      'es': '',
      'fr': '',
    },
    'fclmw88o': {
      'en': 'References',
      'es': '',
      'fr': '',
    },
    '6fn6e16t': {
      'en': '4',
      'es': '',
      'fr': '',
    },
    'hn54z3ew': {
      'en': 'Event\nSelection',
      'es': '',
      'fr': '',
    },
    'kuplj6sg': {
      'en': '5',
      'es': '',
      'fr': '',
    },
    'jg4o4l6s': {
      'en': 'Availability',
      'es': '',
      'fr': '',
    },
    'ruu018sv': {
      'en': '6',
      'es': '',
      'fr': '',
    },
    '4k7dz404': {
      'en': 'Waiver',
      'es': '',
      'fr': '',
    },
    'qc7drtd6': {
      'en': '7',
      'es': '',
      'fr': '',
    },
    'mejmv51l': {
      'en': 'Payment Details',
      'es': '',
      'fr': '',
    },
    '20zo6yex': {
      'en': '5',
      'es': '',
      'fr': '',
    },
    '96rcig35': {
      'en': 'Back',
      'es': 'atrás',
      'fr': 'Retour',
    },
    'zafjogfr': {
      'en': 'Next',
      'es': 'próximo',
      'fr': 'Suivant',
    },
    'uyj38kzv': {
      'en': 'Register',
      'es': '',
      'fr': '',
    },
  },
  // Register_Referee_06
  {
    '8wle8vco': {
      'en': 'Menu',
      'es': 'Menú',
      'fr': 'Menu',
    },
    'm9t7nrgc': {
      'en': 'PlayOn! Store',
      'es': '¡Juega! Tienda',
      'fr': 'Jouer sur! Boutique',
    },
    'nthsbv0s': {
      'en': 'Go to the PlayOn! Store',
      'es': '¡Ve al PlayOn! Tienda',
      'fr': 'Rendez-vous sur PlayOn! Boutique',
    },
    'zqqp1skn': {
      'en': 'Referee Registration',
      'es': 'Registro de árbitros',
      'fr': 'Inscription des arbitres',
    },
    'p923sil5': {
      'en': '7',
      'es': '',
      'fr': '',
    },
    'w12lt9j8': {
      'en': '1',
      'es': '',
      'fr': '',
    },
    '0x9iarbx': {
      'en': 'Basic Details',
      'es': '',
      'fr': '',
    },
    '1bt0kbna': {
      'en': '2',
      'es': '',
      'fr': '',
    },
    'qoc854jl': {
      'en': 'Experience',
      'es': '',
      'fr': '',
    },
    'wzv4cfqb': {
      'en': '3',
      'es': '',
      'fr': '',
    },
    'e1mc0po3': {
      'en': 'References',
      'es': '',
      'fr': '',
    },
    '20sgww0e': {
      'en': '4',
      'es': '',
      'fr': '',
    },
    '0lnozy63': {
      'en': 'Event\nSelection',
      'es': '',
      'fr': '',
    },
    '1jpu1d2u': {
      'en': '5',
      'es': '',
      'fr': '',
    },
    'w2wc99h1': {
      'en': 'Availability',
      'es': '',
      'fr': '',
    },
    'aehrdy04': {
      'en': '6',
      'es': '',
      'fr': '',
    },
    'adutfdrh': {
      'en': 'Waiver',
      'es': '',
      'fr': '',
    },
    'j3e0jlnz': {
      'en': '7',
      'es': '',
      'fr': '',
    },
    'qmb9y55f': {
      'en': 'Payment Details',
      'es': '',
      'fr': '',
    },
    '4yggl8j3': {
      'en': 'Cheque Emailing',
      'es': 'Comprobar el envío de correos electrónicos',
      'fr': 'Vérifier l&#39;envoi d&#39;e-mails',
    },
    'c2vo7ljt': {
      'en': 'Cheque Emailing',
      'es': 'Comprobar el envío de correos electrónicos',
      'fr': 'Vérifier l&#39;envoi d&#39;e-mails',
    },
    'xnipvoq8': {
      'en': 'Cash',
      'es': 'Dinero en efectivo',
      'fr': 'En espèces',
    },
    'e95ucjzy': {
      'en': 'Please select...',
      'es': 'Por favor selecciona...',
      'fr': 'Veuillez sélectionner...',
    },
    'q5h9hfak': {
      'en':
          'Please confirm your address for payment. Its is your responsibility to make sure your mailing address is entered correctly',
      'es':
          'Por favor, confirme su dirección para el pago. es su responsabilidad asegurarse de que su dirección postal se ingrese correctamente',
      'fr':
          'Veuillez confirmer votre adresse pour le paiement. il est de votre responsabilité de vous assurer que votre adresse postale est saisie correctement',
    },
    'oxpck7a4': {
      'en': ' Enter street address',
      'es': '',
      'fr': '',
    },
    'lk4zb053': {
      'en': 'City 1',
      'es': 'Ciudad 1',
      'fr': 'Ville 1',
    },
    'qintzww5': {
      'en': 'City 2',
      'es': 'Ciudad 2',
      'fr': 'Ville 2',
    },
    'xikr13w3': {
      'en': 'Please select...',
      'es': 'Por favor selecciona...',
      'fr': 'Veuillez sélectionner...',
    },
    'n337g266': {
      'en': 'British Columbia',
      'es': 'Columbia Británica',
      'fr': 'Colombie britannique',
    },
    '9lishs49': {
      'en': 'Please select...',
      'es': 'Por favor selecciona...',
      'fr': 'Veuillez sélectionner...',
    },
    '5dhhlqfw': {
      'en': 'TOJOAO',
      'es': '',
      'fr': '',
    },
    'sev2hebb': {
      'en': 'I confirm the emailng address entered above is correct',
      'es':
          'Confirmo que la dirección de correo electrónico ingresada arriba es correcta',
      'fr':
          'Je confirme que l&#39;adresse e-mail saisie ci-dessus est correcte',
    },
    'hsabczuq': {
      'en':
          'Please upload a VOID cheque or upload image of a direct bank deposit or please provide a bank details',
      'es':
          'Cargue un cheque VOID o cargue una imagen de un depósito bancario directo o proporcione los datos bancarios',
      'fr':
          'Veuillez télécharger un chèque ANNULÉ ou télécharger une image d&#39;un dépôt bancaire direct ou veuillez fournir des coordonnées bancaires',
    },
    'uptjpgol': {
      'en': 'Enter name',
      'es': '',
      'fr': '',
    },
    'c9ceh1bf': {
      'en': ' Enter account number',
      'es': '',
      'fr': '',
    },
    '9f28h04l': {
      'en': ' Enter bank',
      'es': '',
      'fr': '',
    },
    '5xjpfagt': {
      'en': 'Enter transit number',
      'es': '',
      'fr': '',
    },
    'hig5u0he': {
      'en': 'Back',
      'es': 'atrás',
      'fr': 'Retour',
    },
    'txd6w3l6': {
      'en': 'Next',
      'es': 'Entregar',
      'fr': 'Soumettre',
    },
    '2gcf7ukk': {
      'en': 'Register',
      'es': '',
      'fr': '',
    },
  },
  // Captain_Profile
  {
    'js4pw7tj': {
      'en': 'Login',
      'es': '',
      'fr': '',
    },
    'e20jhsuj': {
      'en': 'Menu',
      'es': 'Menú',
      'fr': 'Menu',
    },
    'onhhaavj': {
      'en': 'PlayOn! Store',
      'es': '¡Juega! Tienda',
      'fr': 'Jouer sur! Boutique',
    },
    'g7iepeau': {
      'en': 'Go to the PlayOn! Store',
      'es': '¡Ve al PlayOn! Tienda',
      'fr': 'Rendez-vous sur PlayOn! Boutique',
    },
    'jsi1x9q5': {
      'en': 'My Profile',
      'es': '',
      'fr': '',
    },
    'kc3gh8u6': {
      'en': 'Balaji Reddy',
      'es': '',
      'fr': '',
    },
    'smdvhemk': {
      'en': '15/02/2022',
      'es': '',
      'fr': '',
    },
    'ech7q8ic': {
      'en': 'Male',
      'es': '',
      'fr': '',
    },
    '5wq9ktbj': {
      'en': '9751 34 Ave NW, Edmonton, AB T6E 5X9, Canada',
      'es': '',
      'fr': '',
    },
    'x5u0jfpj': {
      'en': 'My Experience',
      'es': '',
      'fr': '',
    },
    'vf5488ks': {
      'en': 'My Stats',
      'es': '',
      'fr': '',
    },
    'emf5tkgj': {
      'en': 'My Donations',
      'es': '',
      'fr': '',
    },
    '78v9v48n': {
      'en': 'Cancel',
      'es': '',
      'fr': '',
    },
    'fakpx5xz': {
      'en': 'Edit',
      'es': '',
      'fr': '',
    },
    'thc91kbv': {
      'en': 'Register',
      'es': '',
      'fr': '',
    },
  },
  // Register_FreeAgent_00
  {
    'x2spr29j': {
      'en': 'Looking for a team? Register as a Free Agent!',
      'es': '',
      'fr': '',
    },
    '39g4ri5t': {
      'en': '1',
      'es': '',
      'fr': '',
    },
    '2sskl7zk': {
      'en':
          'When you register as a Free Agent, other teams will be able to see your profile, location, name, age and experience level.',
      'es': '',
      'fr': '',
    },
    'i4vhzbos': {
      'en': '2',
      'es': '',
      'fr': '',
    },
    'g023x4qm': {
      'en':
          'Teams that are looking for additional players may invite you to join their team.',
      'es': '',
      'fr': '',
    },
    '2jg28xkv': {
      'en': '3',
      'es': '',
      'fr': '',
    },
    '3ovdb9xj': {
      'en': 'You will be notified when you have been invited to join a team.',
      'es': '',
      'fr': '',
    },
    '7xgt9cw2': {
      'en': '4',
      'es': '',
      'fr': '',
    },
    'eqsmn9mp': {
      'en':
          'You will have up to 3 days to decide whether to accept or decline the invitation.',
      'es': '',
      'fr': '',
    },
    'hbonu4n5': {
      'en': '5',
      'es': '',
      'fr': '',
    },
    'zi80rf7j': {
      'en': 'You must join a team before the Registration deadline.',
      'es': '',
      'fr': '',
    },
    'vez6ar2x': {
      'en': '6',
      'es': '',
      'fr': '',
    },
    '81pa7nck': {
      'en':
          'Once you accept an invitation to join a team, you will be required to submit payment immediately via Visa, MasterCard, or PayPal.',
      'es': '',
      'fr': '',
    },
    '8xbnz12r': {
      'en': 'Are you ready?',
      'es': '',
      'fr': '',
    },
    'mr2s4oa6': {
      'en': 'Click here to agree to the Free Agent policies and conditions',
      'es': '',
      'fr': '',
    },
    'kkb0c2jv': {
      'en': 'Begin Free Agent Registration',
      'es': '',
      'fr': '',
    },
    'vvs2pzww': {
      'en':
          'Watch the following video to understand the exciting new Pay for Play program.',
      'es': '',
      'fr': '',
    },
    'cj8os4wx': {
      'en': 'Watch Online',
      'es': '',
      'fr': '',
    },
    'mppg607a': {
      'en': 'Back',
      'es': '',
      'fr': '',
    },
    'ta1hamv5': {
      'en': 'Next',
      'es': '',
      'fr': '',
    },
    'nawgd02m': {
      'en': 'Register',
      'es': '',
      'fr': '',
    },
  },
  // Register_FreeAgent_03
  {
    '8h4numnm': {
      'en': 'Menu',
      'es': 'Menú',
      'fr': 'Menu',
    },
    'pq85r8io': {
      'en': 'PlayOn! Store',
      'es': '¡Juega! Tienda',
      'fr': 'Jouer sur! Boutique',
    },
    '3cntygir': {
      'en': 'Go to the PlayOn! Store',
      'es': '¡Ve al PlayOn! Tienda',
      'fr': 'Rendez-vous sur PlayOn! Boutique',
    },
    '7wgz084e': {
      'en': 'Free Agent Registration',
      'es': '',
      'fr': '',
    },
    'g5cql18g': {
      'en': '1',
      'es': '',
      'fr': '',
    },
    'zr4mmkif': {
      'en': 'Select Event',
      'es': '',
      'fr': '',
    },
    'mrm0qihd': {
      'en': '2',
      'es': '',
      'fr': '',
    },
    'lw2lbe6h': {
      'en': 'Your Details',
      'es': '',
      'fr': '',
    },
    'xmwjjv6o': {
      'en': '3',
      'es': '',
      'fr': '',
    },
    'u3vtmx5b': {
      'en': 'Experience',
      'es': '',
      'fr': '',
    },
    'wz083lq1': {
      'en': '4',
      'es': '',
      'fr': '',
    },
    'dz72u0lb': {
      'en': 'Acknowledgement',
      'es': '',
      'fr': '',
    },
    'spn1el2l': {
      'en': '5',
      'es': '',
      'fr': '',
    },
    'm4at36st': {
      'en': 'Waiver',
      'es': '',
      'fr': '',
    },
    '9vqwqdcm': {
      'en': '6',
      'es': '',
      'fr': '',
    },
    'ivzok5rn': {
      'en': 'Payment',
      'es': '',
      'fr': '',
    },
    'a60365b1': {
      'en': '7',
      'es': '',
      'fr': '',
    },
    'd4sj3skl': {
      'en': 'Charity',
      'es': '',
      'fr': '',
    },
    'qe9kgdq2': {
      'en': '3',
      'es': '',
      'fr': '',
    },
    '0id79ezj': {
      'en': 'Your Team Name is:',
      'es': '',
      'fr': '',
    },
    '3gugoi8u': {
      'en': 'London Giants (pending approval)',
      'es': '',
      'fr': '',
    },
    '9ycokc7s': {
      'en': 'Your playing in:',
      'es': '',
      'fr': '',
    },
    'sl4ps17b': {
      'en': 'Event 1',
      'es': '',
      'fr': '',
    },
    'it60s2bh': {
      'en': 'Ice Hockey Experience',
      'es': '',
      'fr': '',
    },
    'imqafh9k': {
      'en': 'Yes',
      'es': '',
      'fr': '',
    },
    'p8asd1ru': {
      'en': 'No',
      'es': '',
      'fr': '',
    },
    'rscdy20f': {
      'en': 'Please select...',
      'es': '',
      'fr': '',
    },
    'nlfqw637': {
      'en': 'Your last team',
      'es': '',
      'fr': '',
    },
    '7zxfvhx9': {
      'en': 'House/Local/Recreational League',
      'es': '',
      'fr': '',
    },
    'str6kugm': {
      'en': 'AE/MD',
      'es': '',
      'fr': '',
    },
    'zuejtifn': {
      'en': 'A',
      'es': '',
      'fr': '',
    },
    'bpfhhsfm': {
      'en': 'AA',
      'es': '',
      'fr': '',
    },
    'pi8rtf1v': {
      'en': 'AAA',
      'es': '',
      'fr': '',
    },
    '6sudy7oh': {
      'en': 'Junior A/CHL​​',
      'es': '',
      'fr': '',
    },
    'jppsaabx': {
      'en': 'Junior B/C/D​​',
      'es': '',
      'fr': '',
    },
    '9yveufx0': {
      'en': 'College/University​​',
      'es': '',
      'fr': '',
    },
    'zslwjt4c': {
      'en': 'Professional (Europe, AHL, NHL or other)​​​',
      'es': '',
      'fr': '',
    },
    'oben80n9': {
      'en': 'Please select...',
      'es': '',
      'fr': '',
    },
    'ju3bizal': {
      'en': 'Yes',
      'es': '',
      'fr': '',
    },
    'a1c0ojjn': {
      'en': 'No',
      'es': '',
      'fr': '',
    },
    '38haqnp6': {
      'en': 'Please select...',
      'es': '',
      'fr': '',
    },
    '09tunce4': {
      'en': 'Ball Hockey Experience',
      'es': '',
      'fr': '',
    },
    's0t0ac06': {
      'en': 'Yes',
      'es': '',
      'fr': '',
    },
    '513sfait': {
      'en': 'No',
      'es': '',
      'fr': '',
    },
    'tvmkgbeu': {
      'en': 'Please select...',
      'es': '',
      'fr': '',
    },
    'o1brc78j': {
      'en': 'Your last team',
      'es': '',
      'fr': '',
    },
    'pgxa8hrf': {
      'en': 'Street Hockey only / Play On!​',
      'es': '',
      'fr': '',
    },
    'ke8vqy64': {
      'en': 'Minor Ball Hockey League​',
      'es': '',
      'fr': '',
    },
    'v7fj3reo': {
      'en': 'Provincial Ball Hockey Tournament​',
      'es': '',
      'fr': '',
    },
    'hsu823r0': {
      'en': 'Competitive DEK Hockey (common in Quebec and USA)​',
      'es': '',
      'fr': '',
    },
    'rhatotew': {
      'en': 'National / International Tournament (NBHF, CBHA, or ISBHF)​​',
      'es': '',
      'fr': '',
    },
    'vnsdmcpz': {
      'en': 'Redwood Cup',
      'es': '',
      'fr': '',
    },
    'yk719gl2': {
      'en': 'Please select...',
      'es': '',
      'fr': '',
    },
    '2z9usege': {
      'en': 'Yes',
      'es': '',
      'fr': '',
    },
    '1mijbtw8': {
      'en': 'No',
      'es': '',
      'fr': '',
    },
    '8i69rynx': {
      'en': 'Please select...',
      'es': '',
      'fr': '',
    },
    'cjhju7v8': {
      'en': 'Back',
      'es': '',
      'fr': '',
    },
    'od8beq3q': {
      'en': 'Next',
      'es': '',
      'fr': '',
    },
    '8gn5t09o': {
      'en': 'Register',
      'es': '',
      'fr': '',
    },
  },
  // Register_FreeAgent_01
  {
    'h0dftbe6': {
      'en': 'Menu',
      'es': 'Menú',
      'fr': 'Menu',
    },
    'l7945z64': {
      'en': 'PlayOn! Store',
      'es': '¡Juega! Tienda',
      'fr': 'Jouer sur! Boutique',
    },
    'k87l1ll5': {
      'en': 'Go to the PlayOn! Store',
      'es': '¡Ve al PlayOn! Tienda',
      'fr': 'Rendez-vous sur PlayOn! Boutique',
    },
    'grbka6dc': {
      'en': 'Free Agent Registration',
      'es': '',
      'fr': '',
    },
    'c6rji3xh': {
      'en': '1',
      'es': '',
      'fr': '',
    },
    'o0v53jue': {
      'en': 'Select Event',
      'es': '',
      'fr': '',
    },
    'igsospt9': {
      'en': '2',
      'es': '',
      'fr': '',
    },
    'rodgq6zy': {
      'en': 'Your Details',
      'es': '',
      'fr': '',
    },
    '803kn3s6': {
      'en': '3',
      'es': '',
      'fr': '',
    },
    'e9adxbti': {
      'en': 'Experience',
      'es': '',
      'fr': '',
    },
    '2iw044y8': {
      'en': '4',
      'es': '',
      'fr': '',
    },
    'uyn12och': {
      'en': 'Acknowledgement',
      'es': '',
      'fr': '',
    },
    '3as0g86a': {
      'en': '5',
      'es': '',
      'fr': '',
    },
    'yaklycg7': {
      'en': 'Waiver',
      'es': '',
      'fr': '',
    },
    '5n548ptn': {
      'en': '6',
      'es': '',
      'fr': '',
    },
    'j9qlie4x': {
      'en': 'Payment',
      'es': '',
      'fr': '',
    },
    'z0yiuash': {
      'en': '7',
      'es': '',
      'fr': '',
    },
    'cemdrofp': {
      'en': 'Charity',
      'es': '',
      'fr': '',
    },
    'wct8woic': {
      'en': '2',
      'es': '',
      'fr': '',
    },
    'heaxrebc': {
      'en': 'Your Team Name is:',
      'es': '',
      'fr': '',
    },
    'q1ga9h3h': {
      'en': 'London Giants (pending approval)',
      'es': '',
      'fr': '',
    },
    'vhae0ui7': {
      'en': 'You are playing in:',
      'es': '',
      'fr': '',
    },
    'gje4v79n': {
      'en': 'Event 1',
      'es': '',
      'fr': '',
    },
    'hfu7sc33': {
      'en': 'First Name',
      'es': '',
      'fr': '',
    },
    'or4h0szl': {
      'en': 'Enter your first name',
      'es': '',
      'fr': '',
    },
    'gq9dhyzi': {
      'en': 'Last Name',
      'es': '',
      'fr': '',
    },
    '38cnt8yh': {
      'en': 'Enter your last name',
      'es': '',
      'fr': '',
    },
    'ymbzy6xy': {
      'en': 'Mobile Number',
      'es': '',
      'fr': '',
    },
    'ttb823fl': {
      'en': 'Enter mobile number',
      'es': '',
      'fr': '',
    },
    'e5x3o63g': {
      'en': 'Email address',
      'es': '',
      'fr': '',
    },
    'kqcs8ayz': {
      'en': 'Enter your email address',
      'es': '',
      'fr': '',
    },
    'hq7lb511': {
      'en': 'Address',
      'es': '',
      'fr': '',
    },
    'thudkf8b': {
      'en': 'Enter your address',
      'es': '',
      'fr': '',
    },
    'brb6q13d': {
      'en': '',
      'es': '',
      'fr': '',
    },
    'ngr3vldq': {
      'en': 'Country',
      'es': '',
      'fr': '',
    },
    'd7vvdrrd': {
      'en': 'Please select...',
      'es': '',
      'fr': '',
    },
    'hhgqfazf': {
      'en': 'State',
      'es': '',
      'fr': '',
    },
    'oz9d2ypm': {
      'en': 'Province',
      'es': '',
      'fr': '',
    },
    'flolyhaz': {
      'en': 'Please select...',
      'es': '',
      'fr': '',
    },
    'g0km2oud': {
      'en': 'City',
      'es': '',
      'fr': '',
    },
    '43i0etn7': {
      'en': 'Enter name of city',
      'es': '',
      'fr': '',
    },
    '9y5xle4w': {
      'en': 'Zip Code',
      'es': '',
      'fr': '',
    },
    'houuf3p7': {
      'en': 'Enter your zip code',
      'es': '',
      'fr': '',
    },
    'cmek9uv6': {
      'en': 'Postal Code',
      'es': '',
      'fr': '',
    },
    '22euq2j1': {
      'en': 'A1A 1A1',
      'es': '',
      'fr': '',
    },
    'luk89x7s': {
      'en': 'Your Stats',
      'es': '',
      'fr': '',
    },
    '8xhv0ghz': {
      'en': 'lbs',
      'es': '',
      'fr': '',
    },
    'zp2t5885': {
      'en': 'Feet',
      'es': '',
      'fr': '',
    },
    'mp4y895u': {
      'en': 'Inches',
      'es': '',
      'fr': '',
    },
    'mu343vgt': {
      'en': 'Left',
      'es': '',
      'fr': '',
    },
    'hd48jbcb': {
      'en': 'Right',
      'es': '',
      'fr': '',
    },
    'jj3y0hhb': {
      'en': 'Select one',
      'es': '',
      'fr': '',
    },
    'rjd0qg9k': {
      'en': 'Jersey number',
      'es': '',
      'fr': '',
    },
    'b3i9112r': {
      'en': 'Male',
      'es': '',
      'fr': '',
    },
    'drk5l8ey': {
      'en': 'Female',
      'es': '',
      'fr': '',
    },
    'uabfomcy': {
      'en': 'Neither',
      'es': '',
      'fr': '',
    },
    '0lld42fm': {
      'en': 'Select one',
      'es': '',
      'fr': '',
    },
    'ae7c0ymd': {
      'en': 'Back',
      'es': '',
      'fr': '',
    },
    'a47oeuy4': {
      'en': 'Next',
      'es': '',
      'fr': '',
    },
    'ndtfsrvs': {
      'en': 'Register',
      'es': '',
      'fr': '',
    },
  },
  // Register_FreeAgent_02
  {
    'kw2n58o4': {
      'en': 'Menu',
      'es': 'Menú',
      'fr': 'Menu',
    },
    'o3a6bgpt': {
      'en': 'PlayOn! Store',
      'es': '¡Juega! Tienda',
      'fr': 'Jouer sur! Boutique',
    },
    'sg1elcy4': {
      'en': 'Go to the PlayOn! Store',
      'es': '¡Ve al PlayOn! Tienda',
      'fr': 'Rendez-vous sur PlayOn! Boutique',
    },
    '9is6m8ju': {
      'en': 'Free Agent Registration',
      'es': '',
      'fr': '',
    },
    'xm7jzese': {
      'en': '1',
      'es': '',
      'fr': '',
    },
    'wx8bfgsm': {
      'en': 'Select Event',
      'es': '',
      'fr': '',
    },
    'tukq2bji': {
      'en': '2',
      'es': '',
      'fr': '',
    },
    'r86cu7u4': {
      'en': 'Your Details',
      'es': '',
      'fr': '',
    },
    'zl1tdugr': {
      'en': '3',
      'es': '',
      'fr': '',
    },
    'vspnocno': {
      'en': 'Experience',
      'es': '',
      'fr': '',
    },
    'oy6vve7x': {
      'en': '4',
      'es': '',
      'fr': '',
    },
    'sjum7vi9': {
      'en': 'Acknowledgement',
      'es': '',
      'fr': '',
    },
    'g1tg6xe1': {
      'en': '5',
      'es': '',
      'fr': '',
    },
    'mplu6r3m': {
      'en': 'Waiver',
      'es': '',
      'fr': '',
    },
    'vyc94b4t': {
      'en': '6',
      'es': '',
      'fr': '',
    },
    'n8cxjz9x': {
      'en': 'Payment',
      'es': '',
      'fr': '',
    },
    'mzxm06nw': {
      'en': '7',
      'es': '',
      'fr': '',
    },
    'o5kc2c9w': {
      'en': 'Charity',
      'es': '',
      'fr': '',
    },
    'p2ytqsrq': {
      'en': '1',
      'es': '',
      'fr': '',
    },
    '9ll68hd3': {
      'en': 'Please select the event(s) you would to participate in:',
      'es': '',
      'fr': '',
    },
    'vzc3dov0': {
      'en': 'Back',
      'es': '',
      'fr': '',
    },
    'm5o0peg9': {
      'en': 'Next',
      'es': '',
      'fr': '',
    },
    'ejb3jfzx': {
      'en': 'Register',
      'es': '',
      'fr': '',
    },
  },
  // Register_FreeAgent_05
  {
    '8xrya04r': {
      'en': 'Menu',
      'es': 'Menú',
      'fr': 'Menu',
    },
    '9t5d7jg8': {
      'en': 'PlayOn! Store',
      'es': '¡Juega! Tienda',
      'fr': 'Jouer sur! Boutique',
    },
    'lh6vtr4j': {
      'en': 'Go to the PlayOn! Store',
      'es': '¡Ve al PlayOn! Tienda',
      'fr': 'Rendez-vous sur PlayOn! Boutique',
    },
    '2krrg1c0': {
      'en': 'Free Agent Registration',
      'es': '',
      'fr': '',
    },
    'qwueth37': {
      'en': '1',
      'es': '',
      'fr': '',
    },
    'jmmw2ro3': {
      'en': 'Select Event',
      'es': '',
      'fr': '',
    },
    'dyddof4w': {
      'en': '2',
      'es': '',
      'fr': '',
    },
    'vcpnw2ce': {
      'en': 'Your Details',
      'es': '',
      'fr': '',
    },
    '20o0pvoh': {
      'en': '3',
      'es': '',
      'fr': '',
    },
    'kf0805hg': {
      'en': 'Experience',
      'es': '',
      'fr': '',
    },
    '935wuclg': {
      'en': '4',
      'es': '',
      'fr': '',
    },
    'ggti275b': {
      'en': 'Acknowledgement',
      'es': '',
      'fr': '',
    },
    '50dyfsfd': {
      'en': '5',
      'es': '',
      'fr': '',
    },
    'v9pv40xx': {
      'en': 'Waiver',
      'es': '',
      'fr': '',
    },
    'amiw08ql': {
      'en': '6',
      'es': '',
      'fr': '',
    },
    'cbyo430z': {
      'en': 'Payment',
      'es': '',
      'fr': '',
    },
    'jh2ismnw': {
      'en': '7',
      'es': '',
      'fr': '',
    },
    'hqqwk1g7': {
      'en': 'Charity',
      'es': '',
      'fr': '',
    },
    '2q6nzrgw': {
      'en': '5',
      'es': '',
      'fr': '',
    },
    '4y92ch7g': {
      'en': 'Your Team Name is:',
      'es': '',
      'fr': '',
    },
    'z850er8f': {
      'en': 'London Giants (pending approval)',
      'es': '',
      'fr': '',
    },
    'mjtj7e6s': {
      'en': 'Your playing in:',
      'es': '',
      'fr': '',
    },
    '9m0mm9gc': {
      'en': 'Event 1',
      'es': '',
      'fr': '',
    },
    'ozphnls5': {
      'en': 'WAIVER, RELEASE AND INDEMNIFICATION:',
      'es': '',
      'fr': '',
    },
    'd4fzx4xo': {
      'en':
          'Every player, and his/her parent or guardian (if the player is under 18) must read. execute, and deliver this waiver to tournament organizers prior to the commencement of the tournament. in consideration of the right and opportunity to participate in the play On! street hockey tournament conducted by the not for profit organization play On! Canada (POC),and its licensed affiliates, the undersigned hereby acknowledges and agrees as follows: I (who am the participant\'s parent or legal guardian if the participant is under 18 year old) hereby consent to the use without compensation, of my/his/her name  and/or likeness, biographical material and/or voice in publicity and advertising concerning the play On! tournament by PPOC and/or any playOn! tournament partners or sponsored in any and all media and/or promotion and throughout the world. in addition, the undersigned (on behalf of the participant if the participant is under 18 years of age) forever generally and completely release and discharge and shall indemnify and hold harmless Play On! Canada and its employees, directors, officers, agents, sponsors, partners and licensees and each other party affiliated with play On! Canada and each of its owners, agents, directors, officers, employees, sponsors and partners(collectively, \"Event Organizers\") against and from any and all claims and demands of every kind and nature whatsoever, for damages or injuries ,actual or consequential, past, present or future, raising out of or in any   way related to the Play On! street hockey  tournament, including but not limited to any claims of injury from participating in OR observing the tournament, the loss of personal property by theft to otherwise during the tournament, any publicity related to the tournament, or any prizes   awarded. The undersigned acknowledges that of its own free will he/she has chosen to participate in the tournament and related activities. I understand and acknowledge that the aforementioned activities carry with them a high level of risk of injury  and additional hazards related thereto. i certify that i am  aware kof ,and accept, these increased risks and that i am mentally and physically prepared for the risks associated with the play On! street hockey tournament. This general release shall further apply to all unknown, unanticipated, unsuspected, and undisclosed claims, demands, liabilities, actions or causes of action, in law, equality or otherwise.  This Waiver shall bind heirs, personal representatives, and successors of the undersigned, and inure to the benefit of the Event Organizers.',
      'es': '',
      'fr': '',
    },
    'qeahbgan': {
      'en':
          'I HAVE READ AND UNDERSTAND THE TERMS OF THE ABOVE AGREEMENT, WILL COMPLY WITH TERMS HERE OF AND ACKNOWLEDGE THAT BY SIGNIG THIS FORM I AM GIVING UP LEGAL RIGHTS.',
      'es': '',
      'fr': '',
    },
    '0mwtim6j': {
      'en': 'Date Of Birth',
      'es': '',
      'fr': '',
    },
    '39lqxhrf': {
      'en': '1',
      'es': '',
      'fr': '',
    },
    'nafkd5v8': {
      'en': '2',
      'es': '',
      'fr': '',
    },
    '42ri6twg': {
      'en': '3',
      'es': '',
      'fr': '',
    },
    'j4qx5p7h': {
      'en': '4',
      'es': '',
      'fr': '',
    },
    'mlvsv9nn': {
      'en': '5',
      'es': '',
      'fr': '',
    },
    'zkk29r2w': {
      'en': '6',
      'es': '',
      'fr': '',
    },
    '2qdedigk': {
      'en': '7',
      'es': '',
      'fr': '',
    },
    '20umxe90': {
      'en': '8',
      'es': '',
      'fr': '',
    },
    '8sj3s4n2': {
      'en': '9',
      'es': '',
      'fr': '',
    },
    'u47fv4mr': {
      'en': '10',
      'es': '',
      'fr': '',
    },
    'qq0c4de6': {
      'en': '11',
      'es': '',
      'fr': '',
    },
    '9685bhr4': {
      'en': '12',
      'es': '',
      'fr': '',
    },
    'sqe0ivtn': {
      'en': '13',
      'es': '',
      'fr': '',
    },
    'j5d8wo8y': {
      'en': '14',
      'es': '',
      'fr': '',
    },
    '941ux99h': {
      'en': '15',
      'es': '',
      'fr': '',
    },
    'd9hpidb0': {
      'en': '16',
      'es': '',
      'fr': '',
    },
    'suep2eiu': {
      'en': '17',
      'es': '',
      'fr': '',
    },
    'qfmuvbng': {
      'en': '18',
      'es': '',
      'fr': '',
    },
    'jnl5acrj': {
      'en': '19',
      'es': '',
      'fr': '',
    },
    'vqoj9lgq': {
      'en': '20',
      'es': '',
      'fr': '',
    },
    '2i5ciy3j': {
      'en': '21',
      'es': '',
      'fr': '',
    },
    'bwkjlp1v': {
      'en': '22',
      'es': '',
      'fr': '',
    },
    '0hktwdre': {
      'en': '23',
      'es': '',
      'fr': '',
    },
    '1otitulm': {
      'en': '24',
      'es': '',
      'fr': '',
    },
    'xvlxyobc': {
      'en': '25',
      'es': '',
      'fr': '',
    },
    'gyld4kvl': {
      'en': '26',
      'es': '',
      'fr': '',
    },
    'z4cza706': {
      'en': '27',
      'es': '',
      'fr': '',
    },
    'm47xcu7b': {
      'en': '28',
      'es': '',
      'fr': '',
    },
    'imzfmg5p': {
      'en': '29',
      'es': '',
      'fr': '',
    },
    'j3vip3i1': {
      'en': '30',
      'es': '',
      'fr': '',
    },
    't4js6qlb': {
      'en': '31',
      'es': '',
      'fr': '',
    },
    'kpgldehc': {
      'en': 'Day',
      'es': '',
      'fr': '',
    },
    '69bstupl': {
      'en': 'January',
      'es': '',
      'fr': '',
    },
    '1cnlyyr9': {
      'en': 'February',
      'es': '',
      'fr': '',
    },
    'j5g89q8z': {
      'en': 'March',
      'es': '',
      'fr': '',
    },
    'biu11sep': {
      'en': 'April',
      'es': '',
      'fr': '',
    },
    'mbh5y2ol': {
      'en': 'May',
      'es': '',
      'fr': '',
    },
    'u56yfwra': {
      'en': 'June',
      'es': '',
      'fr': '',
    },
    '35sut0xo': {
      'en': 'July',
      'es': '',
      'fr': '',
    },
    'x9pn77pw': {
      'en': 'August',
      'es': '',
      'fr': '',
    },
    'oyrpjyad': {
      'en': 'September',
      'es': '',
      'fr': '',
    },
    'rbq01s87': {
      'en': 'October',
      'es': '',
      'fr': '',
    },
    'qru4mmd4': {
      'en': 'November',
      'es': '',
      'fr': '',
    },
    'w5cwngn8': {
      'en': 'December',
      'es': '',
      'fr': '',
    },
    'ld6w5qat': {
      'en': 'Month',
      'es': '',
      'fr': '',
    },
    '2zgdxyfx': {
      'en': 'Year',
      'es': '',
      'fr': '',
    },
    '2e2steu6': {
      'en': 'Age of participant',
      'es': '',
      'fr': '',
    },
    'lelpbope': {
      'en': 'Event Location(City) ',
      'es': '',
      'fr': '',
    },
    'ykac1skl': {
      'en': 'January',
      'es': '',
      'fr': '',
    },
    '1m4xxvub': {
      'en': 'Please Select ',
      'es': '',
      'fr': '',
    },
    'p7ttf8tl': {
      'en': 'Team Name',
      'es': '',
      'fr': '',
    },
    'nexo1dxr': {
      'en': 'Signature',
      'es': '',
      'fr': '',
    },
    'xv6o8b09': {
      'en': 'Back',
      'es': '',
      'fr': '',
    },
    '8mas4d8b': {
      'en': 'Next',
      'es': '',
      'fr': '',
    },
    'xo2n2d8v': {
      'en': 'Register',
      'es': '',
      'fr': '',
    },
  },
  // Register_FreeAgent_04
  {
    'f23mz3hf': {
      'en': 'Menu',
      'es': 'Menú',
      'fr': 'Menu',
    },
    'et8p2b2m': {
      'en': 'PlayOn! Store',
      'es': '¡Juega! Tienda',
      'fr': 'Jouer sur! Boutique',
    },
    '6xk5670y': {
      'en': 'Go to the PlayOn! Store',
      'es': '¡Ve al PlayOn! Tienda',
      'fr': 'Rendez-vous sur PlayOn! Boutique',
    },
    'frfajerm': {
      'en': 'Free Agent Registration',
      'es': '',
      'fr': '',
    },
    'pqapmsht': {
      'en': '1',
      'es': '',
      'fr': '',
    },
    'ctu9zkfk': {
      'en': 'Select Event',
      'es': '',
      'fr': '',
    },
    '48avrwz6': {
      'en': '2',
      'es': '',
      'fr': '',
    },
    'takezneg': {
      'en': 'Your Details',
      'es': '',
      'fr': '',
    },
    'de6lt268': {
      'en': '3',
      'es': '',
      'fr': '',
    },
    '62xu8vds': {
      'en': 'Experience',
      'es': '',
      'fr': '',
    },
    '1isp0tqa': {
      'en': '4',
      'es': '',
      'fr': '',
    },
    'ufapv8cj': {
      'en': 'Acknowledgement',
      'es': '',
      'fr': '',
    },
    'kofxvlaq': {
      'en': '5',
      'es': '',
      'fr': '',
    },
    '57s47rv8': {
      'en': 'Waiver',
      'es': '',
      'fr': '',
    },
    'gjixubo0': {
      'en': '6',
      'es': '',
      'fr': '',
    },
    'jnm5vdh9': {
      'en': 'Payment',
      'es': '',
      'fr': '',
    },
    'f0kw6dhv': {
      'en': '7',
      'es': '',
      'fr': '',
    },
    'j579ie38': {
      'en': 'Charity',
      'es': '',
      'fr': '',
    },
    '8ydbdi55': {
      'en': '4',
      'es': '',
      'fr': '',
    },
    'wu3s2ijq': {
      'en': 'Your BirthDate',
      'es': '',
      'fr': '',
    },
    'df79tp42': {
      'en': '1',
      'es': '',
      'fr': '',
    },
    '0c0zgfxt': {
      'en': '2',
      'es': '',
      'fr': '',
    },
    '0kj9hroe': {
      'en': '3',
      'es': '',
      'fr': '',
    },
    '5tcodg25': {
      'en': '4',
      'es': '',
      'fr': '',
    },
    'obgqeby2': {
      'en': '5',
      'es': '',
      'fr': '',
    },
    '8dv5hten': {
      'en': '6',
      'es': '',
      'fr': '',
    },
    'r1v3noza': {
      'en': '7',
      'es': '',
      'fr': '',
    },
    'uns0zrav': {
      'en': '8',
      'es': '',
      'fr': '',
    },
    'vuixlkbx': {
      'en': '9',
      'es': '',
      'fr': '',
    },
    '5brtp7lw': {
      'en': '10',
      'es': '',
      'fr': '',
    },
    's3vhnpc0': {
      'en': '11',
      'es': '',
      'fr': '',
    },
    'y1s269w1': {
      'en': '12',
      'es': '',
      'fr': '',
    },
    '0otl9ox1': {
      'en': '13',
      'es': '',
      'fr': '',
    },
    'lrkyphif': {
      'en': '14',
      'es': '',
      'fr': '',
    },
    's44wexcc': {
      'en': '15',
      'es': '',
      'fr': '',
    },
    'dro060x2': {
      'en': '16',
      'es': '',
      'fr': '',
    },
    'u3m0v6rd': {
      'en': '17',
      'es': '',
      'fr': '',
    },
    '0vei0be4': {
      'en': '18',
      'es': '',
      'fr': '',
    },
    'br68b3u1': {
      'en': '19',
      'es': '',
      'fr': '',
    },
    '8av67f5z': {
      'en': '20',
      'es': '',
      'fr': '',
    },
    '6805le06': {
      'en': '21',
      'es': '',
      'fr': '',
    },
    '9p0w5fgk': {
      'en': '22',
      'es': '',
      'fr': '',
    },
    '3rmq08cf': {
      'en': '23',
      'es': '',
      'fr': '',
    },
    '06tzuqrh': {
      'en': '24',
      'es': '',
      'fr': '',
    },
    'eaivl8rz': {
      'en': '25',
      'es': '',
      'fr': '',
    },
    '3ljgxgmr': {
      'en': '26',
      'es': '',
      'fr': '',
    },
    'cbg09wk8': {
      'en': '27',
      'es': '',
      'fr': '',
    },
    'nko0axme': {
      'en': '28',
      'es': '',
      'fr': '',
    },
    'ew6xqiwk': {
      'en': '29',
      'es': '',
      'fr': '',
    },
    '8tkt6gfq': {
      'en': '30',
      'es': '',
      'fr': '',
    },
    'e9h31hg7': {
      'en': '31',
      'es': '',
      'fr': '',
    },
    '6co1goer': {
      'en': 'Day',
      'es': '',
      'fr': '',
    },
    'elsdcn0b': {
      'en': 'January',
      'es': '',
      'fr': '',
    },
    '5um5hss6': {
      'en': 'February',
      'es': '',
      'fr': '',
    },
    'mhxz7ovy': {
      'en': 'March',
      'es': '',
      'fr': '',
    },
    'njvrjo03': {
      'en': 'April',
      'es': '',
      'fr': '',
    },
    '9st44y65': {
      'en': 'May',
      'es': '',
      'fr': '',
    },
    'i7n26lfq': {
      'en': 'June',
      'es': '',
      'fr': '',
    },
    'y8qpisi8': {
      'en': 'July',
      'es': '',
      'fr': '',
    },
    'j53myy14': {
      'en': 'August',
      'es': '',
      'fr': '',
    },
    'kkfgoxjt': {
      'en': 'September',
      'es': '',
      'fr': '',
    },
    'h7u5srb9': {
      'en': 'October',
      'es': '',
      'fr': '',
    },
    '6mlfoylk': {
      'en': 'November',
      'es': '',
      'fr': '',
    },
    'qp0dljcv': {
      'en': 'December',
      'es': '',
      'fr': '',
    },
    '6p1et3bw': {
      'en': 'Month',
      'es': '',
      'fr': '',
    },
    'grnn2a6k': {
      'en': 'Year',
      'es': '',
      'fr': '',
    },
    'uuqyxsye': {
      'en': 'I certify that this birthdate is correct',
      'es': '',
      'fr': '',
    },
    '3tc6b3ll': {
      'en':
          'I understand my division will be assigned based on the birth year of the oldest player in the team',
      'es': '',
      'fr': '',
    },
    'bjnrnyl5': {
      'en':
          'I acknowledge that I may be required to show proof of age at any time during the event',
      'es': '',
      'fr': '',
    },
    'cxh6irps': {
      'en': 'Back',
      'es': '',
      'fr': '',
    },
    'd5qke8x5': {
      'en': 'Next',
      'es': '',
      'fr': '',
    },
    'ry0h0m68': {
      'en': 'Register',
      'es': '',
      'fr': '',
    },
  },
  // Register_FreeAgent_06
  {
    '52gbrip5': {
      'en': 'Menu',
      'es': 'Menú',
      'fr': 'Menu',
    },
    'bo0mnohe': {
      'en': 'PlayOn! Store',
      'es': '¡Juega! Tienda',
      'fr': 'Jouer sur! Boutique',
    },
    '4yenw0xw': {
      'en': 'Go to the PlayOn! Store',
      'es': '¡Ve al PlayOn! Tienda',
      'fr': 'Rendez-vous sur PlayOn! Boutique',
    },
    '2kyxvj09': {
      'en': 'Free Agent Registration',
      'es': '',
      'fr': '',
    },
    'kidz9x6w': {
      'en': '1',
      'es': '',
      'fr': '',
    },
    'b6857a4q': {
      'en': 'Select Event',
      'es': '',
      'fr': '',
    },
    'mfkl1ifc': {
      'en': '2',
      'es': '',
      'fr': '',
    },
    'rny0xmnl': {
      'en': 'Your Details',
      'es': '',
      'fr': '',
    },
    't3z7vqjk': {
      'en': '3',
      'es': '',
      'fr': '',
    },
    '5j5zfksn': {
      'en': 'Experience',
      'es': '',
      'fr': '',
    },
    't2ew5r2h': {
      'en': '4',
      'es': '',
      'fr': '',
    },
    'yv85o6ec': {
      'en': 'Acknowledgement',
      'es': '',
      'fr': '',
    },
    'dxrj0hl7': {
      'en': '5',
      'es': '',
      'fr': '',
    },
    'mbc2emwj': {
      'en': 'Waiver',
      'es': '',
      'fr': '',
    },
    '66bdbbnt': {
      'en': '6',
      'es': '',
      'fr': '',
    },
    '20dd25hh': {
      'en': 'Payment',
      'es': '',
      'fr': '',
    },
    'z0duua96': {
      'en': '7',
      'es': '',
      'fr': '',
    },
    'ojwrv47j': {
      'en': 'Charity',
      'es': '',
      'fr': '',
    },
    'mnzr8e7n': {
      'en': '6',
      'es': '',
      'fr': '',
    },
    'lk9mzlhh': {
      'en': 'Your Team Name is:',
      'es': '',
      'fr': '',
    },
    'o5p5278s': {
      'en': 'London Giants (pending approval)',
      'es': '',
      'fr': '',
    },
    '76v7qrrl': {
      'en': 'Your playing in:',
      'es': '',
      'fr': '',
    },
    'cwq5xfhc': {
      'en': 'Event 1',
      'es': '',
      'fr': '',
    },
    'ri7eixip': {
      'en': 'The individual Player Fee is',
      'es': '',
      'fr': '',
    },
    'xlni3nlp': {
      'en': 'Tax',
      'es': '',
      'fr': '',
    },
    '5lcrvdki': {
      'en':
          'By paying your fees you confirm that you will participate in this event. Please do not pay your registration fee unless you are certain that you will play, as participation fees are not refundable under any circumstances',
      'es': '',
      'fr': '',
    },
    'hj6wldbl': {
      'en': 'I understand, I am committed to playing!',
      'es': '',
      'fr': '',
    },
    'dfsdavmn': {
      'en': 'Back',
      'es': '',
      'fr': '',
    },
    'wbxeyu9w': {
      'en': 'Next',
      'es': '',
      'fr': '',
    },
    'kn7kepa2': {
      'en': 'Register',
      'es': '',
      'fr': '',
    },
  },
  // Register_FreeAgent_07
  {
    'xbzkwzlv': {
      'en': 'Menu',
      'es': 'Menú',
      'fr': 'Menu',
    },
    'i7p0smd0': {
      'en': 'PlayOn! Store',
      'es': '¡Juega! Tienda',
      'fr': 'Jouer sur! Boutique',
    },
    '5mfklvkw': {
      'en': 'Go to the PlayOn! Store',
      'es': '¡Ve al PlayOn! Tienda',
      'fr': 'Rendez-vous sur PlayOn! Boutique',
    },
    '9iyiysq6': {
      'en': 'Free Agent Registration',
      'es': '',
      'fr': '',
    },
    'ao25huha': {
      'en': '1',
      'es': '',
      'fr': '',
    },
    '89qfqvoi': {
      'en': 'Select Team',
      'es': '',
      'fr': '',
    },
    'wi2ohlrc': {
      'en': '2',
      'es': '',
      'fr': '',
    },
    '7di8s6vv': {
      'en': 'Your Details',
      'es': '',
      'fr': '',
    },
    'ihpi1d8k': {
      'en': '3',
      'es': '',
      'fr': '',
    },
    'w23r4cz2': {
      'en': 'Experience',
      'es': '',
      'fr': '',
    },
    'pa1gr34z': {
      'en': '4',
      'es': '',
      'fr': '',
    },
    '0jtxqon2': {
      'en': 'Acknowledgement',
      'es': '',
      'fr': '',
    },
    'gx8q4ydi': {
      'en': '5',
      'es': '',
      'fr': '',
    },
    '2xiriwv9': {
      'en': 'Waiver',
      'es': '',
      'fr': '',
    },
    'thl91kax': {
      'en': '6',
      'es': '',
      'fr': '',
    },
    'zu9exia3': {
      'en': 'Payment',
      'es': '',
      'fr': '',
    },
    'rlc0snu1': {
      'en': '7',
      'es': '',
      'fr': '',
    },
    '1nbm1ma5': {
      'en': 'Charity',
      'es': '',
      'fr': '',
    },
    'oy3yimo2': {
      'en': '7',
      'es': '',
      'fr': '',
    },
    'rf5obblm': {
      'en': 'Your Team Name is:',
      'es': '',
      'fr': '',
    },
    'g2re6ria': {
      'en': 'London Giants (pending approval)',
      'es': '',
      'fr': '',
    },
    'gnjwb54e': {
      'en': 'Your playing in:',
      'es': '',
      'fr': '',
    },
    '88s5r5p9': {
      'en': 'Event 1',
      'es': '',
      'fr': '',
    },
    'nkbeigdn': {
      'en': '<Message once Payment is successful>',
      'es': '',
      'fr': '',
    },
    '8v8cpb8i': {
      'en':
          'Now, please allow us to explain an exciting new aspect of the Play On! program: Play for Pay&trade;.',
      'es': '',
      'fr': '',
    },
    'qnx2mk5b': {
      'en': 'Please take 2 minutes to watch this animated video that explains',
      'es': '',
      'fr': '',
    },
    'w8e9p73z': {
      'en': 'Watch Online',
      'es': '',
      'fr': '',
    },
    '5c6ju2sf': {
      'en': 'Back',
      'es': '',
      'fr': '',
    },
    'h8i0sg2s': {
      'en': 'Next',
      'es': '',
      'fr': '',
    },
    'kz7pwi32': {
      'en': 'Register',
      'es': '',
      'fr': '',
    },
  },
  // Dashboard_Captain
  {
    '1ed50qf0': {
      'en': 'Login',
      'es': 'Acceso',
      'fr': 'Connexion',
    },
    '3rx6juk9': {
      'en': 'Menu',
      'es': 'Menú',
      'fr': 'Menu',
    },
    '6fw8u3yo': {
      'en': 'PlayOn! Store',
      'es': '¡Juega! Tienda',
      'fr': 'Jouer sur! Boutique',
    },
    'lphw992f': {
      'en': 'Go to the PlayOn! Store',
      'es': '¡Ve al PlayOn! Tienda',
      'fr': 'Rendez-vous sur PlayOn! Boutique',
    },
    'nn15wpmj': {
      'en': 'You have 5 notifications.',
      'es': '',
      'fr': '',
    },
    '2g1tf97q': {
      'en': ' Click here ',
      'es': '',
      'fr': '',
    },
    'adx01hvj': {
      'en': 'My Team(s)',
      'es': '',
      'fr': '',
    },
    'newjdcll': {
      'en': 'My Profile',
      'es': '',
      'fr': '',
    },
    'zomtrszr': {
      'en': 'My Fans',
      'es': '',
      'fr': '',
    },
    'zh31itli': {
      'en': 'My Donations',
      'es': '',
      'fr': '',
    },
    'wmvwcg59': {
      'en': 'My Schedule',
      'es': '',
      'fr': '',
    },
    'k7pvd0y8': {
      'en': 'My Stats',
      'es': '',
      'fr': '',
    },
    '28xtkr6t': {
      'en': 'My Rewards',
      'es': '',
      'fr': '',
    },
    'xmfq9uks': {
      'en': 'My Invitations',
      'es': '',
      'fr': '',
    },
    'tq3l15d9': {
      'en': 'Register',
      'es': '',
      'fr': '',
    },
  },
  // Player_Profile
  {
    'ty9r9att': {
      'en': 'Login',
      'es': '',
      'fr': '',
    },
    'las2iqlo': {
      'en': 'Menu',
      'es': 'Menú',
      'fr': 'Menu',
    },
    'xmlmcy9g': {
      'en': 'PlayOn! Store',
      'es': '¡Juega! Tienda',
      'fr': 'Jouer sur! Boutique',
    },
    'jfzw65nz': {
      'en': 'Go to the PlayOn! Store',
      'es': '¡Ve al PlayOn! Tienda',
      'fr': 'Rendez-vous sur PlayOn! Boutique',
    },
    'ldcjeo55': {
      'en': 'My Profile',
      'es': '',
      'fr': '',
    },
    'fwml9jon': {
      'en': 'Balaji Reddy',
      'es': '',
      'fr': '',
    },
    '00dajy3q': {
      'en': '15/02/2022',
      'es': '',
      'fr': '',
    },
    'qme07x96': {
      'en': 'Male',
      'es': '',
      'fr': '',
    },
    '277ot9dx': {
      'en': '9751 34 Ave NW, Edmonton, AB T6E 5X9, Canada',
      'es': '',
      'fr': '',
    },
    'phmv76pz': {
      'en': 'My Experience',
      'es': '',
      'fr': '',
    },
    'ejd09co7': {
      'en': 'My Stats',
      'es': '',
      'fr': '',
    },
    'umaq12uc': {
      'en': 'My Donations',
      'es': '',
      'fr': '',
    },
    'l3n3doty': {
      'en': 'Cancel',
      'es': '',
      'fr': '',
    },
    'h97o0ik7': {
      'en': 'Edit',
      'es': '',
      'fr': '',
    },
    'hqmmk4aa': {
      'en': 'Register',
      'es': '',
      'fr': '',
    },
  },
  // Register_BusinessPartner_00
  {
    'wywkphov': {
      'en': 'Business Partner Registration',
      'es': 'Registro de socios comerciales',
      'fr': 'Inscription des partenaires commerciaux',
    },
    '38ezxtmd': {
      'en':
          'Please take a moment to watch this explainer video prior to beginning the process',
      'es':
          'Tómese un momento para ver este video explicativo antes de comenzar el proceso',
      'fr':
          'Veuillez prendre un moment pour regarder cette vidéo explicative avant de commencer le processus',
    },
    'x7amkza5': {
      'en': 'Back',
      'es': 'atrás',
      'fr': 'Retour',
    },
    '27woh2n9': {
      'en': 'Next',
      'es': 'próximo',
      'fr': 'Suivant',
    },
    '3oqft242': {
      'en': 'Home',
      'es': 'Hogar',
      'fr': 'Maison',
    },
  },
  // Register_BusinessPartner_01
  {
    '5oc3ng64': {
      'en': 'Business Partner Registration',
      'es': 'Registro de socios comerciales',
      'fr': 'Inscription des partenaires commerciaux',
    },
    '1jpt785k': {
      'en': '1',
      'es': '1',
      'fr': '1',
    },
    'm7u30gbs': {
      'en': 'Please tell us about your corporation',
      'es': 'Cuéntanos sobre tu corporación',
      'fr': 'Veuillez nous parler de votre société',
    },
    'ujjb4m5z': {
      'en':
          'We will ensure that your organization is not already a registered partner of the event',
      'es':
          'Nos aseguraremos de que su organización no sea ya un socio registrado del evento.',
      'fr':
          'Nous nous assurerons que votre organisation n\'est pas déjà un partenaire enregistré de l\'événement',
    },
    'wmux9nfu': {
      'en': '361679-7',
      'es': '361679-7',
      'fr': '361679-7',
    },
    'h1aazqkt': {
      'en': 'Enter organization name',
      'es': 'Ingrese el nombre de la organización',
      'fr': 'Entrez le nom de l\'organisation',
    },
    '1w6pbiy2': {
      'en': 'Enter address',
      'es': 'Ingresa la direccion',
      'fr': 'Entrer l\'adresse',
    },
    '7pwd9dgo': {
      'en': 'Enter  description',
      'es': 'Introduce la descripción',
      'fr': 'Entrez la description',
    },
    'k5hhr504': {
      'en': 'Business id is required',
      'es': 'Se requiere identificación comercial',
      'fr': 'L\'identifiant de l\'entreprise est requis',
    },
    'tvfhoy4b': {
      'en': 'Enter valid business id',
      'es': 'Ingrese una identificación comercial válida',
      'fr': 'Entrez un identifiant d\'entreprise valide',
    },
    'okbscchc': {
      'en': 'Organization name is required',
      'es': 'El nombre de la organización es obligatorio',
      'fr': 'Le nom de l\'organisation est requis',
    },
    'b8zzzphn': {
      'en': 'Please enter valid organization name',
      'es': 'Introduzca un nombre de organización válido',
      'fr': 'Entrez un nom d\'organisation valide',
    },
    'eginxjo4': {
      'en': 'Address is required',
      'es': 'La dirección es necesaria',
      'fr': 'L\'adresse est obligatoire',
    },
    '323k5adi': {
      'en': 'Enter valid address',
      'es': 'Introduce una dirección válida',
      'fr': 'Entrez une adresse valide',
    },
    'bcqxlaaq': {
      'en': 'Description  is required',
      'es': 'Se requiere descripción',
      'fr': 'La description est obligatoire',
    },
    'fnuwtg8j': {
      'en': 'Enter valid description',
      'es': 'Introduce una descripción válida',
      'fr': 'Entrez une description valide',
    },
    '9mj1hq0t': {
      'en': 'Back',
      'es': 'atrás',
      'fr': 'Retour',
    },
    '0517r8j0': {
      'en': 'Next',
      'es': 'próximo',
      'fr': 'Prochain',
    },
    'rx8e820g': {
      'en': 'Home',
      'es': 'Hogar',
      'fr': 'Maison',
    },
  },
  // Register_BusinessPartner_02
  {
    'bu0q8hq4': {
      'en': 'Business Partner Registration',
      'es': 'Registro de socios comerciales',
      'fr': 'Inscription des partenaires commerciaux',
    },
    'upmzbxoh': {
      'en': '2',
      'es': '2',
      'fr': '2',
    },
    'bx5h7yrc': {
      'en': 'Contact Information',
      'es': 'Información del contacto',
      'fr': 'Coordonnées',
    },
    'gri25pum': {
      'en': 'Enter first name',
      'es': 'Ingrese el nombre',
      'fr': 'entrez votre prénom',
    },
    'c2wlbhsc': {
      'en': 'Enter last name',
      'es': 'Introduzca el apellido',
      'fr': 'Entrer le nom de famille',
    },
    'ahs7iyz4': {
      'en': 'Enter title',
      'es': 'Introduce el título',
      'fr': 'Entrez le titre',
    },
    '33sfzlbh': {
      'en': 'Enter email address',
      'es': 'Introduzca la dirección de correo electrónico',
      'fr': 'Entrer l\'adresse e-mail',
    },
    '1ct7trdm': {
      'en': 'Enter extension',
      'es': 'Extensión',
      'fr': 'Extension',
    },
    'ul5x03nn': {
      'en': 'First name is required',
      'es': 'Se requiere el primer nombre',
      'fr': 'Le prénom est requis',
    },
    '4pj6koj0': {
      'en': 'Enter valid first name',
      'es': 'Introduce un nombre válido',
      'fr': 'Saisissez un prénom valide',
    },
    'w8x2bc29': {
      'en': 'Last name is required',
      'es': 'Se requiere apellido',
      'fr': 'Le nom de famille est requis',
    },
    'mdo3bttc': {
      'en': 'Enter valid last name',
      'es': 'Introduce un apellido válido',
      'fr': 'Entrez un nom de famille valide',
    },
    '2kxvj089': {
      'en': 'Title is required',
      'es': 'Se requiere título',
      'fr': 'Le titre est requis',
    },
    'tqqt0yzt': {
      'en': 'Enter valid title',
      'es': 'Introduce un título válido',
      'fr': 'Entrez un titre valide',
    },
    '08g3jx9k': {
      'en': 'Email address is required',
      'es': 'Se requiere Dirección de correo electrónico',
      'fr': 'Adresse e-mail est nécessaire',
    },
    '5we7vict': {
      'en': 'Enter valid email address',
      'es': 'Introduzca una dirección de correo electrónico válida',
      'fr': 'Saisissez une adresse e-mail valide',
    },
    'vhxo4144': {
      'en': 'Extension is required',
      'es': 'Se requiere extensión',
      'fr': 'Une extension est requise',
    },
    'u589pc1l': {
      'en': 'Please enter 2 digits for extension number',
      'es': 'Introduzca una extensión válida',
      'fr': 'Entrez une extension valide',
    },
    'd8ysca7y': {
      'en': 'Back',
      'es': 'atrás',
      'fr': 'Retour',
    },
    'gpem8wng': {
      'en': 'Next',
      'es': 'próximo',
      'fr': 'Prochain',
    },
    'fuf3x6xa': {
      'en': 'Home',
      'es': 'Hogar',
      'fr': 'Maison',
    },
  },
  // Register_BusinessParter_4a
  {
    'krvujtv0': {
      'en': 'en_US',
      'es': '',
      'fr': '',
    },
    'b53hk7ne': {
      'en': 'en_US',
      'es': '',
      'fr': '',
    },
    'rlx18za2': {
      'en': 'fr_FR',
      'es': '',
      'fr': '',
    },
    'dyd8g5in': {
      'en': 'es_ES',
      'es': '',
      'fr': '',
    },
    '6zvwjmg3': {
      'en': 'Login',
      'es': '',
      'fr': '',
    },
    'iq0dm33p': {
      'en': 'Login',
      'es': '',
      'fr': '',
    },
    'k0uwpght': {
      'en': '1',
      'es': '',
      'fr': '',
    },
    'v276sokc': {
      'en': 'Organization Details',
      'es': '',
      'fr': '',
    },
    '3li0a92z': {
      'en': '2',
      'es': '',
      'fr': '',
    },
    'tghqej96': {
      'en': 'Contact Details',
      'es': '',
      'fr': '',
    },
    'eijeaf2n': {
      'en': '3',
      'es': '',
      'fr': '',
    },
    '066694wb': {
      'en': 'Login Id',
      'es': '',
      'fr': '',
    },
    '8dl41d1l': {
      'en': '4',
      'es': '',
      'fr': '',
    },
    '4b84o70s': {
      'en': 'Event Selection',
      'es': '',
      'fr': '',
    },
    'd2ky21ic': {
      'en': '5',
      'es': '',
      'fr': '',
    },
    '1dk5el12': {
      'en': 'Confirmation',
      'es': '',
      'fr': '',
    },
    'fan3bavh': {
      'en': '6',
      'es': '',
      'fr': '',
    },
    'p7wka10y': {
      'en': 'Coupon Details',
      'es': '',
      'fr': '',
    },
    'mqpy5kuk': {
      'en': '7',
      'es': '',
      'fr': '',
    },
    'krj3h9e6': {
      'en': 'Terms and Conditions',
      'es': '',
      'fr': '',
    },
    'glh3r0db': {
      'en': 'Button',
      'es': '',
      'fr': '',
    },
    'coonb19i': {
      'en': 'Home',
      'es': '',
      'fr': '',
    },
  },
  // Register_BusinessPartner_03
  {
    'ir1d3xse': {
      'en': 'Business Partner Registration',
      'es': 'Registro de socios comerciales',
      'fr': 'Inscription des partenaires commerciaux',
    },
    'lae9hqwo': {
      'en': '3',
      'es': '3',
      'fr': '3',
    },
    'uvonf1iy': {
      'en': 'No event available to select',
      'es': '',
      'fr': '',
    },
    'nnbpolnc': {
      'en': 'Back',
      'es': 'atrás',
      'fr': 'Retour',
    },
    'qb9jj6wr': {
      'en': 'Next',
      'es': 'próximo',
      'fr': 'Prochain',
    },
    'm6f39ued': {
      'en': 'Home',
      'es': 'Hogar',
      'fr': 'Maison',
    },
  },
  // Register_BusinessPartner_04
  {
    'n9vd4d2f': {
      'en': 'Business Partner Registration',
      'es': 'Registro de socios comerciales',
      'fr': 'Inscription des partenaires commerciaux',
    },
    'eilfczdt': {
      'en': '4',
      'es': '4',
      'fr': '4',
    },
    '2jl17aw6': {
      'en': 'Event Name:',
      'es': 'Nombre del evento:',
      'fr': 'Nom de l\'événement:',
    },
    'mm9aamvp': {
      'en': 'Airline',
      'es': 'Aerolínea',
      'fr': 'Compagnie aérienne',
    },
    '4z8elxxt': {
      'en': 'Other',
      'es': 'Otro',
      'fr': 'Autre',
    },
    '5d4t3dak': {
      'en': 'Please select your industry',
      'es': 'Por favor seleccione su industria',
      'fr': 'Veuillez sélectionner votre industrie',
    },
    'wtnwrieo': {
      'en': 'Enter your other industry',
      'es': 'Introduzca su otra industria',
      'fr': 'Entrez votre autre industrie',
    },
    'gbg09eir': {
      'en': 'Re-upload',
      'es': '',
      'fr': '',
    },
    'zs2cnydv': {
      'en':
          'I confirm, I am employee with authority to blind the organization ',
      'es': 'Confirmo, soy empleado con autoridad para cegar a la organización',
      'fr':
          'Je confirme, je suis un employé ayant le pouvoir d\'aveugler l\'organisation',
    },
    'nz5qlcog': {
      'en': 'Back ',
      'es': 'atrás',
      'fr': 'Retour',
    },
    'wp4kgyj4': {
      'en': 'Next',
      'es': 'próximo',
      'fr': 'Prochain',
    },
    'zra65wer': {
      'en': 'Field is required',
      'es': 'Se requiere campo',
      'fr': 'Champ requis',
    },
    'vkilklj8': {
      'en': 'Home',
      'es': 'Hogar',
      'fr': 'Maison',
    },
  },
  // Manage_DivisionList
  {
    'bwa9hn1q': {
      'en': 'Menu',
      'es': 'Menú',
      'fr': 'Menu',
    },
    'ushpn183': {
      'en': 'PlayOn! Store',
      'es': '¡Juega! Tienda',
      'fr': 'Jouer sur! Boutique',
    },
    '0ofdz14m': {
      'en': 'Go to the PlayOn! Store',
      'es': '¡Ve al PlayOn! Tienda',
      'fr': 'Rendez-vous sur PlayOn! Boutique',
    },
    'x7zq8016': {
      'en': 'Manage Division',
      'es': 'Administrar evento',
      'fr': 'Gérer la division',
    },
    'x2ye0bpi': {
      'en': 'Add Division',
      'es': 'Añadir evento',
      'fr': 'Ajouter un évènement',
    },
    '4vrk89v0': {
      'en': 'Back',
      'es': 'atrás',
      'fr': 'Retour',
    },
    'gi9tybzu': {
      'en': 'Next',
      'es': 'próximo',
      'fr': 'Suivant',
    },
    '2t21t5dr': {
      'en': 'Register',
      'es': 'Registro',
      'fr': 'S\'inscrire',
    },
  },
  // Register_BusinessPartner_05
  {
    'usp6kicx': {
      'en': 'Business Partner Registration',
      'es': 'Registro de socios comerciales',
      'fr': 'Inscription des partenaires commerciaux',
    },
    'heetbhxy': {
      'en': '5',
      'es': '5',
      'fr': '5',
    },
    '5kobpqg7': {
      'en': 'Event Name:',
      'es': 'Nombre del evento:',
      'fr': 'Nom de l\'événement:',
    },
    '36197562': {
      'en': '\$ 1000.00',
      'es': '\$ 1000.00',
      'fr': '1000,00 \$',
    },
    '7k1mep6t': {
      'en': 'Option 1',
      'es': 'Opción 1',
      'fr': 'Option 1',
    },
    'ris7a5mj': {
      'en': 'Option 1',
      'es': 'Opción 1',
      'fr': 'Option 1',
    },
    'dle4lat0': {
      'en': 'Preview Coupon',
      'es': 'Cupón de vista previa',
      'fr': 'Avant-première',
    },
    'cbnhncdu': {
      'en': 'Chart',
      'es': 'Cuadro',
      'fr': 'Graphique',
    },
    '6zudbds3': {
      'en': 'Male',
      'es': 'Masculino',
      'fr': 'Homme',
    },
    '91e215fz': {
      'en': 'Female',
      'es': 'Femenino',
      'fr': 'Femelle',
    },
    '9uzrxwox': {
      'en': 'Another gender',
      'es': 'otro genero',
      'fr': 'Un autre genre',
    },
    '0ucuwowc': {
      'en': 'Please select',
      'es': 'Por favor seleccione',
      'fr': 'Veuillez sélectionner',
    },
    'k17ndoqv': {
      'en': 'Back',
      'es': 'atrás',
      'fr': 'Retour',
    },
    '4kr74hee': {
      'en': 'Next',
      'es': 'próximo',
      'fr': 'Prochain',
    },
    'tkoh1qc2': {
      'en': 'Home',
      'es': 'Hogar',
      'fr': 'Maison',
    },
  },
  // Captain_Invitation_01
  {
    'd3c6i9cv': {
      'en': 'Login',
      'es': '',
      'fr': '',
    },
    '8fsaumpf': {
      'en': 'Menu',
      'es': 'Menú',
      'fr': 'Menu',
    },
    'fy84qds8': {
      'en': 'PlayOn! Store',
      'es': '¡Juega! Tienda',
      'fr': 'Jouer sur! Boutique',
    },
    'q8xhlmci': {
      'en': 'Go to the PlayOn! Store',
      'es': '¡Ve al PlayOn! Tienda',
      'fr': 'Rendez-vous sur PlayOn! Boutique',
    },
    'q4mp5dqd': {
      'en': 'Invitations',
      'es': '',
      'fr': '',
    },
    '267g5yyl': {
      'en': 'Past Invitations',
      'es': '',
      'fr': '',
    },
    'ot26w1bj': {
      'en': 'Invitation\nSent ',
      'es': '',
      'fr': '',
    },
    'z9ujznrk': {
      'en': 'Invitation\nReceived',
      'es': '',
      'fr': '',
    },
    '4rdc0jxb': {
      'en': 'Fans',
      'es': '',
      'fr': '',
    },
    '96mm4ghh': {
      'en': 'Cancel',
      'es': '',
      'fr': '',
    },
    '4qqwulkc': {
      'en': 'Register',
      'es': '',
      'fr': '',
    },
  },
  // Manage_EventList
  {
    'ibrh0x5f': {
      'en': 'Menu',
      'es': 'Menú',
      'fr': 'Menu',
    },
    '0rpeqjf3': {
      'en': 'PlayOn! Store',
      'es': '¡Juega! Tienda',
      'fr': 'Jouer sur! Boutique',
    },
    'tzdciw7r': {
      'en': 'Go to the PlayOn! Store',
      'es': '¡Ve al PlayOn! Tienda',
      'fr': 'Rendez-vous sur PlayOn! Boutique',
    },
    '21b1um25': {
      'en': 'Manage Event',
      'es': 'Administrar evento',
      'fr': 'Gérer l&#39;événement',
    },
    'hrjdbg90': {
      'en': 'Add Event',
      'es': 'Añadir evento',
      'fr': 'Ajouter un évènement',
    },
    'n9i5kx3t': {
      'en': 'Back',
      'es': 'atrás',
      'fr': 'Retour',
    },
    'thclsw34': {
      'en': 'Next',
      'es': 'próximo',
      'fr': 'Suivant',
    },
    's4sxo0ur': {
      'en': 'Register',
      'es': 'Registro',
      'fr': '',
    },
  },
  // Add_Event
  {
    '5l6fsi9z': {
      'en': 'Add Event',
      'es': '',
      'fr': '',
    },
    '063gdeja': {
      'en': 'Enter a value',
      'es': '',
      'fr': '',
    },
    'np2nf1i7': {
      'en': 'Play On!',
      'es': '',
      'fr': '',
    },
    'hurdsn9k': {
      'en': 'Play On!',
      'es': '',
      'fr': '',
    },
    'izxfsn8l': {
      'en': 'Location Detailss',
      'es': '',
      'fr': '',
    },
    'fgh0fokg': {
      'en': 'Enter a  value',
      'es': '',
      'fr': '',
    },
    'psva9ukm': {
      'en': 'Enter address',
      'es': '',
      'fr': '',
    },
    'tpama5ne': {
      'en': 'Select one',
      'es': '',
      'fr': '',
    },
    't0tb0dg1': {
      'en': 'Canada',
      'es': '',
      'fr': '',
    },
    '2na86x4z': {
      'en': 'USA',
      'es': '',
      'fr': '',
    },
    'wkhcss29': {
      'en': 'Other',
      'es': '',
      'fr': '',
    },
    'n8y886ru': {
      'en': 'Select one',
      'es': '',
      'fr': '',
    },
    'bu0mjqtv': {
      'en': 'State',
      'es': '',
      'fr': '',
    },
    'b59dkmyx': {
      'en': 'Province',
      'es': '',
      'fr': '',
    },
    't369owbd': {
      'en': 'Selectone',
      'es': '',
      'fr': '',
    },
    'l64xmjop': {
      'en': 'Canada',
      'es': '',
      'fr': '',
    },
    '3spox912': {
      'en': 'USA',
      'es': '',
      'fr': '',
    },
    'vsux3ix8': {
      'en': 'Select one',
      'es': '',
      'fr': '',
    },
    '18e38y0o': {
      'en': 'City1',
      'es': '',
      'fr': '',
    },
    '8wzjdrl4': {
      'en': 'Select one',
      'es': '',
      'fr': '',
    },
    'yn7vosua': {
      'en': 'Zip  Code',
      'es': '',
      'fr': '',
    },
    '05iiy98m': {
      'en': 'Enter your zip  code',
      'es': '',
      'fr': '',
    },
    'c87tj8g9': {
      'en': 'Postal Code',
      'es': '',
      'fr': '',
    },
    '06uqbndh': {
      'en': 'A1A 1A1',
      'es': '',
      'fr': '',
    },
    'oketaput': {
      'en': 'Choose a file',
      'es': '',
      'fr': '',
    },
    '1ld52df8': {
      'en': 'Team',
      'es': '',
      'fr': '',
    },
    'gkx0ltb4': {
      'en': 'Enter a  value',
      'es': '',
      'fr': '',
    },
    '378yutut': {
      'en': 'Enter a  value',
      'es': '',
      'fr': '',
    },
    '5hy9ak87': {
      'en': 'Enter a  value',
      'es': '',
      'fr': '',
    },
    'wauwlch7': {
      'en': 'Fee',
      'es': '',
      'fr': '',
    },
    '5pmbpvud': {
      'en': 'Enter a value',
      'es': '',
      'fr': '',
    },
    'bc8u52po': {
      'en': 'Enter a value',
      'es': '',
      'fr': '',
    },
    'e91owmfy': {
      'en': 'Enter a value',
      'es': '',
      'fr': '',
    },
    'jf7polyh': {
      'en': 'Enter a value',
      'es': '',
      'fr': '',
    },
    '2c3io4eu': {
      'en': 'Space',
      'es': '',
      'fr': '',
    },
    'd7rbcj20': {
      'en': 'Enter a  value',
      'es': '',
      'fr': '',
    },
    'tt0yptip': {
      'en': 'Enter a  value',
      'es': '',
      'fr': '',
    },
    'a9r7abca': {
      'en': 'Enter a  value',
      'es': '',
      'fr': '',
    },
    'e5h7nwwm': {
      'en': 'Important Dates',
      'es': '',
      'fr': '',
    },
    '5e3njt20': {
      'en': '1',
      'es': '',
      'fr': '',
    },
    '0a1vf7gm': {
      'en': 'Day',
      'es': '',
      'fr': '',
    },
    'cspixapi': {
      'en': 'January',
      'es': '',
      'fr': '',
    },
    'o9w0ae30': {
      'en': 'February',
      'es': '',
      'fr': '',
    },
    'texw3tmp': {
      'en': 'March',
      'es': '',
      'fr': '',
    },
    'vcgvh60m': {
      'en': 'April',
      'es': '',
      'fr': '',
    },
    'cfuzicvu': {
      'en': 'Month',
      'es': '',
      'fr': '',
    },
    'hmupcbgg': {
      'en': '1935',
      'es': '',
      'fr': '',
    },
    '0wtqewl7': {
      'en': 'Year',
      'es': '',
      'fr': '',
    },
    'kr54yp4e': {
      'en': '1',
      'es': '',
      'fr': '',
    },
    'hlgx7xxl': {
      'en': 'Day',
      'es': '',
      'fr': '',
    },
    'by2gjdx1': {
      'en': 'April',
      'es': '',
      'fr': '',
    },
    'fqu3s8nt': {
      'en': 'March',
      'es': '',
      'fr': '',
    },
    'qnbczrbf': {
      'en': 'July',
      'es': '',
      'fr': '',
    },
    'l6hfy8bn': {
      'en': 'Month',
      'es': '',
      'fr': '',
    },
    'd99xog8o': {
      'en': '1935',
      'es': '',
      'fr': '',
    },
    'ji7cced0': {
      'en': 'Year',
      'es': '',
      'fr': '',
    },
    'mbxmp030': {
      'en': '1',
      'es': '',
      'fr': '',
    },
    'khq095ea': {
      'en': 'Day',
      'es': '',
      'fr': '',
    },
    'zxtq88wh': {
      'en': 'September',
      'es': '',
      'fr': '',
    },
    'fs27m0rh': {
      'en': 'April',
      'es': '',
      'fr': '',
    },
    '9n9iizb6': {
      'en': 'February',
      'es': '',
      'fr': '',
    },
    'iao2hpsm': {
      'en': 'Month',
      'es': '',
      'fr': '',
    },
    '541e0htg': {
      'en': '1935',
      'es': '',
      'fr': '',
    },
    '97f3hd44': {
      'en': 'Year',
      'es': '',
      'fr': '',
    },
    'yjaunzr8': {
      'en': 'Coordinator ',
      'es': '',
      'fr': '',
    },
    '9uxtmwvs': {
      'en': 'Option 1',
      'es': '',
      'fr': '',
    },
    'x3vg5kfg': {
      'en': 'Please select...',
      'es': '',
      'fr': '',
    },
    'f37e4np1': {
      'en': 'Option 1',
      'es': '',
      'fr': '',
    },
    '412hekcz': {
      'en': 'Please select...',
      'es': '',
      'fr': '',
    },
    'zf30xrl6': {
      'en': 'Option 1',
      'es': '',
      'fr': '',
    },
    'qmry9xee': {
      'en': 'Please select...',
      'es': '',
      'fr': '',
    },
    'msd03uyf': {
      'en': 'Cancel',
      'es': '',
      'fr': '',
    },
    'qtw7k3bo': {
      'en': 'Save',
      'es': '',
      'fr': '',
    },
    'we1q69lz': {
      'en': 'Home',
      'es': '',
      'fr': '',
    },
  },
  // Dashboard_Referee
  {
    'mia1xq0u': {
      'en': 'Login',
      'es': '',
      'fr': '',
    },
    'h826yyvu': {
      'en': 'Menu',
      'es': 'Menú',
      'fr': 'Menu',
    },
    'fpp4qqbz': {
      'en': 'PlayOn! Store',
      'es': '¡Juega! Tienda',
      'fr': 'Jouer sur! Boutique',
    },
    'rtr9d2r0': {
      'en': 'Go to the PlayOn! Store',
      'es': '¡Ve al PlayOn! Tienda',
      'fr': 'Rendez-vous sur PlayOn! Boutique',
    },
    'e6l0t9s4': {
      'en': 'My Profile',
      'es': '',
      'fr': '',
    },
    '50kbg7w8': {
      'en': 'My Schedule',
      'es': '',
      'fr': '',
    },
    'y4o1qn9j': {
      'en': 'My Stats',
      'es': '',
      'fr': '',
    },
    '22p08e6m': {
      'en': ' My Rewards',
      'es': '',
      'fr': '',
    },
    's4p9i47i': {
      'en': 'Register',
      'es': '',
      'fr': '',
    },
  },
  // Dashboard_FreeAgent
  {
    'vlkc8nhx': {
      'en': 'Login',
      'es': '',
      'fr': '',
    },
    'ooar5lyd': {
      'en': 'Menu',
      'es': 'Menú',
      'fr': 'Menu',
    },
    '96lzocuc': {
      'en': 'PlayOn! Store',
      'es': '¡Juega! Tienda',
      'fr': 'Jouer sur! Boutique',
    },
    'u2y21r1t': {
      'en': 'Go to the PlayOn! Store',
      'es': '¡Ve al PlayOn! Tienda',
      'fr': 'Rendez-vous sur PlayOn! Boutique',
    },
    '01t4h5g2': {
      'en': 'You have 5 notifications.',
      'es': '',
      'fr': '',
    },
    'ox3cb4yt': {
      'en': ' Click here ',
      'es': '',
      'fr': '',
    },
    '3y29ke1h': {
      'en': 'My Team(s)',
      'es': '',
      'fr': '',
    },
    '174i62pw': {
      'en': 'My Profile',
      'es': '',
      'fr': '',
    },
    'fj92ichf': {
      'en': 'My Fans',
      'es': '',
      'fr': '',
    },
    '6cht2sx0': {
      'en': 'My Donations',
      'es': '',
      'fr': '',
    },
    'jwd4xfbo': {
      'en': 'My Schedule',
      'es': '',
      'fr': '',
    },
    '49obxmyb': {
      'en': 'My Stats',
      'es': '',
      'fr': '',
    },
    'e47gwzvu': {
      'en': 'My Rewards',
      'es': '',
      'fr': '',
    },
    'fbjct7b2': {
      'en': 'My Invitations',
      'es': '',
      'fr': '',
    },
    'jmygubkv': {
      'en': 'Register',
      'es': '',
      'fr': '',
    },
  },
  // Playerregister_Copy
  {
    'ch3h0orh': {
      'en': 'Login',
      'es': 'Acceso',
      'fr': 'Connexion',
    },
    '76sjxxo0': {
      'en': 'Menu',
      'es': 'Menú',
      'fr': 'Menu',
    },
    '31yxr181': {
      'en': 'PlayOn! Store',
      'es': '¡Juega! Tienda',
      'fr': 'Jouer sur! Boutique',
    },
    'vxv1eg4o': {
      'en': 'Go to the PlayOn! Store',
      'es': '¡Ve al PlayOn! Tienda',
      'fr': 'Rendez-vous sur PlayOn! Boutique',
    },
    'fj7bjwti': {
      'en': 'To register as a Player, you will need:',
      'es': '',
      'fr': '',
    },
    'mn4nzvta': {
      'en':
          '1) If your team has not been created yet, you will have to wait for an invitation to join the team',
      'es': '',
      'fr': '',
    },
    'xgsuyytc': {
      'en': '2) Your profile will remain private and limited to your team',
      'es': '',
      'fr': '',
    },
    'fy5hm95b': {
      'en':
          '3) You will need to pay or join a team via Credit Card for payment: Visa, MasterCard or Paypal',
      'es': '',
      'fr': '',
    },
    'wgwfnf0t': {
      'en': '4) Your division will be assigned based on your team\'s',
      'es': '',
      'fr': '',
    },
    'f1wueow8': {
      'en': 'a) Gender',
      'es': '',
      'fr': '',
    },
    'snfawxo3': {
      'en': 'b) Age',
      'es': '',
      'fr': '',
    },
    'di0avoss': {
      'en': 'c) Skill Level* (if necessary)',
      'es': '',
      'fr': '',
    },
    'qko796na': {
      'en':
          '*Skill level will only be considered if, after gender segregation, an age division exceeds 16 teams',
      'es': '',
      'fr': '',
    },
    'akew4j09': {
      'en':
          'Skill level will be assigned by algorithm based on the infomation each player on your team provides during  this registration process',
      'es': '',
      'fr': '',
    },
    '26jlx63n': {
      'en':
          'You will be held responsible for the integrity of the information you submit as part of this process and your captain will be held responsible for the integrity of all information submitted by all members of the team',
      'es': '',
      'fr': '',
    },
    '5tkecynr': {
      'en':
          '5) Any team that submits false information will be disqualified without refund or rewards given',
      'es': '',
      'fr': '',
    },
    '9ascfx3w': {
      'en': 'Back',
      'es': '',
      'fr': '',
    },
    'vtlrjbls': {
      'en': 'Next',
      'es': '',
      'fr': '',
    },
    'mfdmiyr4': {
      'en': 'Register',
      'es': '',
      'fr': '',
    },
  },
  // FreeAgent_Profile
  {
    'ieik5u7q': {
      'en': 'Login',
      'es': '',
      'fr': '',
    },
    'tkxy01tq': {
      'en': 'Menu',
      'es': 'Menú',
      'fr': 'Menu',
    },
    'u3mjpyf0': {
      'en': 'PlayOn! Store',
      'es': '¡Juega! Tienda',
      'fr': 'Jouer sur! Boutique',
    },
    'r7iryxsq': {
      'en': 'Go to the PlayOn! Store',
      'es': '¡Ve al PlayOn! Tienda',
      'fr': 'Rendez-vous sur PlayOn! Boutique',
    },
    'r1fswlh3': {
      'en': 'My Profile',
      'es': '',
      'fr': '',
    },
    'fsudraax': {
      'en': 'Balaji Reddy',
      'es': '',
      'fr': '',
    },
    'y3a3qa5s': {
      'en': '15/02/2022',
      'es': '',
      'fr': '',
    },
    'brd6bau1': {
      'en': 'Male',
      'es': '',
      'fr': '',
    },
    '7r23b4bh': {
      'en': '9751 34 Ave NW, Edmonton, AB T6E 5X9, Canada',
      'es': '',
      'fr': '',
    },
    'p04ylhfm': {
      'en': 'My Experience',
      'es': '',
      'fr': '',
    },
    '5lpaqkg1': {
      'en': 'My Stats',
      'es': '',
      'fr': '',
    },
    'pcqqaot0': {
      'en': 'My Donations',
      'es': '',
      'fr': '',
    },
    'k2ro8jca': {
      'en': 'Cancel',
      'es': '',
      'fr': '',
    },
    'cwv1exai': {
      'en': 'Edit',
      'es': '',
      'fr': '',
    },
    '70lyku3p': {
      'en': 'Register',
      'es': '',
      'fr': '',
    },
  },
  // Captain_Invitation_02
  {
    'h6bdocmq': {
      'en': 'Login',
      'es': '',
      'fr': '',
    },
    'ntzrfq0p': {
      'en': 'Menu',
      'es': 'Menú',
      'fr': 'Menu',
    },
    'yytkmo2z': {
      'en': 'PlayOn! Store',
      'es': '¡Juega! Tienda',
      'fr': 'Jouer sur! Boutique',
    },
    'fduizmui': {
      'en': 'Go to the PlayOn! Store',
      'es': '¡Ve al PlayOn! Tienda',
      'fr': 'Rendez-vous sur PlayOn! Boutique',
    },
    'pq1af357': {
      'en': 'Invitations',
      'es': '',
      'fr': '',
    },
    'a9u1w8i6': {
      'en': 'Select  team to see details',
      'es': '',
      'fr': '',
    },
    'cvcpfc7g': {
      'en': 'Cancel',
      'es': '',
      'fr': '',
    },
    'ry9k1hy9': {
      'en': 'Register',
      'es': '',
      'fr': '',
    },
  },
  // Register_BusinessPartner_06
  {
    'a19qaip0': {
      'en': 'Business Partner Registration',
      'es': 'Registro de socios comerciales',
      'fr': 'Inscription des partenaires commerciaux',
    },
    'rwn0gs3a': {
      'en': '6',
      'es': '6',
      'fr': '6',
    },
    'yo0ii3q8': {
      'en': 'Event Name:',
      'es': 'Nombre del evento:',
      'fr': 'Nom de l\'événement:',
    },
    'k7uy1nt4': {
      'en':
          'I confirm, I am an employee with authority to bind the organization',
      'es':
          'Confirmo que soy un empleado con autoridad para obligar a la organización',
      'fr':
          'Je confirme, je suis un employé ayant le pouvoir d\'engager l\'organisation',
    },
    'at367nif': {
      'en': 'I agree to all terms and conditions',
      'es': 'Estoy de acuerdo con todos los términos y condiciones',
      'fr': 'J\'accepte tous les termes et conditions',
    },
    '55i1kelk': {
      'en': 'Back',
      'es': 'atrás',
      'fr': 'Retour',
    },
    'pzob1te4': {
      'en': 'Complete registration',
      'es': 'Registro completo',
      'fr': 'enregistrement complet',
    },
    'lij1v3a5': {
      'en': 'Home',
      'es': 'Hogar',
      'fr': 'Maison',
    },
  },
  // Business_RegistrationCoupon
  {
    'w4sh7mwh': {
      'en': 'en_US',
      'es': '',
      'fr': '',
    },
    '0zq90pxl': {
      'en': 'en_US',
      'es': '',
      'fr': '',
    },
    'jv9i6omp': {
      'en': 'fr_FR',
      'es': '',
      'fr': '',
    },
    'k3mm71c5': {
      'en': 'es_ES',
      'es': '',
      'fr': '',
    },
    'x00hdexp': {
      'en': 'Login',
      'es': '',
      'fr': '',
    },
    'b0ykp1xu': {
      'en': 'Coupon Calculator',
      'es': '',
      'fr': '',
    },
    '0shr0jv3': {
      'en':
          'Experience the world\'s largest Street Tournament and Sports Festival',
      'es': '',
      'fr': '',
    },
    'iqo0css5': {
      'en': 'AVERAGE COUPON AMOUNT (ACA) \$',
      'es': '',
      'fr': '',
    },
    '4d9cs38b': {
      'en': '\$',
      'es': '',
      'fr': '',
    },
    'hfw8h6hp': {
      'en': '50',
      'es': '',
      'fr': '',
    },
    'e4yebqwb': {
      'en': 'PAYOUT PER GOAL \$',
      'es': '',
      'fr': '',
    },
    'pjp8f9tt': {
      'en': 'PROJECTED CUSTOMERS ACQUIRED (RANGE)',
      'es': '',
      'fr': '',
    },
    'wcjft3d3': {
      'en': 'Coupons',
      'es': '',
      'fr': '',
    },
  },
  // Dashboard_Player
  {
    'iafcdeqb': {
      'en': 'You have 5 notifications.',
      'es': '',
      'fr': '',
    },
    'w5rdpyye': {
      'en': ' Click here ',
      'es': '',
      'fr': '',
    },
    'mpai9ra6': {
      'en': 'My Team(s)',
      'es': '',
      'fr': '',
    },
    'eo7cibf6': {
      'en': 'My Profile',
      'es': '',
      'fr': '',
    },
    'rkohlgh6': {
      'en': 'My Fans',
      'es': '',
      'fr': '',
    },
    'y44ce98j': {
      'en': 'My Donations',
      'es': '',
      'fr': '',
    },
    '4nzmk5n6': {
      'en': 'My Schedule',
      'es': '',
      'fr': '',
    },
    '70hzz45f': {
      'en': 'My Stats',
      'es': '',
      'fr': '',
    },
    'x7wpersu': {
      'en': 'My Rewards',
      'es': '',
      'fr': '',
    },
    'u4klbjtz': {
      'en': 'My Invitations',
      'es': '',
      'fr': '',
    },
    'd50b4v3t': {
      'en': 'Register',
      'es': '',
      'fr': '',
    },
  },
  // Volunteer_Profile
  {
    'zzs21qlr': {
      'en': 'Login',
      'es': '',
      'fr': '',
    },
    'mxxrz08l': {
      'en': 'Menu',
      'es': 'Menú',
      'fr': 'Menu',
    },
    'of69lo2m': {
      'en': 'PlayOn! Store',
      'es': '¡Juega! Tienda',
      'fr': 'Jouer sur! Boutique',
    },
    '1rktip4q': {
      'en': 'Go to the PlayOn! Store',
      'es': '¡Ve al PlayOn! Tienda',
      'fr': 'Rendez-vous sur PlayOn! Boutique',
    },
    'hryu0a7i': {
      'en': 'My Profile',
      'es': '',
      'fr': '',
    },
    '1crbwwy1': {
      'en': 'Balaji Reddy',
      'es': '',
      'fr': '',
    },
    'vs1xxa4m': {
      'en': '15/02/2022',
      'es': '',
      'fr': '',
    },
    'nay1n1hh': {
      'en': 'Male',
      'es': '',
      'fr': '',
    },
    '9n398s3y': {
      'en': '9751 34 Ave NW, Edmonton, AB T6E 5X9, Canada',
      'es': '',
      'fr': '',
    },
    '250srzqs': {
      'en': 'My Experience',
      'es': '',
      'fr': '',
    },
    'lh1vml86': {
      'en': 'My Stats',
      'es': '',
      'fr': '',
    },
    '3g8927ai': {
      'en': 'My Donations',
      'es': '',
      'fr': '',
    },
    'g43zjzby': {
      'en': 'Cancel',
      'es': '',
      'fr': '',
    },
    'nzsimcvk': {
      'en': 'Edit',
      'es': '',
      'fr': '',
    },
    '9kz7mxzk': {
      'en': 'Register',
      'es': '',
      'fr': '',
    },
  },
  // Businessprofile
  {
    'nggu8vee': {
      'en': 'Profile',
      'es': 'editar usuario',
      'fr': 'Modifier l\'utilisateur',
    },
    'j8blk4ov': {
      'en': 'Enter business id',
      'es': 'Ingrese el nombre',
      'fr': 'entrez votre prénom',
    },
    'g82j2ry1': {
      'en': 'Enter organization name',
      'es': 'Introduzca el apellido',
      'fr': 'Entrer le nom de famille',
    },
    'w7bvo5r9': {
      'en': 'Enter address',
      'es': 'Introduzca la dirección de correo electrónico',
      'fr': 'Entrer l\'adresse e-mail',
    },
    'cdpveb80': {
      'en': 'Airline',
      'es': '',
      'fr': '',
    },
    'l49x1ilt': {
      'en': 'Other',
      'es': '',
      'fr': '',
    },
    'i9mz44uv': {
      'en': 'Please select your industry',
      'es': '',
      'fr': '',
    },
    '2ipvjobt': {
      'en': 'Enter other industry name',
      'es': 'Introduzca el apellido',
      'fr': 'Entrer le nom de famille',
    },
    'd8gob5ni': {
      'en': 'Change logo',
      'es': '',
      'fr': '',
    },
    'isw8pd5a': {
      'en': 'Business id is required',
      'es': '',
      'fr': '',
    },
    'vjmwum4y': {
      'en': 'Please choose an option from the dropdown',
      'es': '',
      'fr': '',
    },
    'v5vidfv2': {
      'en': 'Organization name is required',
      'es': '',
      'fr': '',
    },
    'qwqdy1fb': {
      'en': 'Please choose an option from the dropdown',
      'es': '',
      'fr': '',
    },
    '64mujon0': {
      'en': 'Address is required',
      'es': '',
      'fr': '',
    },
    '8ta3kanf': {
      'en': 'Please choose an option from the dropdown',
      'es': '',
      'fr': '',
    },
    'xbu5d0yn': {
      'en': 'Field is required',
      'es': '',
      'fr': '',
    },
    'jonhjdc1': {
      'en': 'Please choose an option from the dropdown',
      'es': '',
      'fr': '',
    },
    '9ydq6ffx': {
      'en': 'Back',
      'es': 'atrás',
      'fr': 'Retour',
    },
    'k5a8bbb9': {
      'en': 'Save',
      'es': 'Ahorrar',
      'fr': 'sauvegarder',
    },
    'k88y9eaa': {
      'en': 'Home',
      'es': '',
      'fr': '',
    },
  },
  // Dashboard_BusinessPartner
  {
    'kc282aeb': {
      'en': 'All Score',
      'es': 'Recompensas',
      'fr': 'Récompenses',
    },
    'n07tlvmu': {
      'en': 'Manage Events',
      'es': 'Administrar eventos',
      'fr': 'Gérer les événements',
    },
    '1py14k2q': {
      'en': 'Manage Users',
      'es': 'Administrar usuarios',
      'fr': 'gérer les utilisateurs',
    },
    'engz1rrv': {
      'en': 'Profile',
      'es': 'Perfil',
      'fr': 'Profil',
    },
    '5fp5xfv7': {
      'en': 'Rewards',
      'es': 'Recompensas',
      'fr': 'Récompenses',
    },
    '60mamzau': {
      'en': 'Coming soon',
      'es': 'Recompensas',
      'fr': 'Récompenses',
    },
    'd9jegyh8': {
      'en': 'Schedules',
      'es': 'Horarios',
      'fr': 'Des horaires',
    },
    'fc55girm': {
      'en': 'Coming soon',
      'es': 'Horarios',
      'fr': 'Des horaires',
    },
    'rnzpgs21': {
      'en': 'Score',
      'es': 'Recompensas',
      'fr': 'Récompenses',
    },
    'oy3edkfe': {
      'en': 'Score',
      'es': 'Recompensas',
      'fr': 'Récompenses',
    },
    'tr5p0grs': {
      'en': 'Quiz',
      'es': 'Recompensas',
      'fr': 'Récompenses',
    },
    'pbrztpow': {
      'en': 'Assign quiz',
      'es': 'Recompensas',
      'fr': 'Récompenses',
    },
    '79xwizz3': {
      'en': 'Register',
      'es': 'Registro',
      'fr': 'S\'inscrire',
    },
  },
  // Dashboard_Volunteer
  {
    'r2wtina0': {
      'en': 'Login',
      'es': '',
      'fr': '',
    },
    'y3ha75l5': {
      'en': 'Menu',
      'es': 'Menú',
      'fr': 'Menu',
    },
    'a3rlnoha': {
      'en': 'PlayOn! Store',
      'es': '¡Juega! Tienda',
      'fr': 'Jouer sur! Boutique',
    },
    'f0ou181b': {
      'en': 'Go to the PlayOn! Store',
      'es': '¡Ve al PlayOn! Tienda',
      'fr': 'Rendez-vous sur PlayOn! Boutique',
    },
    '0a419s6z': {
      'en': 'You have 5 notifications.',
      'es': '',
      'fr': '',
    },
    'jixdndvt': {
      'en': ' Click here ',
      'es': '',
      'fr': '',
    },
    '0ss755fq': {
      'en': 'My Team(s)',
      'es': '',
      'fr': '',
    },
    '88b8nlkv': {
      'en': 'My Profile',
      'es': '',
      'fr': '',
    },
    '4rr8r2rh': {
      'en': 'My Fans',
      'es': '',
      'fr': '',
    },
    'dmwnlx8r': {
      'en': 'My Donations',
      'es': '',
      'fr': '',
    },
    'sfmsl3zi': {
      'en': 'My Schedule',
      'es': '',
      'fr': '',
    },
    't5s7g209': {
      'en': 'My Stats',
      'es': '',
      'fr': '',
    },
    'q0qyi9w3': {
      'en': 'My Rewards',
      'es': '',
      'fr': '',
    },
    'udq8rvhe': {
      'en': 'My Invitations',
      'es': '',
      'fr': '',
    },
    '8ug22tzk': {
      'en': 'Register',
      'es': '',
      'fr': '',
    },
  },
  // ManageEvents_BusinessPartner
  {
    'o0s29kn4': {
      'en': 'Manage Events',
      'es': 'Administrar eventos',
      'fr': 'Gérer les événements',
    },
    'vfb5m4d9': {
      'en': 'Selected Events',
      'es': 'Eventos seleccionados',
      'fr': 'Événements sélectionnés',
    },
    'a4ua18o9': {
      'en': 'UnSelect',
      'es': 'Deseleccionar',
      'fr': 'Désélectionner',
    },
    'udgqzj6f': {
      'en': 'UnSelect',
      'es': 'Deseleccionar',
      'fr': 'Désélectionner',
    },
    '6rv7lnaf': {
      'en': 'Available Events',
      'es': 'Eventos disponibles',
      'fr': 'Événements disponibles',
    },
    '9odsmj5t': {
      'en': 'Select',
      'es': 'Seleccione',
      'fr': 'Sélectionner',
    },
    'o1yrjus5': {
      'en': 'Select',
      'es': 'Seleccione',
      'fr': 'Sélectionner',
    },
    's1y1xt8l': {
      'en': 'No event available to select',
      'es': 'Ningún evento disponible para seleccionar',
      'fr': 'Aucun événement disponible pour sélectionner',
    },
    'jqqsdwml': {
      'en': 'Back',
      'es': 'atrás',
      'fr': 'Retour',
    },
    'vlp3r59x': {
      'en': 'Save',
      'es': 'Ahorrar',
      'fr': 'sauvegarder',
    },
    'zuy7dggz': {
      'en': 'Register',
      'es': 'Registro',
      'fr': 'S\'inscrire',
    },
  },
  // Dashboard_Admin
  {
    'dzscly6q': {
      'en': 'Menu',
      'es': 'Menú',
      'fr': 'Menu',
    },
    '4kdxtrrf': {
      'en': 'PlayOn! Store',
      'es': '¡Juega! Tienda',
      'fr': 'Jouer sur! Boutique',
    },
    'rw4dpde1': {
      'en': 'Go to the PlayOn! Store',
      'es': '¡Ve al PlayOn! Tienda',
      'fr': 'Rendez-vous sur PlayOn! Boutique',
    },
    'avm930ry': {
      'en': 'Manage Events\n',
      'es': 'Administrar eventos',
      'fr': 'Gérer les événements',
    },
    'xxduarjq': {
      'en': 'Manage Divisions',
      'es': 'Administrar divisiones',
      'fr': 'Gérer les divisions',
    },
    'zw6loyk9': {
      'en': 'Manage Fees',
      'es': 'Administrar tarifas',
      'fr': 'Gérer les frais',
    },
    'vab3lzsd': {
      'en': 'Manage Tax',
      'es': 'Administrar impuestos',
      'fr': 'Gérer la taxe',
    },
    'umu9a903': {
      'en': 'Manage Users',
      'es': 'Administrar usuarios',
      'fr': 'gérer les utilisateurs',
    },
    'unkmq4c4': {
      'en': 'Manage Referees',
      'es': 'Administrar árbitros',
      'fr': 'Gérer les arbitres',
    },
    'jkpfarke': {
      'en': 'Manage Teams',
      'es': 'Administrar equipos',
      'fr': 'Gérer les équipes',
    },
    '78vecmbm': {
      'en': 'Schedule Events',
      'es': 'Programar eventos',
      'fr': 'Planifier des événements',
    },
    'gu0r1kmm': {
      'en': 'Register',
      'es': '',
      'fr': '',
    },
  },
  // Captain_Invitation_03
  {
    'h3ds8lzl': {
      'en': 'Login',
      'es': '',
      'fr': '',
    },
    '1rsnal7y': {
      'en': 'Menu',
      'es': 'Menú',
      'fr': 'Menu',
    },
    'mb0ziir4': {
      'en': 'PlayOn! Store',
      'es': '¡Juega! Tienda',
      'fr': 'Jouer sur! Boutique',
    },
    'gwzboe4e': {
      'en': 'Go to the PlayOn! Store',
      'es': '¡Ve al PlayOn! Tienda',
      'fr': 'Rendez-vous sur PlayOn! Boutique',
    },
    '6a4nbk51': {
      'en': 'Invitations',
      'es': '',
      'fr': '',
    },
    'skkf0vsh': {
      'en': 'Status of Players invited ',
      'es': '',
      'fr': '',
    },
    'ezfc6l72': {
      'en': 'Invite Players',
      'es': '',
      'fr': '',
    },
    'bwuhgm59': {
      'en': 'Register',
      'es': '',
      'fr': '',
    },
  },
  // Add_Division
  {
    'q8cm6sp8': {
      'en': 'Menu',
      'es': 'Menú',
      'fr': 'Menu',
    },
    '3111fq4j': {
      'en': 'PlayOn! Store',
      'es': '¡Juega! Tienda',
      'fr': 'Jouer sur! Boutique',
    },
    'oiqqis8m': {
      'en': 'Go to the PlayOn! Store',
      'es': '¡Ve al PlayOn! Tienda',
      'fr': 'Rendez-vous sur PlayOn! Boutique',
    },
    'lhkac54m': {
      'en': '\nAdd Division',
      'es': 'Agregar división',
      'fr': 'Ajouter une division',
    },
    '0l2eihyk': {
      'en': 'Enter a value',
      'es': '',
      'fr': '',
    },
    '3bt52hon': {
      'en': 'Enter description',
      'es': 'Ingrese la descripción',
      'fr': 'Entrez la description',
    },
    '8lqeldd7': {
      'en': 'Adult',
      'es': '',
      'fr': '',
    },
    'b9ktybvc': {
      'en': 'Youth',
      'es': '',
      'fr': '',
    },
    'tx87s1w1': {
      'en': 'Please select...',
      'es': '',
      'fr': '',
    },
    'u4o2gowg': {
      'en': '7 and under',
      'es': 'Opción 1',
      'fr': 'Option 1',
    },
    'rx1ejbhw': {
      'en': '8 and under',
      'es': '',
      'fr': '',
    },
    'v1di3yh0': {
      'en': '19 and over',
      'es': '',
      'fr': '',
    },
    'pa07uvgx': {
      'en': 'Please select...',
      'es': 'Por favor selecciona...',
      'fr': 'Veuillez sélectionner...',
    },
    'r987kmof': {
      'en': 'Yes',
      'es': 'sí',
      'fr': 'Oui',
    },
    '6a3a797c': {
      'en': 'No',
      'es': 'No',
      'fr': 'Non',
    },
    'mrvax9kt': {
      'en': 'Please select...',
      'es': 'Por favor selecciona...',
      'fr': 'Veuillez sélectionner...',
    },
    'kfhbzvya': {
      'en': 'Option 1',
      'es': 'Opción 1',
      'fr': 'Option 1',
    },
    'rz2f6ikj': {
      'en': 'Please select...',
      'es': 'Por favor selecciona...',
      'fr': 'Veuillez sélectionner...',
    },
    '1gvmoxxr': {
      'en': 'Male',
      'es': '',
      'fr': '',
    },
    't3vr5bdb': {
      'en': 'Female',
      'es': '',
      'fr': '',
    },
    'tv0ysxto': {
      'en': 'Please select...',
      'es': '',
      'fr': '',
    },
    'zir81awm': {
      'en': 'Cancel',
      'es': 'Cancelar',
      'fr': 'Annuler',
    },
    '6nttzv73': {
      'en': 'Save',
      'es': 'Ahorrar',
      'fr': 'Sauvegarder',
    },
    '6vxwjlp3': {
      'en': 'Register',
      'es': '',
      'fr': '',
    },
  },
  // Referee_Profile
  {
    'za4zgu05': {
      'en': 'Login',
      'es': '',
      'fr': '',
    },
    'n0jzen62': {
      'en': 'Menu',
      'es': 'Menú',
      'fr': 'Menu',
    },
    '4bx34xzp': {
      'en': 'PlayOn! Store',
      'es': '¡Juega! Tienda',
      'fr': 'Jouer sur! Boutique',
    },
    'oszf8d5y': {
      'en': 'Go to the PlayOn! Store',
      'es': '¡Ve al PlayOn! Tienda',
      'fr': 'Rendez-vous sur PlayOn! Boutique',
    },
    '08k4ag9d': {
      'en': 'My Profile',
      'es': '',
      'fr': '',
    },
    'pttmp1er': {
      'en': 'Balaji Reddy',
      'es': '',
      'fr': '',
    },
    'h47dgt6h': {
      'en': '15/02/2022',
      'es': '',
      'fr': '',
    },
    'gy9p8eoo': {
      'en': 'Male',
      'es': '',
      'fr': '',
    },
    'ju559s09': {
      'en': '9751 34 Ave NW, Edmonton, AB T6E 5X9, Canada',
      'es': '',
      'fr': '',
    },
    'npbq6vnl': {
      'en': 'My Experience',
      'es': '',
      'fr': '',
    },
    '0tmr40zx': {
      'en': 'My Stats',
      'es': '',
      'fr': '',
    },
    'uop6mxbj': {
      'en': 'My Donations',
      'es': '',
      'fr': '',
    },
    'ndnz1fjb': {
      'en': 'Cancel',
      'es': '',
      'fr': '',
    },
    '02419zbu': {
      'en': 'Edit',
      'es': '',
      'fr': '',
    },
    'tppmggz0': {
      'en': 'Register',
      'es': '',
      'fr': '',
    },
  },
  // Edit_Event
  {
    'h8r3q7g9': {
      'en': 'Edit Event',
      'es': '',
      'fr': '',
    },
    '3bip2qok': {
      'en': 'Enter a value',
      'es': '',
      'fr': '',
    },
    'gowbnd53': {
      'en': 'Play On!',
      'es': '',
      'fr': '',
    },
    'wbi1rve5': {
      'en': 'Play On!',
      'es': '',
      'fr': '',
    },
    'iskrk301': {
      'en': 'Location Detailss',
      'es': '',
      'fr': '',
    },
    'fgvl8ytj': {
      'en': 'Enter a  value',
      'es': '',
      'fr': '',
    },
    '53m2lzg7': {
      'en': 'Enter address',
      'es': '',
      'fr': '',
    },
    'hqyxd2d3': {
      'en': 'Option 1',
      'es': '',
      'fr': '',
    },
    'mmto0vu1': {
      'en': 'Canada',
      'es': '',
      'fr': '',
    },
    '2ml0zjl7': {
      'en': 'Option 1',
      'es': '',
      'fr': '',
    },
    'ai3bozrq': {
      'en': 'Alberta',
      'es': '',
      'fr': '',
    },
    'xr4ryqwv': {
      'en': 'Enter a  value',
      'es': '',
      'fr': '',
    },
    'hqiy1pns': {
      'en': 'Enter zip code',
      'es': '',
      'fr': '',
    },
    '8efrghcg': {
      'en': 'Choose a file',
      'es': '',
      'fr': '',
    },
    'wsue8yeo': {
      'en': 'Choose a file',
      'es': '',
      'fr': '',
    },
    'qmru1lhi': {
      'en': 'Team',
      'es': '',
      'fr': '',
    },
    '3nkjt9d9': {
      'en': 'Enter a  value',
      'es': '',
      'fr': '',
    },
    'wggr17qh': {
      'en': 'Enter a  value',
      'es': '',
      'fr': '',
    },
    'pybveaa6': {
      'en': 'Enter a  value',
      'es': '',
      'fr': '',
    },
    'y0cq0jk7': {
      'en': 'Fee',
      'es': '',
      'fr': '',
    },
    'd1qwl7er': {
      'en': 'Enter a value',
      'es': '',
      'fr': '',
    },
    'joswfm6m': {
      'en': 'Enter a value',
      'es': '',
      'fr': '',
    },
    'y7mry9t1': {
      'en': 'Enter a value',
      'es': '',
      'fr': '',
    },
    'dhxuo7gs': {
      'en': 'Enter a value',
      'es': '',
      'fr': '',
    },
    'sato0s3j': {
      'en': 'Space',
      'es': '',
      'fr': '',
    },
    'c3jt0wxk': {
      'en': 'Enter a  value',
      'es': '',
      'fr': '',
    },
    '5n64zdb6': {
      'en': 'Enter a  value',
      'es': '',
      'fr': '',
    },
    'qx33wfco': {
      'en': 'Enter a  value',
      'es': '',
      'fr': '',
    },
    'whfyii4z': {
      'en': 'Important Dates',
      'es': '',
      'fr': '',
    },
    'grq4squo': {
      'en': '1',
      'es': '',
      'fr': '',
    },
    'lxlkeggw': {
      'en': 'Day',
      'es': '',
      'fr': '',
    },
    'qekmoen7': {
      'en': '1',
      'es': '',
      'fr': '',
    },
    'xhfazagx': {
      'en': 'Month',
      'es': '',
      'fr': '',
    },
    'uup2bx99': {
      'en': '1935',
      'es': '',
      'fr': '',
    },
    '8pep5d0w': {
      'en': 'Year',
      'es': '',
      'fr': '',
    },
    'uhwqdgat': {
      'en': '1',
      'es': '',
      'fr': '',
    },
    'nxur9763': {
      'en': 'Day',
      'es': '',
      'fr': '',
    },
    '82xqa4m7': {
      'en': '1',
      'es': '',
      'fr': '',
    },
    'f3m1gwj1': {
      'en': 'Month',
      'es': '',
      'fr': '',
    },
    'haviz8fu': {
      'en': '1935',
      'es': '',
      'fr': '',
    },
    'stkodgeg': {
      'en': 'Year',
      'es': '',
      'fr': '',
    },
    'n5dtp1z6': {
      'en': '1',
      'es': '',
      'fr': '',
    },
    'ryjtc0bd': {
      'en': 'Day',
      'es': '',
      'fr': '',
    },
    'vge17v5o': {
      'en': '1',
      'es': '',
      'fr': '',
    },
    'ewv8ntjs': {
      'en': 'Month',
      'es': '',
      'fr': '',
    },
    '8lkmsx83': {
      'en': '1935',
      'es': '',
      'fr': '',
    },
    'qgn6lm44': {
      'en': 'Year',
      'es': '',
      'fr': '',
    },
    '1t2i5rf2': {
      'en': 'Coordinator ',
      'es': '',
      'fr': '',
    },
    '4ahgcukr': {
      'en': 'Option 1',
      'es': '',
      'fr': '',
    },
    'k0qaxm6w': {
      'en': 'Please select...',
      'es': '',
      'fr': '',
    },
    'j41uiry7': {
      'en': 'Option 1',
      'es': '',
      'fr': '',
    },
    'l6nolb2m': {
      'en': 'Please select...',
      'es': '',
      'fr': '',
    },
    '8iuu7mig': {
      'en': 'Option 1',
      'es': '',
      'fr': '',
    },
    'mayfbnif': {
      'en': 'Please select...',
      'es': '',
      'fr': '',
    },
    'gmmyye9m': {
      'en': 'Option 1',
      'es': '',
      'fr': '',
    },
    'fyyxjrr3': {
      'en': 'Please select...',
      'es': '',
      'fr': '',
    },
    'fvt0y4n7': {
      'en': 'Donation',
      'es': '',
      'fr': '',
    },
    '1tecgum5': {
      'en': 'Enter a  value',
      'es': '',
      'fr': '',
    },
    'vqvfon46': {
      'en': 'Teams and Schedule',
      'es': '',
      'fr': '',
    },
    '02c3gge5': {
      'en': 'Enter a  value',
      'es': '',
      'fr': '',
    },
    '9hqv5cu8': {
      'en': 'Enter a  value',
      'es': '',
      'fr': '',
    },
    'sni403pf': {
      'en': 'Results',
      'es': '',
      'fr': '',
    },
    'b16csx03': {
      'en': 'Enter a  value',
      'es': '',
      'fr': '',
    },
    'gnn3btub': {
      'en': 'Enter a  value',
      'es': '',
      'fr': '',
    },
    'vjdu9577': {
      'en': 'Cancel',
      'es': '',
      'fr': '',
    },
    '61thp9ew': {
      'en': 'Save',
      'es': '',
      'fr': '',
    },
    'rsbb3wwr': {
      'en': 'Home',
      'es': '',
      'fr': '',
    },
  },
  // Register_Fan_00
  {
    'fpv5oi91': {
      'en': 'To register as a Fan, you will need following:',
      'es': '',
      'fr': '',
    },
    'ra4r8lpz': {
      'en': '1',
      'es': '',
      'fr': '',
    },
    'dj4okvhl': {
      'en': 'Provide a Team Name',
      'es': '',
      'fr': '',
    },
    'l3x86m3m': {
      'en': 'Decide on a unique team name',
      'es': '',
      'fr': '',
    },
    'hninuxfb': {
      'en': '2',
      'es': '',
      'fr': '',
    },
    'aj0knan6': {
      'en': '3 to 8 additional players that are committed to play',
      'es': '',
      'fr': '',
    },
    '8fa8ah8y': {
      'en': 'Teams must have between 4 and 9 players, including the goalie.',
      'es': '',
      'fr': '',
    },
    'uyai2kpw': {
      'en': '3',
      'es': '',
      'fr': '',
    },
    '65pdw63i': {
      'en': 'Email addresses for players you want to invite to your team.',
      'es': '',
      'fr': '',
    },
    'xz92b6u8': {
      'en': 'You can add or change players later.',
      'es': '',
      'fr': '',
    },
    'imr7ojm9': {
      'en': '4',
      'es': '',
      'fr': '',
    },
    '10gmqxaj': {
      'en': 'Credit card for payment: Visa, MasterCard, or PayPal',
      'es': '',
      'fr': '',
    },
    'vvdd4eo8': {
      'en': 'Registration fees are non-refundable. ',
      'es': '',
      'fr': '',
    },
    'ml3zcugz': {
      'en':
          'Watch the following video to understand the exciting new Pay for Play program.',
      'es': '',
      'fr': '',
    },
    'srsp2pxo': {
      'en': 'Watch Online',
      'es': '',
      'fr': '',
    },
    'tf48v8xj': {
      'en': 'Back',
      'es': '',
      'fr': '',
    },
    '2w8iwull': {
      'en': 'Next',
      'es': '',
      'fr': '',
    },
    '03d6bzpp': {
      'en': 'Home',
      'es': '',
      'fr': '',
    },
  },
  // Register_Fan_01
  {
    'l3j0tuzr': {
      'en': 'Fan Registration',
      'es': '',
      'fr': '',
    },
    '8k6jkuvt': {
      'en': '1',
      'es': '',
      'fr': '',
    },
    'bvyqcc5l': {
      'en': 'Select Team',
      'es': '',
      'fr': '',
    },
    'pdep3hk6': {
      'en': '2',
      'es': '',
      'fr': '',
    },
    'ih8djrsu': {
      'en': 'Your Details',
      'es': '',
      'fr': '',
    },
    'x7e94qgw': {
      'en': '3',
      'es': '',
      'fr': '',
    },
    '9urz3law': {
      'en': 'Experience',
      'es': '',
      'fr': '',
    },
    'ox4egg3g': {
      'en': '4',
      'es': '',
      'fr': '',
    },
    'x9jc365l': {
      'en': 'Acknowledgement',
      'es': '',
      'fr': '',
    },
    'it20da1x': {
      'en': '5',
      'es': '',
      'fr': '',
    },
    'um2dig6m': {
      'en': 'Waiver',
      'es': '',
      'fr': '',
    },
    'xona21e6': {
      'en': '6',
      'es': '',
      'fr': '',
    },
    'ise8rv0l': {
      'en': 'Payment',
      'es': '',
      'fr': '',
    },
    'qtrj3yrx': {
      'en': '7',
      'es': '',
      'fr': '',
    },
    'uarqia12': {
      'en': 'Charity',
      'es': '',
      'fr': '',
    },
    'vkvpicq5': {
      'en': '2',
      'es': '',
      'fr': '',
    },
    '6scsgxh7': {
      'en': 'Your Team Name is:',
      'es': '',
      'fr': '',
    },
    't98atgc6': {
      'en': 'London Giants (pending approval)',
      'es': '',
      'fr': '',
    },
    'olezfuju': {
      'en': 'You are playing in:',
      'es': '',
      'fr': '',
    },
    'f2822s3w': {
      'en': 'Event 1',
      'es': '',
      'fr': '',
    },
    '6cl3ebv4': {
      'en': 'First Name',
      'es': '',
      'fr': '',
    },
    'z2fcqaug': {
      'en': 'Enter your first name',
      'es': '',
      'fr': '',
    },
    '4soaaoxw': {
      'en': 'Last Name',
      'es': '',
      'fr': '',
    },
    'jo0i6343': {
      'en': 'Enter your last name',
      'es': '',
      'fr': '',
    },
    'hqd278yx': {
      'en': 'Mobile Number',
      'es': '',
      'fr': '',
    },
    'siictl6e': {
      'en': 'Enter your mobile number',
      'es': '',
      'fr': '',
    },
    'nsmzitp1': {
      'en': 'Email id',
      'es': '',
      'fr': '',
    },
    'esahw6kf': {
      'en': 'Enter your email id',
      'es': '',
      'fr': '',
    },
    'x22ukn18': {
      'en': 'Address 1',
      'es': '',
      'fr': '',
    },
    'qbhv6at2': {
      'en': 'Enter your address details',
      'es': '',
      'fr': '',
    },
    '8a9evjaq': {
      'en': 'Address 2',
      'es': '',
      'fr': '',
    },
    'ivh8ojbp': {
      'en': 'Enter your address details',
      'es': '',
      'fr': '',
    },
    'bpysgypy': {
      'en': 'Country',
      'es': '',
      'fr': '',
    },
    'r6x1cxi3': {
      'en': 'Option 1',
      'es': '',
      'fr': '',
    },
    '0ydodhqc': {
      'en': 'Please select...',
      'es': '',
      'fr': '',
    },
    'vc0iomdx': {
      'en': 'Province/State',
      'es': '',
      'fr': '',
    },
    'gc6bb7zm': {
      'en': 'Option 1',
      'es': '',
      'fr': '',
    },
    '00cg0zl8': {
      'en': 'Please select...',
      'es': '',
      'fr': '',
    },
    'og33qxdp': {
      'en': 'City',
      'es': '',
      'fr': '',
    },
    'yjzfsz9s': {
      'en': 'Option 1',
      'es': '',
      'fr': '',
    },
    'bkr65tk4': {
      'en': 'Please select...',
      'es': '',
      'fr': '',
    },
    'yqdw90gx': {
      'en': 'Postal Code',
      'es': '',
      'fr': '',
    },
    'qdpup6av': {
      'en': 'Enter your postal code',
      'es': '',
      'fr': '',
    },
    'ngr9hop4': {
      'en': 'Your Stats',
      'es': '',
      'fr': '',
    },
    'bt055qms': {
      'en': 'lbs',
      'es': '',
      'fr': '',
    },
    'hwzvt4ei': {
      'en': 'Feet',
      'es': '',
      'fr': '',
    },
    'ppdbtkmy': {
      'en': 'Inches',
      'es': '',
      'fr': '',
    },
    'bebkr5an': {
      'en': 'Left',
      'es': '',
      'fr': '',
    },
    'n8i02gd0': {
      'en': 'Right',
      'es': '',
      'fr': '',
    },
    'ddykyy4u': {
      'en': 'Select one',
      'es': '',
      'fr': '',
    },
    'jq9gfjej': {
      'en': 'Jersey number',
      'es': '',
      'fr': '',
    },
    '9zz6xd6f': {
      'en': 'Male',
      'es': '',
      'fr': '',
    },
    '7m2tartb': {
      'en': 'Female',
      'es': '',
      'fr': '',
    },
    'nzkced26': {
      'en': 'Neither',
      'es': '',
      'fr': '',
    },
    'azygowl6': {
      'en': 'Select one',
      'es': '',
      'fr': '',
    },
    'u6i7fda7': {
      'en': 'Back',
      'es': '',
      'fr': '',
    },
    'r0r26mgh': {
      'en': 'Next',
      'es': '',
      'fr': '',
    },
    'lykvc4l0': {
      'en': 'Home',
      'es': '',
      'fr': '',
    },
  },
  // Register_Fan_02
  {
    'o6g73797': {
      'en': 'Fan Registration',
      'es': '',
      'fr': '',
    },
    'us11he0v': {
      'en': '1',
      'es': '',
      'fr': '',
    },
    'stuv11pq': {
      'en': 'Basic Details',
      'es': '',
      'fr': '',
    },
    'xwgymptu': {
      'en': '2',
      'es': '',
      'fr': '',
    },
    'rjgxfm9u': {
      'en': 'Experience',
      'es': '',
      'fr': '',
    },
    'dceeaj0e': {
      'en': '3',
      'es': '',
      'fr': '',
    },
    'p2irt8tq': {
      'en': 'References',
      'es': '',
      'fr': '',
    },
    'u8o6pttn': {
      'en': '4',
      'es': '',
      'fr': '',
    },
    'ajcqoimm': {
      'en': 'Event\nSelection',
      'es': '',
      'fr': '',
    },
    'cijwldv7': {
      'en': '5',
      'es': '',
      'fr': '',
    },
    'pwcyia3e': {
      'en': 'Availability',
      'es': '',
      'fr': '',
    },
    '7if86baw': {
      'en': '6',
      'es': '',
      'fr': '',
    },
    'mpmhifl6': {
      'en': 'Waiver',
      'es': '',
      'fr': '',
    },
    '8s1qkeaj': {
      'en': '7',
      'es': '',
      'fr': '',
    },
    '37i0bckz': {
      'en': 'Payment Details',
      'es': '',
      'fr': '',
    },
    '6qa65ukp': {
      'en': '4',
      'es': '',
      'fr': '',
    },
    '313saslg': {
      'en': 'Back',
      'es': '',
      'fr': '',
    },
    'ujxbuv3v': {
      'en': 'Next',
      'es': '',
      'fr': '',
    },
    '4pwyodl4': {
      'en': 'Home',
      'es': '',
      'fr': '',
    },
  },
  // Manage_UserList
  {
    '9crcx5ng': {
      'en': 'Menu',
      'es': 'Menú',
      'fr': 'Menu',
    },
    'rlu07mb6': {
      'en': 'PlayOn! Store',
      'es': '¡Juega! Tienda',
      'fr': 'Jouer sur! Boutique',
    },
    'hsqchpi1': {
      'en': 'Go to the PlayOn! Store',
      'es': '¡Ve al PlayOn! Tienda',
      'fr': 'Rendez-vous sur PlayOn! Boutique',
    },
    'vxumyyfs': {
      'en': 'Manage User',
      'es': 'Administrar usuario',
      'fr': 'Gérer l\'utilisateur',
    },
    '4uzi6vsv': {
      'en': 'Add Admin User',
      'es': 'Agregar usuario administrador',
      'fr': 'Ajouter un utilisateur administrateur',
    },
    'aasiqhzj': {
      'en': 'Back',
      'es': 'atrás',
      'fr': 'Retour',
    },
    '4l9e1uph': {
      'en': 'Next',
      'es': 'Próxima',
      'fr': 'Prochaine',
    },
    '0o5kcnxn': {
      'en': 'Register',
      'es': 'Registro',
      'fr': 'S\'inscrire',
    },
  },
  // Contactus
  {
    '11jjwmcn': {
      'en': 'Contact Us',
      'es': 'Contáctenos',
      'fr': 'Nous contacter',
    },
    'icks6fn9': {
      'en': 'Feedback For',
      'es': 'Comentarios para',
      'fr': 'Commentaires pour',
    },
    '66a5fvzp': {
      'en': 'Access Application ',
      'es': 'Solicitud de acceso',
      'fr': 'Demande d\'accès',
    },
    'nnfmpw19': {
      'en': 'Business Partner',
      'es': 'Socio de negocios',
      'fr': 'Associé',
    },
    'dsvn7nxu': {
      'en': 'Captain',
      'es': 'Capitán',
      'fr': 'Capitaine',
    },
    'ctgemo67': {
      'en': 'Charity',
      'es': 'Caridad',
      'fr': 'Charité',
    },
    'y51v5rk5': {
      'en': 'Free Agent',
      'es': 'Agente libre',
      'fr': 'Agent libre',
    },
    '8hnhrb4u': {
      'en': 'Family Account',
      'es': 'Cuenta familiar',
      'fr': 'Compte Famille',
    },
    '7ctgufi0': {
      'en': 'Fan',
      'es': 'Admirador',
      'fr': 'Ventilateur',
    },
    '2lor06t6': {
      'en': 'General',
      'es': 'General',
      'fr': 'Général',
    },
    'bzq1al6x': {
      'en': 'Official',
      'es': 'Oficial',
      'fr': 'Officiel',
    },
    'up9ovjnj': {
      'en': 'Team Player ',
      'es': 'Jugador de equipo',
      'fr': 'Joueur d&#39;équipe',
    },
    'znxj66d7': {
      'en': 'Volunteer',
      'es': 'Voluntario',
      'fr': 'Bénévole',
    },
    'n1bomw72': {
      'en': 'Select one',
      'es': 'Seleccione uno',
      'fr': 'Sélectionnez-en un',
    },
    '5ibtzksr': {
      'en': 'Description',
      'es': 'Descripción',
      'fr': 'La description',
    },
    '67kv38t1': {
      'en': 'Enter description',
      'es': 'Introduce la descripción',
      'fr': 'Entrez la description',
    },
    'p9aeb523': {
      'en': 'Email',
      'es': 'Correo electrónico',
      'fr': 'E-mail',
    },
    '6kkhwxa5': {
      'en': '[Some hint text...]',
      'es': '[Algún texto de pista...]',
      'fr': '[Quelque texte d\'indice...]',
    },
    '18lirz9s': {
      'en': 'Back to registration',
      'es': 'volver al registro',
      'fr': 'Retour à l\'inscription',
    },
    'uqhji44k': {
      'en': 'Submit',
      'es': 'Enviar',
      'fr': 'Soumettre',
    },
    'glqssazf': {
      'en': 'Home',
      'es': 'Hogar',
      'fr': 'Maison',
    },
  },
  // AddUser_BusinessPartner
  {
    '922k9sqm': {
      'en': 'Add User',
      'es': 'Agregar usuario',
      'fr': 'Ajouter un utilisateur',
    },
    'wq0lu7k5': {
      'en': 'Edit User',
      'es': 'editar usuario',
      'fr': 'Modifier l\'utilisateur',
    },
    'ktsgar7e': {
      'en': 'Enter first name',
      'es': 'Ingrese el nombre',
      'fr': 'entrez votre prénom',
    },
    'bccryb3c': {
      'en': 'Enter last name',
      'es': 'Introduzca el apellido',
      'fr': 'Entrer le nom de famille',
    },
    'x8rhslqb': {
      'en': 'Enter email address',
      'es': 'Introduzca la dirección de correo electrónico',
      'fr': 'Entrer l\'adresse e-mail',
    },
    'd9zrl8yc': {
      'en': 'First name is required',
      'es': 'Se requiere el primer nombre',
      'fr': 'Le prénom est requis',
    },
    'sct0w1te': {
      'en': 'Enter valid first name',
      'es': 'Introduce un nombre válido',
      'fr': 'Saisissez un prénom valide',
    },
    'q74ne2q0': {
      'en': 'Last name is required',
      'es': 'Se requiere apellido',
      'fr': 'Le nom de famille est requis',
    },
    '0sbf939o': {
      'en': 'Enter valid last name',
      'es': 'Introduce un apellido válido',
      'fr': 'Entrez un nom de famille valide',
    },
    'zcd1qmdn': {
      'en': 'Email address is required',
      'es': 'Se requiere Dirección de correo electrónico',
      'fr': 'Adresse e-mail est nécessaire',
    },
    'isjq0yxv': {
      'en': 'Enter valid email address',
      'es': 'Introduzca una dirección de correo electrónico válida',
      'fr': 'Saisissez une adresse e-mail valide',
    },
    '1w7p82a0': {
      'en': 'Back',
      'es': 'atrás',
      'fr': 'Retour',
    },
    'aa9rzxmv': {
      'en': 'Save',
      'es': 'Ahorrar',
      'fr': 'sauvegarder',
    },
    'zc9f38f8': {
      'en': 'Register',
      'es': 'Registro',
      'fr': 'S\'inscrire',
    },
  },
  // businesspartnerquiz
  {
    'kjj6auxc': {
      'en': 'Training Certification Test',
      'es': '',
      'fr': '',
    },
    'ww93ij1y': {
      'en':
          'In this module you will be required to complete a 5 quession assessment.you must get all questions correct to finalize\nyour certification.Once you submit your answers, you will be given your overall score as well as any questions you \nmay have gotten incorrect.You\'llable to repeat the assessment as needed until the correct answers are submitted.',
      'es': '',
      'fr': '',
    },
    'u8vpru5u': {
      'en': 'Your score is',
      'es': '',
      'fr': '',
    },
    'cf33blvs': {
      'en': '/5 and wrong answers are',
      'es': '',
      'fr': '',
    },
    'sqftj923': {
      'en': 'Back',
      'es': 'atrás',
      'fr': 'Retour',
    },
    'fd3e4rq7': {
      'en': 'Submit',
      'es': 'Ahorrar',
      'fr': 'sauvegarder',
    },
    'vbgy9fur': {
      'en': 'Home',
      'es': '',
      'fr': '',
    },
  },
  // Listinguser_BusinessPartner
  {
    '6juhiyti': {
      'en': 'Add user',
      'es': '',
      'fr': '',
    },
    '8nswbpqa': {
      'en': 'Current User',
      'es': 'Usuario actual',
      'fr': 'Utilisateur actuel',
    },
    '9udvfmdp': {
      'en': 'Search...',
      'es': '',
      'fr': '',
    },
    'z9um9a3d': {
      'en': '',
      'es': '',
      'fr': '',
    },
    'qqtpzkxh': {
      'en': 'First Name',
      'es': 'Primer nombre',
      'fr': 'Prénom',
    },
    'fsq8ftdx': {
      'en': 'Last Name',
      'es': 'Apellido',
      'fr': 'Nom de famille',
    },
    '8so4iero': {
      'en': 'Email',
      'es': 'Correo electrónico',
      'fr': 'E-mail',
    },
    'rbg3fiab': {
      'en': 'Status',
      'es': 'Estado',
      'fr': 'Statut',
    },
    'loapsr7e': {
      'en': 'Action',
      'es': 'Acción',
      'fr': 'Action',
    },
    'sypjhqxz': {
      'en': 'Edit',
      'es': 'Editar',
      'fr': 'Éditer',
    },
    'yh9refjk': {
      'en': 'Delete',
      'es': 'Borrar',
      'fr': 'Effacer',
    },
    '4cr1kl3q': {
      'en': 'No user found',
      'es': 'Ningún usuario agregado',
      'fr': 'Aucun utilisateur ajouté',
    },
    '0ss06vo9': {
      'en': 'Edit',
      'es': 'Editar',
      'fr': 'Éditer',
    },
    'x2ffwabn': {
      'en': 'Delete',
      'es': 'Borrar',
      'fr': 'Effacer',
    },
    'a6hyksey': {
      'en': 'Back',
      'es': 'atrás',
      'fr': 'Retour',
    },
    'yngnoudg': {
      'en': 'Register',
      'es': 'Registro',
      'fr': 'S\'inscrire',
    },
  },
  // Quiz_score_bp
  {
    '9fyrt7tq': {
      'en': 'Scorecard',
      'es': 'Usuario actual',
      'fr': 'Utilisateur actuel',
    },
    'j8rjyxrr': {
      'en': 'Search...',
      'es': '',
      'fr': '',
    },
    'opbj3v8u': {
      'en': '',
      'es': '',
      'fr': '',
    },
    'sf79nm08': {
      'en': 'First Name',
      'es': 'Primer nombre',
      'fr': 'Prénom',
    },
    'uhnye5jx': {
      'en': 'Last Name',
      'es': 'Apellido',
      'fr': 'Nom de famille',
    },
    'z4g9w6sx': {
      'en': 'Email',
      'es': 'Correo electrónico',
      'fr': 'E-mail',
    },
    'svv5ctm5': {
      'en': 'Score',
      'es': 'Estado',
      'fr': 'Statut',
    },
    '87uopwhe': {
      'en': 'Quiz submitted Date',
      'es': 'Acción',
      'fr': 'Action',
    },
    '1veg0m11': {
      'en': 'Action',
      'es': 'Acción',
      'fr': 'Action',
    },
    '5l0b7nvz': {
      'en': 'View',
      'es': '',
      'fr': '',
    },
    'tgtp5sl8': {
      'en': 'View',
      'es': '',
      'fr': '',
    },
    'fd6jxzcn': {
      'en': 'No data found',
      'es': 'Ningún usuario agregado',
      'fr': 'Aucun utilisateur ajouté',
    },
    '94qufgrq': {
      'en': 'Back',
      'es': 'atrás',
      'fr': 'Retour',
    },
    'z1y4r7aw': {
      'en': 'Register',
      'es': 'Registro',
      'fr': 'S\'inscrire',
    },
  },
  // Assign_quiz_to_user
  {
    '5pr9h5zd': {
      'en': 'Current User',
      'es': 'Usuario actual',
      'fr': 'Utilisateur actuel',
    },
    '1ymxi5a3': {
      'en': 'Search...',
      'es': '',
      'fr': '',
    },
    '3pwg1fta': {
      'en': '',
      'es': '',
      'fr': '',
    },
    'ps9n67js': {
      'en': 'First Name',
      'es': 'Primer nombre',
      'fr': 'Prénom',
    },
    'ic1gcm4q': {
      'en': 'Last Name',
      'es': 'Apellido',
      'fr': 'Nom de famille',
    },
    'x3f7opty': {
      'en': 'Email',
      'es': 'Correo electrónico',
      'fr': 'E-mail',
    },
    '9bs1pc05': {
      'en': 'Action',
      'es': 'Acción',
      'fr': 'Action',
    },
    '2se4uuna': {
      'en': 'Assign quiz',
      'es': 'Editar',
      'fr': 'Éditer',
    },
    'ezdo4a1p': {
      'en': 'No user found',
      'es': 'Ningún usuario agregado',
      'fr': 'Aucun utilisateur ajouté',
    },
    'oi9rlmta': {
      'en': 'Assign quiz',
      'es': 'Editar',
      'fr': 'Éditer',
    },
    'bexdbkvr': {
      'en': 'Back',
      'es': 'atrás',
      'fr': 'Retour',
    },
    'a9qi0n40': {
      'en': 'Register',
      'es': 'Registro',
      'fr': 'S\'inscrire',
    },
  },
  // Bp_quiz_view
  {
    '0ht69iy0': {
      'en': 'Training Certification Test',
      'es': '',
      'fr': '',
    },
    'l3h4zhch': {
      'en':
          'In this module you will be required to complete a 5 quession assessment.you must get all questions correct to finalize your certification.Once you submit your answers, you will be given your overall score as well as any questions you may have gotten incorrect.You\'llable to repeat the assessment as needed until the correct answers are submitted.',
      'es': '',
      'fr': '',
    },
    '2ykxklcp': {
      'en': 'Back',
      'es': 'atrás',
      'fr': 'Retour',
    },
    'g78qv6b1': {
      'en': 'Home',
      'es': '',
      'fr': '',
    },
  },
  // Assignquiz
  {
    '4cq1selj': {
      'en': 'Assign quiz',
      'es': 'Registro de socios comerciales',
      'fr': 'Inscription des partenaires commerciaux',
    },
    'uhhnnyz1': {
      'en': 'No event available to select',
      'es': '',
      'fr': '',
    },
    'c035jfzv': {
      'en': 'Please enter quiz start time',
      'es': '',
      'fr': '',
    },
    'ukr6myzb': {
      'en': 'Start time',
      'es': '',
      'fr': '',
    },
    'mhdan6b9': {
      'en': 'Date',
      'es': '',
      'fr': '',
    },
    '4kl8s2ao': {
      'en': 'Month',
      'es': '',
      'fr': '',
    },
    'ktmnf11v': {
      'en': '2022',
      'es': '',
      'fr': '',
    },
    'of8rfhyh': {
      'en': '2023',
      'es': '',
      'fr': '',
    },
    '35spukjp': {
      'en': 'Year',
      'es': '',
      'fr': '',
    },
    'av5qzc76': {
      'en': 'Time',
      'es': '',
      'fr': '',
    },
    'trzgo0m6': {
      'en': 'AM',
      'es': '',
      'fr': '',
    },
    'q5n6dk44': {
      'en': 'PM',
      'es': '',
      'fr': '',
    },
    '74n6u8o5': {
      'en': 'AM',
      'es': '',
      'fr': '',
    },
    '2extol6a': {
      'en': 'End time',
      'es': '',
      'fr': '',
    },
    '6zhdxkba': {
      'en': 'Date',
      'es': '',
      'fr': '',
    },
    '4amwic5m': {
      'en': 'Month',
      'es': '',
      'fr': '',
    },
    '3lv42ktg': {
      'en': '2022',
      'es': '',
      'fr': '',
    },
    '4up46c58': {
      'en': '2023',
      'es': '',
      'fr': '',
    },
    'h071jnmo': {
      'en': 'Year',
      'es': '',
      'fr': '',
    },
    'ehtylon8': {
      'en': 'Time',
      'es': '',
      'fr': '',
    },
    'xghmnso1': {
      'en': 'AM',
      'es': '',
      'fr': '',
    },
    'ejkm18xq': {
      'en': 'PM',
      'es': '',
      'fr': '',
    },
    'bqzs2eux': {
      'en': 'AM',
      'es': '',
      'fr': '',
    },
    't2uo3t67': {
      'en': 'Back',
      'es': 'atrás',
      'fr': 'Retour',
    },
    '9hjueo7c': {
      'en': 'Submit',
      'es': 'próximo',
      'fr': 'Prochain',
    },
    '6j957fe0': {
      'en': 'Home',
      'es': 'Hogar',
      'fr': 'Maison',
    },
  },
  // select_quiz
  {
    'cl9syej2': {
      'en': 'Select Quiz',
      'es': '',
      'fr': '',
    },
    '8e73yb6y': {
      'en': 'Option 1',
      'es': '',
      'fr': '',
    },
    'mw4muwwa': {
      'en': 'Please select...',
      'es': '',
      'fr': '',
    },
    'vwtb0sfz': {
      'en': 'Back',
      'es': '',
      'fr': '',
    },
    '6nk48y5t': {
      'en': 'Next',
      'es': '',
      'fr': '',
    },
    'n3iwy8n3': {
      'en': 'Register',
      'es': 'Registro',
      'fr': 'S\'inscrire',
    },
  },
  // otpPhone
  {
    'fccfokdv': {
      'en': 'Enter mobile number',
      'es': '',
      'fr': '',
    },
    'v9dtgflh': {
      'en':
          'Please enter mobile number because a One Time Password(OTP) has been sent to this number.',
      'es': '',
      'fr': '',
    },
    '5nedzvfl': {
      'en': ' Enter mobile number',
      'es': '',
      'fr': '',
    },
    'gi3oi6sd': {
      'en': 'Get OTP',
      'es': '',
      'fr': '',
    },
    '04kri96t': {
      'en':
          'By continuing, you have to veryfy the OTP with your mobile number, Conditions of Use and Privacy Notice.',
      'es': '',
      'fr': '',
    },
    'pvq4t80w': {
      'en': 'Need help',
      'es': '',
      'fr': '',
    },
    '3xkvnhz4': {
      'en': 'Home',
      'es': '',
      'fr': '',
    },
  },
  // verifyotp
  {
    '4xi8owvo': {
      'en': 'Verify mobile number',
      'es': '',
      'fr': '',
    },
    'accrlkus': {
      'en': 'A text with a One Time Password(OTP) has been sent to your number',
      'es': '',
      'fr': '',
    },
    '1xzwphfi': {
      'en': 'Enter OTP',
      'es': '',
      'fr': '',
    },
    'lfq7338i': {
      'en': 'Submit',
      'es': '',
      'fr': '',
    },
    'wu4wdrfk': {
      'en':
          'By continuing, you agree to Amazon\'s Conditions of Use and Privacy Notice.',
      'es': '',
      'fr': '',
    },
    'vh9mhner': {
      'en': 'Need help',
      'es': '',
      'fr': '',
    },
    'j2qy1uic': {
      'en': 'Home',
      'es': '',
      'fr': '',
    },
  },
  // User_Login_withotp
  {
    'u3uibo1s': {
      'en': 'Welcome to Play On!',
      'es': '¡Bienvenido a Jugar!',
      'fr': 'Bienvenue sur Jouez !',
    },
    'r33793tq': {
      'en':
          'Experience the world\'s largest Street Tournament and Sports Festival',
      'es':
          'Experimente el torneo callejero y festival deportivo más grande del mundo',
      'fr':
          'Découvrez le plus grand tournoi de rue et festival sportif au monde',
    },
    'z1qdexdx': {
      'en': 'Login',
      'es': 'Acceso',
      'fr': 'Connexion',
    },
    '8aks0ai2': {
      'en': 'Login Email Id',
      'es': 'ID de correo electrónico de inicio de sesión',
      'fr': 'Identifiant de connexion',
    },
    'ks2yjifw': {
      'en': 'Your email id',
      'es': 'su identificación de correo electrónico',
      'fr': 'Votre identifiant de messagerie',
    },
    'tz27g8k2': {
      'en': 'Password',
      'es': 'Clave',
      'fr': 'Mot de passe',
    },
    '7hezbvyx': {
      'en': 'Password',
      'es': 'Clave',
      'fr': 'Mot de passe',
    },
    'j9vf6onj': {
      'en': 'Login',
      'es': 'Acceso',
      'fr': 'Connexion',
    },
    'ny2wbfmk': {
      'en': 'Login to your existing Play On! account',
      'es': '¡Inicie sesión en su Play On! cuenta',
      'fr': 'Connectez-vous à votre compte Play On ! Compte',
    },
    's9nc46ve': {
      'en': 'Forgot Password',
      'es': 'Has olvidado tu contraseña',
      'fr': 'Mot de passe oublié',
    },
    'chprwte5': {
      'en': 'Test Login',
      'es': 'Inicio de sesión de prueba',
      'fr': 'Connexion d\'essai',
    },
    'qi20bz0p': {
      'en': 'Mandatory Field',
      'es': 'Campo obligatorio',
      'fr': 'Champ obligatoire',
    },
    'q0sx5hta': {
      'en': 'Field is required',
      'es': 'Se requiere campo',
      'fr': 'Champ requis',
    },
    'maujwku1': {
      'en': 'Field is required',
      'es': 'Se requiere campo',
      'fr': 'Champ requis',
    },
    're4joeah': {
      'en': 'Field is required',
      'es': 'Se requiere campo',
      'fr': 'Champ requis',
    },
    'x1gmllfb': {
      'en': 'Register',
      'es': 'Registro',
      'fr': 'S\'inscrire',
    },
    'e1pxq37z': {
      'en': 'Email',
      'es': 'Correo electrónico',
      'fr': 'E-mail',
    },
    'erszverp': {
      'en': 'Your email id',
      'es': 'su identificación de correo electrónico',
      'fr': 'Votre identifiant de messagerie',
    },
    'ylz5kj1f': {
      'en': 'Password',
      'es': 'Clave',
      'fr': 'Mot de passe',
    },
    'jv1rs4ak': {
      'en': 'Password',
      'es': 'Clave',
      'fr': 'Mot de passe',
    },
    'h2ksjwzd': {
      'en': 'Confirm Password',
      'es': 'Confirmar contraseña',
      'fr': 'Confirmez le mot de passe',
    },
    'knr5q2ny': {
      'en': 'Confirm Password',
      'es': 'Confirmar contraseña',
      'fr': 'Confirmez le mot de passe',
    },
    's8gl1013': {
      'en': 'Register',
      'es': 'Registro',
      'fr': 'S\'inscrire',
    },
    'q73877ka': {
      'en': 'Register for a new Play On! account',
      'es': 'Regístrese para un nuevo Play On! cuenta',
      'fr': 'Inscrivez-vous pour un nouveau Play On! Compte',
    },
    'nwmvillw': {
      'en': 'Enter a valid Email address',
      'es': 'Introduzca una dirección de correo electrónico válida',
      'fr': 'Entrez une adresse mail valide',
    },
    'n6q2bhjz': {
      'en':
          'Minimum: 8 characters, 1 Upper case, 1 number or special character',
      'es': 'Mínimo: 8 caracteres, 1 mayúscula, 1 número o carácter especial',
      'fr':
          'Minimum : 8 caractères, 1 majuscule, 1 chiffre ou caractère spécial',
    },
    'icg82z0y': {
      'en': 'Confirm Pasword',
      'es': 'Confirmar contraseña',
      'fr': 'Confirmer pasword',
    },
    'wds3gnyq': {
      'en': 'You can register for different roles, click on them to learn more',
      'es':
          'Puede registrarse para diferentes roles, haga clic en ellos para obtener más información.',
      'fr':
          'Vous pouvez vous inscrire à différents rôles, cliquez dessus pour en savoir plus',
    },
    '1xyda83f': {
      'en': 'Fan',
      'es': 'Admirador',
      'fr': 'Ventilateur',
    },
    'lu9diz45': {
      'en': 'Player\n',
      'es': 'Jugador',
      'fr': 'Joueur',
    },
    'anjtec2i': {
      'en': 'Volunteer',
      'es': 'Voluntario',
      'fr': 'Bénévole',
    },
    'ikg5mztc': {
      'en': 'Referee',
      'es': 'Árbitro',
      'fr': 'Arbitre',
    },
    'd1s6pgdp': {
      'en': 'Charity',
      'es': 'Caridad',
      'fr': 'Charité',
    },
    'jpwpi9xk': {
      'en': 'Host Muncipality',
      'es': 'Municipio anfitrión',
      'fr': 'Municipalité hôte',
    },
    'alqgzosr': {
      'en': 'Business Partner',
      'es': 'Socio de negocios',
      'fr': 'Associé',
    },
    '81vksmd7': {
      'en': 'Vendor',
      'es': 'Vendedor',
      'fr': 'Vendeur',
    },
    'r12gonid': {
      'en': 'Home',
      'es': 'Hogar',
      'fr': 'Maison',
    },
  },
  // poDropDown
  {
    'glbdm85c': {
      'en': 'en_US',
      'es': 'es_ES',
      'fr': 'fr_US',
    },
    '90t358vw': {
      'en': 'en_US',
      'es': 'es_ES',
      'fr': 'fr_US',
    },
    '33wt3yp3': {
      'en': 'fr_FR',
      'es': 'fr_FR',
      'fr': 'F RFR',
    },
    '0neefrd5': {
      'en': 'es_ES',
      'es': 'es_ES',
      'fr': 'es_ES',
    },
  },
  // AppHeader
  {
    '8w3jm262': {
      'en': 'Beta',
      'es': 'Beta',
      'fr': 'Bêta',
    },
  },
  // AppNavBar
  {
    'v4aql383': {
      'en': 'Home',
      'es': '',
      'fr': '',
    },
    'fywleba7': {
      'en': 'Hello World',
      'es': '',
      'fr': '',
    },
    '9af4hdfv': {
      'en': 'Coupons',
      'es': '',
      'fr': '',
    },
    'r8kis22h': {
      'en': 'My Events',
      'es': '',
      'fr': '',
    },
    '1mheu51t': {
      'en': 'Settings',
      'es': '',
      'fr': '',
    },
  },
  // Menu
  {
    'f9hl663z': {
      'en': 'Menu',
      'es': 'Menú',
      'fr': 'Menu',
    },
    '2mlghl1p': {
      'en': 'Go to Playon.ca',
      'es': 'Ir a Playon.ca',
      'fr': 'Aller à Playon.ca',
    },
    'gqnyduwd': {
      'en': '',
      'es': '',
      'fr': '',
    },
    'fqkm7a6b': {
      'en': 'Go to Dashboard',
      'es': 'Ir al panel de control',
      'fr': 'Aller au tableau de bord',
    },
    'jrykgf3f': {
      'en': '',
      'es': '',
      'fr': '',
    },
    'bpk5f619': {
      'en': 'Privacy Policy',
      'es': 'Política de privacidad',
      'fr': 'Politique de confidentialité',
    },
    'we15kds8': {
      'en': '',
      'es': '',
      'fr': '',
    },
    'nh171fmk': {
      'en': 'Version: B_V1.0',
      'es': 'Versión: B_V1.0',
      'fr': 'Version : B_V1.0',
    },
  },
].reduce((a, b) => a..addAll(b));
