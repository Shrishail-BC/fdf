import '../flutter_flow/flutter_flow_theme.dart';
import '../flutter_flow/flutter_flow_util.dart';
import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:google_fonts/google_fonts.dart';

class ActiveArrowWidget extends StatefulWidget {
  const ActiveArrowWidget({Key? key}) : super(key: key);

  @override
  _ActiveArrowWidgetState createState() => _ActiveArrowWidgetState();
}

class _ActiveArrowWidgetState extends State<ActiveArrowWidget> {
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsetsDirectional.fromSTEB(0, 8, 0, 0),
      child: Icon(
        Icons.arrow_right_alt,
        color: Color(0xFFFF0E07),
        size: 24,
      ),
    );
  }
}
