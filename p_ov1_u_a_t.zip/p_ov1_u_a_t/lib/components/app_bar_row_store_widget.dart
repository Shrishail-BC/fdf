import '../flutter_flow/flutter_flow_theme.dart';
import '../flutter_flow/flutter_flow_util.dart';
import '../custom_code/widgets/index.dart' as custom_widgets;
import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:google_fonts/google_fonts.dart';

class AppBarRowStoreWidget extends StatefulWidget {
  const AppBarRowStoreWidget({
    Key? key,
    this.iconButton,
    this.buttonText,
    this.buttonTextColor,
    this.buttonTextSize,
    this.buttonColor,
    this.buttonURL,
  }) : super(key: key);

  final Widget? iconButton;
  final String? buttonText;
  final Color? buttonTextColor;
  final double? buttonTextSize;
  final Color? buttonColor;
  final String? buttonURL;

  @override
  _AppBarRowStoreWidgetState createState() => _AppBarRowStoreWidgetState();
}

class _AppBarRowStoreWidgetState extends State<AppBarRowStoreWidget> {
  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.max,
      mainAxisAlignment: MainAxisAlignment.center,
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        Padding(
          padding: EdgeInsetsDirectional.fromSTEB(5, 5, 0, 5),
          child: custom_widgets.OrientationBasedButton(
            width: 90,
            height: 48,
            buttonText: widget.buttonText!,
            icon: widget.iconButton!,
            textSize: widget.buttonTextSize!,
            url: widget.buttonURL!,
            buttonColor: widget.buttonColor!,
            buttonTextColor: widget.buttonTextColor!,
          ),
        ),
      ],
    );
  }
}
