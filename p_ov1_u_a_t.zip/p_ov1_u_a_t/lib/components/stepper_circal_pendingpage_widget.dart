import '../flutter_flow/flutter_flow_theme.dart';
import '../flutter_flow/flutter_flow_util.dart';
import 'package:auto_size_text/auto_size_text.dart';
import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:google_fonts/google_fonts.dart';

class StepperCircalPendingpageWidget extends StatefulWidget {
  const StepperCircalPendingpageWidget({
    Key? key,
    this.stepName,
    this.stepNumber,
  }) : super(key: key);

  final String? stepName;
  final int? stepNumber;

  @override
  _StepperCircalPendingpageWidgetState createState() =>
      _StepperCircalPendingpageWidgetState();
}

class _StepperCircalPendingpageWidgetState
    extends State<StepperCircalPendingpageWidget> {
  @override
  Widget build(BuildContext context) {
    return Container(
      width: 81,
      decoration: BoxDecoration(),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Material(
            color: Colors.transparent,
            elevation: 12,
            shape: const CircleBorder(),
            child: Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                border: Border.all(
                  color: Color(0xFF696969),
                  width: 3,
                ),
              ),
              child: Align(
                alignment: AlignmentDirectional(0, 0),
                child: Text(
                  widget.stepNumber!.toString(),
                  textAlign: TextAlign.center,
                  style: FlutterFlowTheme.of(context).bodyText1.override(
                        fontFamily: 'Poppins',
                        color: Color(0xFF696969),
                        fontSize: 18,
                      ),
                ),
              ),
            ),
          ),
          Container(
            decoration: BoxDecoration(
              color: Colors.transparent,
            ),
            child: Padding(
              padding: EdgeInsetsDirectional.fromSTEB(0, 5, 0, 0),
              child: AutoSizeText(
                widget.stepName!,
                textAlign: TextAlign.center,
                style: FlutterFlowTheme.of(context).bodyText1.override(
                      fontFamily: 'Poppins',
                      color: Colors.white,
                      fontSize: 10,
                    ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
