import '../flutter_flow/flutter_flow_theme.dart';
import '../flutter_flow/flutter_flow_util.dart';
import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:google_fonts/google_fonts.dart';

class UnactiveArrowWidget extends StatefulWidget {
  const UnactiveArrowWidget({Key? key}) : super(key: key);

  @override
  _UnactiveArrowWidgetState createState() => _UnactiveArrowWidgetState();
}

class _UnactiveArrowWidgetState extends State<UnactiveArrowWidget> {
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsetsDirectional.fromSTEB(0, 8, 0, 0),
      child: Icon(
        Icons.arrow_right_alt,
        color: Color(0xFF696969),
        size: 24,
      ),
    );
  }
}
