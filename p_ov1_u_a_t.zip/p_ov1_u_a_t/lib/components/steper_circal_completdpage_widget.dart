import '../flutter_flow/flutter_flow_theme.dart';
import '../flutter_flow/flutter_flow_util.dart';
import 'package:auto_size_text/auto_size_text.dart';
import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:google_fonts/google_fonts.dart';

class SteperCircalCompletdpageWidget extends StatefulWidget {
  const SteperCircalCompletdpageWidget({
    Key? key,
    this.stepName,
  }) : super(key: key);

  final String? stepName;

  @override
  _SteperCircalCompletdpageWidgetState createState() =>
      _SteperCircalCompletdpageWidgetState();
}

class _SteperCircalCompletdpageWidgetState
    extends State<SteperCircalCompletdpageWidget> {
  @override
  Widget build(BuildContext context) {
    return Container(
      width: 81,
      decoration: BoxDecoration(),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              color: Color(0xFFFF0E07),
              shape: BoxShape.circle,
            ),
            alignment: AlignmentDirectional(0, 0),
            child: Icon(
              Icons.check,
              color: FlutterFlowTheme.of(context).tertiaryColor,
              size: 20,
            ),
          ),
          Container(
            decoration: BoxDecoration(
              color: Colors.transparent,
            ),
            child: Padding(
              padding: EdgeInsetsDirectional.fromSTEB(0, 5, 0, 0),
              child: AutoSizeText(
                widget.stepName!,
                textAlign: TextAlign.center,
                style: FlutterFlowTheme.of(context).bodyText1.override(
                      fontFamily: 'Poppins',
                      color: Colors.white,
                      fontSize: 10,
                    ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
