import '../flutter_flow/flutter_flow_drop_down.dart';
import '../flutter_flow/flutter_flow_theme.dart';
import '../flutter_flow/flutter_flow_util.dart';
import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:google_fonts/google_fonts.dart';

class PoDropDownWidget extends StatefulWidget {
  const PoDropDownWidget({Key? key}) : super(key: key);

  @override
  _PoDropDownWidgetState createState() => _PoDropDownWidgetState();
}

class _PoDropDownWidgetState extends State<PoDropDownWidget> {
  String? dropDownValue;

  @override
  Widget build(BuildContext context) {
    return FlutterFlowDropDown(
      initialOption: dropDownValue ??= FFLocalizations.of(context).getText(
        'glbdm85c' /* en_US */,
      ),
      options: [
        FFLocalizations.of(context).getText(
          '90t358vw' /* en_US */,
        ),
        FFLocalizations.of(context).getText(
          '33wt3yp3' /* fr_FR */,
        ),
        FFLocalizations.of(context).getText(
          '0neefrd5' /* es_ES */,
        )
      ],
      onChanged: (val) => setState(() => dropDownValue = val),
      width: 180,
      height: 50,
      textStyle: FlutterFlowTheme.of(context).bodyText1.override(
            fontFamily: 'Poppins',
            color: Colors.black,
          ),
      fillColor: FlutterFlowTheme.of(context).tertiaryColor,
      elevation: 2,
      borderColor: Colors.transparent,
      borderWidth: 0,
      borderRadius: 0,
      margin: EdgeInsetsDirectional.fromSTEB(12, 4, 12, 4),
      hidesUnderline: true,
    );
  }
}
