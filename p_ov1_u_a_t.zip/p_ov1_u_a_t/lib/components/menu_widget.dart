import '../flutter_flow/flutter_flow_theme.dart';
import '../flutter_flow/flutter_flow_util.dart';
import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:google_fonts/google_fonts.dart';

class MenuWidget extends StatefulWidget {
  const MenuWidget({Key? key}) : super(key: key);

  @override
  _MenuWidgetState createState() => _MenuWidgetState();
}

class _MenuWidgetState extends State<MenuWidget> {
  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Column(
        mainAxisSize: MainAxisSize.max,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 250,
            height: MediaQuery.of(context).size.height * 1,
            constraints: BoxConstraints(
              maxWidth: MediaQuery.of(context).size.width,
              maxHeight: MediaQuery.of(context).size.height * 1,
            ),
            decoration: BoxDecoration(
              color: Color(0xFFD6D6D6),
              shape: BoxShape.rectangle,
              border: Border.all(
                color: Color(0xFF706C6C),
              ),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.max,
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Container(
                  width: 250,
                  height: 80,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).customColor1,
                  ),
                  child: Align(
                    alignment: AlignmentDirectional(0, 0),
                    child: Padding(
                      padding: EdgeInsetsDirectional.fromSTEB(0, 5, 0, 0),
                      child: Text(
                        FFLocalizations.of(context).getText(
                          'f9hl663z' /* Menu */,
                        ),
                        textAlign: TextAlign.center,
                        style: FlutterFlowTheme.of(context).title2.override(
                              fontFamily: 'Poppins',
                              color: FlutterFlowTheme.of(context).tertiaryColor,
                              fontWeight: FontWeight.w600,
                            ),
                      ),
                    ),
                  ),
                ),
                Material(
                  color: Colors.transparent,
                  elevation: 2,
                  child: Container(
                    width: 250,
                    decoration: BoxDecoration(
                      border: Border.all(
                        color: Color(0xFF706C6C),
                      ),
                    ),
                    child: Column(
                      mainAxisSize: MainAxisSize.max,
                      children: [
                        Container(
                          width: 250,
                          decoration: BoxDecoration(
                            color: FlutterFlowTheme.of(context).tertiaryColor,
                            border: Border.all(
                              color: Color(0xFF706C6C),
                            ),
                          ),
                          child: InkWell(
                            onTap: () async {
                              await launchURL('https://playon.ca');
                            },
                            child: ListTile(
                              leading: FaIcon(
                                FontAwesomeIcons.globeAfrica,
                                color: FlutterFlowTheme.of(context).black,
                                size: 22,
                              ),
                              title: Text(
                                FFLocalizations.of(context).getText(
                                  '2mlghl1p' /* Go to Playon.ca */,
                                ),
                                textAlign: TextAlign.start,
                                style: FlutterFlowTheme.of(context)
                                    .title3
                                    .override(
                                      fontFamily: 'Poppins',
                                      color: Colors.black,
                                      fontSize: 14,
                                    ),
                              ),
                              dense: false,
                            ),
                          ),
                        ),
                        Container(
                          width: 250,
                          decoration: BoxDecoration(
                            color: FlutterFlowTheme.of(context).tertiaryColor,
                            border: Border.all(
                              color: Color(0xFF706C6C),
                            ),
                          ),
                          child: ListTile(
                            leading: Icon(
                              Icons.dashboard_outlined,
                              color: FlutterFlowTheme.of(context).black,
                              size: 22,
                            ),
                            title: Text(
                              FFLocalizations.of(context).getText(
                                'fqkm7a6b' /* Go to Dashboard */,
                              ),
                              textAlign: TextAlign.start,
                              style:
                                  FlutterFlowTheme.of(context).title3.override(
                                        fontFamily: 'Poppins',
                                        color: Colors.black,
                                        fontSize: 14,
                                      ),
                            ),
                            dense: false,
                          ),
                        ),
                        Container(
                          width: 250,
                          decoration: BoxDecoration(
                            color: FlutterFlowTheme.of(context).tertiaryColor,
                            border: Border.all(
                              color: Color(0xFF706C6C),
                            ),
                          ),
                          child: InkWell(
                            onTap: () async {
                              await launchURL(
                                  'https://www.playon.ca/privacy-policy');
                            },
                            child: ListTile(
                              leading: Icon(
                                Icons.privacy_tip_outlined,
                                color: FlutterFlowTheme.of(context).black,
                                size: 22,
                              ),
                              title: Text(
                                FFLocalizations.of(context).getText(
                                  'bpk5f619' /* Privacy Policy */,
                                ),
                                textAlign: TextAlign.start,
                                style: FlutterFlowTheme.of(context)
                                    .title3
                                    .override(
                                      fontFamily: 'Poppins',
                                      color: Colors.black,
                                      fontSize: 14,
                                    ),
                              ),
                              dense: false,
                            ),
                          ),
                        ),
                        Container(
                          width: 250,
                          decoration: BoxDecoration(
                            color: FlutterFlowTheme.of(context).tertiaryColor,
                            border: Border.all(
                              color: Color(0xFF706C6C),
                            ),
                          ),
                          child: Text(
                            FFLocalizations.of(context).getText(
                              'nh171fmk' /* Version: B_V1.0 */,
                            ),
                            textAlign: TextAlign.center,
                            style:
                                FlutterFlowTheme.of(context).bodyText1.override(
                                      fontFamily: 'Poppins',
                                      color: FlutterFlowTheme.of(context).black,
                                    ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
