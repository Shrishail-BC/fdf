import '../assignquiz/assignquiz_widget.dart';
import '../backend/api_requests/api_calls.dart';
import '../components/app_header_widget.dart';
import '../components/menu_widget.dart';
import '../dashboard_business_partner/dashboard_business_partner_widget.dart';
import '../flutter_flow/flutter_flow_theme.dart';
import '../flutter_flow/flutter_flow_util.dart';
import '../flutter_flow/flutter_flow_widgets.dart';
import '../flutter_flow/custom_functions.dart' as functions;
import 'package:easy_debounce/easy_debounce.dart';
import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:google_fonts/google_fonts.dart';

class AssignQuizToUserWidget extends StatefulWidget {
  const AssignQuizToUserWidget({Key? key}) : super(key: key);

  @override
  _AssignQuizToUserWidgetState createState() => _AssignQuizToUserWidgetState();
}

class _AssignQuizToUserWidgetState extends State<AssignQuizToUserWidget> {
  ApiCallResponse? apiResulting12;
  ApiCallResponse? apiResulting;
  TextEditingController? textController;
  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    textController = TextEditingController();
  }

  @override
  void dispose() {
    textController?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: scaffoldKey,
      backgroundColor: Color(0xFF274078),
      drawer: Container(
        width: 250,
        child: Drawer(
          elevation: 16,
          child: MenuWidget(),
        ),
      ),
      body: SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.max,
          children: [
            AppHeaderWidget(),
            Align(
              alignment: AlignmentDirectional(0, 0),
              child: Container(
                width: MediaQuery.of(context).size.width * 0.95,
                height: MediaQuery.of(context).size.height * 0.8,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(0),
                ),
                child: FutureBuilder<ApiCallResponse>(
                  future: GetDataSCall.call(
                    refreshToken: FFAppState().sessionRefreshToken,
                    formstep: '15',
                    type: textController!.text,
                  ),
                  builder: (context, snapshot) {
                    // Customize what your widget looks like when it's loading.
                    if (!snapshot.hasData) {
                      return Center(
                        child: SizedBox(
                          width: 50,
                          height: 50,
                          child: SpinKitHourGlass(
                            color: Color(0xFFFFC107),
                            size: 50,
                          ),
                        ),
                      );
                    }
                    final columnMainButtonGetDataSResponse = snapshot.data!;
                    return Column(
                      mainAxisSize: MainAxisSize.max,
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Padding(
                          padding:
                              EdgeInsetsDirectional.fromSTEB(10, 10, 10, 10),
                          child: Text(
                            FFLocalizations.of(context).getText(
                              '5pr9h5zd' /* Current User */,
                            ),
                            style:
                                FlutterFlowTheme.of(context).bodyText1.override(
                                      fontFamily: 'Poppins',
                                      fontSize: 20,
                                    ),
                          ),
                        ),
                        Align(
                          alignment: AlignmentDirectional(-0.4, 0),
                          child: Container(
                            width: 350,
                            decoration: BoxDecoration(
                              color: FlutterFlowTheme.of(context).tertiaryColor,
                              borderRadius: BorderRadius.circular(20),
                            ),
                            child: TextFormField(
                              controller: textController,
                              onChanged: (_) => EasyDebounce.debounce(
                                'textController',
                                Duration(milliseconds: 2000),
                                () => setState(() {}),
                              ),
                              autofocus: true,
                              obscureText: false,
                              decoration: InputDecoration(
                                hintText: FFLocalizations.of(context).getText(
                                  '1ymxi5a3' /* Search... */,
                                ),
                                enabledBorder: OutlineInputBorder(
                                  borderSide: BorderSide(
                                    color: Color(0x00000000),
                                    width: 1,
                                  ),
                                  borderRadius: const BorderRadius.only(
                                    topLeft: Radius.circular(4.0),
                                    topRight: Radius.circular(4.0),
                                  ),
                                ),
                                focusedBorder: OutlineInputBorder(
                                  borderSide: BorderSide(
                                    color: Color(0x00000000),
                                    width: 1,
                                  ),
                                  borderRadius: const BorderRadius.only(
                                    topLeft: Radius.circular(4.0),
                                    topRight: Radius.circular(4.0),
                                  ),
                                ),
                                errorBorder: OutlineInputBorder(
                                  borderSide: BorderSide(
                                    color: Color(0x00000000),
                                    width: 1,
                                  ),
                                  borderRadius: const BorderRadius.only(
                                    topLeft: Radius.circular(4.0),
                                    topRight: Radius.circular(4.0),
                                  ),
                                ),
                                focusedErrorBorder: OutlineInputBorder(
                                  borderSide: BorderSide(
                                    color: Color(0x00000000),
                                    width: 1,
                                  ),
                                  borderRadius: const BorderRadius.only(
                                    topLeft: Radius.circular(4.0),
                                    topRight: Radius.circular(4.0),
                                  ),
                                ),
                                prefixIcon: Icon(
                                  Icons.search,
                                  color: FlutterFlowTheme.of(context).black,
                                ),
                                suffixIcon: textController!.text.isNotEmpty
                                    ? InkWell(
                                        onTap: () async {
                                          textController?.clear();
                                          setState(() {});
                                        },
                                        child: Icon(
                                          Icons.clear,
                                          color: Color(0xFF757575),
                                          size: 22,
                                        ),
                                      )
                                    : null,
                              ),
                              style: FlutterFlowTheme.of(context)
                                  .bodyText1
                                  .override(
                                    fontFamily: 'Poppins',
                                    color: FlutterFlowTheme.of(context).black,
                                  ),
                            ),
                          ),
                        ),
                        SingleChildScrollView(
                          scrollDirection: Axis.horizontal,
                          child: Row(
                            mainAxisSize: MainAxisSize.max,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Column(
                                mainAxisSize: MainAxisSize.max,
                                children: [
                                  Padding(
                                    padding: EdgeInsetsDirectional.fromSTEB(
                                        0, 10, 0, 0),
                                    child: Container(
                                      decoration: BoxDecoration(
                                        color: FlutterFlowTheme.of(context)
                                            .primaryColor,
                                      ),
                                      child: Row(
                                        mainAxisSize: MainAxisSize.max,
                                        mainAxisAlignment:
                                            MainAxisAlignment.center,
                                        children: [
                                          Padding(
                                            padding:
                                                EdgeInsetsDirectional.fromSTEB(
                                                    5, 5, 5, 5),
                                            child: Container(
                                              width: 200,
                                              decoration: BoxDecoration(
                                                color:
                                                    FlutterFlowTheme.of(context)
                                                        .secondaryBackground,
                                              ),
                                              child: Align(
                                                alignment:
                                                    AlignmentDirectional(0, 0),
                                                child: Text(
                                                  FFLocalizations.of(context)
                                                      .getText(
                                                    'ps9n67js' /* First Name */,
                                                  ),
                                                  textAlign: TextAlign.center,
                                                  style: FlutterFlowTheme.of(
                                                          context)
                                                      .bodyText1
                                                      .override(
                                                        fontFamily: 'Poppins',
                                                        fontSize: 16,
                                                      ),
                                                ),
                                              ),
                                            ),
                                          ),
                                          Padding(
                                            padding:
                                                EdgeInsetsDirectional.fromSTEB(
                                                    5, 5, 5, 5),
                                            child: Container(
                                              width: 200,
                                              decoration: BoxDecoration(
                                                color:
                                                    FlutterFlowTheme.of(context)
                                                        .secondaryBackground,
                                              ),
                                              child: Align(
                                                alignment:
                                                    AlignmentDirectional(0, 0),
                                                child: Text(
                                                  FFLocalizations.of(context)
                                                      .getText(
                                                    'ic1gcm4q' /* Last Name */,
                                                  ),
                                                  textAlign: TextAlign.center,
                                                  style: FlutterFlowTheme.of(
                                                          context)
                                                      .bodyText1
                                                      .override(
                                                        fontFamily: 'Poppins',
                                                        fontSize: 16,
                                                      ),
                                                ),
                                              ),
                                            ),
                                          ),
                                          Padding(
                                            padding:
                                                EdgeInsetsDirectional.fromSTEB(
                                                    5, 5, 5, 5),
                                            child: Container(
                                              width: 200,
                                              decoration: BoxDecoration(
                                                color:
                                                    FlutterFlowTheme.of(context)
                                                        .secondaryBackground,
                                              ),
                                              child: Align(
                                                alignment:
                                                    AlignmentDirectional(0, 0),
                                                child: Text(
                                                  FFLocalizations.of(context)
                                                      .getText(
                                                    'x3f7opty' /* Email */,
                                                  ),
                                                  textAlign: TextAlign.center,
                                                  style: FlutterFlowTheme.of(
                                                          context)
                                                      .bodyText1
                                                      .override(
                                                        fontFamily: 'Poppins',
                                                        fontSize: 16,
                                                      ),
                                                ),
                                              ),
                                            ),
                                          ),
                                          Padding(
                                            padding:
                                                EdgeInsetsDirectional.fromSTEB(
                                                    5, 5, 5, 5),
                                            child: Container(
                                              width: 200,
                                              decoration: BoxDecoration(
                                                color:
                                                    FlutterFlowTheme.of(context)
                                                        .secondaryBackground,
                                              ),
                                              child: Align(
                                                alignment:
                                                    AlignmentDirectional(0, 0),
                                                child: Text(
                                                  FFLocalizations.of(context)
                                                      .getText(
                                                    '9bs1pc05' /* Action */,
                                                  ),
                                                  textAlign: TextAlign.center,
                                                  style: FlutterFlowTheme.of(
                                                          context)
                                                      .bodyText1
                                                      .override(
                                                        fontFamily: 'Poppins',
                                                        fontSize: 16,
                                                      ),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                  Padding(
                                    padding: EdgeInsetsDirectional.fromSTEB(
                                        0, 10, 0, 0),
                                    child: Container(
                                      height: 280,
                                      decoration: BoxDecoration(),
                                      child: SingleChildScrollView(
                                        child: Column(
                                          mainAxisSize: MainAxisSize.max,
                                          children: [
                                            if (functions.jsonLength(
                                                    columnMainButtonGetDataSResponse
                                                        .jsonBody) >
                                                1)
                                              Builder(
                                                builder: (context) {
                                                  final list = getJsonField(
                                                    columnMainButtonGetDataSResponse
                                                        .jsonBody,
                                                    r'''$[*]''',
                                                  ).toList();
                                                  return SingleChildScrollView(
                                                    child: Column(
                                                      mainAxisSize:
                                                          MainAxisSize.max,
                                                      children: List.generate(
                                                          list.length,
                                                          (listIndex) {
                                                        final listItem =
                                                            list[listIndex];
                                                        return Container(
                                                          decoration:
                                                              BoxDecoration(
                                                            color: FlutterFlowTheme
                                                                    .of(context)
                                                                .secondaryBackground,
                                                          ),
                                                          child: Row(
                                                            mainAxisSize:
                                                                MainAxisSize
                                                                    .max,
                                                            mainAxisAlignment:
                                                                MainAxisAlignment
                                                                    .center,
                                                            children: [
                                                              Padding(
                                                                padding:
                                                                    EdgeInsetsDirectional
                                                                        .fromSTEB(
                                                                            5,
                                                                            5,
                                                                            5,
                                                                            5),
                                                                child:
                                                                    Container(
                                                                  width: 200,
                                                                  decoration:
                                                                      BoxDecoration(
                                                                    color: FlutterFlowTheme.of(
                                                                            context)
                                                                        .secondaryBackground,
                                                                  ),
                                                                  child: Align(
                                                                    alignment:
                                                                        AlignmentDirectional(
                                                                            0,
                                                                            0),
                                                                    child: Text(
                                                                      getJsonField(
                                                                        listItem,
                                                                        r'''$..user_first_name''',
                                                                      ).toString(),
                                                                      textAlign:
                                                                          TextAlign
                                                                              .center,
                                                                      style: FlutterFlowTheme.of(
                                                                              context)
                                                                          .bodyText1
                                                                          .override(
                                                                            fontFamily:
                                                                                'Poppins',
                                                                            fontSize:
                                                                                14,
                                                                          ),
                                                                    ),
                                                                  ),
                                                                ),
                                                              ),
                                                              Padding(
                                                                padding:
                                                                    EdgeInsetsDirectional
                                                                        .fromSTEB(
                                                                            5,
                                                                            5,
                                                                            5,
                                                                            5),
                                                                child:
                                                                    Container(
                                                                  width: 200,
                                                                  decoration:
                                                                      BoxDecoration(
                                                                    color: FlutterFlowTheme.of(
                                                                            context)
                                                                        .secondaryBackground,
                                                                  ),
                                                                  child: Align(
                                                                    alignment:
                                                                        AlignmentDirectional(
                                                                            0,
                                                                            0),
                                                                    child: Text(
                                                                      getJsonField(
                                                                        listItem,
                                                                        r'''$..user_last_name''',
                                                                      ).toString(),
                                                                      textAlign:
                                                                          TextAlign
                                                                              .center,
                                                                      style: FlutterFlowTheme.of(
                                                                              context)
                                                                          .bodyText1
                                                                          .override(
                                                                            fontFamily:
                                                                                'Poppins',
                                                                            fontSize:
                                                                                14,
                                                                          ),
                                                                    ),
                                                                  ),
                                                                ),
                                                              ),
                                                              Padding(
                                                                padding:
                                                                    EdgeInsetsDirectional
                                                                        .fromSTEB(
                                                                            5,
                                                                            5,
                                                                            5,
                                                                            5),
                                                                child:
                                                                    Container(
                                                                  width: 200,
                                                                  decoration:
                                                                      BoxDecoration(
                                                                    color: FlutterFlowTheme.of(
                                                                            context)
                                                                        .secondaryBackground,
                                                                  ),
                                                                  child: Align(
                                                                    alignment:
                                                                        AlignmentDirectional(
                                                                            0,
                                                                            0),
                                                                    child: Text(
                                                                      getJsonField(
                                                                        listItem,
                                                                        r'''$..user_email''',
                                                                      ).toString(),
                                                                      textAlign:
                                                                          TextAlign
                                                                              .center,
                                                                      style: FlutterFlowTheme.of(
                                                                              context)
                                                                          .bodyText1
                                                                          .override(
                                                                            fontFamily:
                                                                                'Poppins',
                                                                            fontSize:
                                                                                14,
                                                                          ),
                                                                    ),
                                                                  ),
                                                                ),
                                                              ),
                                                              Padding(
                                                                padding:
                                                                    EdgeInsetsDirectional
                                                                        .fromSTEB(
                                                                            5,
                                                                            5,
                                                                            5,
                                                                            5),
                                                                child:
                                                                    Container(
                                                                  width: 200,
                                                                  decoration:
                                                                      BoxDecoration(
                                                                    color: FlutterFlowTheme.of(
                                                                            context)
                                                                        .secondaryBackground,
                                                                  ),
                                                                  child: Wrap(
                                                                    spacing: 0,
                                                                    runSpacing:
                                                                        0,
                                                                    alignment:
                                                                        WrapAlignment
                                                                            .center,
                                                                    crossAxisAlignment:
                                                                        WrapCrossAlignment
                                                                            .start,
                                                                    direction: Axis
                                                                        .horizontal,
                                                                    runAlignment:
                                                                        WrapAlignment
                                                                            .start,
                                                                    verticalDirection:
                                                                        VerticalDirection
                                                                            .down,
                                                                    clipBehavior:
                                                                        Clip.none,
                                                                    children: [
                                                                      Padding(
                                                                        padding: EdgeInsetsDirectional.fromSTEB(
                                                                            0,
                                                                            0,
                                                                            5,
                                                                            5),
                                                                        child:
                                                                            FFButtonWidget(
                                                                          onPressed:
                                                                              () async {
                                                                            setState(() =>
                                                                                FFAppState().user = getJsonField(
                                                                                  listItem,
                                                                                  r'''$..id''',
                                                                                ).toString());
                                                                            setState(() =>
                                                                                FFAppState().assignquiz = []);
                                                                            apiResulting =
                                                                                await QuizbpCall.call(
                                                                              refreshToken: FFAppState().sessionRefreshToken,
                                                                              i1: FFAppState().user,
                                                                              formstep: 'getassingquiz',
                                                                            );
                                                                            if (functions.arraycontains(
                                                                                    functions
                                                                                        .splitarray(getJsonField(
                                                                                          (apiResulting?.jsonBody ?? ''),
                                                                                          r'''$..quiz1''',
                                                                                        ).toString())
                                                                                        .toList(),
                                                                                    'Business_partner') ==
                                                                                true) {
                                                                              setState(() => FFAppState().assignquiz.add('Business_partner'));
                                                                              setState(() => FFAppState().date1 = functions.stringintotimestamp(getJsonField(
                                                                                    (apiResulting?.jsonBody ?? ''),
                                                                                    r'''$..start_time1''',
                                                                                  ).toString()));
                                                                              setState(() => FFAppState().date2 = functions.stringintotimestamp(getJsonField(
                                                                                    (apiResulting?.jsonBody ?? ''),
                                                                                    r'''$..end_time1''',
                                                                                  ).toString()));
                                                                            } else {
                                                                              setState(() => FFAppState().date1 = null);
                                                                              setState(() => FFAppState().date2 = null);
                                                                            }

                                                                            if (functions.arraycontains(
                                                                                    functions
                                                                                        .splitarray(getJsonField(
                                                                                          (apiResulting?.jsonBody ?? ''),
                                                                                          r'''$..quiz1''',
                                                                                        ).toString())
                                                                                        .toList(),
                                                                                    'Charity') ==
                                                                                true) {
                                                                              setState(() => FFAppState().assignquiz.add('Charity'));
                                                                              setState(() => FFAppState().date3 = functions.stringintotimestamp(getJsonField(
                                                                                    (apiResulting?.jsonBody ?? ''),
                                                                                    r'''$..start_time2''',
                                                                                  ).toString()));
                                                                              setState(() => FFAppState().date4 = functions.stringintotimestamp(getJsonField(
                                                                                    (apiResulting?.jsonBody ?? ''),
                                                                                    r'''$..end_time2''',
                                                                                  ).toString()));
                                                                            } else {
                                                                              setState(() => FFAppState().date3 = null);
                                                                              setState(() => FFAppState().date4 = null);
                                                                            }

                                                                            if (functions.arraycontains(
                                                                                    functions
                                                                                        .splitarray(getJsonField(
                                                                                          (apiResulting?.jsonBody ?? ''),
                                                                                          r'''$..quiz1''',
                                                                                        ).toString())
                                                                                        .toList(),
                                                                                    'Referee') ==
                                                                                true) {
                                                                              setState(() => FFAppState().assignquiz.add('Referee'));
                                                                              setState(() => FFAppState().date5 = functions.stringintotimestamp(getJsonField(
                                                                                    (apiResulting?.jsonBody ?? ''),
                                                                                    r'''$..start_time3''',
                                                                                  ).toString()));
                                                                              setState(() => FFAppState().date6 = functions.stringintotimestamp(getJsonField(
                                                                                    (apiResulting?.jsonBody ?? ''),
                                                                                    r'''$..end_time3''',
                                                                                  ).toString()));
                                                                            } else {
                                                                              setState(() => FFAppState().date5 = null);
                                                                              setState(() => FFAppState().date6 = null);
                                                                            }

                                                                            await Navigator.push(
                                                                              context,
                                                                              PageTransition(
                                                                                type: PageTransitionType.rightToLeft,
                                                                                duration: Duration(milliseconds: 50),
                                                                                reverseDuration: Duration(milliseconds: 50),
                                                                                child: AssignquizWidget(),
                                                                              ),
                                                                            );

                                                                            setState(() {});
                                                                          },
                                                                          text:
                                                                              FFLocalizations.of(context).getText(
                                                                            '2se4uuna' /* Assign quiz */,
                                                                          ),
                                                                          options:
                                                                              FFButtonOptions(
                                                                            width:
                                                                                150,
                                                                            height:
                                                                                40,
                                                                            color:
                                                                                FlutterFlowTheme.of(context).tertiaryColor,
                                                                            textStyle: FlutterFlowTheme.of(context).subtitle2.override(
                                                                                  fontFamily: 'Poppins',
                                                                                  color: FlutterFlowTheme.of(context).black,
                                                                                  fontSize: 16,
                                                                                ),
                                                                            borderSide:
                                                                                BorderSide(
                                                                              color: Colors.transparent,
                                                                              width: 1,
                                                                            ),
                                                                            borderRadius:
                                                                                BorderRadius.circular(40),
                                                                          ),
                                                                        ),
                                                                      ),
                                                                    ],
                                                                  ),
                                                                ),
                                                              ),
                                                            ],
                                                          ),
                                                        );
                                                      }),
                                                    ),
                                                  );
                                                },
                                              ),
                                            if (functions.jsonLength(
                                                    columnMainButtonGetDataSResponse
                                                        .jsonBody) ==
                                                0)
                                              Text(
                                                FFLocalizations.of(context)
                                                    .getText(
                                                  'ezdo4a1p' /* No user found */,
                                                ),
                                                style:
                                                    FlutterFlowTheme.of(context)
                                                        .bodyText1
                                                        .override(
                                                          fontFamily: 'Poppins',
                                                          fontSize: 16,
                                                        ),
                                              ),
                                            if (functions.jsonLength(
                                                    columnMainButtonGetDataSResponse
                                                        .jsonBody) ==
                                                1)
                                              Row(
                                                mainAxisSize: MainAxisSize.max,
                                                mainAxisAlignment:
                                                    MainAxisAlignment.center,
                                                children: [
                                                  Padding(
                                                    padding:
                                                        EdgeInsetsDirectional
                                                            .fromSTEB(
                                                                5, 5, 5, 5),
                                                    child: Container(
                                                      width: 200,
                                                      decoration: BoxDecoration(
                                                        color: FlutterFlowTheme
                                                                .of(context)
                                                            .secondaryBackground,
                                                      ),
                                                      child: Align(
                                                        alignment:
                                                            AlignmentDirectional(
                                                                0, 0),
                                                        child: Text(
                                                          getJsonField(
                                                            columnMainButtonGetDataSResponse
                                                                .jsonBody,
                                                            r'''$..user_first_name''',
                                                          ).toString(),
                                                          textAlign:
                                                              TextAlign.center,
                                                          style: FlutterFlowTheme
                                                                  .of(context)
                                                              .bodyText1
                                                              .override(
                                                                fontFamily:
                                                                    'Poppins',
                                                                fontSize: 14,
                                                              ),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                  Padding(
                                                    padding:
                                                        EdgeInsetsDirectional
                                                            .fromSTEB(
                                                                5, 5, 5, 5),
                                                    child: Container(
                                                      width: 200,
                                                      decoration: BoxDecoration(
                                                        color: FlutterFlowTheme
                                                                .of(context)
                                                            .secondaryBackground,
                                                      ),
                                                      child: Align(
                                                        alignment:
                                                            AlignmentDirectional(
                                                                0, 0),
                                                        child: Text(
                                                          getJsonField(
                                                            columnMainButtonGetDataSResponse
                                                                .jsonBody,
                                                            r'''$..user_last_name''',
                                                          ).toString(),
                                                          textAlign:
                                                              TextAlign.center,
                                                          style: FlutterFlowTheme
                                                                  .of(context)
                                                              .bodyText1
                                                              .override(
                                                                fontFamily:
                                                                    'Poppins',
                                                                fontSize: 14,
                                                              ),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                  Padding(
                                                    padding:
                                                        EdgeInsetsDirectional
                                                            .fromSTEB(
                                                                5, 5, 5, 5),
                                                    child: Container(
                                                      width: 200,
                                                      decoration: BoxDecoration(
                                                        color: FlutterFlowTheme
                                                                .of(context)
                                                            .secondaryBackground,
                                                      ),
                                                      child: Align(
                                                        alignment:
                                                            AlignmentDirectional(
                                                                0, 0),
                                                        child: Text(
                                                          getJsonField(
                                                            columnMainButtonGetDataSResponse
                                                                .jsonBody,
                                                            r'''$..user_email''',
                                                          ).toString(),
                                                          textAlign:
                                                              TextAlign.center,
                                                          style: FlutterFlowTheme
                                                                  .of(context)
                                                              .bodyText1
                                                              .override(
                                                                fontFamily:
                                                                    'Poppins',
                                                                fontSize: 14,
                                                              ),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                  Padding(
                                                    padding:
                                                        EdgeInsetsDirectional
                                                            .fromSTEB(
                                                                5, 5, 5, 5),
                                                    child: Container(
                                                      width: 200,
                                                      decoration: BoxDecoration(
                                                        color: FlutterFlowTheme
                                                                .of(context)
                                                            .secondaryBackground,
                                                      ),
                                                      child: Wrap(
                                                        spacing: 0,
                                                        runSpacing: 0,
                                                        alignment: WrapAlignment
                                                            .center,
                                                        crossAxisAlignment:
                                                            WrapCrossAlignment
                                                                .start,
                                                        direction:
                                                            Axis.horizontal,
                                                        runAlignment:
                                                            WrapAlignment.start,
                                                        verticalDirection:
                                                            VerticalDirection
                                                                .down,
                                                        clipBehavior: Clip.none,
                                                        children: [
                                                          Padding(
                                                            padding:
                                                                EdgeInsetsDirectional
                                                                    .fromSTEB(
                                                                        0,
                                                                        0,
                                                                        5,
                                                                        5),
                                                            child:
                                                                FFButtonWidget(
                                                              onPressed:
                                                                  () async {
                                                                setState(() =>
                                                                    FFAppState()
                                                                            .user =
                                                                        getJsonField(
                                                                      columnMainButtonGetDataSResponse
                                                                          .jsonBody,
                                                                      r'''$..id''',
                                                                    ).toString());
                                                                setState(() =>
                                                                    FFAppState()
                                                                            .assignquiz =
                                                                        []);
                                                                apiResulting12 =
                                                                    await QuizbpCall
                                                                        .call(
                                                                  refreshToken:
                                                                      FFAppState()
                                                                          .sessionRefreshToken,
                                                                  i1: FFAppState()
                                                                      .user,
                                                                  formstep:
                                                                      'getassingquiz',
                                                                );
                                                                if (functions.arraycontains(
                                                                        functions
                                                                            .splitarray(getJsonField(
                                                                              (apiResulting12?.jsonBody ?? ''),
                                                                              r'''$..quiz1''',
                                                                            ).toString())
                                                                            .toList(),
                                                                        'Business_partner') ==
                                                                    true) {
                                                                  setState(() =>
                                                                      FFAppState()
                                                                          .assignquiz
                                                                          .add(
                                                                              'Business_partner'));
                                                                  setState(() =>
                                                                      FFAppState()
                                                                              .date1 =
                                                                          functions
                                                                              .stringintotimestamp(getJsonField(
                                                                        (apiResulting12?.jsonBody ??
                                                                            ''),
                                                                        r'''$..start_time1''',
                                                                      ).toString()));
                                                                  setState(() =>
                                                                      FFAppState()
                                                                              .date2 =
                                                                          functions
                                                                              .stringintotimestamp(getJsonField(
                                                                        (apiResulting12?.jsonBody ??
                                                                            ''),
                                                                        r'''$..end_time1''',
                                                                      ).toString()));
                                                                } else {
                                                                  setState(() =>
                                                                      FFAppState()
                                                                              .date1 =
                                                                          null);
                                                                  setState(() =>
                                                                      FFAppState()
                                                                              .date2 =
                                                                          null);
                                                                }

                                                                if (functions.arraycontains(
                                                                        functions
                                                                            .splitarray(getJsonField(
                                                                              (apiResulting12?.jsonBody ?? ''),
                                                                              r'''$..quiz1''',
                                                                            ).toString())
                                                                            .toList(),
                                                                        'Charity') ==
                                                                    true) {
                                                                  setState(() =>
                                                                      FFAppState()
                                                                          .assignquiz
                                                                          .add(
                                                                              'Charity'));
                                                                  setState(() =>
                                                                      FFAppState()
                                                                              .date3 =
                                                                          functions
                                                                              .stringintotimestamp(getJsonField(
                                                                        (apiResulting12?.jsonBody ??
                                                                            ''),
                                                                        r'''$..start_time2''',
                                                                      ).toString()));
                                                                  setState(() =>
                                                                      FFAppState()
                                                                              .date4 =
                                                                          functions
                                                                              .stringintotimestamp(getJsonField(
                                                                        (apiResulting12?.jsonBody ??
                                                                            ''),
                                                                        r'''$..end_time2''',
                                                                      ).toString()));
                                                                } else {
                                                                  setState(() =>
                                                                      FFAppState()
                                                                              .date3 =
                                                                          null);
                                                                  setState(() =>
                                                                      FFAppState()
                                                                              .date4 =
                                                                          null);
                                                                }

                                                                if (functions.arraycontains(
                                                                        functions
                                                                            .splitarray(getJsonField(
                                                                              (apiResulting12?.jsonBody ?? ''),
                                                                              r'''$..quiz1''',
                                                                            ).toString())
                                                                            .toList(),
                                                                        'Referee') ==
                                                                    true) {
                                                                  setState(() =>
                                                                      FFAppState()
                                                                          .assignquiz
                                                                          .add(
                                                                              'Referee'));
                                                                  setState(() =>
                                                                      FFAppState()
                                                                              .date5 =
                                                                          functions
                                                                              .stringintotimestamp(getJsonField(
                                                                        (apiResulting12?.jsonBody ??
                                                                            ''),
                                                                        r'''$..start_time3''',
                                                                      ).toString()));
                                                                  setState(() =>
                                                                      FFAppState()
                                                                              .date6 =
                                                                          functions
                                                                              .stringintotimestamp(getJsonField(
                                                                        (apiResulting12?.jsonBody ??
                                                                            ''),
                                                                        r'''$..end_time3''',
                                                                      ).toString()));
                                                                } else {
                                                                  setState(() =>
                                                                      FFAppState()
                                                                              .date5 =
                                                                          null);
                                                                  setState(() =>
                                                                      FFAppState()
                                                                              .date6 =
                                                                          null);
                                                                }

                                                                await Navigator
                                                                    .push(
                                                                  context,
                                                                  PageTransition(
                                                                    type: PageTransitionType
                                                                        .rightToLeft,
                                                                    duration: Duration(
                                                                        milliseconds:
                                                                            50),
                                                                    reverseDuration:
                                                                        Duration(
                                                                            milliseconds:
                                                                                50),
                                                                    child:
                                                                        AssignquizWidget(),
                                                                  ),
                                                                );

                                                                setState(() {});
                                                              },
                                                              text: FFLocalizations
                                                                      .of(context)
                                                                  .getText(
                                                                'oi9rlmta' /* Assign quiz */,
                                                              ),
                                                              options:
                                                                  FFButtonOptions(
                                                                width: 150,
                                                                height: 40,
                                                                color: FlutterFlowTheme.of(
                                                                        context)
                                                                    .tertiaryColor,
                                                                textStyle: FlutterFlowTheme.of(
                                                                        context)
                                                                    .subtitle2
                                                                    .override(
                                                                      fontFamily:
                                                                          'Poppins',
                                                                      color: FlutterFlowTheme.of(
                                                                              context)
                                                                          .black,
                                                                      fontSize:
                                                                          16,
                                                                    ),
                                                                borderSide:
                                                                    BorderSide(
                                                                  color: Colors
                                                                      .transparent,
                                                                  width: 1,
                                                                ),
                                                                borderRadius:
                                                                    BorderRadius
                                                                        .circular(
                                                                            40),
                                                              ),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                          ],
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                        Wrap(
                          spacing: 0,
                          runSpacing: 0,
                          alignment: WrapAlignment.start,
                          crossAxisAlignment: WrapCrossAlignment.start,
                          direction: Axis.horizontal,
                          runAlignment: WrapAlignment.start,
                          verticalDirection: VerticalDirection.down,
                          clipBehavior: Clip.none,
                          children: [
                            Padding(
                              padding: EdgeInsetsDirectional.fromSTEB(
                                  10, 10, 10, 10),
                              child: FFButtonWidget(
                                onPressed: () async {
                                  await Navigator.push(
                                    context,
                                    PageTransition(
                                      type: PageTransitionType.rightToLeft,
                                      duration: Duration(milliseconds: 50),
                                      reverseDuration:
                                          Duration(milliseconds: 50),
                                      child: DashboardBusinessPartnerWidget(),
                                    ),
                                  );
                                },
                                text: FFLocalizations.of(context).getText(
                                  'bexdbkvr' /* Back */,
                                ),
                                options: FFButtonOptions(
                                  width: 130,
                                  height: 40,
                                  color:
                                      FlutterFlowTheme.of(context).customColor1,
                                  textStyle: FlutterFlowTheme.of(context)
                                      .subtitle2
                                      .override(
                                        fontFamily: 'Poppins',
                                        color: FlutterFlowTheme.of(context)
                                            .tertiaryColor,
                                      ),
                                  borderSide: BorderSide(
                                    color: FlutterFlowTheme.of(context)
                                        .tertiaryColor,
                                    width: 1,
                                  ),
                                  borderRadius: BorderRadius.circular(40),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ],
                    );
                  },
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
