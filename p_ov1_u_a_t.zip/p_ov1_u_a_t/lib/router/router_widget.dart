import '../backend/api_requests/api_calls.dart';
import '../components/app_header_widget.dart';
import '../flutter_flow/flutter_flow_theme.dart';
import '../flutter_flow/flutter_flow_util.dart';
import '../register_business_partner_00/register_business_partner00_widget.dart';
import '../register_business_partner_01/register_business_partner01_widget.dart';
import '../register_business_partner_02/register_business_partner02_widget.dart';
import '../register_business_partner_03/register_business_partner03_widget.dart';
import '../register_business_partner_04/register_business_partner04_widget.dart';
import '../register_business_partner_05/register_business_partner05_widget.dart';
import '../register_business_partner_06/register_business_partner06_widget.dart';
import '../register_captain_00/register_captain00_widget.dart';
import '../register_captain_01/register_captain01_widget.dart';
import '../register_captain_02/register_captain02_widget.dart';
import '../register_captain_03/register_captain03_widget.dart';
import '../register_captain_04/register_captain04_widget.dart';
import '../register_captain_05/register_captain05_widget.dart';
import '../register_captain_06/register_captain06_widget.dart';
import '../register_captain_07/register_captain07_widget.dart';
import '../register_captain_08/register_captain08_widget.dart';
import '../register_charity_00/register_charity00_widget.dart';
import '../register_charity_01/register_charity01_widget.dart';
import '../register_charity_02/register_charity02_widget.dart';
import '../register_charity_03/register_charity03_widget.dart';
import '../register_charity_04/register_charity04_widget.dart';
import '../register_charity_05/register_charity05_widget.dart';
import '../register_family_acc_00/register_family_acc00_widget.dart';
import '../register_family_acc_01/register_family_acc01_widget.dart';
import '../register_fan_00/register_fan00_widget.dart';
import '../register_fan_01/register_fan01_widget.dart';
import '../register_fan_02/register_fan02_widget.dart';
import '../register_free_agent_00/register_free_agent00_widget.dart';
import '../register_free_agent_01/register_free_agent01_widget.dart';
import '../register_free_agent_02/register_free_agent02_widget.dart';
import '../register_free_agent_03/register_free_agent03_widget.dart';
import '../register_free_agent_04/register_free_agent04_widget.dart';
import '../register_free_agent_05/register_free_agent05_widget.dart';
import '../register_free_agent_06/register_free_agent06_widget.dart';
import '../register_free_agent_07/register_free_agent07_widget.dart';
import '../register_player_00/register_player00_widget.dart';
import '../register_player_01/register_player01_widget.dart';
import '../register_player_02/register_player02_widget.dart';
import '../register_player_03/register_player03_widget.dart';
import '../register_player_04/register_player04_widget.dart';
import '../register_player_05/register_player05_widget.dart';
import '../register_player_06/register_player06_widget.dart';
import '../register_player_07/register_player07_widget.dart';
import '../register_referee_00/register_referee00_widget.dart';
import '../register_referee_01/register_referee01_widget.dart';
import '../register_referee_02/register_referee02_widget.dart';
import '../register_referee_03/register_referee03_widget.dart';
import '../register_referee_04/register_referee04_widget.dart';
import '../register_referee_05/register_referee05_widget.dart';
import '../register_referee_06/register_referee06_widget.dart';
import '../register_role_select/register_role_select_widget.dart';
import '../register_volunteer_00/register_volunteer00_widget.dart';
import '../register_volunteer_01/register_volunteer01_widget.dart';
import '../register_volunteer_02/register_volunteer02_widget.dart';
import '../register_volunteer_03/register_volunteer03_widget.dart';
import '../register_volunteer_04/register_volunteer04_widget.dart';
import '../register_volunteer_05/register_volunteer05_widget.dart';
import '../register_volunteer_06/register_volunteer06_widget.dart';
import '../register_volunteer_07/register_volunteer07_widget.dart';
import '../register_volunteer_08/register_volunteer08_widget.dart';
import '../register_volunteer_09/register_volunteer09_widget.dart';
import '../user_login_register/user_login_register_widget.dart';
import '../custom_code/actions/index.dart' as actions;
import '../flutter_flow/custom_functions.dart' as functions;
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:google_fonts/google_fonts.dart';

class RouterWidget extends StatefulWidget {
  const RouterWidget({Key? key}) : super(key: key);

  @override
  _RouterWidgetState createState() => _RouterWidgetState();
}

class _RouterWidgetState extends State<RouterWidget> {
  ApiCallResponse? route;
  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    // On page load action.
    SchedulerBinding.instance.addPostFrameCallback((_) async {
      route = await NCurrentPageGetCall.call(
        refreshToken: FFAppState().sessionRefreshToken,
      );
      await actions.printSession(
        getJsonField(
          (route?.jsonBody ?? ''),
          r'''$..currentPage''',
        ).toString(),
      );
      if ((route?.succeeded ?? true)) {
        await actions.printSession(
          'API Succeeded : Check Role',
        );
      } else {
        await Navigator.push(
          context,
          PageTransition(
            type: PageTransitionType.rightToLeft,
            duration: Duration(milliseconds: 50),
            reverseDuration: Duration(milliseconds: 50),
            child: UserLoginRegisterWidget(),
          ),
        );
        return;
      }

      if (functions.compareStrings(
          getJsonField(
            (route?.jsonBody ?? ''),
            r'''$..currentPage''',
          ).toString(),
          'RS01')) {
        await Navigator.push(
          context,
          PageTransition(
            type: PageTransitionType.rightToLeft,
            duration: Duration(milliseconds: 50),
            reverseDuration: Duration(milliseconds: 50),
            child: RegisterRoleSelectWidget(),
          ),
        );
        return;
      } else {
        await actions.printSession(
          'Not RS01, Check RPL00',
        );
      }

      if (functions.compareStrings(
          getJsonField(
            (route?.jsonBody ?? ''),
            r'''$..currentPage''',
          ).toString(),
          'RPL00')) {
        await Navigator.push(
          context,
          PageTransition(
            type: PageTransitionType.rightToLeft,
            duration: Duration(milliseconds: 50),
            reverseDuration: Duration(milliseconds: 50),
            child: RegisterPlayer00Widget(),
          ),
        );
        return;
      }
      if (functions.compareStrings(
          getJsonField(
            (route?.jsonBody ?? ''),
            r'''$..currentPage''',
          ).toString(),
          'RPL01')) {
        await Navigator.push(
          context,
          PageTransition(
            type: PageTransitionType.rightToLeft,
            duration: Duration(milliseconds: 50),
            reverseDuration: Duration(milliseconds: 50),
            child: RegisterPlayer01Widget(),
          ),
        );
        return;
      }
      if (functions.compareStrings(
          getJsonField(
            (route?.jsonBody ?? ''),
            r'''$..currentPage''',
          ).toString(),
          'RPL02')) {
        await Navigator.push(
          context,
          PageTransition(
            type: PageTransitionType.rightToLeft,
            duration: Duration(milliseconds: 50),
            reverseDuration: Duration(milliseconds: 50),
            child: RegisterPlayer02Widget(),
          ),
        );
        return;
      }
      if (functions.compareStrings(
          getJsonField(
            (route?.jsonBody ?? ''),
            r'''$..currentPage''',
          ).toString(),
          'RPL03')) {
        await Navigator.push(
          context,
          PageTransition(
            type: PageTransitionType.rightToLeft,
            duration: Duration(milliseconds: 50),
            reverseDuration: Duration(milliseconds: 50),
            child: RegisterPlayer03Widget(),
          ),
        );
        return;
      }
      if (functions.compareStrings(
          getJsonField(
            (route?.jsonBody ?? ''),
            r'''$..currentPage''',
          ).toString(),
          'RPL04')) {
        await Navigator.push(
          context,
          PageTransition(
            type: PageTransitionType.rightToLeft,
            duration: Duration(milliseconds: 50),
            reverseDuration: Duration(milliseconds: 50),
            child: RegisterPlayer04Widget(),
          ),
        );
        return;
      }
      if (functions.compareStrings(
          getJsonField(
            (route?.jsonBody ?? ''),
            r'''$..currentPage''',
          ).toString(),
          'RPL05')) {
        await Navigator.push(
          context,
          PageTransition(
            type: PageTransitionType.rightToLeft,
            duration: Duration(milliseconds: 50),
            reverseDuration: Duration(milliseconds: 50),
            child: RegisterPlayer05Widget(),
          ),
        );
        return;
      }
      if (functions.compareStrings(
          getJsonField(
            (route?.jsonBody ?? ''),
            r'''$..currentPage''',
          ).toString(),
          'RPL06')) {
        await Navigator.push(
          context,
          PageTransition(
            type: PageTransitionType.rightToLeft,
            duration: Duration(milliseconds: 50),
            reverseDuration: Duration(milliseconds: 50),
            child: RegisterPlayer06Widget(),
          ),
        );
        return;
      }
      if (functions.compareStrings(
          getJsonField(
            (route?.jsonBody ?? ''),
            r'''$..currentPage''',
          ).toString(),
          'RPL07')) {
        await Navigator.push(
          context,
          PageTransition(
            type: PageTransitionType.rightToLeft,
            duration: Duration(milliseconds: 50),
            reverseDuration: Duration(milliseconds: 50),
            child: RegisterPlayer07Widget(),
          ),
        );
        return;
      }
      if (functions.compareStrings(
          getJsonField(
            (route?.jsonBody ?? ''),
            r'''$..currentPage''',
          ).toString(),
          'RCA00')) {
        await Navigator.push(
          context,
          PageTransition(
            type: PageTransitionType.rightToLeft,
            duration: Duration(milliseconds: 50),
            reverseDuration: Duration(milliseconds: 50),
            child: RegisterCaptain00Widget(),
          ),
        );
        return;
      }
      if (functions.compareStrings(
          getJsonField(
            (route?.jsonBody ?? ''),
            r'''$..currentPage''',
          ).toString(),
          'RCA01')) {
        await Navigator.push(
          context,
          PageTransition(
            type: PageTransitionType.rightToLeft,
            duration: Duration(milliseconds: 50),
            reverseDuration: Duration(milliseconds: 50),
            child: RegisterCaptain01Widget(),
          ),
        );
        return;
      }
      if (functions.compareStrings(
          getJsonField(
            (route?.jsonBody ?? ''),
            r'''$..currentPage''',
          ).toString(),
          'RCA02')) {
        await Navigator.push(
          context,
          PageTransition(
            type: PageTransitionType.rightToLeft,
            duration: Duration(milliseconds: 50),
            reverseDuration: Duration(milliseconds: 50),
            child: RegisterCaptain02Widget(),
          ),
        );
        return;
      }
      if (functions.compareStrings(
          getJsonField(
            (route?.jsonBody ?? ''),
            r'''$..currentPage''',
          ).toString(),
          'RCA03')) {
        await Navigator.push(
          context,
          PageTransition(
            type: PageTransitionType.rightToLeft,
            duration: Duration(milliseconds: 50),
            reverseDuration: Duration(milliseconds: 50),
            child: RegisterCaptain03Widget(),
          ),
        );
        return;
      }
      if (functions.compareStrings(
          getJsonField(
            (route?.jsonBody ?? ''),
            r'''$..currentPage''',
          ).toString(),
          'RCA04')) {
        await Navigator.push(
          context,
          PageTransition(
            type: PageTransitionType.rightToLeft,
            duration: Duration(milliseconds: 50),
            reverseDuration: Duration(milliseconds: 50),
            child: RegisterCaptain04Widget(),
          ),
        );
        return;
      }
      if (functions.compareStrings(
          getJsonField(
            (route?.jsonBody ?? ''),
            r'''$..currentPage''',
          ).toString(),
          'RCA05')) {
        await Navigator.push(
          context,
          PageTransition(
            type: PageTransitionType.rightToLeft,
            duration: Duration(milliseconds: 50),
            reverseDuration: Duration(milliseconds: 50),
            child: RegisterCaptain05Widget(),
          ),
        );
        return;
      }
      if (functions.compareStrings(
          getJsonField(
            (route?.jsonBody ?? ''),
            r'''$..currentPage''',
          ).toString(),
          'RCA06')) {
        await Navigator.push(
          context,
          PageTransition(
            type: PageTransitionType.rightToLeft,
            duration: Duration(milliseconds: 50),
            reverseDuration: Duration(milliseconds: 50),
            child: RegisterCaptain06Widget(),
          ),
        );
        return;
      }
      if (functions.compareStrings(
          getJsonField(
            (route?.jsonBody ?? ''),
            r'''$..currentPage''',
          ).toString(),
          'RCA07')) {
        await Navigator.push(
          context,
          PageTransition(
            type: PageTransitionType.rightToLeft,
            duration: Duration(milliseconds: 50),
            reverseDuration: Duration(milliseconds: 50),
            child: RegisterCaptain07Widget(),
          ),
        );
        return;
      }
      if (functions.compareStrings(
          getJsonField(
            (route?.jsonBody ?? ''),
            r'''$..currentPage''',
          ).toString(),
          'RCA08')) {
        await Navigator.push(
          context,
          PageTransition(
            type: PageTransitionType.rightToLeft,
            duration: Duration(milliseconds: 50),
            reverseDuration: Duration(milliseconds: 50),
            child: RegisterCaptain08Widget(),
          ),
        );
        return;
      }
      if (functions.compareStrings(
          getJsonField(
            (route?.jsonBody ?? ''),
            r'''$..currentPage''',
          ).toString(),
          'RFA00')) {
        await Navigator.push(
          context,
          PageTransition(
            type: PageTransitionType.rightToLeft,
            duration: Duration(milliseconds: 50),
            reverseDuration: Duration(milliseconds: 50),
            child: RegisterFreeAgent00Widget(),
          ),
        );
        return;
      }
      if (functions.compareStrings(
          getJsonField(
            (route?.jsonBody ?? ''),
            r'''$..currentPage''',
          ).toString(),
          'RFA01')) {
        await Navigator.push(
          context,
          PageTransition(
            type: PageTransitionType.rightToLeft,
            duration: Duration(milliseconds: 50),
            reverseDuration: Duration(milliseconds: 50),
            child: RegisterFreeAgent01Widget(),
          ),
        );
        return;
      }
      if (functions.compareStrings(
          getJsonField(
            (route?.jsonBody ?? ''),
            r'''$..currentPage''',
          ).toString(),
          'RFA02')) {
        await Navigator.push(
          context,
          PageTransition(
            type: PageTransitionType.rightToLeft,
            duration: Duration(milliseconds: 50),
            reverseDuration: Duration(milliseconds: 50),
            child: RegisterFreeAgent02Widget(),
          ),
        );
        return;
      }
      if (functions.compareStrings(
          getJsonField(
            (route?.jsonBody ?? ''),
            r'''$..currentPage''',
          ).toString(),
          'RFA03')) {
        await Navigator.push(
          context,
          PageTransition(
            type: PageTransitionType.rightToLeft,
            duration: Duration(milliseconds: 50),
            reverseDuration: Duration(milliseconds: 50),
            child: RegisterFreeAgent03Widget(),
          ),
        );
        return;
      }
      if (functions.compareStrings(
          getJsonField(
            (route?.jsonBody ?? ''),
            r'''$..currentPage''',
          ).toString(),
          'RFA04')) {
        await Navigator.push(
          context,
          PageTransition(
            type: PageTransitionType.rightToLeft,
            duration: Duration(milliseconds: 50),
            reverseDuration: Duration(milliseconds: 50),
            child: RegisterFreeAgent04Widget(),
          ),
        );
        return;
      }
      if (functions.compareStrings(
          getJsonField(
            (route?.jsonBody ?? ''),
            r'''$..currentPage''',
          ).toString(),
          'RFA05')) {
        await Navigator.push(
          context,
          PageTransition(
            type: PageTransitionType.rightToLeft,
            duration: Duration(milliseconds: 50),
            reverseDuration: Duration(milliseconds: 50),
            child: RegisterFreeAgent05Widget(),
          ),
        );
        return;
      }
      if (functions.compareStrings(
          getJsonField(
            (route?.jsonBody ?? ''),
            r'''$..currentPage''',
          ).toString(),
          'RFA06')) {
        await Navigator.push(
          context,
          PageTransition(
            type: PageTransitionType.rightToLeft,
            duration: Duration(milliseconds: 50),
            reverseDuration: Duration(milliseconds: 50),
            child: RegisterFreeAgent06Widget(),
          ),
        );
        return;
      }
      if (functions.compareStrings(
          getJsonField(
            (route?.jsonBody ?? ''),
            r'''$..currentPage''',
          ).toString(),
          'RFA07')) {
        await Navigator.push(
          context,
          PageTransition(
            type: PageTransitionType.rightToLeft,
            duration: Duration(milliseconds: 50),
            reverseDuration: Duration(milliseconds: 50),
            child: RegisterFreeAgent07Widget(),
          ),
        );
        return;
      }
      if (functions.compareStrings(
          getJsonField(
            (route?.jsonBody ?? ''),
            r'''$..currentPage''',
          ).toString(),
          'RBP00')) {
        await Navigator.push(
          context,
          PageTransition(
            type: PageTransitionType.rightToLeft,
            duration: Duration(milliseconds: 50),
            reverseDuration: Duration(milliseconds: 50),
            child: RegisterBusinessPartner00Widget(),
          ),
        );
        return;
      }
      if (functions.compareStrings(
          getJsonField(
            (route?.jsonBody ?? ''),
            r'''$..currentPage''',
          ).toString(),
          'RBP01')) {
        await Navigator.push(
          context,
          PageTransition(
            type: PageTransitionType.rightToLeft,
            duration: Duration(milliseconds: 50),
            reverseDuration: Duration(milliseconds: 50),
            child: RegisterBusinessPartner01Widget(),
          ),
        );
        return;
      }
      if (functions.compareStrings(
          getJsonField(
            (route?.jsonBody ?? ''),
            r'''$..currentPage''',
          ).toString(),
          'RBP02')) {
        await Navigator.push(
          context,
          PageTransition(
            type: PageTransitionType.rightToLeft,
            duration: Duration(milliseconds: 50),
            reverseDuration: Duration(milliseconds: 50),
            child: RegisterBusinessPartner02Widget(),
          ),
        );
        return;
      }
      if (functions.compareStrings(
          getJsonField(
            (route?.jsonBody ?? ''),
            r'''$..currentPage''',
          ).toString(),
          'RBP03')) {
        await Navigator.push(
          context,
          PageTransition(
            type: PageTransitionType.rightToLeft,
            duration: Duration(milliseconds: 50),
            reverseDuration: Duration(milliseconds: 50),
            child: RegisterBusinessPartner03Widget(),
          ),
        );
        return;
      }
      if (functions.compareStrings(
          getJsonField(
            (route?.jsonBody ?? ''),
            r'''$..currentPage''',
          ).toString(),
          'RBP04')) {
        await Navigator.push(
          context,
          PageTransition(
            type: PageTransitionType.rightToLeft,
            duration: Duration(milliseconds: 50),
            reverseDuration: Duration(milliseconds: 50),
            child: RegisterBusinessPartner04Widget(),
          ),
        );
        return;
      }
      if (functions.compareStrings(
          getJsonField(
            (route?.jsonBody ?? ''),
            r'''$..currentPage''',
          ).toString(),
          'RBP05')) {
        await Navigator.push(
          context,
          PageTransition(
            type: PageTransitionType.rightToLeft,
            duration: Duration(milliseconds: 50),
            reverseDuration: Duration(milliseconds: 50),
            child: RegisterBusinessPartner05Widget(),
          ),
        );
        return;
      }
      if (functions.compareStrings(
          getJsonField(
            (route?.jsonBody ?? ''),
            r'''$..currentPage''',
          ).toString(),
          'RBP06')) {
        await Navigator.push(
          context,
          PageTransition(
            type: PageTransitionType.rightToLeft,
            duration: Duration(milliseconds: 50),
            reverseDuration: Duration(milliseconds: 50),
            child: RegisterBusinessPartner06Widget(),
          ),
        );
        return;
      }
      if (functions.compareStrings(
          getJsonField(
            (route?.jsonBody ?? ''),
            r'''$..currentPage''',
          ).toString(),
          'RRE00')) {
        await Navigator.push(
          context,
          PageTransition(
            type: PageTransitionType.rightToLeft,
            duration: Duration(milliseconds: 50),
            reverseDuration: Duration(milliseconds: 50),
            child: RegisterReferee00Widget(),
          ),
        );
        return;
      }
      if (functions.compareStrings(
          getJsonField(
            (route?.jsonBody ?? ''),
            r'''$..currentPage''',
          ).toString(),
          'RRE01')) {
        await Navigator.push(
          context,
          PageTransition(
            type: PageTransitionType.rightToLeft,
            duration: Duration(milliseconds: 50),
            reverseDuration: Duration(milliseconds: 50),
            child: RegisterReferee01Widget(),
          ),
        );
        return;
      }
      if (functions.compareStrings(
          getJsonField(
            (route?.jsonBody ?? ''),
            r'''$..currentPage''',
          ).toString(),
          'RRE02')) {
        await Navigator.push(
          context,
          PageTransition(
            type: PageTransitionType.rightToLeft,
            duration: Duration(milliseconds: 50),
            reverseDuration: Duration(milliseconds: 50),
            child: RegisterReferee02Widget(),
          ),
        );
        return;
      }
      if (functions.compareStrings(
          getJsonField(
            (route?.jsonBody ?? ''),
            r'''$..currentPage''',
          ).toString(),
          'RRE03')) {
        await Navigator.push(
          context,
          PageTransition(
            type: PageTransitionType.rightToLeft,
            duration: Duration(milliseconds: 50),
            reverseDuration: Duration(milliseconds: 50),
            child: RegisterReferee03Widget(),
          ),
        );
        return;
      }
      if (functions.compareStrings(
          getJsonField(
            (route?.jsonBody ?? ''),
            r'''$..currentPage''',
          ).toString(),
          'RRE04')) {
        await Navigator.push(
          context,
          PageTransition(
            type: PageTransitionType.rightToLeft,
            duration: Duration(milliseconds: 50),
            reverseDuration: Duration(milliseconds: 50),
            child: RegisterReferee04Widget(),
          ),
        );
        return;
      }
      if (functions.compareStrings(
          getJsonField(
            (route?.jsonBody ?? ''),
            r'''$..currentPage''',
          ).toString(),
          'RRE04')) {
        await Navigator.push(
          context,
          PageTransition(
            type: PageTransitionType.rightToLeft,
            duration: Duration(milliseconds: 50),
            reverseDuration: Duration(milliseconds: 50),
            child: RegisterReferee05Widget(),
          ),
        );
        return;
      }
      if (functions.compareStrings(
          getJsonField(
            (route?.jsonBody ?? ''),
            r'''$..currentPage''',
          ).toString(),
          'RRE06')) {
        await Navigator.push(
          context,
          PageTransition(
            type: PageTransitionType.rightToLeft,
            duration: Duration(milliseconds: 50),
            reverseDuration: Duration(milliseconds: 50),
            child: RegisterReferee06Widget(),
          ),
        );
        return;
      }
      if (functions.compareStrings(
          getJsonField(
            (route?.jsonBody ?? ''),
            r'''$..currentPage''',
          ).toString(),
          'RCH00')) {
        await Navigator.push(
          context,
          PageTransition(
            type: PageTransitionType.rightToLeft,
            duration: Duration(milliseconds: 50),
            reverseDuration: Duration(milliseconds: 50),
            child: RegisterCharity00Widget(),
          ),
        );
        return;
      }
      if (functions.compareStrings(
          getJsonField(
            (route?.jsonBody ?? ''),
            r'''$..currentPage''',
          ).toString(),
          'RCH01')) {
        await Navigator.push(
          context,
          PageTransition(
            type: PageTransitionType.rightToLeft,
            duration: Duration(milliseconds: 50),
            reverseDuration: Duration(milliseconds: 50),
            child: RegisterCharity01Widget(),
          ),
        );
        return;
      }
      if (functions.compareStrings(
          getJsonField(
            (route?.jsonBody ?? ''),
            r'''$..currentPage''',
          ).toString(),
          'RCH02')) {
        await Navigator.push(
          context,
          PageTransition(
            type: PageTransitionType.rightToLeft,
            duration: Duration(milliseconds: 50),
            reverseDuration: Duration(milliseconds: 50),
            child: RegisterCharity02Widget(),
          ),
        );
        return;
      }
      if (functions.compareStrings(
          getJsonField(
            (route?.jsonBody ?? ''),
            r'''$..currentPage''',
          ).toString(),
          'RCH03')) {
        await Navigator.push(
          context,
          PageTransition(
            type: PageTransitionType.rightToLeft,
            duration: Duration(milliseconds: 50),
            reverseDuration: Duration(milliseconds: 50),
            child: RegisterCharity03Widget(),
          ),
        );
        return;
      }
      if (functions.compareStrings(
          getJsonField(
            (route?.jsonBody ?? ''),
            r'''$..currentPage''',
          ).toString(),
          'RCH04')) {
        await Navigator.push(
          context,
          PageTransition(
            type: PageTransitionType.rightToLeft,
            duration: Duration(milliseconds: 50),
            reverseDuration: Duration(milliseconds: 50),
            child: RegisterCharity04Widget(),
          ),
        );
        return;
      }
      if (functions.compareStrings(
          getJsonField(
            (route?.jsonBody ?? ''),
            r'''$..currentPage''',
          ).toString(),
          'RCH05')) {
        await Navigator.push(
          context,
          PageTransition(
            type: PageTransitionType.rightToLeft,
            duration: Duration(milliseconds: 50),
            reverseDuration: Duration(milliseconds: 50),
            child: RegisterCharity05Widget(),
          ),
        );
        return;
      }
      if (functions.compareStrings(
          getJsonField(
            (route?.jsonBody ?? ''),
            r'''$..currentPage''',
          ).toString(),
          'RVO00')) {
        await Navigator.push(
          context,
          PageTransition(
            type: PageTransitionType.rightToLeft,
            duration: Duration(milliseconds: 50),
            reverseDuration: Duration(milliseconds: 50),
            child: RegisterVolunteer00Widget(),
          ),
        );
        return;
      }
      if (functions.compareStrings(
          getJsonField(
            (route?.jsonBody ?? ''),
            r'''$..currentPage''',
          ).toString(),
          'RVO01')) {
        await Navigator.push(
          context,
          PageTransition(
            type: PageTransitionType.rightToLeft,
            duration: Duration(milliseconds: 50),
            reverseDuration: Duration(milliseconds: 50),
            child: RegisterVolunteer01Widget(),
          ),
        );
        return;
      }
      if (functions.compareStrings(
          getJsonField(
            (route?.jsonBody ?? ''),
            r'''$..currentPage''',
          ).toString(),
          'RVO02')) {
        await Navigator.push(
          context,
          PageTransition(
            type: PageTransitionType.rightToLeft,
            duration: Duration(milliseconds: 50),
            reverseDuration: Duration(milliseconds: 50),
            child: RegisterVolunteer02Widget(),
          ),
        );
        return;
      }
      if (functions.compareStrings(
          getJsonField(
            (route?.jsonBody ?? ''),
            r'''$..currentPage''',
          ).toString(),
          'RVO03')) {
        await Navigator.push(
          context,
          PageTransition(
            type: PageTransitionType.rightToLeft,
            duration: Duration(milliseconds: 50),
            reverseDuration: Duration(milliseconds: 50),
            child: RegisterVolunteer03Widget(),
          ),
        );
        return;
      }
      if (functions.compareStrings(
          getJsonField(
            (route?.jsonBody ?? ''),
            r'''$..currentPage''',
          ).toString(),
          'RVO04')) {
        await Navigator.push(
          context,
          PageTransition(
            type: PageTransitionType.rightToLeft,
            duration: Duration(milliseconds: 50),
            reverseDuration: Duration(milliseconds: 50),
            child: RegisterVolunteer04Widget(),
          ),
        );
        return;
      }
      if (functions.compareStrings(
          getJsonField(
            (route?.jsonBody ?? ''),
            r'''$..currentPage''',
          ).toString(),
          'RVO05')) {
        await Navigator.push(
          context,
          PageTransition(
            type: PageTransitionType.rightToLeft,
            duration: Duration(milliseconds: 50),
            reverseDuration: Duration(milliseconds: 50),
            child: RegisterVolunteer05Widget(),
          ),
        );
        return;
      }
      if (functions.compareStrings(
          getJsonField(
            (route?.jsonBody ?? ''),
            r'''$..currentPage''',
          ).toString(),
          'RVO06')) {
        await Navigator.push(
          context,
          PageTransition(
            type: PageTransitionType.rightToLeft,
            duration: Duration(milliseconds: 50),
            reverseDuration: Duration(milliseconds: 50),
            child: RegisterVolunteer06Widget(),
          ),
        );
        return;
      }
      if (functions.compareStrings(
          getJsonField(
            (route?.jsonBody ?? ''),
            r'''$..currentPage''',
          ).toString(),
          'RVO07')) {
        await Navigator.push(
          context,
          PageTransition(
            type: PageTransitionType.rightToLeft,
            duration: Duration(milliseconds: 50),
            reverseDuration: Duration(milliseconds: 50),
            child: RegisterVolunteer07Widget(),
          ),
        );
        return;
      }
      if (functions.compareStrings(
          getJsonField(
            (route?.jsonBody ?? ''),
            r'''$..currentPage''',
          ).toString(),
          'RVO08')) {
        await Navigator.push(
          context,
          PageTransition(
            type: PageTransitionType.rightToLeft,
            duration: Duration(milliseconds: 50),
            reverseDuration: Duration(milliseconds: 50),
            child: RegisterVolunteer08Widget(),
          ),
        );
        return;
      }
      if (functions.compareStrings(
          getJsonField(
            (route?.jsonBody ?? ''),
            r'''$..currentPage''',
          ).toString(),
          'RVO09')) {
        await Navigator.push(
          context,
          PageTransition(
            type: PageTransitionType.rightToLeft,
            duration: Duration(milliseconds: 50),
            reverseDuration: Duration(milliseconds: 50),
            child: RegisterVolunteer09Widget(),
          ),
        );
        return;
      }
      if (functions.compareStrings(
          getJsonField(
            (route?.jsonBody ?? ''),
            r'''$..currentPage''',
          ).toString(),
          'RFM00')) {
        await Navigator.push(
          context,
          PageTransition(
            type: PageTransitionType.rightToLeft,
            duration: Duration(milliseconds: 50),
            reverseDuration: Duration(milliseconds: 50),
            child: RegisterFamilyAcc00Widget(),
          ),
        );
        return;
      }
      if (functions.compareStrings(
          getJsonField(
            (route?.jsonBody ?? ''),
            r'''$..currentPage''',
          ).toString(),
          'RFM01')) {
        await Navigator.push(
          context,
          PageTransition(
            type: PageTransitionType.rightToLeft,
            duration: Duration(milliseconds: 50),
            reverseDuration: Duration(milliseconds: 50),
            child: RegisterFamilyAcc01Widget(),
          ),
        );
        return;
      }
      if (functions.compareStrings(
          getJsonField(
            (route?.jsonBody ?? ''),
            r'''$..currentPage''',
          ).toString(),
          'RFN00')) {
        await Navigator.push(
          context,
          PageTransition(
            type: PageTransitionType.rightToLeft,
            duration: Duration(milliseconds: 50),
            reverseDuration: Duration(milliseconds: 50),
            child: RegisterFan00Widget(),
          ),
        );
        return;
      }
      if (functions.compareStrings(
          getJsonField(
            (route?.jsonBody ?? ''),
            r'''$..currentPage''',
          ).toString(),
          'RFN01')) {
        await Navigator.push(
          context,
          PageTransition(
            type: PageTransitionType.rightToLeft,
            duration: Duration(milliseconds: 50),
            reverseDuration: Duration(milliseconds: 50),
            child: RegisterFan01Widget(),
          ),
        );
        return;
      }
      if (functions.compareStrings(
          getJsonField(
            (route?.jsonBody ?? ''),
            r'''$..currentPage''',
          ).toString(),
          'RFN02')) {
        await Navigator.push(
          context,
          PageTransition(
            type: PageTransitionType.rightToLeft,
            duration: Duration(milliseconds: 50),
            reverseDuration: Duration(milliseconds: 50),
            child: RegisterFan02Widget(),
          ),
        );
        return;
      }
      await Navigator.push(
        context,
        PageTransition(
          type: PageTransitionType.rightToLeft,
          duration: Duration(milliseconds: 50),
          reverseDuration: Duration(milliseconds: 50),
          child: RegisterRoleSelectWidget(),
        ),
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: scaffoldKey,
      backgroundColor: Color(0xFF274078),
      body: SafeArea(
        child: GestureDetector(
          onTap: () => FocusScope.of(context).unfocus(),
          child: Column(
            mainAxisSize: MainAxisSize.max,
            children: [
              AppHeaderWidget(),
              Padding(
                padding: EdgeInsetsDirectional.fromSTEB(0, 40, 0, 0),
                child: Text(
                  FFLocalizations.of(context).getText(
                    'zemjutf7' /* GETTING STARTED */,
                  ),
                  style: FlutterFlowTheme.of(context).bodyText1,
                ),
              ),
              if (functions.returnFalse())
                Padding(
                  padding: EdgeInsetsDirectional.fromSTEB(0, 20, 0, 0),
                  child: Container(
                    width: 100,
                    height: 80,
                    decoration: BoxDecoration(
                      border: Border.all(
                        color: Colors.white,
                      ),
                    ),
                    child: Column(
                      mainAxisSize: MainAxisSize.max,
                      children: [
                        Text(
                          getJsonField(
                            (route?.jsonBody ?? ''),
                            r'''$..currentPage''',
                          ).toString(),
                          style:
                              FlutterFlowTheme.of(context).bodyText1.override(
                                    fontFamily: 'Poppins',
                                    color: Colors.white,
                                  ),
                        ),
                        Padding(
                          padding: EdgeInsetsDirectional.fromSTEB(0, 20, 0, 0),
                          child: Text(
                            FFAppState().sessionRefreshToken,
                            style:
                                FlutterFlowTheme.of(context).bodyText1.override(
                                      fontFamily: 'Poppins',
                                      color: Colors.white,
                                    ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}
