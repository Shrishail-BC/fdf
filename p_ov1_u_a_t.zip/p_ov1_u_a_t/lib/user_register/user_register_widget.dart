import '../backend/api_requests/api_calls.dart';
import '../components/app_header_widget.dart';
import '../components/app_nav_bar_widget.dart';
import '../flutter_flow/flutter_flow_theme.dart';
import '../flutter_flow/flutter_flow_util.dart';
import '../flutter_flow/flutter_flow_widgets.dart';
import '../register_business_partner_00/register_business_partner00_widget.dart';
import '../register_captain_00/register_captain00_widget.dart';
import '../register_charity_00/register_charity00_widget.dart';
import '../register_family_acc_00/register_family_acc00_widget.dart';
import '../register_fan_00/register_fan00_widget.dart';
import '../register_free_agent_00/register_free_agent00_widget.dart';
import '../register_player_00/register_player00_widget.dart';
import '../register_referee_00/register_referee00_widget.dart';
import '../register_volunteer_00/register_volunteer00_widget.dart';
import '../custom_code/actions/index.dart' as actions;
import 'package:easy_debounce/easy_debounce.dart';
import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:google_fonts/google_fonts.dart';

class UserRegisterWidget extends StatefulWidget {
  const UserRegisterWidget({
    Key? key,
    this.poRegType,
  }) : super(key: key);

  final String? poRegType;

  @override
  _UserRegisterWidgetState createState() => _UserRegisterWidgetState();
}

class _UserRegisterWidgetState extends State<UserRegisterWidget> {
  ApiCallResponse? apiSessionDetails;
  TextEditingController? textFieldEmailController;
  TextEditingController? textFieldPController;

  late bool textFieldPVisibility;
  final formKey = GlobalKey<FormState>();
  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    textFieldEmailController = TextEditingController();
    textFieldPController = TextEditingController();
    textFieldPVisibility = false;
  }

  @override
  void dispose() {
    textFieldEmailController?.dispose();
    textFieldPController?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: scaffoldKey,
      backgroundColor: Color(0xFF274078),
      drawer: Drawer(
        elevation: 16,
      ),
      body: SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.max,
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Material(
              color: Colors.transparent,
              elevation: 6,
              child: Container(
                width: MediaQuery.of(context).size.width,
                height: MediaQuery.of(context).size.height * 0.06,
                decoration: BoxDecoration(),
                child: Padding(
                  padding: EdgeInsetsDirectional.fromSTEB(10, 0, 0, 0),
                  child: Row(
                    mainAxisSize: MainAxisSize.max,
                    children: [
                      Expanded(
                        child: AppHeaderWidget(),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            Container(
              width: MediaQuery.of(context).size.width,
              height: MediaQuery.of(context).size.height * 0.875,
              decoration: BoxDecoration(),
              child: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.max,
                  children: [
                    Form(
                      key: formKey,
                      autovalidateMode: AutovalidateMode.always,
                      child: SingleChildScrollView(
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Padding(
                              padding:
                                  EdgeInsetsDirectional.fromSTEB(0, 30, 0, 0),
                              child: Wrap(
                                spacing: 0,
                                runSpacing: 0,
                                alignment: WrapAlignment.start,
                                crossAxisAlignment: WrapCrossAlignment.start,
                                direction: Axis.horizontal,
                                runAlignment: WrapAlignment.start,
                                verticalDirection: VerticalDirection.down,
                                clipBehavior: Clip.none,
                                children: [
                                  Align(
                                    alignment: AlignmentDirectional(0, 0),
                                    child: Text(
                                      FFLocalizations.of(context).getText(
                                        'hyuh99qi' /* You are almost there! */,
                                      ),
                                      textAlign: TextAlign.center,
                                      style: FlutterFlowTheme.of(context)
                                          .title1
                                          .override(
                                            fontFamily: 'Poppins',
                                            color: FlutterFlowTheme.of(context)
                                                .tertiaryColor,
                                          ),
                                    ),
                                  ),
                                  Align(
                                    alignment: AlignmentDirectional(0, 0),
                                    child: Text(
                                      FFLocalizations.of(context).getText(
                                        'i6d6fifx' /* Experience the world's largest... */,
                                      ),
                                      textAlign: TextAlign.center,
                                      style: FlutterFlowTheme.of(context)
                                          .title2
                                          .override(
                                            fontFamily: 'Poppins',
                                            fontStyle: FontStyle.italic,
                                          ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Align(
                              alignment: AlignmentDirectional(0, 0),
                              child: Padding(
                                padding:
                                    EdgeInsetsDirectional.fromSTEB(0, 40, 0, 0),
                                child: Column(
                                  mainAxisSize: MainAxisSize.max,
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Align(
                                      alignment: AlignmentDirectional(0, 0),
                                      child: Container(
                                        width: 400,
                                        height: 350,
                                        decoration: BoxDecoration(
                                          color: Colors.transparent,
                                          boxShadow: [
                                            BoxShadow(
                                              blurRadius: 2,
                                              color: Colors.transparent,
                                              offset: Offset(2, 2),
                                              spreadRadius: 2,
                                            )
                                          ],
                                          border: Border.all(
                                            color: FlutterFlowTheme.of(context)
                                                .tertiaryColor,
                                          ),
                                        ),
                                        child: Padding(
                                          padding:
                                              EdgeInsetsDirectional.fromSTEB(
                                                  0, 30, 0, 0),
                                          child: Wrap(
                                            spacing: 0,
                                            runSpacing: 0,
                                            alignment: WrapAlignment.center,
                                            crossAxisAlignment:
                                                WrapCrossAlignment.start,
                                            direction: Axis.horizontal,
                                            runAlignment: WrapAlignment.start,
                                            verticalDirection:
                                                VerticalDirection.down,
                                            clipBehavior: Clip.none,
                                            children: [
                                              Padding(
                                                padding: EdgeInsetsDirectional
                                                    .fromSTEB(0, 0, 0, 15),
                                                child: Text(
                                                  FFLocalizations.of(context)
                                                      .getText(
                                                    'u1ox94vi' /* Create Your Play On! Account */,
                                                  ),
                                                  style: FlutterFlowTheme.of(
                                                          context)
                                                      .bodyText1
                                                      .override(
                                                        fontFamily: 'Poppins',
                                                        color:
                                                            Color(0xFFFFC107),
                                                        fontSize: 18,
                                                        fontStyle:
                                                            FontStyle.italic,
                                                      ),
                                                ),
                                              ),
                                              Align(
                                                alignment:
                                                    AlignmentDirectional(0, 0),
                                                child: Padding(
                                                  padding: EdgeInsetsDirectional
                                                      .fromSTEB(10, 10, 10, 10),
                                                  child: TextFormField(
                                                    controller:
                                                        textFieldEmailController,
                                                    onChanged: (_) =>
                                                        EasyDebounce.debounce(
                                                      'textFieldEmailController',
                                                      Duration(
                                                          milliseconds: 2000),
                                                      () => setState(() {}),
                                                    ),
                                                    obscureText: false,
                                                    decoration: InputDecoration(
                                                      labelText:
                                                          FFLocalizations.of(
                                                                  context)
                                                              .getText(
                                                        'yjlwizq5' /* Email Id */,
                                                      ),
                                                      hintText:
                                                          FFLocalizations.of(
                                                                  context)
                                                              .getText(
                                                        'lrqm59xj' /* Enter your email address */,
                                                      ),
                                                      enabledBorder:
                                                          UnderlineInputBorder(
                                                        borderSide: BorderSide(
                                                          color:
                                                              Color(0x00000000),
                                                          width: 1,
                                                        ),
                                                        borderRadius:
                                                            BorderRadius
                                                                .circular(4),
                                                      ),
                                                      focusedBorder:
                                                          UnderlineInputBorder(
                                                        borderSide: BorderSide(
                                                          color:
                                                              Color(0x00000000),
                                                          width: 1,
                                                        ),
                                                        borderRadius:
                                                            BorderRadius
                                                                .circular(4),
                                                      ),
                                                      errorBorder:
                                                          UnderlineInputBorder(
                                                        borderSide: BorderSide(
                                                          color:
                                                              Color(0x00000000),
                                                          width: 1,
                                                        ),
                                                        borderRadius:
                                                            BorderRadius
                                                                .circular(4),
                                                      ),
                                                      focusedErrorBorder:
                                                          UnderlineInputBorder(
                                                        borderSide: BorderSide(
                                                          color:
                                                              Color(0x00000000),
                                                          width: 1,
                                                        ),
                                                        borderRadius:
                                                            BorderRadius
                                                                .circular(4),
                                                      ),
                                                      filled: true,
                                                      fillColor: Colors.white,
                                                      contentPadding:
                                                          EdgeInsetsDirectional
                                                              .fromSTEB(
                                                                  4, 4, 4, 4),
                                                      prefixIcon: Icon(
                                                        Icons.email_outlined,
                                                      ),
                                                      suffixIcon:
                                                          textFieldEmailController!
                                                                  .text
                                                                  .isNotEmpty
                                                              ? InkWell(
                                                                  onTap:
                                                                      () async {
                                                                    textFieldEmailController
                                                                        ?.clear();
                                                                    setState(
                                                                        () {});
                                                                  },
                                                                  child: Icon(
                                                                    Icons.clear,
                                                                    color: Color(
                                                                        0xFF757575),
                                                                    size: 22,
                                                                  ),
                                                                )
                                                              : null,
                                                    ),
                                                    style: FlutterFlowTheme.of(
                                                            context)
                                                        .bodyText1
                                                        .override(
                                                          fontFamily: 'Poppins',
                                                          color: Colors.black,
                                                        ),
                                                    textAlign: TextAlign.start,
                                                    keyboardType: TextInputType
                                                        .emailAddress,
                                                    validator: (val) {
                                                      if (val == null ||
                                                          val.isEmpty) {
                                                        return FFLocalizations
                                                                .of(context)
                                                            .getText(
                                                          'rr6tn3iw' /* Field is required */,
                                                        );
                                                      }

                                                      if (val.length < 7) {
                                                        return FFLocalizations
                                                                .of(context)
                                                            .getText(
                                                          'g30n0jlt' /* Minimum Length of 7 Characters */,
                                                        );
                                                      }

                                                      return null;
                                                    },
                                                  ),
                                                ),
                                              ),
                                              Padding(
                                                padding: EdgeInsetsDirectional
                                                    .fromSTEB(10, 10, 10, 10),
                                                child: TextFormField(
                                                  controller:
                                                      textFieldPController,
                                                  obscureText:
                                                      !textFieldPVisibility,
                                                  decoration: InputDecoration(
                                                    labelText:
                                                        FFLocalizations.of(
                                                                context)
                                                            .getText(
                                                      'sym2mcs9' /* Password */,
                                                    ),
                                                    hintText:
                                                        FFLocalizations.of(
                                                                context)
                                                            .getText(
                                                      '90q6439l' /* Min 1 Upper case, 1 lower case... */,
                                                    ),
                                                    enabledBorder:
                                                        UnderlineInputBorder(
                                                      borderSide: BorderSide(
                                                        color:
                                                            Color(0x00000000),
                                                        width: 1,
                                                      ),
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              4),
                                                    ),
                                                    focusedBorder:
                                                        UnderlineInputBorder(
                                                      borderSide: BorderSide(
                                                        color:
                                                            Color(0x00000000),
                                                        width: 1,
                                                      ),
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              4),
                                                    ),
                                                    errorBorder:
                                                        UnderlineInputBorder(
                                                      borderSide: BorderSide(
                                                        color:
                                                            Color(0x00000000),
                                                        width: 1,
                                                      ),
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              4),
                                                    ),
                                                    focusedErrorBorder:
                                                        UnderlineInputBorder(
                                                      borderSide: BorderSide(
                                                        color:
                                                            Color(0x00000000),
                                                        width: 1,
                                                      ),
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              4),
                                                    ),
                                                    filled: true,
                                                    fillColor: Colors.white,
                                                    prefixIcon: Icon(
                                                      Icons.enhanced_encryption,
                                                    ),
                                                    suffixIcon: InkWell(
                                                      onTap: () => setState(
                                                        () => textFieldPVisibility =
                                                            !textFieldPVisibility,
                                                      ),
                                                      focusNode: FocusNode(
                                                          skipTraversal: true),
                                                      child: Icon(
                                                        textFieldPVisibility
                                                            ? Icons
                                                                .visibility_outlined
                                                            : Icons
                                                                .visibility_off_outlined,
                                                        color:
                                                            Color(0xFF757575),
                                                        size: 22,
                                                      ),
                                                    ),
                                                  ),
                                                  style: FlutterFlowTheme.of(
                                                          context)
                                                      .bodyText1
                                                      .override(
                                                        fontFamily: 'Poppins',
                                                        color: Colors.black,
                                                      ),
                                                  validator: (val) {
                                                    if (val == null ||
                                                        val.isEmpty) {
                                                      return FFLocalizations.of(
                                                              context)
                                                          .getText(
                                                        'mdgouf7q' /* Field is required */,
                                                      );
                                                    }

                                                    if (val.length < 8) {
                                                      return FFLocalizations.of(
                                                              context)
                                                          .getText(
                                                        'laei86xx' /* Minimum Length of 8 Characters */,
                                                      );
                                                    }

                                                    return null;
                                                  },
                                                ),
                                              ),
                                              Padding(
                                                padding: EdgeInsetsDirectional
                                                    .fromSTEB(20, 20, 20, 20),
                                                child: FFButtonWidget(
                                                  onPressed: () async {
                                                    apiSessionDetails =
                                                        await NRegisterUserCall
                                                            .call(
                                                      loginId:
                                                          textFieldEmailController!
                                                              .text,
                                                      password:
                                                          textFieldPController!
                                                              .text,
                                                      applicationId:
                                                          FFAppState()
                                                              .applicationId,
                                                      defaultroleid:
                                                          FFAppState()
                                                              .roleSelected
                                                              .toString(),
                                                    );
                                                    if ((apiSessionDetails
                                                            ?.succeeded ??
                                                        true)) {
                                                      await showDialog(
                                                        context: context,
                                                        builder:
                                                            (alertDialogContext) {
                                                          return AlertDialog(
                                                            title: Text(
                                                                'Registered'),
                                                            content: Text(
                                                                'Registered'),
                                                            actions: [
                                                              TextButton(
                                                                onPressed: () =>
                                                                    Navigator.pop(
                                                                        alertDialogContext),
                                                                child:
                                                                    Text('Ok'),
                                                              ),
                                                            ],
                                                          );
                                                        },
                                                      );
                                                    } else {
                                                      await showDialog(
                                                        context: context,
                                                        builder:
                                                            (alertDialogContext) {
                                                          return AlertDialog(
                                                            title: Text(
                                                                'Unable to register'),
                                                            content: Text(
                                                                'Please contact support'),
                                                            actions: [
                                                              TextButton(
                                                                onPressed: () =>
                                                                    Navigator.pop(
                                                                        alertDialogContext),
                                                                child:
                                                                    Text('Ok'),
                                                              ),
                                                            ],
                                                          );
                                                        },
                                                      );
                                                    }

                                                    if (formKey.currentState ==
                                                            null ||
                                                        !formKey.currentState!
                                                            .validate()) {
                                                      return;
                                                    }

                                                    await actions.setSession(
                                                      getJsonField(
                                                        (apiSessionDetails
                                                                ?.jsonBody ??
                                                            ''),
                                                        r'''$..refreshToken''',
                                                      ).toString(),
                                                      getJsonField(
                                                        (apiSessionDetails
                                                                ?.jsonBody ??
                                                            ''),
                                                        r'''$..token''',
                                                      ).toString(),
                                                      getJsonField(
                                                        (apiSessionDetails
                                                                ?.jsonBody ??
                                                            ''),
                                                        r'''$..passwordChangeRequired''',
                                                      ).toString(),
                                                      getJsonField(
                                                        (apiSessionDetails
                                                                ?.jsonBody ??
                                                            ''),
                                                        r'''$..passwordLastUpdatedInstant''',
                                                      ).toString(),
                                                      getJsonField(
                                                        (apiSessionDetails
                                                                ?.jsonBody ??
                                                            ''),
                                                        r'''$..lastLoginInstant''',
                                                      ).toString(),
                                                      getJsonField(
                                                        (apiSessionDetails
                                                                ?.jsonBody ??
                                                            ''),
                                                        r'''$..active''',
                                                      ).toString(),
                                                      getJsonField(
                                                        (apiSessionDetails
                                                                ?.jsonBody ??
                                                            ''),
                                                        r'''$..verified''',
                                                      ).toString(),
                                                      getJsonField(
                                                        (apiSessionDetails
                                                                ?.jsonBody ??
                                                            ''),
                                                        r'''$..usernameStatus''',
                                                      ).toString(),
                                                      textFieldEmailController!
                                                          .text,
                                                    );
                                                    if (widget.poRegType ==
                                                        'Captain') {
                                                      await Navigator.push(
                                                        context,
                                                        PageTransition(
                                                          type:
                                                              PageTransitionType
                                                                  .rightToLeft,
                                                          duration: Duration(
                                                              milliseconds: 50),
                                                          reverseDuration:
                                                              Duration(
                                                                  milliseconds:
                                                                      50),
                                                          child:
                                                              RegisterCaptain00Widget(),
                                                        ),
                                                      );
                                                    }
                                                    if (widget.poRegType ==
                                                        'Player') {
                                                      await Navigator.push(
                                                        context,
                                                        PageTransition(
                                                          type:
                                                              PageTransitionType
                                                                  .rightToLeft,
                                                          duration: Duration(
                                                              milliseconds: 50),
                                                          reverseDuration:
                                                              Duration(
                                                                  milliseconds:
                                                                      50),
                                                          child:
                                                              RegisterPlayer00Widget(),
                                                        ),
                                                      );
                                                    }
                                                    if (widget.poRegType ==
                                                        'FreeAgent') {
                                                      await Navigator.push(
                                                        context,
                                                        PageTransition(
                                                          type:
                                                              PageTransitionType
                                                                  .rightToLeft,
                                                          duration: Duration(
                                                              milliseconds: 50),
                                                          reverseDuration:
                                                              Duration(
                                                                  milliseconds:
                                                                      50),
                                                          child:
                                                              RegisterFreeAgent00Widget(),
                                                        ),
                                                      );
                                                    }
                                                    if (widget.poRegType ==
                                                        'Family') {
                                                      await Navigator.push(
                                                        context,
                                                        PageTransition(
                                                          type:
                                                              PageTransitionType
                                                                  .rightToLeft,
                                                          duration: Duration(
                                                              milliseconds: 50),
                                                          reverseDuration:
                                                              Duration(
                                                                  milliseconds:
                                                                      50),
                                                          child:
                                                              RegisterFamilyAcc00Widget(),
                                                        ),
                                                      );
                                                    }
                                                    if (widget.poRegType ==
                                                        'Volunteer') {
                                                      await Navigator.push(
                                                        context,
                                                        PageTransition(
                                                          type:
                                                              PageTransitionType
                                                                  .rightToLeft,
                                                          duration: Duration(
                                                              milliseconds: 50),
                                                          reverseDuration:
                                                              Duration(
                                                                  milliseconds:
                                                                      50),
                                                          child:
                                                              RegisterVolunteer00Widget(),
                                                        ),
                                                      );
                                                    }
                                                    if (widget.poRegType ==
                                                        'Referee') {
                                                      await Navigator.push(
                                                        context,
                                                        PageTransition(
                                                          type:
                                                              PageTransitionType
                                                                  .rightToLeft,
                                                          duration: Duration(
                                                              milliseconds: 50),
                                                          reverseDuration:
                                                              Duration(
                                                                  milliseconds:
                                                                      50),
                                                          child:
                                                              RegisterReferee00Widget(),
                                                        ),
                                                      );
                                                    }
                                                    if (widget.poRegType ==
                                                        'Charity') {
                                                      await Navigator.push(
                                                        context,
                                                        PageTransition(
                                                          type:
                                                              PageTransitionType
                                                                  .rightToLeft,
                                                          duration: Duration(
                                                              milliseconds: 50),
                                                          reverseDuration:
                                                              Duration(
                                                                  milliseconds:
                                                                      50),
                                                          child:
                                                              RegisterCharity00Widget(),
                                                        ),
                                                      );
                                                    }
                                                    if (widget.poRegType ==
                                                        'BusinessPartner') {
                                                      await Navigator.push(
                                                        context,
                                                        PageTransition(
                                                          type:
                                                              PageTransitionType
                                                                  .rightToLeft,
                                                          duration: Duration(
                                                              milliseconds: 50),
                                                          reverseDuration:
                                                              Duration(
                                                                  milliseconds:
                                                                      50),
                                                          child:
                                                              RegisterBusinessPartner00Widget(),
                                                        ),
                                                      );
                                                    }
                                                    if (widget.poRegType ==
                                                        'Fan') {
                                                      await Navigator.push(
                                                        context,
                                                        PageTransition(
                                                          type:
                                                              PageTransitionType
                                                                  .rightToLeft,
                                                          duration: Duration(
                                                              milliseconds: 50),
                                                          reverseDuration:
                                                              Duration(
                                                                  milliseconds:
                                                                      50),
                                                          child:
                                                              RegisterFan00Widget(),
                                                        ),
                                                      );
                                                    }

                                                    setState(() {});
                                                  },
                                                  text: FFLocalizations.of(
                                                          context)
                                                      .getText(
                                                    'p082ilv5' /* Create account */,
                                                  ),
                                                  icon: Icon(
                                                    Icons
                                                        .sports_hockey_outlined,
                                                    color: Color(0xFFB3B3B3),
                                                    size: 15,
                                                  ),
                                                  options: FFButtonOptions(
                                                    width: 200,
                                                    height: 40,
                                                    color: Colors.white,
                                                    textStyle: FlutterFlowTheme
                                                            .of(context)
                                                        .subtitle2
                                                        .override(
                                                          fontFamily: 'Poppins',
                                                          color: Colors.black,
                                                        ),
                                                    borderSide: BorderSide(
                                                      color: Colors.transparent,
                                                      width: 1,
                                                    ),
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            6),
                                                  ),
                                                ),
                                              ),
                                              Padding(
                                                padding: EdgeInsetsDirectional
                                                    .fromSTEB(20, 20, 20, 20),
                                                child: FFButtonWidget(
                                                  onPressed: () async {
                                                    if (widget.poRegType ==
                                                        'Captain') {
                                                      await Navigator.push(
                                                        context,
                                                        PageTransition(
                                                          type:
                                                              PageTransitionType
                                                                  .rightToLeft,
                                                          duration: Duration(
                                                              milliseconds: 50),
                                                          reverseDuration:
                                                              Duration(
                                                                  milliseconds:
                                                                      50),
                                                          child:
                                                              RegisterCaptain00Widget(),
                                                        ),
                                                      );
                                                    }
                                                    if (widget.poRegType ==
                                                        'Player') {
                                                      await Navigator.push(
                                                        context,
                                                        PageTransition(
                                                          type:
                                                              PageTransitionType
                                                                  .rightToLeft,
                                                          duration: Duration(
                                                              milliseconds: 50),
                                                          reverseDuration:
                                                              Duration(
                                                                  milliseconds:
                                                                      50),
                                                          child:
                                                              RegisterPlayer00Widget(),
                                                        ),
                                                      );
                                                    }
                                                    if (widget.poRegType ==
                                                        'FreeAgent') {
                                                      await Navigator.push(
                                                        context,
                                                        PageTransition(
                                                          type:
                                                              PageTransitionType
                                                                  .rightToLeft,
                                                          duration: Duration(
                                                              milliseconds: 50),
                                                          reverseDuration:
                                                              Duration(
                                                                  milliseconds:
                                                                      50),
                                                          child:
                                                              RegisterFreeAgent00Widget(),
                                                        ),
                                                      );
                                                    }
                                                    if (widget.poRegType ==
                                                        'Family') {
                                                      await Navigator.push(
                                                        context,
                                                        PageTransition(
                                                          type:
                                                              PageTransitionType
                                                                  .rightToLeft,
                                                          duration: Duration(
                                                              milliseconds: 50),
                                                          reverseDuration:
                                                              Duration(
                                                                  milliseconds:
                                                                      50),
                                                          child:
                                                              RegisterFamilyAcc00Widget(),
                                                        ),
                                                      );
                                                    }
                                                    if (widget.poRegType ==
                                                        'Volunteer') {
                                                      await Navigator.push(
                                                        context,
                                                        PageTransition(
                                                          type:
                                                              PageTransitionType
                                                                  .rightToLeft,
                                                          duration: Duration(
                                                              milliseconds: 50),
                                                          reverseDuration:
                                                              Duration(
                                                                  milliseconds:
                                                                      50),
                                                          child:
                                                              RegisterVolunteer00Widget(),
                                                        ),
                                                      );
                                                    }
                                                    if (widget.poRegType ==
                                                        'Referee') {
                                                      await Navigator.push(
                                                        context,
                                                        PageTransition(
                                                          type:
                                                              PageTransitionType
                                                                  .rightToLeft,
                                                          duration: Duration(
                                                              milliseconds: 50),
                                                          reverseDuration:
                                                              Duration(
                                                                  milliseconds:
                                                                      50),
                                                          child:
                                                              RegisterReferee00Widget(),
                                                        ),
                                                      );
                                                    }
                                                    if (widget.poRegType ==
                                                        'Charity') {
                                                      await Navigator.push(
                                                        context,
                                                        PageTransition(
                                                          type:
                                                              PageTransitionType
                                                                  .rightToLeft,
                                                          duration: Duration(
                                                              milliseconds: 50),
                                                          reverseDuration:
                                                              Duration(
                                                                  milliseconds:
                                                                      50),
                                                          child:
                                                              RegisterCharity00Widget(),
                                                        ),
                                                      );
                                                    }
                                                    if (widget.poRegType ==
                                                        'BusinessPartner') {
                                                      await Navigator.push(
                                                        context,
                                                        PageTransition(
                                                          type:
                                                              PageTransitionType
                                                                  .rightToLeft,
                                                          duration: Duration(
                                                              milliseconds: 50),
                                                          reverseDuration:
                                                              Duration(
                                                                  milliseconds:
                                                                      50),
                                                          child:
                                                              RegisterBusinessPartner00Widget(),
                                                        ),
                                                      );
                                                    }
                                                    if (widget.poRegType ==
                                                        'Fan') {
                                                      await Navigator.push(
                                                        context,
                                                        PageTransition(
                                                          type:
                                                              PageTransitionType
                                                                  .rightToLeft,
                                                          duration: Duration(
                                                              milliseconds: 50),
                                                          reverseDuration:
                                                              Duration(
                                                                  milliseconds:
                                                                      50),
                                                          child:
                                                              RegisterFan00Widget(),
                                                        ),
                                                      );
                                                    }
                                                  },
                                                  text: FFLocalizations.of(
                                                          context)
                                                      .getText(
                                                    'fa1ncm5m' /* Test Login */,
                                                  ),
                                                  icon: Icon(
                                                    Icons
                                                        .sports_hockey_outlined,
                                                    color: Color(0xFFB3B3B3),
                                                    size: 15,
                                                  ),
                                                  options: FFButtonOptions(
                                                    width: 200,
                                                    height: 40,
                                                    color: Colors.white,
                                                    textStyle: FlutterFlowTheme
                                                            .of(context)
                                                        .subtitle2
                                                        .override(
                                                          fontFamily: 'Poppins',
                                                          color: Colors.black,
                                                        ),
                                                    borderSide: BorderSide(
                                                      color: Colors.transparent,
                                                      width: 1,
                                                    ),
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            6),
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Container(
              width: MediaQuery.of(context).size.width,
              height: MediaQuery.of(context).size.height * 0.06,
              decoration: BoxDecoration(
                color: Color(0xFFEEEEEE),
                borderRadius: BorderRadius.circular(50),
              ),
              child: AppNavBarWidget(),
            ),
          ],
        ),
      ),
    );
  }
}
