import '../backend/api_requests/api_calls.dart';
import '../components/active_arrow_widget.dart';
import '../components/app_header_widget.dart';
import '../components/menu_widget.dart';
import '../components/steper_circal_completdpage_widget.dart';
import '../components/stepper_circal_current_page_widget.dart';
import '../components/stepper_circal_pendingpage_widget.dart';
import '../components/unactive_arrow_widget.dart';
import '../flutter_flow/flutter_flow_drop_down.dart';
import '../flutter_flow/flutter_flow_theme.dart';
import '../flutter_flow/flutter_flow_util.dart';
import '../flutter_flow/flutter_flow_widgets.dart';
import '../register_business_partner_05/register_business_partner05_widget.dart';
import '../custom_code/widgets/index.dart' as custom_widgets;
import '../flutter_flow/custom_functions.dart' as functions;
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:percent_indicator/percent_indicator.dart';

class RegisterBusinessPartner04Widget extends StatefulWidget {
  const RegisterBusinessPartner04Widget({Key? key}) : super(key: key);

  @override
  _RegisterBusinessPartner04WidgetState createState() =>
      _RegisterBusinessPartner04WidgetState();
}

class _RegisterBusinessPartner04WidgetState
    extends State<RegisterBusinessPartner04Widget> {
  ApiCallResponse? apiCallOutput;
  final formKey = GlobalKey<FormState>();
  final scaffoldKey = GlobalKey<ScaffoldState>();
  String? dropDownValue;
  TextEditingController? textController;
  bool? checkboxListTileValue;

  @override
  void initState() {
    super.initState();
    // On page load action.
    SchedulerBinding.instance.addPostFrameCallback((_) async {
      apiCallOutput = await NCurrentPageSetCall.call(
        currentPage: 'RBP04',
        refreshToken: FFAppState().sessionRefreshToken,
      );
    });

    textController = TextEditingController(text: FFAppState().otherindustry);
  }

  @override
  void dispose() {
    textController?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: scaffoldKey,
      backgroundColor: Color(0xFF274078),
      drawer: Container(
        width: 250,
        child: Drawer(
          elevation: 16,
          child: MenuWidget(),
        ),
      ),
      body: SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.max,
          children: [
            Column(
              mainAxisSize: MainAxisSize.max,
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Row(
                  mainAxisSize: MainAxisSize.max,
                  children: [
                    AppHeaderWidget(),
                  ],
                ),
                Container(
                  width: MediaQuery.of(context).size.width,
                  height: MediaQuery.of(context).size.height * 0.84,
                  decoration: BoxDecoration(),
                  child: SingleChildScrollView(
                    child: Column(
                      mainAxisSize: MainAxisSize.max,
                      children: [
                        Align(
                          alignment: AlignmentDirectional(0, -1),
                          child: Container(
                            width: 1200,
                            height: MediaQuery.of(context).size.height * 0.84,
                            decoration: BoxDecoration(),
                            child: SingleChildScrollView(
                              child: Column(
                                mainAxisSize: MainAxisSize.max,
                                children: [
                                  Align(
                                    alignment: AlignmentDirectional(0, 0),
                                    child: Padding(
                                      padding: EdgeInsetsDirectional.fromSTEB(
                                          0, 10, 0, 0),
                                      child: Column(
                                        mainAxisSize: MainAxisSize.min,
                                        mainAxisAlignment:
                                            MainAxisAlignment.center,
                                        crossAxisAlignment:
                                            CrossAxisAlignment.center,
                                        children: [
                                          Text(
                                            FFLocalizations.of(context).getText(
                                              'n9vd4d2f' /* Business Partner Registration */,
                                            ),
                                            textAlign: TextAlign.center,
                                            style: FlutterFlowTheme.of(context)
                                                .title1
                                                .override(
                                                  fontFamily: 'Poppins',
                                                  color: FlutterFlowTheme.of(
                                                          context)
                                                      .tertiaryColor,
                                                  fontSize: 24,
                                                  fontWeight: FontWeight.w600,
                                                ),
                                          ),
                                          if (responsiveVisibility(
                                            context: context,
                                            phone: false,
                                            tablet: false,
                                          ))
                                            Padding(
                                              padding: EdgeInsetsDirectional
                                                  .fromSTEB(0, 10, 0, 0),
                                              child: Wrap(
                                                spacing: 0,
                                                runSpacing: 0,
                                                alignment: WrapAlignment.center,
                                                crossAxisAlignment:
                                                    WrapCrossAlignment.start,
                                                direction: Axis.horizontal,
                                                runAlignment:
                                                    WrapAlignment.start,
                                                verticalDirection:
                                                    VerticalDirection.down,
                                                clipBehavior: Clip.none,
                                                children: [
                                                  SteperCircalCompletdpageWidget(
                                                    stepName:
                                                        'Organization Details',
                                                  ),
                                                  ActiveArrowWidget(),
                                                  SteperCircalCompletdpageWidget(
                                                    stepName: 'Contact Details',
                                                  ),
                                                  ActiveArrowWidget(),
                                                  SteperCircalCompletdpageWidget(
                                                    stepName: 'Event Selection',
                                                  ),
                                                  ActiveArrowWidget(),
                                                  StepperCircalCurrentPageWidget(
                                                    stepName: 'Confirmation',
                                                    stepNumber: 4,
                                                  ),
                                                  UnactiveArrowWidget(),
                                                  StepperCircalPendingpageWidget(
                                                    stepName: 'Coupon Details',
                                                    stepNumber: 5,
                                                  ),
                                                  UnactiveArrowWidget(),
                                                  StepperCircalPendingpageWidget(
                                                    stepName:
                                                        'Terms and Conditions',
                                                    stepNumber: 6,
                                                  ),
                                                ],
                                              ),
                                            ),
                                        ],
                                      ),
                                    ),
                                  ),
                                  Padding(
                                    padding: EdgeInsetsDirectional.fromSTEB(
                                        0, 10, 0, 0),
                                    child: Container(
                                      width: 250,
                                      height: 24,
                                      decoration: BoxDecoration(),
                                      child: Visibility(
                                        visible: responsiveVisibility(
                                          context: context,
                                          tabletLandscape: false,
                                          desktop: false,
                                        ),
                                        child: Align(
                                          alignment: AlignmentDirectional(0, 0),
                                          child: LinearPercentIndicator(
                                            percent: 0.71,
                                            width: 250,
                                            lineHeight: 24,
                                            animation: true,
                                            progressColor: Color(0xFFFF0E07),
                                            backgroundColor: Color(0xFFF1F4F8),
                                            center: Text(
                                              FFLocalizations.of(context)
                                                  .getText(
                                                'eilfczdt' /* 4 */,
                                              ),
                                              style:
                                                  FlutterFlowTheme.of(context)
                                                      .bodyText1
                                                      .override(
                                                        fontFamily: 'Poppins',
                                                        color:
                                                            FlutterFlowTheme.of(
                                                                    context)
                                                                .black,
                                                      ),
                                            ),
                                            barRadius: Radius.circular(10),
                                            padding: EdgeInsets.zero,
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                  Align(
                                    alignment: AlignmentDirectional(0, 0),
                                    child: SingleChildScrollView(
                                      child: Column(
                                        mainAxisSize: MainAxisSize.min,
                                        mainAxisAlignment:
                                            MainAxisAlignment.start,
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Padding(
                                            padding:
                                                EdgeInsetsDirectional.fromSTEB(
                                                    15, 0, 15, 0),
                                            child: SingleChildScrollView(
                                              child: Column(
                                                mainAxisSize: MainAxisSize.max,
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.start,
                                                children: [
                                                  Container(
                                                    width:
                                                        MediaQuery.of(context)
                                                                .size
                                                                .width *
                                                            0.9,
                                                    height: 5,
                                                    decoration: BoxDecoration(
                                                      color: Colors.transparent,
                                                    ),
                                                  ),
                                                  Form(
                                                    key: formKey,
                                                    autovalidateMode:
                                                        AutovalidateMode.always,
                                                    child: Padding(
                                                      padding:
                                                          EdgeInsetsDirectional
                                                              .fromSTEB(
                                                                  15, 0, 15, 0),
                                                      child: Column(
                                                        mainAxisSize:
                                                            MainAxisSize.min,
                                                        mainAxisAlignment:
                                                            MainAxisAlignment
                                                                .end,
                                                        crossAxisAlignment:
                                                            CrossAxisAlignment
                                                                .center,
                                                        children: [
                                                          Align(
                                                            alignment:
                                                                AlignmentDirectional(
                                                                    0, 1),
                                                            child: Padding(
                                                              padding:
                                                                  EdgeInsetsDirectional
                                                                      .fromSTEB(
                                                                          15,
                                                                          15,
                                                                          0,
                                                                          0),
                                                              child: Wrap(
                                                                spacing: 0,
                                                                runSpacing: 0,
                                                                alignment:
                                                                    WrapAlignment
                                                                        .start,
                                                                crossAxisAlignment:
                                                                    WrapCrossAlignment
                                                                        .start,
                                                                direction: Axis
                                                                    .horizontal,
                                                                runAlignment:
                                                                    WrapAlignment
                                                                        .start,
                                                                verticalDirection:
                                                                    VerticalDirection
                                                                        .down,
                                                                clipBehavior:
                                                                    Clip.none,
                                                                children: [
                                                                  Container(
                                                                    width: MediaQuery.of(
                                                                            context)
                                                                        .size
                                                                        .width,
                                                                    decoration:
                                                                        BoxDecoration(
                                                                      color: FlutterFlowTheme.of(
                                                                              context)
                                                                          .secondaryBackground,
                                                                    ),
                                                                    child: Row(
                                                                      mainAxisSize:
                                                                          MainAxisSize
                                                                              .max,
                                                                      children: [
                                                                        Padding(
                                                                          padding: EdgeInsetsDirectional.fromSTEB(
                                                                              0,
                                                                              0,
                                                                              10,
                                                                              0),
                                                                          child:
                                                                              Text(
                                                                            FFLocalizations.of(context).getText(
                                                                              '2jl17aw6' /* Event Name: */,
                                                                            ),
                                                                            style: FlutterFlowTheme.of(context).bodyText1.override(
                                                                                  fontFamily: 'Poppins',
                                                                                  fontSize: 16,
                                                                                ),
                                                                          ),
                                                                        ),
                                                                        Text(
                                                                          FFAppState()
                                                                              .selectedEventName,
                                                                          style: FlutterFlowTheme.of(context)
                                                                              .bodyText1
                                                                              .override(
                                                                                fontFamily: 'Poppins',
                                                                                color: FlutterFlowTheme.of(context).orange,
                                                                                fontSize: 16,
                                                                                fontWeight: FontWeight.bold,
                                                                              ),
                                                                        ),
                                                                      ],
                                                                    ),
                                                                  ),
                                                                ],
                                                              ),
                                                            ),
                                                          ),
                                                          Align(
                                                            alignment:
                                                                AlignmentDirectional(
                                                                    0, 1),
                                                            child: Padding(
                                                              padding:
                                                                  EdgeInsetsDirectional
                                                                      .fromSTEB(
                                                                          10,
                                                                          15,
                                                                          0,
                                                                          0),
                                                              child: Wrap(
                                                                spacing: 0,
                                                                runSpacing: 0,
                                                                alignment:
                                                                    WrapAlignment
                                                                        .start,
                                                                crossAxisAlignment:
                                                                    WrapCrossAlignment
                                                                        .center,
                                                                direction: Axis
                                                                    .horizontal,
                                                                runAlignment:
                                                                    WrapAlignment
                                                                        .end,
                                                                verticalDirection:
                                                                    VerticalDirection
                                                                        .down,
                                                                clipBehavior:
                                                                    Clip.none,
                                                                children: [
                                                                  Container(
                                                                    width: 550,
                                                                    decoration:
                                                                        BoxDecoration(
                                                                      color: Colors
                                                                          .transparent,
                                                                    ),
                                                                    child:
                                                                        Padding(
                                                                      padding: EdgeInsetsDirectional
                                                                          .fromSTEB(
                                                                              0,
                                                                              0,
                                                                              20,
                                                                              0),
                                                                      child: custom_widgets
                                                                          .OrientationBasedText(
                                                                        width: MediaQuery.of(context)
                                                                            .size
                                                                            .width,
                                                                        height:
                                                                            35,
                                                                        text:
                                                                            'Which of the following best describes your industry(Select one from your list):',
                                                                        textColor:
                                                                            FlutterFlowTheme.of(context).tertiaryColor,
                                                                        textSize:
                                                                            14.0,
                                                                        textFont:
                                                                            'Poppins',
                                                                        fontWeight:
                                                                            0,
                                                                        mobileAlignment:
                                                                            'L',
                                                                        desktopAlignment:
                                                                            'R',
                                                                      ),
                                                                    ),
                                                                  ),
                                                                  Container(
                                                                    width: 500,
                                                                    height: 50,
                                                                    decoration:
                                                                        BoxDecoration(
                                                                      color: Colors
                                                                          .transparent,
                                                                    ),
                                                                    child:
                                                                        FlutterFlowDropDown(
                                                                      initialOption:
                                                                          dropDownValue ??=
                                                                              FFAppState().industryname,
                                                                      options: [
                                                                        FFLocalizations.of(context)
                                                                            .getText(
                                                                          'mm9aamvp' /* Airline */,
                                                                        ),
                                                                        FFLocalizations.of(context)
                                                                            .getText(
                                                                          '4z8elxxt' /* Other */,
                                                                        )
                                                                      ],
                                                                      onChanged:
                                                                          (val) =>
                                                                              setState(() => dropDownValue = val),
                                                                      width:
                                                                          180,
                                                                      height:
                                                                          50,
                                                                      textStyle: FlutterFlowTheme.of(
                                                                              context)
                                                                          .bodyText1
                                                                          .override(
                                                                            fontFamily:
                                                                                'Poppins',
                                                                            color:
                                                                                Colors.black,
                                                                          ),
                                                                      hintText:
                                                                          FFLocalizations.of(context)
                                                                              .getText(
                                                                        '5d4t3dak' /* Please select your industry */,
                                                                      ),
                                                                      fillColor:
                                                                          Colors
                                                                              .white,
                                                                      elevation:
                                                                          2,
                                                                      borderColor:
                                                                          Colors
                                                                              .transparent,
                                                                      borderWidth:
                                                                          0,
                                                                      borderRadius:
                                                                          0,
                                                                      margin: EdgeInsetsDirectional
                                                                          .fromSTEB(
                                                                              12,
                                                                              4,
                                                                              12,
                                                                              4),
                                                                      hidesUnderline:
                                                                          true,
                                                                    ),
                                                                  ),
                                                                ],
                                                              ),
                                                            ),
                                                          ),
                                                          if (dropDownValue ==
                                                              'Other')
                                                            Align(
                                                              alignment:
                                                                  AlignmentDirectional(
                                                                      0, 1),
                                                              child: Padding(
                                                                padding:
                                                                    EdgeInsetsDirectional
                                                                        .fromSTEB(
                                                                            10,
                                                                            15,
                                                                            0,
                                                                            0),
                                                                child: Wrap(
                                                                  spacing: 0,
                                                                  runSpacing: 0,
                                                                  alignment:
                                                                      WrapAlignment
                                                                          .start,
                                                                  crossAxisAlignment:
                                                                      WrapCrossAlignment
                                                                          .center,
                                                                  direction: Axis
                                                                      .horizontal,
                                                                  runAlignment:
                                                                      WrapAlignment
                                                                          .end,
                                                                  verticalDirection:
                                                                      VerticalDirection
                                                                          .down,
                                                                  clipBehavior:
                                                                      Clip.none,
                                                                  children: [
                                                                    Container(
                                                                      width:
                                                                          550,
                                                                      decoration:
                                                                          BoxDecoration(
                                                                        color: Colors
                                                                            .transparent,
                                                                      ),
                                                                      child:
                                                                          Padding(
                                                                        padding: EdgeInsetsDirectional.fromSTEB(
                                                                            0,
                                                                            0,
                                                                            20,
                                                                            0),
                                                                        child: custom_widgets
                                                                            .OrientationBasedText(
                                                                          width: MediaQuery.of(context)
                                                                              .size
                                                                              .width,
                                                                          height:
                                                                              40,
                                                                          text:
                                                                              'If you selected \"Other industry\" above, please enter your industry here:',
                                                                          textColor:
                                                                              FlutterFlowTheme.of(context).tertiaryColor,
                                                                          textSize:
                                                                              14.0,
                                                                          textFont:
                                                                              'Poppins',
                                                                          fontWeight:
                                                                              0,
                                                                          mobileAlignment:
                                                                              'L',
                                                                          desktopAlignment:
                                                                              'R',
                                                                        ),
                                                                      ),
                                                                    ),
                                                                    Container(
                                                                      width:
                                                                          500,
                                                                      decoration:
                                                                          BoxDecoration(
                                                                        color: Colors
                                                                            .transparent,
                                                                      ),
                                                                      child:
                                                                          Align(
                                                                        alignment: AlignmentDirectional(
                                                                            0,
                                                                            0),
                                                                        child:
                                                                            TextFormField(
                                                                          controller:
                                                                              textController,
                                                                          obscureText:
                                                                              false,
                                                                          decoration:
                                                                              InputDecoration(
                                                                            hintText:
                                                                                FFLocalizations.of(context).getText(
                                                                              'wtnwrieo' /* Enter your other industry */,
                                                                            ),
                                                                            enabledBorder:
                                                                                UnderlineInputBorder(
                                                                              borderSide: BorderSide(
                                                                                color: Color(0x00000000),
                                                                                width: 1,
                                                                              ),
                                                                              borderRadius: BorderRadius.circular(4),
                                                                            ),
                                                                            focusedBorder:
                                                                                UnderlineInputBorder(
                                                                              borderSide: BorderSide(
                                                                                color: Color(0x00000000),
                                                                                width: 1,
                                                                              ),
                                                                              borderRadius: BorderRadius.circular(4),
                                                                            ),
                                                                            errorBorder:
                                                                                UnderlineInputBorder(
                                                                              borderSide: BorderSide(
                                                                                color: Color(0x00000000),
                                                                                width: 1,
                                                                              ),
                                                                              borderRadius: BorderRadius.circular(4),
                                                                            ),
                                                                            focusedErrorBorder:
                                                                                UnderlineInputBorder(
                                                                              borderSide: BorderSide(
                                                                                color: Color(0x00000000),
                                                                                width: 1,
                                                                              ),
                                                                              borderRadius: BorderRadius.circular(4),
                                                                            ),
                                                                            filled:
                                                                                true,
                                                                            fillColor:
                                                                                Colors.white,
                                                                          ),
                                                                          style: FlutterFlowTheme.of(context)
                                                                              .bodyText2
                                                                              .override(
                                                                                fontFamily: 'Poppins',
                                                                                color: FlutterFlowTheme.of(context).black,
                                                                              ),
                                                                          textAlign:
                                                                              TextAlign.start,
                                                                          maxLines:
                                                                              5,
                                                                          keyboardType:
                                                                              TextInputType.multiline,
                                                                        ),
                                                                      ),
                                                                    ),
                                                                  ],
                                                                ),
                                                              ),
                                                            ),
                                                          Align(
                                                            alignment:
                                                                AlignmentDirectional(
                                                                    0, 1),
                                                            child: Padding(
                                                              padding:
                                                                  EdgeInsetsDirectional
                                                                      .fromSTEB(
                                                                          10,
                                                                          15,
                                                                          0,
                                                                          0),
                                                              child: Wrap(
                                                                spacing: 0,
                                                                runSpacing: 0,
                                                                alignment:
                                                                    WrapAlignment
                                                                        .start,
                                                                crossAxisAlignment:
                                                                    WrapCrossAlignment
                                                                        .center,
                                                                direction: Axis
                                                                    .horizontal,
                                                                runAlignment:
                                                                    WrapAlignment
                                                                        .end,
                                                                verticalDirection:
                                                                    VerticalDirection
                                                                        .down,
                                                                clipBehavior:
                                                                    Clip.none,
                                                                children: [
                                                                  Container(
                                                                    width: 550,
                                                                    decoration:
                                                                        BoxDecoration(
                                                                      color: Colors
                                                                          .transparent,
                                                                    ),
                                                                    child:
                                                                        Padding(
                                                                      padding: EdgeInsetsDirectional
                                                                          .fromSTEB(
                                                                              0,
                                                                              0,
                                                                              20,
                                                                              0),
                                                                      child: custom_widgets
                                                                          .OrientationBasedText(
                                                                        width: MediaQuery.of(context)
                                                                            .size
                                                                            .width,
                                                                        height:
                                                                            40,
                                                                        text:
                                                                            'Please upload copy of your organization logo (Provide preferred format .png)',
                                                                        textColor:
                                                                            FlutterFlowTheme.of(context).tertiaryColor,
                                                                        textSize:
                                                                            14.0,
                                                                        textFont:
                                                                            'Poppins',
                                                                        fontWeight:
                                                                            0,
                                                                        mobileAlignment:
                                                                            'L',
                                                                        desktopAlignment:
                                                                            'R',
                                                                      ),
                                                                    ),
                                                                  ),
                                                                  Visibility(
                                                                    visible: FFAppState().uploadimgname ==
                                                                            null ||
                                                                        FFAppState().uploadimgname ==
                                                                            '',
                                                                    child:
                                                                        Padding(
                                                                      padding: EdgeInsetsDirectional
                                                                          .fromSTEB(
                                                                              0,
                                                                              0,
                                                                              10,
                                                                              0),
                                                                      child:
                                                                          Container(
                                                                        width:
                                                                            400,
                                                                        height:
                                                                            400,
                                                                        decoration:
                                                                            BoxDecoration(
                                                                          color:
                                                                              Colors.transparent,
                                                                        ),
                                                                        child:
                                                                            Stack(
                                                                          children: [
                                                                            Align(
                                                                              alignment: AlignmentDirectional(0, 0),
                                                                              child: Padding(
                                                                                padding: EdgeInsetsDirectional.fromSTEB(0, 0, 0, 20),
                                                                                child: custom_widgets.ImagePickerWidget(
                                                                                  width: 400,
                                                                                  height: 400,
                                                                                  textColor: Colors.black,
                                                                                  buttonBackground: Colors.white,
                                                                                  galleryText: 'Gallery',
                                                                                  cameraText: 'Camera',
                                                                                  clearText: 'Clear',
                                                                                  saveText: 'Save',
                                                                                ),
                                                                              ),
                                                                            ),
                                                                          ],
                                                                        ),
                                                                      ),
                                                                    ),
                                                                  ),
                                                                  Visibility(
                                                                    visible: FFAppState().uploadimgname !=
                                                                            null &&
                                                                        FFAppState().uploadimgname !=
                                                                            '',
                                                                    child:
                                                                        Padding(
                                                                      padding: EdgeInsetsDirectional
                                                                          .fromSTEB(
                                                                              0,
                                                                              0,
                                                                              10,
                                                                              0),
                                                                      child: FutureBuilder<
                                                                          ApiCallResponse>(
                                                                        future:
                                                                            BpRegistrationbCall.call(
                                                                          refreshToken:
                                                                              FFAppState().sessionRefreshToken,
                                                                          formstep:
                                                                              '100',
                                                                          description:
                                                                              FFAppState().uploadimgname,
                                                                        ),
                                                                        builder:
                                                                            (context,
                                                                                snapshot) {
                                                                          // Customize what your widget looks like when it's loading.
                                                                          if (!snapshot
                                                                              .hasData) {
                                                                            return Center(
                                                                              child: SizedBox(
                                                                                width: 50,
                                                                                height: 50,
                                                                                child: SpinKitHourGlass(
                                                                                  color: Color(0xFFFFC107),
                                                                                  size: 50,
                                                                                ),
                                                                              ),
                                                                            );
                                                                          }
                                                                          final containerBpRegistrationbResponse =
                                                                              snapshot.data!;
                                                                          return Container(
                                                                            width:
                                                                                400,
                                                                            height:
                                                                                400,
                                                                            decoration:
                                                                                BoxDecoration(
                                                                              color: Colors.transparent,
                                                                            ),
                                                                            child:
                                                                                Column(
                                                                              mainAxisSize: MainAxisSize.max,
                                                                              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                                                              children: [
                                                                                Container(
                                                                                  width: 350,
                                                                                  height: 350,
                                                                                  child: custom_widgets.Base64Image(
                                                                                    width: 350,
                                                                                    height: 350,
                                                                                    base64: getJsonField(
                                                                                      containerBpRegistrationbResponse.jsonBody,
                                                                                      r'''$..data''',
                                                                                    ).toString(),
                                                                                  ),
                                                                                ),
                                                                                Align(
                                                                                  alignment: AlignmentDirectional(-0.06, 0.94),
                                                                                  child: FFButtonWidget(
                                                                                    onPressed: () async {
                                                                                      setState(() => FFAppState().uploadimgname = '');
                                                                                    },
                                                                                    text: FFLocalizations.of(context).getText(
                                                                                      'gbg09eir' /* Re-upload */,
                                                                                    ),
                                                                                    options: FFButtonOptions(
                                                                                      width: 130,
                                                                                      height: 40,
                                                                                      color: FlutterFlowTheme.of(context).tertiaryColor,
                                                                                      textStyle: FlutterFlowTheme.of(context).subtitle2.override(
                                                                                            fontFamily: 'Poppins',
                                                                                            color: FlutterFlowTheme.of(context).black,
                                                                                          ),
                                                                                      borderSide: BorderSide(
                                                                                        color: Colors.transparent,
                                                                                        width: 1,
                                                                                      ),
                                                                                      borderRadius: BorderRadius.circular(8),
                                                                                    ),
                                                                                  ),
                                                                                ),
                                                                              ],
                                                                            ),
                                                                          );
                                                                        },
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ],
                                                              ),
                                                            ),
                                                          ),
                                                          Padding(
                                                            padding:
                                                                EdgeInsetsDirectional
                                                                    .fromSTEB(
                                                                        10,
                                                                        10,
                                                                        0,
                                                                        0),
                                                            child: Theme(
                                                              data: ThemeData(
                                                                unselectedWidgetColor:
                                                                    FlutterFlowTheme.of(
                                                                            context)
                                                                        .tertiaryColor,
                                                              ),
                                                              child:
                                                                  CheckboxListTile(
                                                                value: checkboxListTileValue ??=
                                                                    FFAppState()
                                                                        .confirmorg,
                                                                onChanged: (newValue) =>
                                                                    setState(() =>
                                                                        checkboxListTileValue =
                                                                            newValue!),
                                                                title: Text(
                                                                  FFLocalizations.of(
                                                                          context)
                                                                      .getText(
                                                                    'zs2cnydv' /* I confirm, I am employee with ... */,
                                                                  ),
                                                                  style: FlutterFlowTheme.of(
                                                                          context)
                                                                      .title3
                                                                      .override(
                                                                        fontFamily:
                                                                            'Poppins',
                                                                        color: FlutterFlowTheme.of(context)
                                                                            .tertiaryColor,
                                                                        fontSize:
                                                                            14,
                                                                      ),
                                                                ),
                                                                activeColor:
                                                                    FlutterFlowTheme.of(
                                                                            context)
                                                                        .tertiaryColor,
                                                                checkColor: Color(
                                                                    0xFF274078),
                                                                dense: true,
                                                                controlAffinity:
                                                                    ListTileControlAffinity
                                                                        .leading,
                                                              ),
                                                            ),
                                                          ),
                                                          Padding(
                                                            padding:
                                                                EdgeInsetsDirectional
                                                                    .fromSTEB(
                                                                        0,
                                                                        15,
                                                                        0,
                                                                        15),
                                                            child: Wrap(
                                                              spacing: 0,
                                                              runSpacing: 0,
                                                              alignment:
                                                                  WrapAlignment
                                                                      .center,
                                                              crossAxisAlignment:
                                                                  WrapCrossAlignment
                                                                      .center,
                                                              direction: Axis
                                                                  .horizontal,
                                                              runAlignment:
                                                                  WrapAlignment
                                                                      .center,
                                                              verticalDirection:
                                                                  VerticalDirection
                                                                      .up,
                                                              clipBehavior:
                                                                  Clip.none,
                                                              children: [
                                                                FFButtonWidget(
                                                                  onPressed:
                                                                      () async {
                                                                    Navigator.pop(
                                                                        context);
                                                                  },
                                                                  text: FFLocalizations.of(
                                                                          context)
                                                                      .getText(
                                                                    'nz5qlcog' /* Back  */,
                                                                  ),
                                                                  options:
                                                                      FFButtonOptions(
                                                                    width: 130,
                                                                    height: 40,
                                                                    color: Color(
                                                                        0xFF274078),
                                                                    textStyle: FlutterFlowTheme.of(
                                                                            context)
                                                                        .subtitle2
                                                                        .override(
                                                                          fontFamily:
                                                                              'Poppins',
                                                                          color:
                                                                              FlutterFlowTheme.of(context).tertiaryColor,
                                                                        ),
                                                                    borderSide:
                                                                        BorderSide(
                                                                      color: FlutterFlowTheme.of(
                                                                              context)
                                                                          .tertiaryColor,
                                                                      width: 1,
                                                                    ),
                                                                    borderRadius:
                                                                        BorderRadius.circular(
                                                                            40),
                                                                  ),
                                                                ),
                                                                Padding(
                                                                  padding: EdgeInsetsDirectional
                                                                      .fromSTEB(
                                                                          30,
                                                                          0,
                                                                          0,
                                                                          0),
                                                                  child:
                                                                      FFButtonWidget(
                                                                    onPressed:
                                                                        () async {
                                                                      if (formKey.currentState ==
                                                                              null ||
                                                                          !formKey
                                                                              .currentState!
                                                                              .validate()) {
                                                                        return;
                                                                      }

                                                                      if (dropDownValue ==
                                                                          null) {
                                                                        await showDialog(
                                                                          context:
                                                                              context,
                                                                          builder:
                                                                              (alertDialogContext) {
                                                                            return AlertDialog(
                                                                              content: Text('Please select your Industry'),
                                                                              actions: [
                                                                                TextButton(
                                                                                  onPressed: () => Navigator.pop(alertDialogContext),
                                                                                  child: Text('Ok'),
                                                                                ),
                                                                              ],
                                                                            );
                                                                          },
                                                                        );
                                                                        return;
                                                                      }

                                                                      if (!(dropDownValue !=
                                                                              null &&
                                                                          dropDownValue !=
                                                                              '')) {
                                                                        await showDialog(
                                                                          context:
                                                                              context,
                                                                          builder:
                                                                              (alertDialogContext) {
                                                                            return AlertDialog(
                                                                              content: Text('Please select your Industry'),
                                                                              actions: [
                                                                                TextButton(
                                                                                  onPressed: () => Navigator.pop(alertDialogContext),
                                                                                  child: Text('Ok'),
                                                                                ),
                                                                              ],
                                                                            );
                                                                          },
                                                                        );
                                                                        return;
                                                                      }
                                                                      if (dropDownValue ==
                                                                          'Other') {
                                                                        if (!(textController!.text !=
                                                                                null &&
                                                                            textController!.text !=
                                                                                '')) {
                                                                          await showDialog(
                                                                            context:
                                                                                context,
                                                                            builder:
                                                                                (alertDialogContext) {
                                                                              return AlertDialog(
                                                                                content: Text('Please enter your other industry '),
                                                                                actions: [
                                                                                  TextButton(
                                                                                    onPressed: () => Navigator.pop(alertDialogContext),
                                                                                    child: Text('Ok'),
                                                                                  ),
                                                                                ],
                                                                              );
                                                                            },
                                                                          );
                                                                          return;
                                                                        }
                                                                      }
                                                                      if (!checkboxListTileValue!) {
                                                                        await showDialog(
                                                                          context:
                                                                              context,
                                                                          builder:
                                                                              (alertDialogContext) {
                                                                            return AlertDialog(
                                                                              content: Text('Please confirm the check box'),
                                                                              actions: [
                                                                                TextButton(
                                                                                  onPressed: () => Navigator.pop(alertDialogContext),
                                                                                  child: Text('Ok'),
                                                                                ),
                                                                              ],
                                                                            );
                                                                          },
                                                                        );
                                                                        return;
                                                                      }
                                                                      if (!(FFAppState().uploadimgname !=
                                                                              null &&
                                                                          FFAppState().uploadimgname !=
                                                                              '')) {
                                                                        await showDialog(
                                                                          context:
                                                                              context,
                                                                          builder:
                                                                              (alertDialogContext) {
                                                                            return AlertDialog(
                                                                              content: Text('Please upload your logo'),
                                                                              actions: [
                                                                                TextButton(
                                                                                  onPressed: () => Navigator.pop(alertDialogContext),
                                                                                  child: Text('Ok'),
                                                                                ),
                                                                              ],
                                                                            );
                                                                          },
                                                                        );
                                                                        return;
                                                                      }
                                                                      setState(() =>
                                                                          FFAppState().industryname =
                                                                              dropDownValue!);
                                                                      setState(() => FFAppState()
                                                                              .otherindustry =
                                                                          functions
                                                                              .jsonString(textController!.text));
                                                                      setState(() =>
                                                                          FFAppState().confirmorg =
                                                                              checkboxListTileValue!);
                                                                      await Navigator
                                                                          .push(
                                                                        context,
                                                                        PageTransition(
                                                                          type:
                                                                              PageTransitionType.rightToLeft,
                                                                          duration:
                                                                              Duration(milliseconds: 50),
                                                                          reverseDuration:
                                                                              Duration(milliseconds: 50),
                                                                          child:
                                                                              RegisterBusinessPartner05Widget(),
                                                                        ),
                                                                      );
                                                                    },
                                                                    text: FFLocalizations.of(
                                                                            context)
                                                                        .getText(
                                                                      'wp4kgyj4' /* Next */,
                                                                    ),
                                                                    options:
                                                                        FFButtonOptions(
                                                                      width:
                                                                          130,
                                                                      height:
                                                                          40,
                                                                      color: FlutterFlowTheme.of(
                                                                              context)
                                                                          .tertiaryColor,
                                                                      textStyle: FlutterFlowTheme.of(
                                                                              context)
                                                                          .subtitle2
                                                                          .override(
                                                                            fontFamily:
                                                                                'Poppins',
                                                                            color:
                                                                                Color(0xFF274078),
                                                                            fontWeight:
                                                                                FontWeight.normal,
                                                                          ),
                                                                      borderSide:
                                                                          BorderSide(
                                                                        color: Color(
                                                                            0xFF274078),
                                                                        width:
                                                                            1,
                                                                      ),
                                                                      borderRadius:
                                                                          BorderRadius.circular(
                                                                              40),
                                                                    ),
                                                                  ),
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
