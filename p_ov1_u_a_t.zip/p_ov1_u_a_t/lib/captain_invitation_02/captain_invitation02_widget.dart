import '../backend/api_requests/api_calls.dart';
import '../captain_invitation_03/captain_invitation03_widget.dart';
import '../components/app_bar_row_logo_widget.dart';
import '../flutter_flow/flutter_flow_language_selector.dart';
import '../flutter_flow/flutter_flow_theme.dart';
import '../flutter_flow/flutter_flow_util.dart';
import '../flutter_flow/flutter_flow_widgets.dart';
import '../custom_code/widgets/index.dart' as custom_widgets;
import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:google_fonts/google_fonts.dart';

class CaptainInvitation02Widget extends StatefulWidget {
  const CaptainInvitation02Widget({Key? key}) : super(key: key);

  @override
  _CaptainInvitation02WidgetState createState() =>
      _CaptainInvitation02WidgetState();
}

class _CaptainInvitation02WidgetState extends State<CaptainInvitation02Widget> {
  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: scaffoldKey,
      appBar: AppBar(
        backgroundColor: Color(0xFF274078),
        automaticallyImplyLeading: true,
        leading: Row(
          mainAxisSize: MainAxisSize.max,
          children: [
            Expanded(
              child: AppBarRowLogoWidget(),
            ),
          ],
        ),
        title: Align(
          alignment: AlignmentDirectional(-1, 0),
          child: Row(
            mainAxisSize: MainAxisSize.max,
            mainAxisAlignment: MainAxisAlignment.end,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              FlutterFlowLanguageSelector(
                width: 100,
                backgroundColor: FlutterFlowTheme.of(context).tertiaryColor,
                borderColor: FlutterFlowTheme.of(context).tertiaryColor,
                dropdownColor: FlutterFlowTheme.of(context).tertiaryColor,
                dropdownIconColor: Color(0xFF14181B),
                borderRadius: 8,
                textStyle: TextStyle(
                  color: Colors.black,
                  fontWeight: FontWeight.normal,
                  fontSize: 13,
                ),
                hideFlags: false,
                flagSize: 24,
                flagTextGap: 8,
                currentLanguage: FFLocalizations.of(context).languageCode,
                languages: FFLocalizations.languages(),
                onChanged: (lang) => setAppLanguage(context, lang),
              ),
              Padding(
                padding: EdgeInsetsDirectional.fromSTEB(5, 5, 0, 5),
                child: FFButtonWidget(
                  onPressed: () async {
                    await launchURL('https://shop.playon.ca');
                  },
                  text: FFLocalizations.of(context).getText(
                    'h6bdocmq' /* Login */,
                  ),
                  icon: Icon(
                    Icons.login,
                    color: Color(0xFFFFC107),
                    size: 15,
                  ),
                  options: FFButtonOptions(
                    width: 90,
                    height: 40,
                    color: FlutterFlowTheme.of(context).primaryColor,
                    textStyle: FlutterFlowTheme.of(context).subtitle2.override(
                          fontFamily: 'Poppins',
                          color: Colors.white,
                          fontSize: 14,
                        ),
                    borderSide: BorderSide(
                      color: Colors.transparent,
                      width: 1,
                    ),
                    borderRadius: BorderRadius.circular(4),
                  ),
                ),
              ),
            ],
          ),
        ),
        actions: [
          Row(
            mainAxisSize: MainAxisSize.max,
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Padding(
                padding: EdgeInsetsDirectional.fromSTEB(5, 5, 0, 5),
                child: custom_widgets.OrientationBasedButton(
                  width: 100,
                  height: 48,
                  buttonText: 'Store',
                  icon: Icon(
                    Icons.shopping_cart_outlined,
                    color: Color(0xFFFFC107),
                    size: 22,
                  ),
                  textSize: 14.0,
                  url: 'https://shop.playon.ca',
                  buttonColor: Colors.transparent,
                  buttonTextColor: FlutterFlowTheme.of(context).tertiaryColor,
                  hideInMobile: true,
                  borderColor: Colors.transparent,
                  borderRadius: 4.0,
                  borderWidth: 0.0,
                  elevation: 4.0,
                  textFont: 'Roboto',
                  fontWeight: 0,
                ),
              ),
            ],
          ),
        ],
        centerTitle: true,
        elevation: 12,
      ),
      backgroundColor: Color(0xFF274078),
      drawer: Drawer(
        elevation: 16,
        child: Column(
          mainAxisSize: MainAxisSize.max,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              width: MediaQuery.of(context).size.width,
              height: MediaQuery.of(context).size.height * 1,
              constraints: BoxConstraints(
                maxWidth: MediaQuery.of(context).size.width,
                maxHeight: MediaQuery.of(context).size.height * 1,
              ),
              decoration: BoxDecoration(
                color: Color(0xFFD6D6D6),
                shape: BoxShape.rectangle,
              ),
              child: Column(
                mainAxisSize: MainAxisSize.max,
                children: [
                  Padding(
                    padding: EdgeInsetsDirectional.fromSTEB(0, 10, 0, 10),
                    child: Text(
                      FFLocalizations.of(context).getText(
                        'ntzrfq0p' /* Menu */,
                      ),
                      style: FlutterFlowTheme.of(context).title1,
                    ),
                  ),
                  ListTile(
                    title: Text(
                      FFLocalizations.of(context).getText(
                        'yytkmo2z' /* PlayOn! Store */,
                      ),
                      style: FlutterFlowTheme.of(context).title3,
                    ),
                    subtitle: Text(
                      FFLocalizations.of(context).getText(
                        'fduizmui' /* Go to the PlayOn! Store */,
                      ),
                      style: FlutterFlowTheme.of(context).subtitle2,
                    ),
                    trailing: Icon(
                      Icons.arrow_forward_ios,
                      color: Color(0xFF303030),
                      size: 20,
                    ),
                    tileColor: Color(0xFFF5F5F5),
                    dense: false,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
      body: SafeArea(
        child: Align(
          alignment: AlignmentDirectional(0, -1),
          child: Container(
            width: 1200,
            height: MediaQuery.of(context).size.height * 0.84,
            decoration: BoxDecoration(),
            child: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.max,
                children: [
                  Padding(
                    padding: EdgeInsetsDirectional.fromSTEB(20, 20, 20, 20),
                    child: Text(
                      FFLocalizations.of(context).getText(
                        'pq1af357' /* Invitations */,
                      ),
                      textAlign: TextAlign.center,
                      style: FlutterFlowTheme.of(context).title1.override(
                            fontFamily: 'Poppins',
                            color: FlutterFlowTheme.of(context).tertiaryColor,
                          ),
                    ),
                  ),
                  Padding(
                    padding: EdgeInsetsDirectional.fromSTEB(30, 20, 30, 20),
                    child: Container(
                      width: MediaQuery.of(context).size.width,
                      decoration: BoxDecoration(),
                      child: Wrap(
                        spacing: 0,
                        runSpacing: 0,
                        alignment: WrapAlignment.spaceBetween,
                        crossAxisAlignment: WrapCrossAlignment.center,
                        direction: Axis.horizontal,
                        runAlignment: WrapAlignment.start,
                        verticalDirection: VerticalDirection.down,
                        clipBehavior: Clip.none,
                        children: [
                          Text(
                            FFLocalizations.of(context).getText(
                              'a9u1w8i6' /* Select  team to see details */,
                            ),
                            style:
                                FlutterFlowTheme.of(context).subtitle1.override(
                                      fontFamily: 'Poppins',
                                      color: FlutterFlowTheme.of(context)
                                          .tertiaryColor,
                                    ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Align(
                    alignment: AlignmentDirectional(0, 0),
                    child: Padding(
                      padding: EdgeInsetsDirectional.fromSTEB(30, 0, 30, 20),
                      child: FutureBuilder<ApiCallResponse>(
                        future: GetTeamsMetaDataCall.call(),
                        builder: (context, snapshot) {
                          // Customize what your widget looks like when it's loading.
                          if (!snapshot.hasData) {
                            return Center(
                              child: SizedBox(
                                width: 50,
                                height: 50,
                                child: SpinKitHourGlass(
                                  color: Color(0xFFFFC107),
                                  size: 50,
                                ),
                              ),
                            );
                          }
                          final columnMainContentGetTeamsMetaDataResponse =
                              snapshot.data!;
                          return SingleChildScrollView(
                            child: Column(
                              mainAxisSize: MainAxisSize.min,
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                FutureBuilder<ApiCallResponse>(
                                  future: GetTeamsCall.call(),
                                  builder: (context, snapshot) {
                                    // Customize what your widget looks like when it's loading.
                                    if (!snapshot.hasData) {
                                      return Center(
                                        child: SizedBox(
                                          width: 50,
                                          height: 50,
                                          child: SpinKitHourGlass(
                                            color: Color(0xFFFFC107),
                                            size: 50,
                                          ),
                                        ),
                                      );
                                    }
                                    final responsiveTableWidgetGetTeamsResponse =
                                        snapshot.data!;
                                    return InkWell(
                                      onTap: () async {
                                        await Navigator.push(
                                          context,
                                          PageTransition(
                                            type:
                                                PageTransitionType.rightToLeft,
                                            duration:
                                                Duration(milliseconds: 50),
                                            reverseDuration:
                                                Duration(milliseconds: 50),
                                            child: CaptainInvitation03Widget(),
                                          ),
                                        );
                                      },
                                      child:
                                          custom_widgets.ResponsiveTableWidget(
                                        width:
                                            MediaQuery.of(context).size.width,
                                        height: 400,
                                        borderColor: Color(0xFFFFBF00),
                                        borderWidth: 1.0,
                                        headerPanelColor:
                                            FlutterFlowTheme.of(context)
                                                .primaryColor,
                                        headerTextColor:
                                            FlutterFlowTheme.of(context)
                                                .tertiaryColor,
                                        headerFont: 'Poppins',
                                        headerFontSize: 14.0,
                                        headerFontWeight: 2,
                                        dataPanelColor: Color(0xFF274078),
                                        dataTextColor: Colors.white,
                                        dataTextFont: 'Poppins',
                                        dataTextSize: 14.0,
                                        dataTextWeight: 0,
                                        showSearch: true,
                                        dataJSON:
                                            responsiveTableWidgetGetTeamsResponse
                                                .jsonBody,
                                        innerRowBorderColor: Color(0xFFD22323),
                                        innerRowBorderWidth: 1.0,
                                        searchPanelColor: Colors.transparent,
                                        elevation: 6.0,
                                        dataJSONMetaData:
                                            columnMainContentGetTeamsMetaDataResponse
                                                .jsonBody,
                                      ),
                                    );
                                  },
                                ),
                              ],
                            ),
                          );
                        },
                      ),
                    ),
                  ),
                  Padding(
                    padding: EdgeInsetsDirectional.fromSTEB(0, 0, 0, 70),
                    child: Wrap(
                      spacing: 20,
                      runSpacing: 0,
                      alignment: WrapAlignment.start,
                      crossAxisAlignment: WrapCrossAlignment.start,
                      direction: Axis.horizontal,
                      runAlignment: WrapAlignment.start,
                      verticalDirection: VerticalDirection.down,
                      clipBehavior: Clip.none,
                      children: [
                        FFButtonWidget(
                          onPressed: () async {
                            Navigator.pop(context);
                          },
                          text: FFLocalizations.of(context).getText(
                            'cvcpfc7g' /* Cancel */,
                          ),
                          options: FFButtonOptions(
                            width: 130,
                            height: 40,
                            color: Color(0xFF274078),
                            textStyle:
                                FlutterFlowTheme.of(context).subtitle2.override(
                                      fontFamily: 'Poppins',
                                      color: FlutterFlowTheme.of(context)
                                          .tertiaryColor,
                                    ),
                            borderSide: BorderSide(
                              color: FlutterFlowTheme.of(context).tertiaryColor,
                              width: 1,
                            ),
                            borderRadius: BorderRadius.circular(25),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
