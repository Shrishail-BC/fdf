import '../backend/api_requests/api_calls.dart';
import '../components/app_header_widget.dart';
import '../components/menu_widget.dart';
import '../dashboard_business_partner/dashboard_business_partner_widget.dart';
import '../flutter_flow/flutter_flow_theme.dart';
import '../flutter_flow/flutter_flow_util.dart';
import '../flutter_flow/flutter_flow_widgets.dart';
import '../register_role_select/register_role_select_widget.dart';
import '../router/router_widget.dart';
import '../user_register/user_register_widget.dart';
import '../custom_code/actions/index.dart' as actions;
import '../flutter_flow/custom_functions.dart' as functions;
import 'package:easy_debounce/easy_debounce.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:google_fonts/google_fonts.dart';

class UserLoginRegisterWidget extends StatefulWidget {
  const UserLoginRegisterWidget({Key? key}) : super(key: key);

  @override
  _UserLoginRegisterWidgetState createState() =>
      _UserLoginRegisterWidgetState();
}

class _UserLoginRegisterWidgetState extends State<UserLoginRegisterWidget> {
  ApiCallResponse? apiSessionDetailsL;
  ApiCallResponse? succed;
  ApiCallResponse? succ;
  TextEditingController? textFieldEmailLController;
  TextEditingController? textFieldPL0Controller;

  late bool textFieldPL0Visibility;
  ApiCallResponse? apiSessionDetailsR;
  TextEditingController? textFieldEmailRController;
  TextEditingController? textFieldPR0Controller;

  late bool textFieldPR0Visibility;
  TextEditingController? textFieldPR1Controller;

  late bool textFieldPR1Visibility;
  final formKey1 = GlobalKey<FormState>();
  final formKey2 = GlobalKey<FormState>();
  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    // On page load action.
    SchedulerBinding.instance.addPostFrameCallback((_) async {
      setState(() => FFAppState().navPopDisabled = true);
      if (FFAppState().sessionRefreshToken != null &&
          FFAppState().sessionRefreshToken != '') {
        await Navigator.push(
          context,
          PageTransition(
            type: PageTransitionType.rightToLeft,
            duration: Duration(milliseconds: 50),
            reverseDuration: Duration(milliseconds: 50),
            child: RouterWidget(),
          ),
        );
      }
    });

    textFieldEmailLController = TextEditingController();
    textFieldPL0Controller = TextEditingController();
    textFieldPL0Visibility = false;
    textFieldEmailRController = TextEditingController();
    textFieldPR0Controller = TextEditingController();
    textFieldPR0Visibility = false;
    textFieldPR1Controller = TextEditingController();
    textFieldPR1Visibility = false;
  }

  @override
  void dispose() {
    textFieldEmailLController?.dispose();
    textFieldPL0Controller?.dispose();
    textFieldEmailRController?.dispose();
    textFieldPR0Controller?.dispose();
    textFieldPR1Controller?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: scaffoldKey,
      backgroundColor: Color(0xFF274078),
      drawer: Container(
        width: 250,
        child: Drawer(
          elevation: 16,
          child: MenuWidget(),
        ),
      ),
      body: SafeArea(
        child: Stack(
          children: [
            SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.max,
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Padding(
                    padding: EdgeInsetsDirectional.fromSTEB(10, 0, 0, 0),
                    child: Row(
                      mainAxisSize: MainAxisSize.max,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Expanded(
                          child: AppHeaderWidget(),
                        ),
                      ],
                    ),
                  ),
                  Padding(
                    padding: EdgeInsetsDirectional.fromSTEB(0, 30, 0, 0),
                    child: SingleChildScrollView(
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Column(
                            mainAxisSize: MainAxisSize.max,
                            children: [
                              Align(
                                alignment: AlignmentDirectional(0, 0),
                                child: Text(
                                  FFLocalizations.of(context).getText(
                                    'tb3z9nvb' /* Welcome to Play On! */,
                                  ),
                                  textAlign: TextAlign.center,
                                  style: FlutterFlowTheme.of(context)
                                      .title1
                                      .override(
                                        fontFamily: 'Poppins',
                                        color: FlutterFlowTheme.of(context)
                                            .tertiaryColor,
                                      ),
                                ),
                              ),
                              Align(
                                alignment: AlignmentDirectional(0, 0),
                                child: Padding(
                                  padding: EdgeInsetsDirectional.fromSTEB(
                                      0, 20, 0, 0),
                                  child: Text(
                                    FFLocalizations.of(context).getText(
                                      '6ce52h7r' /* Experience the world's largest... */,
                                    ),
                                    textAlign: TextAlign.center,
                                    style: FlutterFlowTheme.of(context)
                                        .title3
                                        .override(
                                          fontFamily: 'Poppins',
                                          color: Color(0xFFD7D7D7),
                                          fontSize: 16,
                                          fontStyle: FontStyle.italic,
                                        ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                          Align(
                            alignment: AlignmentDirectional(0, 0),
                            child: Padding(
                              padding:
                                  EdgeInsetsDirectional.fromSTEB(0, 40, 0, 0),
                              child: SingleChildScrollView(
                                child: Column(
                                  mainAxisSize: MainAxisSize.max,
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Align(
                                      alignment: AlignmentDirectional(0, 0),
                                      child: Material(
                                        color: Colors.transparent,
                                        elevation: 12,
                                        child: Container(
                                          width: 400,
                                          decoration: BoxDecoration(
                                            color: Colors.transparent,
                                            border: Border.all(
                                              width: 0,
                                            ),
                                          ),
                                          child: Column(
                                            mainAxisSize: MainAxisSize.max,
                                            children: [
                                              Material(
                                                color: Colors.transparent,
                                                elevation: 12,
                                                child: Container(
                                                  width: MediaQuery.of(context)
                                                      .size
                                                      .width,
                                                  height: 400,
                                                  decoration: BoxDecoration(
                                                    color: Colors.transparent,
                                                    border: Border.all(
                                                      color: Color(0xFFCFCFCF),
                                                      width: 2,
                                                    ),
                                                  ),
                                                  child: Column(
                                                    mainAxisSize:
                                                        MainAxisSize.max,
                                                    children: [
                                                      Expanded(
                                                        child:
                                                            DefaultTabController(
                                                          length: 2,
                                                          initialIndex: 0,
                                                          child: Column(
                                                            children: [
                                                              TabBar(
                                                                labelColor:
                                                                    FlutterFlowTheme.of(
                                                                            context)
                                                                        .orange,
                                                                labelStyle:
                                                                    FlutterFlowTheme.of(
                                                                            context)
                                                                        .bodyText1
                                                                        .override(
                                                                          fontFamily:
                                                                              'Poppins',
                                                                          fontSize:
                                                                              18,
                                                                          fontWeight:
                                                                              FontWeight.bold,
                                                                        ),
                                                                indicatorColor:
                                                                    FlutterFlowTheme.of(
                                                                            context)
                                                                        .secondaryColor,
                                                                tabs: [
                                                                  Tab(
                                                                    text: FFLocalizations.of(
                                                                            context)
                                                                        .getText(
                                                                      '78id3gxb' /* Login */,
                                                                    ),
                                                                  ),
                                                                  Tab(
                                                                    text: FFLocalizations.of(
                                                                            context)
                                                                        .getText(
                                                                      'hxu5f62e' /* Register */,
                                                                    ),
                                                                  ),
                                                                ],
                                                              ),
                                                              Expanded(
                                                                child:
                                                                    TabBarView(
                                                                  children: [
                                                                    Form(
                                                                      key:
                                                                          formKey2,
                                                                      autovalidateMode:
                                                                          AutovalidateMode
                                                                              .disabled,
                                                                      child:
                                                                          SingleChildScrollView(
                                                                        child:
                                                                            Column(
                                                                          mainAxisSize:
                                                                              MainAxisSize.max,
                                                                          children: [
                                                                            Align(
                                                                              alignment: AlignmentDirectional(0, 0),
                                                                              child: Padding(
                                                                                padding: EdgeInsetsDirectional.fromSTEB(10, 30, 10, 10),
                                                                                child: TextFormField(
                                                                                  controller: textFieldEmailLController,
                                                                                  onChanged: (_) => EasyDebounce.debounce(
                                                                                    'textFieldEmailLController',
                                                                                    Duration(milliseconds: 2000),
                                                                                    () => setState(() {}),
                                                                                  ),
                                                                                  obscureText: false,
                                                                                  decoration: InputDecoration(
                                                                                    labelText: FFLocalizations.of(context).getText(
                                                                                      'ap1a297k' /* Login Email Id */,
                                                                                    ),
                                                                                    hintText: FFLocalizations.of(context).getText(
                                                                                      'yjzq9zx5' /* Your email id */,
                                                                                    ),
                                                                                    enabledBorder: UnderlineInputBorder(
                                                                                      borderSide: BorderSide(
                                                                                        color: Color(0x00000000),
                                                                                        width: 1,
                                                                                      ),
                                                                                      borderRadius: BorderRadius.circular(4),
                                                                                    ),
                                                                                    focusedBorder: UnderlineInputBorder(
                                                                                      borderSide: BorderSide(
                                                                                        color: Color(0x00000000),
                                                                                        width: 1,
                                                                                      ),
                                                                                      borderRadius: BorderRadius.circular(4),
                                                                                    ),
                                                                                    errorBorder: UnderlineInputBorder(
                                                                                      borderSide: BorderSide(
                                                                                        color: Color(0x00000000),
                                                                                        width: 1,
                                                                                      ),
                                                                                      borderRadius: BorderRadius.circular(4),
                                                                                    ),
                                                                                    focusedErrorBorder: UnderlineInputBorder(
                                                                                      borderSide: BorderSide(
                                                                                        color: Color(0x00000000),
                                                                                        width: 1,
                                                                                      ),
                                                                                      borderRadius: BorderRadius.circular(4),
                                                                                    ),
                                                                                    filled: true,
                                                                                    fillColor: Colors.white,
                                                                                    contentPadding: EdgeInsetsDirectional.fromSTEB(4, 4, 4, 4),
                                                                                    prefixIcon: Icon(
                                                                                      Icons.email_outlined,
                                                                                    ),
                                                                                    suffixIcon: textFieldEmailLController!.text.isNotEmpty
                                                                                        ? InkWell(
                                                                                            onTap: () async {
                                                                                              textFieldEmailLController?.clear();
                                                                                              setState(() {});
                                                                                            },
                                                                                            child: Icon(
                                                                                              Icons.clear,
                                                                                              color: Color(0xFF757575),
                                                                                              size: 22,
                                                                                            ),
                                                                                          )
                                                                                        : null,
                                                                                  ),
                                                                                  style: FlutterFlowTheme.of(context).bodyText1.override(
                                                                                        fontFamily: 'Poppins',
                                                                                        color: Colors.black,
                                                                                      ),
                                                                                  textAlign: TextAlign.start,
                                                                                  validator: (val) {
                                                                                    if (val == null || val.isEmpty) {
                                                                                      return FFLocalizations.of(context).getText(
                                                                                        'tjhptuwm' /* Mandatory Field */,
                                                                                      );
                                                                                    }

                                                                                    if (val.length < 6) {
                                                                                      return 'Requires at least 6 characters.';
                                                                                    }

                                                                                    return null;
                                                                                  },
                                                                                ),
                                                                              ),
                                                                            ),
                                                                            Padding(
                                                                              padding: EdgeInsetsDirectional.fromSTEB(10, 10, 10, 10),
                                                                              child: TextFormField(
                                                                                controller: textFieldPL0Controller,
                                                                                obscureText: !textFieldPL0Visibility,
                                                                                decoration: InputDecoration(
                                                                                  labelText: FFLocalizations.of(context).getText(
                                                                                    'um7h86fc' /* Password */,
                                                                                  ),
                                                                                  hintText: FFLocalizations.of(context).getText(
                                                                                    'ezvtiacy' /* Password */,
                                                                                  ),
                                                                                  enabledBorder: UnderlineInputBorder(
                                                                                    borderSide: BorderSide(
                                                                                      color: Color(0x00000000),
                                                                                      width: 1,
                                                                                    ),
                                                                                    borderRadius: const BorderRadius.only(
                                                                                      topLeft: Radius.circular(4.0),
                                                                                      topRight: Radius.circular(4.0),
                                                                                    ),
                                                                                  ),
                                                                                  focusedBorder: UnderlineInputBorder(
                                                                                    borderSide: BorderSide(
                                                                                      color: Color(0x00000000),
                                                                                      width: 1,
                                                                                    ),
                                                                                    borderRadius: const BorderRadius.only(
                                                                                      topLeft: Radius.circular(4.0),
                                                                                      topRight: Radius.circular(4.0),
                                                                                    ),
                                                                                  ),
                                                                                  errorBorder: UnderlineInputBorder(
                                                                                    borderSide: BorderSide(
                                                                                      color: Color(0x00000000),
                                                                                      width: 1,
                                                                                    ),
                                                                                    borderRadius: const BorderRadius.only(
                                                                                      topLeft: Radius.circular(4.0),
                                                                                      topRight: Radius.circular(4.0),
                                                                                    ),
                                                                                  ),
                                                                                  focusedErrorBorder: UnderlineInputBorder(
                                                                                    borderSide: BorderSide(
                                                                                      color: Color(0x00000000),
                                                                                      width: 1,
                                                                                    ),
                                                                                    borderRadius: const BorderRadius.only(
                                                                                      topLeft: Radius.circular(4.0),
                                                                                      topRight: Radius.circular(4.0),
                                                                                    ),
                                                                                  ),
                                                                                  filled: true,
                                                                                  fillColor: FlutterFlowTheme.of(context).tertiaryColor,
                                                                                  prefixIcon: Icon(
                                                                                    Icons.lock_outlined,
                                                                                  ),
                                                                                  suffixIcon: InkWell(
                                                                                    onTap: () => setState(
                                                                                      () => textFieldPL0Visibility = !textFieldPL0Visibility,
                                                                                    ),
                                                                                    focusNode: FocusNode(skipTraversal: true),
                                                                                    child: Icon(
                                                                                      textFieldPL0Visibility ? Icons.visibility_outlined : Icons.visibility_off_outlined,
                                                                                      color: Color(0xFF757575),
                                                                                      size: 22,
                                                                                    ),
                                                                                  ),
                                                                                ),
                                                                                style: FlutterFlowTheme.of(context).bodyText1.override(
                                                                                      fontFamily: 'Poppins',
                                                                                      color: FlutterFlowTheme.of(context).black,
                                                                                    ),
                                                                                validator: (val) {
                                                                                  if (val == null || val.isEmpty) {
                                                                                    return FFLocalizations.of(context).getText(
                                                                                      'wwjv5o57' /* Field is required */,
                                                                                    );
                                                                                  }

                                                                                  return null;
                                                                                },
                                                                              ),
                                                                            ),
                                                                            Padding(
                                                                              padding: EdgeInsetsDirectional.fromSTEB(20, 30, 20, 20),
                                                                              child: FFButtonWidget(
                                                                                onPressed: () async {
                                                                                  var _shouldSetState = false;
                                                                                  apiSessionDetailsL = await NLoginCall.call(
                                                                                    loginId: textFieldEmailLController!.text,
                                                                                    password: textFieldPL0Controller!.text,
                                                                                    applicationId: FFAppState().applicationId,
                                                                                  );
                                                                                  _shouldSetState = true;
                                                                                  if ((apiSessionDetailsL?.statusCode ?? 200) == 404) {
                                                                                    await showDialog(
                                                                                      context: context,
                                                                                      builder: (alertDialogContext) {
                                                                                        return AlertDialog(
                                                                                          title: Text('Login Error'),
                                                                                          content: Text('Invalid Email id or Password'),
                                                                                          actions: [
                                                                                            TextButton(
                                                                                              onPressed: () => Navigator.pop(alertDialogContext),
                                                                                              child: Text('Ok'),
                                                                                            ),
                                                                                          ],
                                                                                        );
                                                                                      },
                                                                                    );
                                                                                    if (_shouldSetState) setState(() {});
                                                                                    return;
                                                                                  }
                                                                                  if ((apiSessionDetailsL?.statusCode ?? 200) == 212) {
                                                                                    await showDialog(
                                                                                      context: context,
                                                                                      builder: (alertDialogContext) {
                                                                                        return AlertDialog(
                                                                                          title: Text('Email id not verified'),
                                                                                          content: Text('Check your email and verify your Id'),
                                                                                          actions: [
                                                                                            TextButton(
                                                                                              onPressed: () => Navigator.pop(alertDialogContext),
                                                                                              child: Text('Ok'),
                                                                                            ),
                                                                                          ],
                                                                                        );
                                                                                      },
                                                                                    );
                                                                                    if (_shouldSetState) setState(() {});
                                                                                    return;
                                                                                  }
                                                                                  if ((apiSessionDetailsL?.statusCode ?? 200) == 200) {
                                                                                    await actions.setSession(
                                                                                      getJsonField(
                                                                                        (apiSessionDetailsL?.jsonBody ?? ''),
                                                                                        r'''$..refreshToken''',
                                                                                      ).toString(),
                                                                                      getJsonField(
                                                                                        (apiSessionDetailsL?.jsonBody ?? ''),
                                                                                        r'''$..token''',
                                                                                      ).toString(),
                                                                                      getJsonField(
                                                                                        (apiSessionDetailsL?.jsonBody ?? ''),
                                                                                        r'''$..passwordChangeRequired''',
                                                                                      ).toString(),
                                                                                      getJsonField(
                                                                                        (apiSessionDetailsL?.jsonBody ?? ''),
                                                                                        r'''$..passwordLastUpdatedInstant''',
                                                                                      ).toString(),
                                                                                      getJsonField(
                                                                                        (apiSessionDetailsL?.jsonBody ?? ''),
                                                                                        r'''$..lastLoginInstant''',
                                                                                      ).toString(),
                                                                                      getJsonField(
                                                                                        (apiSessionDetailsL?.jsonBody ?? ''),
                                                                                        r'''$..active''',
                                                                                      ).toString(),
                                                                                      getJsonField(
                                                                                        (apiSessionDetailsL?.jsonBody ?? ''),
                                                                                        r'''$..verified''',
                                                                                      ).toString(),
                                                                                      getJsonField(
                                                                                        (apiSessionDetailsL?.jsonBody ?? ''),
                                                                                        r'''$..usernameStatus''',
                                                                                      ).toString(),
                                                                                      textFieldEmailLController!.text,
                                                                                    );
                                                                                    setState(() => FFAppState().getemailaddress = textFieldEmailLController!.text);
                                                                                    succed = await BpRegistrationbCall.call(
                                                                                      refreshToken: FFAppState().sessionRefreshToken,
                                                                                      formstep: '101',
                                                                                    );
                                                                                    _shouldSetState = true;
                                                                                    if (!(succed?.succeeded ?? true)) {
                                                                                      if (_shouldSetState) setState(() {});
                                                                                      return;
                                                                                    }
                                                                                    succ = await BpRegistrationbCall.call(
                                                                                      refreshToken: FFAppState().sessionRefreshToken,
                                                                                      formstep: '11',
                                                                                    );
                                                                                    _shouldSetState = true;
                                                                                    if ((succ?.succeeded ?? true)) {
                                                                                      await Navigator.push(
                                                                                        context,
                                                                                        PageTransition(
                                                                                          type: PageTransitionType.rightToLeft,
                                                                                          duration: Duration(milliseconds: 50),
                                                                                          reverseDuration: Duration(milliseconds: 50),
                                                                                          child: DashboardBusinessPartnerWidget(),
                                                                                        ),
                                                                                      );
                                                                                    } else {
                                                                                      await Navigator.push(
                                                                                        context,
                                                                                        PageTransition(
                                                                                          type: PageTransitionType.rightToLeft,
                                                                                          duration: Duration(milliseconds: 50),
                                                                                          reverseDuration: Duration(milliseconds: 50),
                                                                                          child: RegisterRoleSelectWidget(),
                                                                                        ),
                                                                                      );
                                                                                    }
                                                                                  }
                                                                                  if (_shouldSetState) setState(() {});
                                                                                },
                                                                                text: FFLocalizations.of(context).getText(
                                                                                  'rwnpjpyx' /* Login */,
                                                                                ),
                                                                                icon: Icon(
                                                                                  Icons.login,
                                                                                  color: FlutterFlowTheme.of(context).black,
                                                                                  size: 15,
                                                                                ),
                                                                                options: FFButtonOptions(
                                                                                  width: 130,
                                                                                  height: 40,
                                                                                  color: Colors.white,
                                                                                  textStyle: FlutterFlowTheme.of(context).subtitle2.override(
                                                                                        fontFamily: 'Poppins',
                                                                                        color: Colors.black,
                                                                                      ),
                                                                                  borderSide: BorderSide(
                                                                                    color: Colors.transparent,
                                                                                    width: 1,
                                                                                  ),
                                                                                  borderRadius: BorderRadius.circular(6),
                                                                                ),
                                                                              ),
                                                                            ),
                                                                            Text(
                                                                              FFLocalizations.of(context).getText(
                                                                                '0lskhttp' /* Login to your existing Play On... */,
                                                                              ),
                                                                              style: FlutterFlowTheme.of(context).bodyText1.override(
                                                                                    fontFamily: 'Poppins',
                                                                                    color: FlutterFlowTheme.of(context).customColor3,
                                                                                  ),
                                                                            ),
                                                                            Padding(
                                                                              padding: EdgeInsetsDirectional.fromSTEB(0, 20, 0, 0),
                                                                              child: InkWell(
                                                                                onTap: () async {
                                                                                  await showDialog(
                                                                                    context: context,
                                                                                    builder: (alertDialogContext) {
                                                                                      return AlertDialog(
                                                                                        title: Text('Password reset'),
                                                                                        content: Text('Sending password reset link'),
                                                                                        actions: [
                                                                                          TextButton(
                                                                                            onPressed: () => Navigator.pop(alertDialogContext),
                                                                                            child: Text('Ok'),
                                                                                          ),
                                                                                        ],
                                                                                      );
                                                                                    },
                                                                                  );
                                                                                },
                                                                                child: Text(
                                                                                  FFLocalizations.of(context).getText(
                                                                                    'q4a88gy2' /* Forgot Password */,
                                                                                  ),
                                                                                  style: FlutterFlowTheme.of(context).bodyText1.override(
                                                                                        fontFamily: 'Poppins',
                                                                                        color: FlutterFlowTheme.of(context).orange,
                                                                                      ),
                                                                                ),
                                                                              ),
                                                                            ),
                                                                            Padding(
                                                                              padding: EdgeInsetsDirectional.fromSTEB(20, 30, 20, 20),
                                                                              child: FFButtonWidget(
                                                                                onPressed: () async {
                                                                                  await Navigator.pushAndRemoveUntil(
                                                                                    context,
                                                                                    PageTransition(
                                                                                      type: PageTransitionType.rightToLeft,
                                                                                      duration: Duration(milliseconds: 50),
                                                                                      reverseDuration: Duration(milliseconds: 50),
                                                                                      child: RegisterRoleSelectWidget(),
                                                                                    ),
                                                                                    (r) => false,
                                                                                  );
                                                                                },
                                                                                text: FFLocalizations.of(context).getText(
                                                                                  'nhgw74hk' /* Test Login */,
                                                                                ),
                                                                                icon: Icon(
                                                                                  Icons.login,
                                                                                  color: FlutterFlowTheme.of(context).black,
                                                                                  size: 15,
                                                                                ),
                                                                                options: FFButtonOptions(
                                                                                  width: 130,
                                                                                  height: 40,
                                                                                  color: Colors.white,
                                                                                  textStyle: FlutterFlowTheme.of(context).subtitle2.override(
                                                                                        fontFamily: 'Poppins',
                                                                                        color: Colors.black,
                                                                                      ),
                                                                                  borderSide: BorderSide(
                                                                                    color: Colors.transparent,
                                                                                    width: 1,
                                                                                  ),
                                                                                  borderRadius: BorderRadius.circular(6),
                                                                                ),
                                                                              ),
                                                                            ),
                                                                          ],
                                                                        ),
                                                                      ),
                                                                    ),
                                                                    Form(
                                                                      key:
                                                                          formKey1,
                                                                      autovalidateMode:
                                                                          AutovalidateMode
                                                                              .always,
                                                                      child:
                                                                          Column(
                                                                        mainAxisSize:
                                                                            MainAxisSize.max,
                                                                        children: [
                                                                          Align(
                                                                            alignment:
                                                                                AlignmentDirectional(0, 0),
                                                                            child:
                                                                                Padding(
                                                                              padding: EdgeInsetsDirectional.fromSTEB(10, 30, 10, 10),
                                                                              child: TextFormField(
                                                                                controller: textFieldEmailRController,
                                                                                onChanged: (_) => EasyDebounce.debounce(
                                                                                  'textFieldEmailRController',
                                                                                  Duration(milliseconds: 2000),
                                                                                  () => setState(() {}),
                                                                                ),
                                                                                obscureText: false,
                                                                                decoration: InputDecoration(
                                                                                  labelText: FFLocalizations.of(context).getText(
                                                                                    'mz4qnkgy' /* Email */,
                                                                                  ),
                                                                                  hintText: FFLocalizations.of(context).getText(
                                                                                    'd8tu8kwd' /* Your email id */,
                                                                                  ),
                                                                                  enabledBorder: UnderlineInputBorder(
                                                                                    borderSide: BorderSide(
                                                                                      color: Color(0x00000000),
                                                                                      width: 1,
                                                                                    ),
                                                                                    borderRadius: BorderRadius.circular(4),
                                                                                  ),
                                                                                  focusedBorder: UnderlineInputBorder(
                                                                                    borderSide: BorderSide(
                                                                                      color: Color(0x00000000),
                                                                                      width: 1,
                                                                                    ),
                                                                                    borderRadius: BorderRadius.circular(4),
                                                                                  ),
                                                                                  errorBorder: UnderlineInputBorder(
                                                                                    borderSide: BorderSide(
                                                                                      color: Color(0x00000000),
                                                                                      width: 1,
                                                                                    ),
                                                                                    borderRadius: BorderRadius.circular(4),
                                                                                  ),
                                                                                  focusedErrorBorder: UnderlineInputBorder(
                                                                                    borderSide: BorderSide(
                                                                                      color: Color(0x00000000),
                                                                                      width: 1,
                                                                                    ),
                                                                                    borderRadius: BorderRadius.circular(4),
                                                                                  ),
                                                                                  filled: true,
                                                                                  fillColor: Colors.white,
                                                                                  contentPadding: EdgeInsetsDirectional.fromSTEB(4, 4, 4, 4),
                                                                                  prefixIcon: Icon(
                                                                                    Icons.email_outlined,
                                                                                  ),
                                                                                  suffixIcon: textFieldEmailRController!.text.isNotEmpty
                                                                                      ? InkWell(
                                                                                          onTap: () async {
                                                                                            textFieldEmailRController?.clear();
                                                                                            setState(() {});
                                                                                          },
                                                                                          child: Icon(
                                                                                            Icons.clear,
                                                                                            color: Color(0xFF757575),
                                                                                            size: 22,
                                                                                          ),
                                                                                        )
                                                                                      : null,
                                                                                ),
                                                                                style: FlutterFlowTheme.of(context).bodyText1.override(
                                                                                      fontFamily: 'Poppins',
                                                                                      color: Colors.black,
                                                                                    ),
                                                                                textAlign: TextAlign.start,
                                                                                validator: (val) {
                                                                                  if (val == null || val.isEmpty) {
                                                                                    return FFLocalizations.of(context).getText(
                                                                                      'lu8ick85' /* Enter a valid Email address */,
                                                                                    );
                                                                                  }

                                                                                  if (val.length < 7) {
                                                                                    return 'Requires at least 7 characters.';
                                                                                  }

                                                                                  return null;
                                                                                },
                                                                              ),
                                                                            ),
                                                                          ),
                                                                          Padding(
                                                                            padding: EdgeInsetsDirectional.fromSTEB(
                                                                                10,
                                                                                10,
                                                                                10,
                                                                                10),
                                                                            child:
                                                                                TextFormField(
                                                                              controller: textFieldPR0Controller,
                                                                              obscureText: !textFieldPR0Visibility,
                                                                              decoration: InputDecoration(
                                                                                labelText: FFLocalizations.of(context).getText(
                                                                                  '1clyikc9' /* Password */,
                                                                                ),
                                                                                hintText: FFLocalizations.of(context).getText(
                                                                                  'mrdha1bs' /* Password */,
                                                                                ),
                                                                                enabledBorder: UnderlineInputBorder(
                                                                                  borderSide: BorderSide(
                                                                                    color: Color(0x00000000),
                                                                                    width: 1,
                                                                                  ),
                                                                                  borderRadius: const BorderRadius.only(
                                                                                    topLeft: Radius.circular(4.0),
                                                                                    topRight: Radius.circular(4.0),
                                                                                  ),
                                                                                ),
                                                                                focusedBorder: UnderlineInputBorder(
                                                                                  borderSide: BorderSide(
                                                                                    color: Color(0x00000000),
                                                                                    width: 1,
                                                                                  ),
                                                                                  borderRadius: const BorderRadius.only(
                                                                                    topLeft: Radius.circular(4.0),
                                                                                    topRight: Radius.circular(4.0),
                                                                                  ),
                                                                                ),
                                                                                errorBorder: UnderlineInputBorder(
                                                                                  borderSide: BorderSide(
                                                                                    color: Color(0x00000000),
                                                                                    width: 1,
                                                                                  ),
                                                                                  borderRadius: const BorderRadius.only(
                                                                                    topLeft: Radius.circular(4.0),
                                                                                    topRight: Radius.circular(4.0),
                                                                                  ),
                                                                                ),
                                                                                focusedErrorBorder: UnderlineInputBorder(
                                                                                  borderSide: BorderSide(
                                                                                    color: Color(0x00000000),
                                                                                    width: 1,
                                                                                  ),
                                                                                  borderRadius: const BorderRadius.only(
                                                                                    topLeft: Radius.circular(4.0),
                                                                                    topRight: Radius.circular(4.0),
                                                                                  ),
                                                                                ),
                                                                                filled: true,
                                                                                fillColor: FlutterFlowTheme.of(context).tertiaryColor,
                                                                                prefixIcon: Icon(
                                                                                  Icons.lock_outlined,
                                                                                ),
                                                                                suffixIcon: InkWell(
                                                                                  onTap: () => setState(
                                                                                    () => textFieldPR0Visibility = !textFieldPR0Visibility,
                                                                                  ),
                                                                                  focusNode: FocusNode(skipTraversal: true),
                                                                                  child: Icon(
                                                                                    textFieldPR0Visibility ? Icons.visibility_outlined : Icons.visibility_off_outlined,
                                                                                    color: Color(0xFF757575),
                                                                                    size: 22,
                                                                                  ),
                                                                                ),
                                                                              ),
                                                                              style: FlutterFlowTheme.of(context).bodyText1.override(
                                                                                    fontFamily: 'Poppins',
                                                                                    color: FlutterFlowTheme.of(context).black,
                                                                                  ),
                                                                              validator: (val) {
                                                                                if (val == null || val.isEmpty) {
                                                                                  return FFLocalizations.of(context).getText(
                                                                                    'ytb9ujxz' /* Minimum: 8 characters, 1 Upper... */,
                                                                                  );
                                                                                }

                                                                                return null;
                                                                              },
                                                                            ),
                                                                          ),
                                                                          Padding(
                                                                            padding: EdgeInsetsDirectional.fromSTEB(
                                                                                10,
                                                                                10,
                                                                                10,
                                                                                10),
                                                                            child:
                                                                                TextFormField(
                                                                              controller: textFieldPR1Controller,
                                                                              obscureText: !textFieldPR1Visibility,
                                                                              decoration: InputDecoration(
                                                                                labelText: FFLocalizations.of(context).getText(
                                                                                  'i5widend' /* Confirm Password */,
                                                                                ),
                                                                                hintText: FFLocalizations.of(context).getText(
                                                                                  'mfxeeukv' /* Confirm Password */,
                                                                                ),
                                                                                enabledBorder: UnderlineInputBorder(
                                                                                  borderSide: BorderSide(
                                                                                    color: Color(0x00000000),
                                                                                    width: 1,
                                                                                  ),
                                                                                  borderRadius: const BorderRadius.only(
                                                                                    topLeft: Radius.circular(4.0),
                                                                                    topRight: Radius.circular(4.0),
                                                                                  ),
                                                                                ),
                                                                                focusedBorder: UnderlineInputBorder(
                                                                                  borderSide: BorderSide(
                                                                                    color: Color(0x00000000),
                                                                                    width: 1,
                                                                                  ),
                                                                                  borderRadius: const BorderRadius.only(
                                                                                    topLeft: Radius.circular(4.0),
                                                                                    topRight: Radius.circular(4.0),
                                                                                  ),
                                                                                ),
                                                                                errorBorder: UnderlineInputBorder(
                                                                                  borderSide: BorderSide(
                                                                                    color: Color(0x00000000),
                                                                                    width: 1,
                                                                                  ),
                                                                                  borderRadius: const BorderRadius.only(
                                                                                    topLeft: Radius.circular(4.0),
                                                                                    topRight: Radius.circular(4.0),
                                                                                  ),
                                                                                ),
                                                                                focusedErrorBorder: UnderlineInputBorder(
                                                                                  borderSide: BorderSide(
                                                                                    color: Color(0x00000000),
                                                                                    width: 1,
                                                                                  ),
                                                                                  borderRadius: const BorderRadius.only(
                                                                                    topLeft: Radius.circular(4.0),
                                                                                    topRight: Radius.circular(4.0),
                                                                                  ),
                                                                                ),
                                                                                filled: true,
                                                                                fillColor: FlutterFlowTheme.of(context).tertiaryColor,
                                                                                prefixIcon: Icon(
                                                                                  Icons.lock_outlined,
                                                                                ),
                                                                                suffixIcon: InkWell(
                                                                                  onTap: () => setState(
                                                                                    () => textFieldPR1Visibility = !textFieldPR1Visibility,
                                                                                  ),
                                                                                  focusNode: FocusNode(skipTraversal: true),
                                                                                  child: Icon(
                                                                                    textFieldPR1Visibility ? Icons.visibility_outlined : Icons.visibility_off_outlined,
                                                                                    color: Color(0xFF757575),
                                                                                    size: 22,
                                                                                  ),
                                                                                ),
                                                                              ),
                                                                              style: FlutterFlowTheme.of(context).bodyText1.override(
                                                                                    fontFamily: 'Poppins',
                                                                                    color: FlutterFlowTheme.of(context).black,
                                                                                  ),
                                                                              validator: (val) {
                                                                                if (val == null || val.isEmpty) {
                                                                                  return FFLocalizations.of(context).getText(
                                                                                    '70uogio2' /* Confirm Pasword */,
                                                                                  );
                                                                                }

                                                                                return null;
                                                                              },
                                                                            ),
                                                                          ),
                                                                          Padding(
                                                                            padding: EdgeInsetsDirectional.fromSTEB(
                                                                                20,
                                                                                20,
                                                                                20,
                                                                                20),
                                                                            child:
                                                                                FFButtonWidget(
                                                                              onPressed: () async {
                                                                                var _shouldSetState = false;
                                                                                if (!functions.isEmail(textFieldEmailRController!.text)) {
                                                                                  await showDialog(
                                                                                    context: context,
                                                                                    builder: (alertDialogContext) {
                                                                                      return AlertDialog(
                                                                                        title: Text('Invalid email address'),
                                                                                        content: Text('Please enter a valid email address'),
                                                                                        actions: [
                                                                                          TextButton(
                                                                                            onPressed: () => Navigator.pop(alertDialogContext),
                                                                                            child: Text('Ok'),
                                                                                          ),
                                                                                        ],
                                                                                      );
                                                                                    },
                                                                                  );
                                                                                  if (_shouldSetState) setState(() {});
                                                                                  return;
                                                                                }
                                                                                if (textFieldPR0Controller!.text == textFieldPR1Controller!.text) {
                                                                                  if (!functions.validatePassword(textFieldPR0Controller!.text)) {
                                                                                    await showDialog(
                                                                                      context: context,
                                                                                      builder: (alertDialogContext) {
                                                                                        return AlertDialog(
                                                                                          title: Text('Check Password'),
                                                                                          content: Text('Passwords need 1 Uppercase, 1 Number and 8 characters length'),
                                                                                          actions: [
                                                                                            TextButton(
                                                                                              onPressed: () => Navigator.pop(alertDialogContext),
                                                                                              child: Text('Ok'),
                                                                                            ),
                                                                                          ],
                                                                                        );
                                                                                      },
                                                                                    );
                                                                                    if (_shouldSetState) setState(() {});
                                                                                    return;
                                                                                  }
                                                                                } else {
                                                                                  await showDialog(
                                                                                    context: context,
                                                                                    builder: (alertDialogContext) {
                                                                                      return AlertDialog(
                                                                                        title: Text('Check Password'),
                                                                                        content: Text('Passwords don\'t match'),
                                                                                        actions: [
                                                                                          TextButton(
                                                                                            onPressed: () => Navigator.pop(alertDialogContext),
                                                                                            child: Text('Ok'),
                                                                                          ),
                                                                                        ],
                                                                                      );
                                                                                    },
                                                                                  );
                                                                                  if (_shouldSetState) setState(() {});
                                                                                  return;
                                                                                }

                                                                                apiSessionDetailsR = await NRegisterUserCall.call(
                                                                                  loginId: textFieldEmailRController!.text,
                                                                                  password: textFieldPR0Controller!.text,
                                                                                  applicationId: FFAppState().applicationId,
                                                                                );
                                                                                _shouldSetState = true;
                                                                                if ((apiSessionDetailsR?.statusCode ?? 200) == 400) {
                                                                                  await showDialog(
                                                                                    context: context,
                                                                                    builder: (alertDialogContext) {
                                                                                      return AlertDialog(
                                                                                        title: Text('Registration Error'),
                                                                                        content: Text('That email address  is already registered. Please sign in.'),
                                                                                        actions: [
                                                                                          TextButton(
                                                                                            onPressed: () => Navigator.pop(alertDialogContext),
                                                                                            child: Text('Ok'),
                                                                                          ),
                                                                                        ],
                                                                                      );
                                                                                    },
                                                                                  );
                                                                                  if (_shouldSetState) setState(() {});
                                                                                  return;
                                                                                }
                                                                                if ((apiSessionDetailsR?.statusCode ?? 200) == 401) {
                                                                                  await showDialog(
                                                                                    context: context,
                                                                                    builder: (alertDialogContext) {
                                                                                      return AlertDialog(
                                                                                        title: Text('Registration Error'),
                                                                                        content: Text('Invalid Email address'),
                                                                                        actions: [
                                                                                          TextButton(
                                                                                            onPressed: () => Navigator.pop(alertDialogContext),
                                                                                            child: Text('Ok'),
                                                                                          ),
                                                                                        ],
                                                                                      );
                                                                                    },
                                                                                  );
                                                                                  if (_shouldSetState) setState(() {});
                                                                                  return;
                                                                                }
                                                                                if ((apiSessionDetailsR?.statusCode ?? 200) == 402) {
                                                                                  await showDialog(
                                                                                    context: context,
                                                                                    builder: (alertDialogContext) {
                                                                                      return AlertDialog(
                                                                                        title: Text('Registration Error'),
                                                                                        content: Text('Password too short'),
                                                                                        actions: [
                                                                                          TextButton(
                                                                                            onPressed: () => Navigator.pop(alertDialogContext),
                                                                                            child: Text('Ok'),
                                                                                          ),
                                                                                        ],
                                                                                      );
                                                                                    },
                                                                                  );
                                                                                  if (_shouldSetState) setState(() {});
                                                                                  return;
                                                                                }
                                                                                if ((apiSessionDetailsR?.statusCode ?? 200) == 404) {
                                                                                  await showDialog(
                                                                                    context: context,
                                                                                    builder: (alertDialogContext) {
                                                                                      return AlertDialog(
                                                                                        title: Text('Registration Error'),
                                                                                        content: Text('Contact support'),
                                                                                        actions: [
                                                                                          TextButton(
                                                                                            onPressed: () => Navigator.pop(alertDialogContext),
                                                                                            child: Text('Ok'),
                                                                                          ),
                                                                                        ],
                                                                                      );
                                                                                    },
                                                                                  );
                                                                                  if (_shouldSetState) setState(() {});
                                                                                  return;
                                                                                }
                                                                                if ((apiSessionDetailsR?.statusCode ?? 200) == 500) {
                                                                                  await showDialog(
                                                                                    context: context,
                                                                                    builder: (alertDialogContext) {
                                                                                      return AlertDialog(
                                                                                        title: Text('Registration Internal  Error'),
                                                                                        content: Text('Contact support'),
                                                                                        actions: [
                                                                                          TextButton(
                                                                                            onPressed: () => Navigator.pop(alertDialogContext),
                                                                                            child: Text('Ok'),
                                                                                          ),
                                                                                        ],
                                                                                      );
                                                                                    },
                                                                                  );
                                                                                  if (_shouldSetState) setState(() {});
                                                                                  return;
                                                                                }
                                                                                if ((apiSessionDetailsR?.statusCode ?? 200) == 200) {
                                                                                  await showDialog(
                                                                                    context: context,
                                                                                    builder: (alertDialogContext) {
                                                                                      return AlertDialog(
                                                                                        content: Text('Please verify your mail'),
                                                                                        actions: [
                                                                                          TextButton(
                                                                                            onPressed: () => Navigator.pop(alertDialogContext),
                                                                                            child: Text('Ok'),
                                                                                          ),
                                                                                        ],
                                                                                      );
                                                                                    },
                                                                                  );
                                                                                }
                                                                                if (_shouldSetState) setState(() {});
                                                                              },
                                                                              text: FFLocalizations.of(context).getText(
                                                                                'sp9lq0e0' /* Register */,
                                                                              ),
                                                                              icon: Icon(
                                                                                Icons.login,
                                                                                color: FlutterFlowTheme.of(context).black,
                                                                                size: 15,
                                                                              ),
                                                                              options: FFButtonOptions(
                                                                                width: 130,
                                                                                height: 40,
                                                                                color: FlutterFlowTheme.of(context).customColor2,
                                                                                textStyle: FlutterFlowTheme.of(context).subtitle2.override(
                                                                                      fontFamily: 'Poppins',
                                                                                      color: Colors.black,
                                                                                    ),
                                                                                borderSide: BorderSide(
                                                                                  color: Colors.transparent,
                                                                                  width: 1,
                                                                                ),
                                                                                borderRadius: BorderRadius.circular(6),
                                                                              ),
                                                                            ),
                                                                          ),
                                                                          Text(
                                                                            FFLocalizations.of(context).getText(
                                                                              'i7y9nz08' /* Register for a new Play On! ac... */,
                                                                            ),
                                                                            style: FlutterFlowTheme.of(context).bodyText1.override(
                                                                                  fontFamily: 'Poppins',
                                                                                  color: FlutterFlowTheme.of(context).customColor3,
                                                                                ),
                                                                          ),
                                                                        ],
                                                                      ),
                                                                    ),
                                                                  ],
                                                                ),
                                                              ),
                                                            ],
                                                          ),
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                    ),
                                    Padding(
                                      padding: EdgeInsetsDirectional.fromSTEB(
                                          0, 30, 0, 0),
                                      child: Text(
                                        FFLocalizations.of(context).getText(
                                          'neq9pg31' /* You can register for different... */,
                                        ),
                                        style: FlutterFlowTheme.of(context)
                                            .bodyText1,
                                      ),
                                    ),
                                    Container(
                                      width: 1200,
                                      decoration: BoxDecoration(),
                                      child: Wrap(
                                        spacing: 0,
                                        runSpacing: 0,
                                        alignment: WrapAlignment.center,
                                        crossAxisAlignment:
                                            WrapCrossAlignment.start,
                                        direction: Axis.horizontal,
                                        runAlignment: WrapAlignment.start,
                                        verticalDirection:
                                            VerticalDirection.down,
                                        clipBehavior: Clip.none,
                                        children: [
                                          Wrap(
                                            spacing: 0,
                                            runSpacing: 0,
                                            alignment: WrapAlignment.start,
                                            crossAxisAlignment:
                                                WrapCrossAlignment.start,
                                            direction: Axis.horizontal,
                                            runAlignment: WrapAlignment.start,
                                            verticalDirection:
                                                VerticalDirection.down,
                                            clipBehavior: Clip.none,
                                            children: [
                                              Wrap(
                                                spacing: 0,
                                                runSpacing: 0,
                                                alignment: WrapAlignment.start,
                                                crossAxisAlignment:
                                                    WrapCrossAlignment.start,
                                                direction: Axis.horizontal,
                                                runAlignment:
                                                    WrapAlignment.start,
                                                verticalDirection:
                                                    VerticalDirection.down,
                                                clipBehavior: Clip.none,
                                                children: [
                                                  Padding(
                                                    padding:
                                                        EdgeInsetsDirectional
                                                            .fromSTEB(
                                                                10, 10, 10, 10),
                                                    child: FFButtonWidget(
                                                      onPressed: () async {
                                                        await showDialog(
                                                          context: context,
                                                          builder:
                                                              (alertDialogContext) {
                                                            return AlertDialog(
                                                              title:
                                                                  Text('Fans'),
                                                              content: Text(
                                                                  'Fans can register to support their favourite teams and charities'),
                                                              actions: [
                                                                TextButton(
                                                                  onPressed: () =>
                                                                      Navigator.pop(
                                                                          alertDialogContext),
                                                                  child: Text(
                                                                      'Ok'),
                                                                ),
                                                              ],
                                                            );
                                                          },
                                                        );
                                                      },
                                                      text: FFLocalizations.of(
                                                              context)
                                                          .getText(
                                                        'mz4a1zgw' /* Fan */,
                                                      ),
                                                      options: FFButtonOptions(
                                                        width: 180,
                                                        height: 50,
                                                        color: Colors.white,
                                                        textStyle:
                                                            FlutterFlowTheme.of(
                                                                    context)
                                                                .subtitle2
                                                                .override(
                                                                  fontFamily:
                                                                      'Poppins',
                                                                  color: Color(
                                                                      0xFF274078),
                                                                ),
                                                        borderSide: BorderSide(
                                                          color: Colors
                                                              .transparent,
                                                          width: 1,
                                                        ),
                                                        borderRadius:
                                                            BorderRadius
                                                                .circular(4),
                                                      ),
                                                    ),
                                                  ),
                                                  Padding(
                                                    padding:
                                                        EdgeInsetsDirectional
                                                            .fromSTEB(
                                                                10, 10, 10, 10),
                                                    child: FFButtonWidget(
                                                      onPressed: () async {
                                                        await showDialog(
                                                          context: context,
                                                          builder:
                                                              (alertDialogContext) {
                                                            return AlertDialog(
                                                              title: Text(
                                                                  'Players'),
                                                              content: Text(
                                                                  'Team Captains, Players & FreeAgents can register to participate in Play On!'),
                                                              actions: [
                                                                TextButton(
                                                                  onPressed: () =>
                                                                      Navigator.pop(
                                                                          alertDialogContext),
                                                                  child: Text(
                                                                      'Ok'),
                                                                ),
                                                              ],
                                                            );
                                                          },
                                                        );
                                                      },
                                                      text: FFLocalizations.of(
                                                              context)
                                                          .getText(
                                                        'xgu0w7ao' /* Player
 */
                                                        ,
                                                      ),
                                                      options: FFButtonOptions(
                                                        width: 180,
                                                        height: 50,
                                                        color: Colors.white,
                                                        textStyle:
                                                            FlutterFlowTheme.of(
                                                                    context)
                                                                .subtitle2
                                                                .override(
                                                                  fontFamily:
                                                                      'Poppins',
                                                                  color: Color(
                                                                      0xFF274078),
                                                                ),
                                                        borderSide: BorderSide(
                                                          color: Colors
                                                              .transparent,
                                                          width: 1,
                                                        ),
                                                        borderRadius:
                                                            BorderRadius
                                                                .circular(4),
                                                      ),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                              Wrap(
                                                spacing: 0,
                                                runSpacing: 0,
                                                alignment: WrapAlignment.start,
                                                crossAxisAlignment:
                                                    WrapCrossAlignment.start,
                                                direction: Axis.horizontal,
                                                runAlignment:
                                                    WrapAlignment.start,
                                                verticalDirection:
                                                    VerticalDirection.down,
                                                clipBehavior: Clip.none,
                                                children: [
                                                  Padding(
                                                    padding:
                                                        EdgeInsetsDirectional
                                                            .fromSTEB(
                                                                10, 10, 10, 10),
                                                    child: FFButtonWidget(
                                                      onPressed: () async {
                                                        await showDialog(
                                                          context: context,
                                                          builder:
                                                              (alertDialogContext) {
                                                            return AlertDialog(
                                                              title: Text(
                                                                  'Volunters'),
                                                              content: Text(
                                                                  'Play On! needs volunteers like you to be a success. Do register and help the event.'),
                                                              actions: [
                                                                TextButton(
                                                                  onPressed: () =>
                                                                      Navigator.pop(
                                                                          alertDialogContext),
                                                                  child: Text(
                                                                      'Ok'),
                                                                ),
                                                              ],
                                                            );
                                                          },
                                                        );
                                                      },
                                                      text: FFLocalizations.of(
                                                              context)
                                                          .getText(
                                                        'v936njii' /* Volunteer */,
                                                      ),
                                                      options: FFButtonOptions(
                                                        width: 180,
                                                        height: 50,
                                                        color: Colors.white,
                                                        textStyle:
                                                            FlutterFlowTheme.of(
                                                                    context)
                                                                .subtitle2
                                                                .override(
                                                                  fontFamily:
                                                                      'Poppins',
                                                                  color: Color(
                                                                      0xFF274078),
                                                                ),
                                                        borderSide: BorderSide(
                                                          color: Colors
                                                              .transparent,
                                                          width: 1,
                                                        ),
                                                        borderRadius:
                                                            BorderRadius
                                                                .circular(4),
                                                      ),
                                                    ),
                                                  ),
                                                  Padding(
                                                    padding:
                                                        EdgeInsetsDirectional
                                                            .fromSTEB(
                                                                10, 10, 10, 10),
                                                    child: FFButtonWidget(
                                                      onPressed: () async {
                                                        await showDialog(
                                                          context: context,
                                                          builder:
                                                              (alertDialogContext) {
                                                            return AlertDialog(
                                                              title: Text(
                                                                  'Referees'),
                                                              content: Text(
                                                                  '\nReferees are the backbone of the matches - we need you \nat the games'),
                                                              actions: [
                                                                TextButton(
                                                                  onPressed: () =>
                                                                      Navigator.pop(
                                                                          alertDialogContext),
                                                                  child: Text(
                                                                      'Ok'),
                                                                ),
                                                              ],
                                                            );
                                                          },
                                                        );
                                                      },
                                                      text: FFLocalizations.of(
                                                              context)
                                                          .getText(
                                                        'ufa8hspv' /* Referee */,
                                                      ),
                                                      options: FFButtonOptions(
                                                        width: 180,
                                                        height: 50,
                                                        color: Colors.white,
                                                        textStyle:
                                                            FlutterFlowTheme.of(
                                                                    context)
                                                                .subtitle2
                                                                .override(
                                                                  fontFamily:
                                                                      'Poppins',
                                                                  color: Color(
                                                                      0xFF274078),
                                                                ),
                                                        borderSide: BorderSide(
                                                          color: Colors
                                                              .transparent,
                                                          width: 1,
                                                        ),
                                                        borderRadius:
                                                            BorderRadius
                                                                .circular(4),
                                                      ),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ],
                                          ),
                                          Wrap(
                                            spacing: 0,
                                            runSpacing: 0,
                                            alignment: WrapAlignment.start,
                                            crossAxisAlignment:
                                                WrapCrossAlignment.start,
                                            direction: Axis.horizontal,
                                            runAlignment: WrapAlignment.start,
                                            verticalDirection:
                                                VerticalDirection.down,
                                            clipBehavior: Clip.none,
                                            children: [
                                              Wrap(
                                                spacing: 0,
                                                runSpacing: 0,
                                                alignment: WrapAlignment.start,
                                                crossAxisAlignment:
                                                    WrapCrossAlignment.start,
                                                direction: Axis.horizontal,
                                                runAlignment:
                                                    WrapAlignment.start,
                                                verticalDirection:
                                                    VerticalDirection.down,
                                                clipBehavior: Clip.none,
                                                children: [
                                                  Padding(
                                                    padding:
                                                        EdgeInsetsDirectional
                                                            .fromSTEB(
                                                                10, 10, 10, 10),
                                                    child: FFButtonWidget(
                                                      onPressed: () async {
                                                        setState(() => FFAppState()
                                                            .roleSelected = 8);
                                                        await Navigator.push(
                                                          context,
                                                          PageTransition(
                                                            type:
                                                                PageTransitionType
                                                                    .rightToLeft,
                                                            duration: Duration(
                                                                milliseconds:
                                                                    50),
                                                            reverseDuration:
                                                                Duration(
                                                                    milliseconds:
                                                                        50),
                                                            child:
                                                                UserRegisterWidget(
                                                              poRegType:
                                                                  'Charity',
                                                            ),
                                                          ),
                                                        );
                                                      },
                                                      text: FFLocalizations.of(
                                                              context)
                                                          .getText(
                                                        'cl3b31f7' /* Charity */,
                                                      ),
                                                      options: FFButtonOptions(
                                                        width: 180,
                                                        height: 50,
                                                        color: Colors.white,
                                                        textStyle:
                                                            FlutterFlowTheme.of(
                                                                    context)
                                                                .subtitle2
                                                                .override(
                                                                  fontFamily:
                                                                      'Poppins',
                                                                  color: Color(
                                                                      0xFF274078),
                                                                ),
                                                        borderSide: BorderSide(
                                                          color: Colors
                                                              .transparent,
                                                          width: 1,
                                                        ),
                                                        borderRadius:
                                                            BorderRadius
                                                                .circular(4),
                                                      ),
                                                    ),
                                                  ),
                                                  Padding(
                                                    padding:
                                                        EdgeInsetsDirectional
                                                            .fromSTEB(
                                                                10, 10, 10, 10),
                                                    child: FFButtonWidget(
                                                      onPressed: () async {
                                                        setState(() => FFAppState()
                                                            .roleSelected = 10);
                                                        await Navigator.push(
                                                          context,
                                                          PageTransition(
                                                            type:
                                                                PageTransitionType
                                                                    .rightToLeft,
                                                            duration: Duration(
                                                                milliseconds:
                                                                    50),
                                                            reverseDuration:
                                                                Duration(
                                                                    milliseconds:
                                                                        50),
                                                            child:
                                                                UserRegisterWidget(
                                                              poRegType:
                                                                  'HostMuncipality',
                                                            ),
                                                          ),
                                                        );
                                                      },
                                                      text: FFLocalizations.of(
                                                              context)
                                                          .getText(
                                                        'ci26w2vj' /* Host Muncipality */,
                                                      ),
                                                      options: FFButtonOptions(
                                                        width: 180,
                                                        height: 50,
                                                        color: Colors.white,
                                                        textStyle:
                                                            FlutterFlowTheme.of(
                                                                    context)
                                                                .subtitle2
                                                                .override(
                                                                  fontFamily:
                                                                      'Poppins',
                                                                  color: Color(
                                                                      0xFF274078),
                                                                ),
                                                        borderSide: BorderSide(
                                                          color: Colors
                                                              .transparent,
                                                          width: 1,
                                                        ),
                                                        borderRadius:
                                                            BorderRadius
                                                                .circular(4),
                                                      ),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                              Wrap(
                                                spacing: 0,
                                                runSpacing: 0,
                                                alignment: WrapAlignment.start,
                                                crossAxisAlignment:
                                                    WrapCrossAlignment.start,
                                                direction: Axis.horizontal,
                                                runAlignment:
                                                    WrapAlignment.start,
                                                verticalDirection:
                                                    VerticalDirection.down,
                                                clipBehavior: Clip.none,
                                                children: [
                                                  Padding(
                                                    padding:
                                                        EdgeInsetsDirectional
                                                            .fromSTEB(
                                                                10, 10, 10, 10),
                                                    child: FFButtonWidget(
                                                      onPressed: () async {
                                                        setState(() => FFAppState()
                                                            .roleSelected = 7);
                                                        await Navigator.push(
                                                          context,
                                                          PageTransition(
                                                            type:
                                                                PageTransitionType
                                                                    .rightToLeft,
                                                            duration: Duration(
                                                                milliseconds:
                                                                    50),
                                                            reverseDuration:
                                                                Duration(
                                                                    milliseconds:
                                                                        50),
                                                            child:
                                                                UserRegisterWidget(
                                                              poRegType:
                                                                  'BusinessPartner',
                                                            ),
                                                          ),
                                                        );
                                                      },
                                                      text: FFLocalizations.of(
                                                              context)
                                                          .getText(
                                                        'vt7wsdeb' /* Business Partner */,
                                                      ),
                                                      options: FFButtonOptions(
                                                        width: 180,
                                                        height: 50,
                                                        color: Colors.white,
                                                        textStyle:
                                                            FlutterFlowTheme.of(
                                                                    context)
                                                                .subtitle2
                                                                .override(
                                                                  fontFamily:
                                                                      'Poppins',
                                                                  color: Color(
                                                                      0xFF274078),
                                                                ),
                                                        borderSide: BorderSide(
                                                          color: Colors
                                                              .transparent,
                                                          width: 1,
                                                        ),
                                                        borderRadius:
                                                            BorderRadius
                                                                .circular(4),
                                                      ),
                                                    ),
                                                  ),
                                                  Padding(
                                                    padding:
                                                        EdgeInsetsDirectional
                                                            .fromSTEB(
                                                                10, 10, 10, 10),
                                                    child: FFButtonWidget(
                                                      onPressed: () async {
                                                        setState(() => FFAppState()
                                                            .roleSelected = 11);
                                                        await Navigator.push(
                                                          context,
                                                          PageTransition(
                                                            type:
                                                                PageTransitionType
                                                                    .rightToLeft,
                                                            duration: Duration(
                                                                milliseconds:
                                                                    0),
                                                            reverseDuration:
                                                                Duration(
                                                                    milliseconds:
                                                                        0),
                                                            child:
                                                                UserRegisterWidget(
                                                              poRegType:
                                                                  'Vendor',
                                                            ),
                                                          ),
                                                        );
                                                      },
                                                      text: FFLocalizations.of(
                                                              context)
                                                          .getText(
                                                        'eglsq5hu' /* Vendor */,
                                                      ),
                                                      options: FFButtonOptions(
                                                        width: 180,
                                                        height: 50,
                                                        color: Colors.white,
                                                        textStyle:
                                                            FlutterFlowTheme.of(
                                                                    context)
                                                                .subtitle2
                                                                .override(
                                                                  fontFamily:
                                                                      'Poppins',
                                                                  color: Color(
                                                                      0xFF274078),
                                                                ),
                                                        borderSide: BorderSide(
                                                          color: Colors
                                                              .transparent,
                                                          width: 1,
                                                        ),
                                                        borderRadius:
                                                            BorderRadius
                                                                .circular(4),
                                                      ),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ],
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
