// Automatic FlutterFlow imports
import '../../flutter_flow/flutter_flow_theme.dart';
import '../../flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom actions
import '../../flutter_flow/custom_functions.dart'; // Imports custom functions
import 'package:flutter/material.dart';

// Begin custom action code
Future printSession(String? currentPage) async {
  // Add your function code here!

  print("*** *** ***");
  print("*** *** ***");
  print("*** *** ***");

  print("Started printSession = ");

  print("sessionRefreshToken = " + FFAppState().sessionRefreshToken);

  print("sessionToken = " + FFAppState().sessionToken);

  print("sessionPasswordChangeRequired = " +
      FFAppState().sessionPasswordChangeRequired);

  print("sessionPasswordLastUpdatedInstant = " +
      FFAppState().sessionPasswordLastUpdatedInstant);

  print("sessionLastLoginInstant = " + FFAppState().sessionLastLoginInstant);

  print("sessionActive = " + FFAppState().sessionActive);

  print("sessionVerified = " + FFAppState().sessionVerified);

  print("sessionUsernameStatus = " + FFAppState().sessionUsernameStatus);

  print("sessionLoginId = " + FFAppState().sessionLoginId);

  print("currentPage = " + currentPage!);

  print("Finished printSession");

  print("*** *** ***");
  print("*** *** ***");
}
