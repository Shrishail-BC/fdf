// Automatic FlutterFlow imports
import '../../flutter_flow/flutter_flow_theme.dart';
import '../../flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom actions
import '../../flutter_flow/custom_functions.dart'; // Imports custom functions
import 'package:flutter/material.dart';
// Begin custom action code
import 'package:twilio_flutter/twilio_flutter.dart';
import 'dart:math';

Future<int> genarateotp(String inputValue) async {
  int otp = Random().nextInt(9999);
  late TwilioFlutter twilioFlutter;
  twilioFlutter = TwilioFlutter(
      accountSid: 'ACbddf9eecffb6c5b8ad9d1e3a0bd5ecde',
      authToken: 'eb3aee2d093bd53a29d46781f28b9cfb',
      twilioNumber: '+16283457087');
  twilioFlutter.sendSMS(
      toNumber: inputValue, messageBody: 'Kanner OTP $otp.toString');
  return otp;
}
