// Automatic FlutterFlow imports
import '../../flutter_flow/flutter_flow_theme.dart';
import '../../flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom actions
import '../../flutter_flow/custom_functions.dart'; // Imports custom functions
import 'package:flutter/material.dart';

// Begin custom action code
Future clearLocalStateValue() async {
  // Add your function code here!
  FFAppState().cEventName = '';
  FFAppState().cTeamName = '';
  FFAppState().firstName = '';
  FFAppState().lastName = '';
  FFAppState().mobileNumber = '';
  FFAppState().phonenumber = '';
  FFAppState().selectedEventName = '';
  FFAppState().contactfirstname = '';
  FFAppState().contactlastname = '';
  FFAppState().contactemail = '';
  FFAppState().contactextension = '';
  FFAppState().contacttitle = '';
  FFAppState().industryname = '';
  FFAppState().otherindustry = '';
  FFAppState().selectedEventName = '';
  FFAppState().confirmorg = false;
  FFAppState().uploadimgname = '';
  FFAppState().startdate1 = '';
  FFAppState().startdate2 = '';
  FFAppState().startdate3 = '';
  FFAppState().enddate1 = '';
  FFAppState().enddate2 = '';
  FFAppState().enddate3 = '';
}
