// Automatic FlutterFlow imports
import '../../flutter_flow/flutter_flow_theme.dart';
import '../../flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom widgets
import '../actions/index.dart'; // Imports custom actions
import '../../flutter_flow/custom_functions.dart'; // Imports custom functions
import 'package:flutter/material.dart';
// Begin custom widget code
import 'package:url_launcher/url_launcher.dart';

class OrientationBasedText extends StatefulWidget {
  const OrientationBasedText({
    Key? key,
    this.width,
    this.height,
    this.text,
    this.textColor,
    this.textSize,
    this.hideInMobile,
    this.textFont,
    this.fontWeight,
    this.mobileAlignment,
    this.desktopAlignment,
    this.url,
  }) : super(key: key);

  final double? width;
  final double? height;
  final String? text;
  final Color? textColor;
  final double? textSize;
  final bool? hideInMobile;
  final String? textFont;
  final int? fontWeight;
  final String? mobileAlignment;
  final String? desktopAlignment;
  final String? url;

  @override
  _OrientationBasedTextState createState() => _OrientationBasedTextState();
}

class _OrientationBasedTextState extends State<OrientationBasedText> {
  @override
  // launchURL
  launchURL(String url) async {
    if (await canLaunch(url)) {
      await launch(url, forceWebView: true);
    } else {
      throw 'Could not launch $url';
    }
  } // end launchURL

  @override
  Widget build(BuildContext context) {
    /*   ButtonStyle style = ElevatedButton.styleFrom(
        primary: widget.buttonColor, // widget.buttonColor,
        onPrimary: widget.buttonColor,
        onSurface: widget.buttonColor,
        disabledMouseCursor: SystemMouseCursors.click,
        alignment: Alignment.center,
        fixedSize: Size(widget.width, widget.height),
        minimumSize: Size(widget.width, widget.height),
        //  elevation: widget.elevation,
        side: BorderSide(
          width: widget.borderWidth == null ? 0 : widget.borderWidth,
          color: widget.borderColor == null
              ? const Color(0x00000000)
              : widget.borderColor,
        ),
        shape: RoundedRectangleBorder(
          borderRadius:
              BorderRadius.circular(widget.borderRadius), // <-- Radius
        ),
        // primary: widget.buttonColor,
        textStyle:
            TextStyle(fontSize: widget.textSize)); // ElevatedButton.styleFrom
*/
    MediaQueryData _mediaQueryData;
    double screenWidth;
    double screenHeight;
    bool vHideInMobile = false;

    _mediaQueryData = MediaQuery.of(context);
    screenWidth = _mediaQueryData.size.width;
    screenHeight = _mediaQueryData.size.height;

    try {
      if (widget.hideInMobile == null || widget.hideInMobile == false) {
        vHideInMobile = false;
      } else {
        vHideInMobile = true;
      }
    } catch (e) {}

    var textAlignment; // Text Alignment Variable

    textAlignment = TextAlign.left;

    if (screenHeight > screenWidth &&
        vHideInMobile) // Portrait Mobile View and Hide
    {
//      setState(() => FFAppState().isPortrait = true);
      return Container(width: 0, height: 0);
    } else if (screenHeight > screenWidth || screenWidth < 1060) // Mobile View
    {
//      setState(() => FFAppState().isPortrait = true);
      if (widget.mobileAlignment == "L") {
        textAlignment = TextAlign.left;
      } else if (widget.mobileAlignment == "C") {
        textAlignment = TextAlign.center;
      } else if (widget.mobileAlignment == "R") {
        textAlignment = TextAlign.right;
      }
    } else // Tablet Desktop View
    {
//      setState(() => FFAppState().isPortrait = false);
      if (widget.desktopAlignment == "L") {
        textAlignment = TextAlign.left;
      } else if (widget.desktopAlignment == "C") {
        textAlignment = TextAlign.center;
      } else if (widget.desktopAlignment == "R") {
        textAlignment = TextAlign.right;
      }
    }

    return Container(
        width: widget.width,
        height: widget.height,
        child: Text(
          widget.text!,
          softWrap: true,
          textAlign: textAlignment,
          style: TextStyle(
            color: widget.textColor,
            fontFamily: widget.textFont,
            fontSize: widget.textSize,
            fontWeight: FontWeight.w400,
          ).apply(fontWeightDelta: widget.fontWeight!), //TextStyle
        ) //Text
        ); // Container
  }
}
