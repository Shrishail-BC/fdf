// Automatic FlutterFlow imports
import '../../flutter_flow/flutter_flow_theme.dart';
import '../../flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom widgets
import '../actions/index.dart'; // Imports custom actions
import '../../flutter_flow/custom_functions.dart'; // Imports custom functions
import 'package:flutter/material.dart';
// Begin custom widget code
import 'package:flutter/foundation.dart' show kIsWeb;
import 'dart:io' as io;

class CustomContainer extends StatefulWidget {
  const CustomContainer({
    Key? key,
    this.width,
    this.height,
    this.mobileWidthPercentage,
    this.desktopWidthPercentage,
  }) : super(key: key);

  final double? width;
  final double? height;
  final double? mobileWidthPercentage;
  final double? desktopWidthPercentage;

  @override
  _CustomContainerState createState() => _CustomContainerState();
}

class _CustomContainerState extends State<CustomContainer> {
  String? globalMessages;
  String? platformName;
  double? containerWidth; // *******

  @override
  Widget build(BuildContext context) {
    final MediaQueryData mediaQueryData = MediaQuery.of(context);
    final Size size = mediaQueryData.size;

    containerWidth = 1;

    print("*  ** * *");
    print("* ");
    print("* ");
    try {
      if (kIsWeb) {
        platformName = "Web";
        print("* Platform: web");
        containerWidth = widget.desktopWidthPercentage;
      } else {
        print("* Platform: Not Web");

        final double deviceWidth =
            (io.Platform.isIOS || io.Platform.isAndroid) &&
                    mediaQueryData.orientation == Orientation.landscape
                ? size.height
                : size.width;

        final double deviceHeight =
            (io.Platform.isIOS || io.Platform.isAndroid) &&
                    mediaQueryData.orientation == Orientation.landscape
                ? size.width
                : size.height;

        if (deviceHeight > deviceWidth) {
          containerWidth = widget.mobileWidthPercentage;
        } else {
          containerWidth = widget.desktopWidthPercentage;
        }

        if (io.Platform.isAndroid) {
          print("Platform: Android");
          platformName = "Android";
        } else if (io.Platform.isIOS) {
          print("Platform: IOS");
          platformName = "IOS";
        } else if (io.Platform.isFuchsia) {
          print("Platform: Fuchsia");
          platformName = "Fuchsia";
        } else if (io.Platform.isLinux) {
          print("Platform: Linux");
          platformName = "Linux";
        } else if (io.Platform.isMacOS) {
          print("Platform: Mac");
          platformName = "MacOS";
        } else if (io.Platform.isWindows) {
          print("Platform: Windows");
          platformName = "Windows";
        }
      } // end if
    } on Exception catch (e) {
      print("Exception=" + e.toString());
    }

    return Container(
      width: MediaQuery.of(context).size.width * containerWidth! / 100,
      height: 1,
      color: Colors.transparent,
    );
  }
}
