// Automatic FlutterFlow imports
import '../../flutter_flow/flutter_flow_theme.dart';
import '../../flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom widgets
import '../actions/index.dart'; // Imports custom actions
import '../../flutter_flow/custom_functions.dart'; // Imports custom functions
import 'package:flutter/material.dart';
// Begin custom widget code
import 'package:charts_flutter/flutter.dart' as charts;
import 'package:charts_flutter/flutter.dart';

class ChartWidgetCoupon extends StatefulWidget {
  const ChartWidgetCoupon({
    Key? key,
    this.width,
    this.height,
    this.xAxisText,
    this.yAxisText,
    this.averageCouponValue,
  }) : super(key: key);

  final double? width;
  final double? height;
  final String? xAxisText;
  final String? yAxisText;
  final int? averageCouponValue;

  @override
  _ChartWidgetCouponState createState() => _ChartWidgetCouponState();
}

class _ChartWidgetCouponState extends State<ChartWidgetCoupon> {
  late List<charts.Series> seriesList;
  bool? animate;

  @override
  Widget build(BuildContext context) {
    seriesList = _createSampleData();

    return Container(
        width: widget.width,
        height: widget.height,
        child:
            // charts.BarChart
            charts.BarChart(
          seriesList as List<Series<dynamic, String>>,
          animate: animate,
          behaviors: [
            new charts.SeriesLegend(),
            new charts.LinePointHighlighter(
                showHorizontalFollowLine:
                    charts.LinePointHighlighterFollowLineType.none,
                showVerticalFollowLine:
                    charts.LinePointHighlighterFollowLineType.nearest),
            new charts.SelectNearest(
                eventTrigger: charts.SelectionTrigger.tapAndDrag),
          ],
          // Configure a stroke width to enable borders on the bars.
          defaultRenderer: new charts.BarRendererConfig(
              groupingType: charts.BarGroupingType.grouped, strokeWidthPx: 2.0),
        ) // charts.BarChart
        ); // Container
  }

  /// Create series list with multiple series
  static List<charts.Series<OrdinalSales, String>> _createSampleData() {
    final desktopSalesData = [
      new OrdinalSales('10', 5),
      new OrdinalSales('20', 25),
      new OrdinalSales('30', 10),
      new OrdinalSales('40', 40),
      new OrdinalSales('50', 60),
      new OrdinalSales('60', 70),
      new OrdinalSales('70', 80),
      new OrdinalSales('80', 50),
      new OrdinalSales('90', 30),
      new OrdinalSales('100', 20),
    ];

    final tableSalesData = [
      new OrdinalSales('10', 8),
      new OrdinalSales('20', 28),
      new OrdinalSales('30', 18),
      new OrdinalSales('40', 48),
      new OrdinalSales('50', 68),
      new OrdinalSales('60', 78),
      new OrdinalSales('70', 88),
      new OrdinalSales('80', 58),
      new OrdinalSales('90', 38),
      new OrdinalSales('100', 28),
    ];

    final mobileSalesData = [
      new OrdinalSales('2014', 20),
      new OrdinalSales('2015', 40),
      new OrdinalSales('2016', 20),
      new OrdinalSales('2017', 30),
    ];

    return [
      // Blue bars with a lighter center color.
      new charts.Series<OrdinalSales, String>(
        id: 'Desktop',
        domainFn: (OrdinalSales sales, _) => sales.year,
        measureFn: (OrdinalSales sales, _) => sales.sales,
        data: desktopSalesData,
        colorFn: (_, __) => charts.MaterialPalette.blue.shadeDefault,
        fillColorFn: (_, __) =>
            charts.MaterialPalette.blue.shadeDefault.lighter,
        //charts.MaterialPalette.cyan.shadeDefault.lighter.lighter.lighter,
      ),
      // Solid red bars. Fill color will default to the series color if no
      // fillColorFn is configured.
      new charts.Series<OrdinalSales, String>(
        id: 'Tablet',
        measureFn: (OrdinalSales sales, _) => sales.sales,
        data: tableSalesData,
        colorFn: (_, __) => charts.MaterialPalette.green.shadeDefault,
        domainFn: (OrdinalSales sales, _) => sales.year,
        fillColorFn: (_, __) =>
            charts.MaterialPalette.green.shadeDefault.lighter,
      ),
      // Hollow green bars.
/*
      new charts.Series<OrdinalSales, String>(
        id: 'Mobile',
        domainFn: (OrdinalSales sales, _) => sales.year,
        measureFn: (OrdinalSales sales, _) => sales.sales,
        data: mobileSalesData,
        colorFn: (_, __) => charts.MaterialPalette.green.shadeDefault,
        fillColorFn: (_, __) => charts.MaterialPalette.transparent,
      ),
 */
    ];
  }
}

/// Sample ordinal data type.
class OrdinalSales {
  final String year;
  final int sales;

  OrdinalSales(this.year, this.sales);
}
