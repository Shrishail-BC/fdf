// Automatic FlutterFlow imports
import '../../flutter_flow/flutter_flow_theme.dart';
import '../../flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom widgets
import '../actions/index.dart'; // Imports custom actions
import '../../flutter_flow/custom_functions.dart'; // Imports custom functions
import 'package:flutter/material.dart';

// Begin custom widget code
class ComputeProjectedCustomers extends StatefulWidget {
  const ComputeProjectedCustomers({
    Key? key,
    this.width,
    this.height,
    this.averageCouponValue,
    this.textFont,
    this.textSize,
    this.fontWeight,
    this.textColor,
  }) : super(key: key);

  final double? width;
  final double? height;
  final String? averageCouponValue;
  final String? textFont;
  final double? textSize;
  final int? fontWeight;
  final Color? textColor;

  @override
  _ComputeProjectedCustomersState createState() =>
      _ComputeProjectedCustomersState();
}

class _ComputeProjectedCustomersState extends State<ComputeProjectedCustomers> {
  @override
  double? payout;
  int? min;
  int? max;

  Widget build(BuildContext context) {
    min = int.parse(widget.averageCouponValue!) * 3000;
    max = int.parse(widget.averageCouponValue!) * 8000;
    return
        /*Container(
        color: Colors.transparent,
        width: widget.width,
        height: widget.height,
        child: Column(
          children: <Widget>[ */
        Text(
      min.toString() + " - " + max.toString(),
      style: TextStyle(
        color: widget.textColor,
        fontFamily: widget.textFont,
        fontSize: widget.textSize,
        fontWeight: FontWeight.w400,
      ).apply(fontWeightDelta: widget.fontWeight!),
      //     ),
      //    ],
      // ) // Column
    ); // Container
  }
}
