// Automatic FlutterFlow imports
import '../../flutter_flow/flutter_flow_theme.dart';
import '../../flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom widgets
import '../actions/index.dart'; // Imports custom actions
import '../../flutter_flow/custom_functions.dart'; // Imports custom functions
import 'package:flutter/material.dart';
// Begin custom widget code
import 'package:url_launcher/url_launcher.dart';

class OrientationBasedButton extends StatefulWidget {
  const OrientationBasedButton({
    Key? key,
    this.width,
    this.height,
    this.icon,
    this.iconColour,
    this.buttonText,
    this.buttonColor,
    this.buttonTextColor,
    this.textSize,
    this.url,
    this.hideInMobile,
    this.borderColor,
    this.borderRadius,
    this.borderWidth,
    this.elevation,
    this.textFont,
    this.fontWeight,
  }) : super(key: key);

  final double? width;
  final double? height;
  final Widget? icon;
  final Color? iconColour;
  final String? buttonText;
  final Color? buttonColor;
  final Color? buttonTextColor;
  final double? textSize;
  final String? url;
  final bool? hideInMobile;
  final Color? borderColor;
  final double? borderRadius;
  final double? borderWidth;
  final double? elevation;
  final String? textFont;
  final int? fontWeight;

  @override
  _OrientationBasedButtonState createState() => _OrientationBasedButtonState();
}

class _OrientationBasedButtonState extends State<OrientationBasedButton> {
  // launchURL
  launchURL(String url) async {
    if (await canLaunch(url)) {
      await launch(url, forceWebView: true);
    } else {
      throw 'Could not launch $url';
    }
  } // end launchURL

  @override
  Widget build(BuildContext context) {
    /*   ButtonStyle style = ElevatedButton.styleFrom(
        primary: widget.buttonColor, // widget.buttonColor,
        onPrimary: widget.buttonColor,
        onSurface: widget.buttonColor,
        disabledMouseCursor: SystemMouseCursors.click,
        alignment: Alignment.center,
        fixedSize: Size(widget.width, widget.height),
        minimumSize: Size(widget.width, widget.height),
        //  elevation: widget.elevation,
        side: BorderSide(
          width: widget.borderWidth == null ? 0 : widget.borderWidth,
          color: widget.borderColor == null
              ? const Color(0x00000000)
              : widget.borderColor,
        ),
        shape: RoundedRectangleBorder(
          borderRadius:
              BorderRadius.circular(widget.borderRadius), // <-- Radius
        ),
        // primary: widget.buttonColor,
        textStyle:
            TextStyle(fontSize: widget.textSize)); // ElevatedButton.styleFrom
*/
    MediaQueryData _mediaQueryData;
    double screenWidth;
    double screenHeight;
    late bool vHideInMobile;
    bool iconPresent;
    Icon? gkIcon;

    try {
      gkIcon = widget.icon as Icon?;
      if (gkIcon != null && gkIcon.size! > 0) {
        iconPresent = true;
      } else {
        iconPresent = false;
      }
    } catch (e) {
      iconPresent = false;
    }

    _mediaQueryData = MediaQuery.of(context);
    screenWidth = _mediaQueryData.size.width;
    screenHeight = _mediaQueryData.size.height;

    try {
      if (widget.hideInMobile == true) {
        vHideInMobile = true;
      } else {
        vHideInMobile = false;
      }
    } catch (e) {}

    if (screenHeight > screenWidth &&
        vHideInMobile &&
        screenWidth < 650) // Portrait
    {
//      setState(() => FFAppState().isPortrait = true);
      return Container();
    } else {
//      setState(() => FFAppState().isPortrait = false);

      if (iconPresent) {
        return Container(
            height: widget.height,
            width: widget.width,
            decoration: BoxDecoration(
              color: widget.buttonColor,
              borderRadius:
                  BorderRadius.all(Radius.circular(widget.borderRadius! + 2)),
            ),
            //         child: ElevatedButton(
            //           onPressed:null,
            //             style: style,
            //          onPressed: (){}, //async {
            //  null;
            // await launchURL(widget.url);
            // },
            child: Row(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisSize: MainAxisSize.min,
              children: [
                widget.icon!,
                Container(
                    height: widget.height,
                    width: widget.width! - (gkIcon!.size! * 3),
                    alignment: Alignment.center,
                    child: Text(
                      widget.buttonText!,
                      softWrap: true,
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        color: widget.buttonTextColor,
                        fontFamily: widget.textFont,
                        fontSize: widget.textSize,
                        fontWeight: FontWeight.w400,
                      ).apply(fontWeightDelta: widget.fontWeight!), //TextStyle
                    ) // Text
                    ) // Container
              ], //children
            ) // Row
            //       ) // ElevatedButton
            ); // Container
      } // if

      else {
        return Container(
            height: widget.height,
            width: widget.width,
            decoration: BoxDecoration(
              color: widget.buttonColor,
              borderRadius:
                  BorderRadius.all(Radius.circular(widget.borderRadius! + 2)),
            ),
            //          child: ElevatedButton(
            //                    onPressed: null,
            //              style: style,
            child: Container(
                alignment: Alignment.center,
                width: widget.width,
                height: widget.height,
                child: Text(
                  widget.buttonText!,
                  softWrap: true,
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: widget.buttonTextColor,
                    fontFamily: widget.textFont,
                    fontSize: widget.textSize,
                    fontWeight: FontWeight.w400,
                  ).apply(fontWeightDelta: widget.fontWeight!), //TextStyle
                ) //Text
                ) // Container
            //            ) // ElevatedButton
            ); // Container
      } // else
    } // return Container();
  }
}

String loadLanguage(
  dynamic poLanguage,
  List<String> localLanguageStore,
  List<String> localLanguageListStore,
) {
  // Add your function code here!
  if (localLanguageStore.isNotEmpty) {
    return "Already Loaded";
  }
  Map vmLangMap;
  vmLangMap = localLanguageStore.asMap();

  String? key = "na";
  String? langValue = "na";
  String currentLanguage = "en_US";

  List languageList;
  List listLanguageValues;
  int? id;
  int counter = 0;
  List listLangValues;

  vmLangMap = new Map();

  languageList = new List.filled(1, 0);
  poLanguage[0].forEach((k, v) {
    if (counter > 1) {
      languageList.add(k);
    }
    counter++;
    //print('{ key: $k, value: $v }');
  });

  for (var langElement in poLanguage) {
    listLangValues = new List.filled(1, 0);
//    for (var subElement in langElement) {
    id = langElement["Id"];
    key = langElement["Key"];
    langValue = langElement[currentLanguage];
    counter = 0;
    langElement.forEach((k, v) {
      if (counter > 1) {
        listLangValues.add(v);
      }
      counter++;
      //print('{ key: $k, value: $v }');
    });
    if (listLangValues.isNotEmpty && key!.isNotEmpty) {
      vmLangMap[key] = listLangValues;
    }
    //vmLangMap.putIfAbsent(key, () => listLangValues);
    //vmLangMap.putIfAbsent(key, () => listLangValues);
//   }
  }
  // langValue = vmLangMap[key].languageList.indexOf(currentLanguage);
  //return localLanguage;
  localLanguageListStore[0] = languageList.toString();
  localLanguageStore[0] = vmLangMap.toString();

  return "none";
}
