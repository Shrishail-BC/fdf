// Automatic FlutterFlow imports
import '../../flutter_flow/flutter_flow_theme.dart';
import '../../flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom widgets
import '../actions/index.dart'; // Imports custom actions
import '../../flutter_flow/custom_functions.dart'; // Imports custom functions
import 'package:flutter/material.dart';
// Begin custom widget code
import 'package:google_fonts/google_fonts.dart';

class DateTextField2 extends StatefulWidget {
  const DateTextField2({
    Key? key,
    this.width,
    this.height,
    this.hintText,
    this.emptyErrorMsg,
    required this.initialValue,
    this.lengthErrorMsg,
    this.fieldcolor,
  }) : super(key: key);

  final double? width;
  final double? height;
  final String? hintText;
  final String? emptyErrorMsg;
  final String initialValue;
  final String? lengthErrorMsg;
  final Color? fieldcolor;

  @override
  _DateTextField2State createState() => _DateTextField2State();
}

class _DateTextField2State extends State<DateTextField2> {
  @override
  Widget build(BuildContext context) {
    if (FFAppState().startdate3.isEmpty) {
      FFAppState().startdate3 = widget.initialValue;
    }
    var maskedController = MaskedTextControllerr(
        mask: '00/00/0000-00', text: FFAppState().startdate3);

    return TextFormField(
      controller: maskedController,
      onChanged: (text) {
        FFAppState().startdate3 = text;
      },
      validator: (value) {
        if (value!.isEmpty) {
          return widget.emptyErrorMsg;
        } else if (value.length != 14) {
          return widget.lengthErrorMsg;
        }
        return null;
      },
      obscureText: false,
      style: GoogleFonts.poppins(
        color: Colors.black,
        fontSize: 14,
      ),
      decoration: InputDecoration(
        hintText: widget.hintText,
        hintStyle: TextStyle(
          color: Color(0xFF706C6C),
        ),
        contentPadding: EdgeInsets.fromLTRB(12, 20, 12, 20),
        enabledBorder: OutlineInputBorder(
          borderSide: BorderSide(
            color: Color(0x00000000),
            width: 1,
          ),
          borderRadius: const BorderRadius.only(
            topLeft: Radius.circular(4.0),
            topRight: Radius.circular(4.0),
          ),
        ),
        focusedBorder: OutlineInputBorder(
          borderSide: BorderSide(
            color: Color(0x00000000),
            width: 1,
          ),
          borderRadius: const BorderRadius.only(
            topLeft: Radius.circular(4.0),
            topRight: Radius.circular(4.0),
          ),
        ),
        filled: true,
        fillColor: widget.fieldcolor,
      ),
    );
  }
}

class MaskedTextControllerr extends TextEditingController {
  MaskedTextControllerr(
      {String? text, this.mask, Map<String, RegExp>? translator})
      : super(text: text) {
    this.translator =
        translator ?? MaskedTextControllerr.getDefaultTranslator();

    this.addListener(() {
      var previous = this._lastUpdatedText;
      if (this.beforeChange(previous, this.text)) {
        this.updateText(this.text);
        this.afterChange(previous, this.text);
      } else {
        this.updateText(this._lastUpdatedText);
      }
    });
    this.updateText(this.text);
  }

  String? mask;

  late Map<String, RegExp> translator;

  Function afterChange = (String previous, String next) {};
  Function beforeChange = (String previous, String next) {
    return true;
  };

  String _lastUpdatedText = '';

  void updateText(String text) {
    if (text != null) {
      this.text = this._applyMask(this.mask, text);
    } else {
      this.text = '';
    }

    this._lastUpdatedText = this.text;
  }

  void updateMask(String mask, {bool moveCursorToEnd = true}) {
    this.mask = mask;
    this.updateText(this.text);

    if (moveCursorToEnd) {
      this.moveCursorToEnd();
    }
  }

  void moveCursorToEnd() {
    var text = this._lastUpdatedText;
    this.selection = new TextSelection.fromPosition(
        new TextPosition(offset: (text ?? '').length));
  }

  @override
  void set text(String newText) {
    if (super.text != newText) {
      super.text = newText;
      this.moveCursorToEnd();
    }
  }

  static Map<String, RegExp> getDefaultTranslator() {
    return {
      'A': new RegExp(r'[A-Za-z]'),
      '0': new RegExp(r'[0-9]'),
      '@': new RegExp(r'[A-Za-z0-9]'),
      '': new RegExp(r'.')
    };
  }

  String _applyMask(String? mask, String value) {
    String result = '';

    var maskCharIndex = 0;
    var valueCharIndex = 0;

    while (true) {
      // if mask is ended, break.
      if (maskCharIndex == mask!.length) {
        break;
      }

      // if value is ended, break.
      if (valueCharIndex == value.length) {
        break;
      }

      var maskChar = mask[maskCharIndex];
      var valueChar = value[valueCharIndex];

      // value equals mask, just set
      if (maskChar == valueChar) {
        result += maskChar;
        valueCharIndex += 1;
        maskCharIndex += 1;
        continue;
      }

      // apply translator if match
      if (this.translator.containsKey(maskChar)) {
        if (this.translator[maskChar]!.hasMatch(valueChar)) {
          result += valueChar;
          maskCharIndex += 1;
        }

        valueCharIndex += 1;
        continue;
      }

      // not masked value, fixed char on mask
      result += maskChar;
      maskCharIndex += 1;
      continue;
    }

    return result;
  }
}
