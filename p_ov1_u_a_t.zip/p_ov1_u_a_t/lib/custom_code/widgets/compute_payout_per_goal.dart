// Automatic FlutterFlow imports
import '../../flutter_flow/flutter_flow_theme.dart';
import '../../flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom widgets
import '../actions/index.dart'; // Imports custom actions
import '../../flutter_flow/custom_functions.dart'; // Imports custom functions
import 'package:flutter/material.dart';

// Begin custom widget code
class ComputePayoutPerGoal extends StatefulWidget {
  const ComputePayoutPerGoal({
    Key? key,
    this.width,
    this.height,
    this.averageCouponValue,
    this.textFont,
    this.textSize,
    this.fontWeight,
    this.textColor,
  }) : super(key: key);

  final double? width;
  final double? height;
  final String? averageCouponValue;
  final String? textFont;
  final double? textSize;
  final int? fontWeight;
  final Color? textColor;

  @override
  _ComputePayoutPerGoalState createState() => _ComputePayoutPerGoalState();
}

class _ComputePayoutPerGoalState extends State<ComputePayoutPerGoal> {
  @override
  double? payout;

  Widget build(BuildContext context) {
    payout = double.parse(widget.averageCouponValue!) * 5;

    return
        /*Container(
        color: Colors.transparent,
        width: widget.width,
        height: widget.height,
        child: Column(
          children: <Widget>[ */
        Text(
      payout.toString(),
      style: TextStyle(
        color: widget.textColor,
        fontFamily: widget.textFont,
        fontSize: widget.textSize,
        fontWeight: FontWeight.w400,
      ).apply(fontWeightDelta: widget.fontWeight!),
      //     ),
      //    ],
      // ) // Column
    ); // Container
  }
}
