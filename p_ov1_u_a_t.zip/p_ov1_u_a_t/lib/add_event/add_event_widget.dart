import '../backend/api_requests/api_calls.dart';
import '../components/app_header_widget.dart';
import '../components/app_nav_bar_widget.dart';
import '../dashboard_admin/dashboard_admin_widget.dart';
import '../flutter_flow/flutter_flow_drop_down.dart';
import '../flutter_flow/flutter_flow_theme.dart';
import '../flutter_flow/flutter_flow_util.dart';
import '../flutter_flow/flutter_flow_widgets.dart';
import '../custom_code/widgets/index.dart' as custom_widgets;
import '../flutter_flow/custom_functions.dart' as functions;
import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:google_fonts/google_fonts.dart';

class AddEventWidget extends StatefulWidget {
  const AddEventWidget({
    Key? key,
    this.poRegType,
  }) : super(key: key);

  final String? poRegType;

  @override
  _AddEventWidgetState createState() => _AddEventWidgetState();
}

class _AddEventWidgetState extends State<AddEventWidget> {
  ApiCallResponse? apiCallOutput3;
  ApiCallResponse? apiCallOutput;
  TextEditingController? citynameController;
  String? eventtypeValue;
  String? cityValue;
  TextEditingController? textController4;
  TextEditingController? textController5;
  String? loccountryValue;
  String? provinceValue;
  TextEditingController? locaddressController;
  TextEditingController? locnameController;
  TextEditingController? maxnoteamplayersController;
  TextEditingController? maxsupportteamsController;
  TextEditingController? minnoteamplayersController;
  TextEditingController? majorityageController;
  TextEditingController? playerregfeeController;
  TextEditingController? salestaxrateController;
  TextEditingController? youthsalestaxrateController;
  TextEditingController? avail1010rentspaceController;
  TextEditingController? avail1015rentspaceController;
  TextEditingController? textController15;
  String? deadlineDayValue;
  String? deadlineMonthValue;
  String? deadlineYearValue;
  String? endDateDayValue;
  String? endDateMonthValue;
  String? endDateYearValue;
  String? startdatedayValue;
  String? startdatemonthValue;
  String? startdateyearValue;
  String? dropDownValue1;
  String? dropDownValue2;
  String? dropDownValue3;
  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    avail1010rentspaceController = TextEditingController();
    avail1015rentspaceController = TextEditingController();
    textController15 = TextEditingController();
    locaddressController = TextEditingController();
    locnameController = TextEditingController();
    textController4 = TextEditingController();
    textController5 = TextEditingController();
    maxnoteamplayersController = TextEditingController();
    maxsupportteamsController = TextEditingController();
    minnoteamplayersController = TextEditingController();
    majorityageController = TextEditingController();
    playerregfeeController = TextEditingController();
    salestaxrateController = TextEditingController();
    youthsalestaxrateController = TextEditingController();
    citynameController = TextEditingController();
  }

  @override
  void dispose() {
    avail1010rentspaceController?.dispose();
    avail1015rentspaceController?.dispose();
    textController15?.dispose();
    locaddressController?.dispose();
    locnameController?.dispose();
    textController4?.dispose();
    textController5?.dispose();
    maxnoteamplayersController?.dispose();
    maxsupportteamsController?.dispose();
    minnoteamplayersController?.dispose();
    majorityageController?.dispose();
    playerregfeeController?.dispose();
    salestaxrateController?.dispose();
    youthsalestaxrateController?.dispose();
    citynameController?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: scaffoldKey,
      backgroundColor: Color(0xFFFAFAFA),
      body: SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.max,
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              width: MediaQuery.of(context).size.width,
              decoration: BoxDecoration(
                color: Color(0xFF274078),
              ),
              child: Padding(
                padding: EdgeInsetsDirectional.fromSTEB(10, 0, 0, 0),
                child: Row(
                  mainAxisSize: MainAxisSize.max,
                  children: [
                    Padding(
                      padding: EdgeInsetsDirectional.fromSTEB(0, 0, 10, 0),
                      child: InkWell(
                        onTap: () async {
                          scaffoldKey.currentState!.openDrawer();
                        },
                        child: Icon(
                          Icons.menu,
                          color: FlutterFlowTheme.of(context).tertiaryColor,
                          size: 24,
                        ),
                      ),
                    ),
                    Expanded(
                      child: AppHeaderWidget(),
                    ),
                  ],
                ),
              ),
            ),
            Container(
              width: MediaQuery.of(context).size.width,
              height: MediaQuery.of(context).size.height * 0.875,
              decoration: BoxDecoration(),
              child: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.max,
                  children: [
                    Padding(
                      padding: EdgeInsetsDirectional.fromSTEB(0, 10, 0, 0),
                      child: Row(
                        mainAxisSize: MainAxisSize.max,
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Container(
                            width: 100,
                            decoration: BoxDecoration(
                              color: Colors.transparent,
                            ),
                          ),
                          Container(
                            width: 200,
                            decoration: BoxDecoration(
                              color: Colors.transparent,
                            ),
                            child: Text(
                              FFLocalizations.of(context).getText(
                                '5l6fsi9z' /* Add Event */,
                              ),
                              textAlign: TextAlign.center,
                              style:
                                  FlutterFlowTheme.of(context).title1.override(
                                        fontFamily: 'Poppins',
                                        color: Color(0xFF274078),
                                        fontSize: 24,
                                        fontWeight: FontWeight.w600,
                                      ),
                            ),
                          ),
                          Container(
                            width: 100,
                            decoration: BoxDecoration(
                              color: Colors.transparent,
                            ),
                            child: Padding(
                              padding:
                                  EdgeInsetsDirectional.fromSTEB(0, 0, 10, 0),
                              child: InkWell(
                                onTap: () async {
                                  await Navigator.push(
                                    context,
                                    PageTransition(
                                      type: PageTransitionType.rightToLeft,
                                      duration: Duration(milliseconds: 50),
                                      reverseDuration:
                                          Duration(milliseconds: 50),
                                      child: DashboardAdminWidget(),
                                    ),
                                  );
                                },
                                child: Icon(
                                  Icons.home,
                                  color: Colors.white,
                                  size: 30,
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    Padding(
                      padding: EdgeInsetsDirectional.fromSTEB(50, 0, 50, 0),
                      child: SingleChildScrollView(
                        child: Column(
                          mainAxisSize: MainAxisSize.max,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Container(
                              width: MediaQuery.of(context).size.width,
                              decoration: BoxDecoration(),
                              child: Padding(
                                padding:
                                    EdgeInsetsDirectional.fromSTEB(0, 10, 0, 0),
                                child: Wrap(
                                  spacing: 0,
                                  runSpacing: 0,
                                  alignment: WrapAlignment.spaceBetween,
                                  crossAxisAlignment: WrapCrossAlignment.start,
                                  direction: Axis.horizontal,
                                  runAlignment: WrapAlignment.end,
                                  verticalDirection: VerticalDirection.down,
                                  clipBehavior: Clip.none,
                                  children: [
                                    Padding(
                                      padding: EdgeInsetsDirectional.fromSTEB(
                                          0, 15, 0, 0),
                                      child: Wrap(
                                        spacing: 0,
                                        runSpacing: 0,
                                        alignment: WrapAlignment.start,
                                        crossAxisAlignment:
                                            WrapCrossAlignment.start,
                                        direction: Axis.horizontal,
                                        runAlignment: WrapAlignment.start,
                                        verticalDirection:
                                            VerticalDirection.down,
                                        clipBehavior: Clip.none,
                                        children: [
                                          Container(
                                            width: 150,
                                            decoration: BoxDecoration(
                                              color: Colors.transparent,
                                            ),
                                            child: Padding(
                                              padding: EdgeInsetsDirectional
                                                  .fromSTEB(0, 15, 20, 0),
                                              child: custom_widgets
                                                  .OrientationBasedText(
                                                width: MediaQuery.of(context)
                                                    .size
                                                    .width,
                                                height: 40,
                                                text: 'City Name',
                                                textColor: Colors.black,
                                                textSize: 14.0,
                                                textFont: 'Poppins',
                                                fontWeight: 0,
                                                mobileAlignment: 'L',
                                                desktopAlignment: 'R',
                                              ),
                                            ),
                                          ),
                                          Container(
                                            width: 370,
                                            height: 50,
                                            decoration: BoxDecoration(),
                                            child: TextFormField(
                                              controller: citynameController,
                                              onFieldSubmitted: (_) async {
                                                apiCallOutput =
                                                    await GetEventsVTwoCall
                                                        .call();

                                                setState(() {});
                                              },
                                              obscureText: false,
                                              decoration: InputDecoration(
                                                hintText:
                                                    FFLocalizations.of(context)
                                                        .getText(
                                                  '063gdeja' /* Enter a value */,
                                                ),
                                                enabledBorder:
                                                    OutlineInputBorder(
                                                  borderSide: BorderSide(
                                                    color: Colors.black,
                                                    width: 1,
                                                  ),
                                                  borderRadius:
                                                      const BorderRadius.only(
                                                    topLeft:
                                                        Radius.circular(4.0),
                                                    topRight:
                                                        Radius.circular(4.0),
                                                  ),
                                                ),
                                                focusedBorder:
                                                    OutlineInputBorder(
                                                  borderSide: BorderSide(
                                                    color: Colors.black,
                                                    width: 1,
                                                  ),
                                                  borderRadius:
                                                      const BorderRadius.only(
                                                    topLeft:
                                                        Radius.circular(4.0),
                                                    topRight:
                                                        Radius.circular(4.0),
                                                  ),
                                                ),
                                                errorBorder: OutlineInputBorder(
                                                  borderSide: BorderSide(
                                                    color: Color(0x00000000),
                                                    width: 1,
                                                  ),
                                                  borderRadius:
                                                      const BorderRadius.only(
                                                    topLeft:
                                                        Radius.circular(4.0),
                                                    topRight:
                                                        Radius.circular(4.0),
                                                  ),
                                                ),
                                                focusedErrorBorder:
                                                    OutlineInputBorder(
                                                  borderSide: BorderSide(
                                                    color: Color(0x00000000),
                                                    width: 1,
                                                  ),
                                                  borderRadius:
                                                      const BorderRadius.only(
                                                    topLeft:
                                                        Radius.circular(4.0),
                                                    topRight:
                                                        Radius.circular(4.0),
                                                  ),
                                                ),
                                                filled: true,
                                                fillColor: Colors.white,
                                              ),
                                              style:
                                                  FlutterFlowTheme.of(context)
                                                      .bodyText1
                                                      .override(
                                                        fontFamily: 'Poppins',
                                                        color:
                                                            FlutterFlowTheme.of(
                                                                    context)
                                                                .black,
                                                      ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                    Padding(
                                      padding: EdgeInsetsDirectional.fromSTEB(
                                          0, 15, 0, 0),
                                      child: Wrap(
                                        spacing: 0,
                                        runSpacing: 0,
                                        alignment: WrapAlignment.start,
                                        crossAxisAlignment:
                                            WrapCrossAlignment.start,
                                        direction: Axis.horizontal,
                                        runAlignment: WrapAlignment.start,
                                        verticalDirection:
                                            VerticalDirection.down,
                                        clipBehavior: Clip.none,
                                        children: [
                                          Container(
                                            width: 150,
                                            decoration: BoxDecoration(
                                              color: Colors.transparent,
                                            ),
                                            child: Padding(
                                              padding: EdgeInsetsDirectional
                                                  .fromSTEB(0, 15, 20, 0),
                                              child: custom_widgets
                                                  .OrientationBasedText(
                                                width: MediaQuery.of(context)
                                                    .size
                                                    .width,
                                                height: 40,
                                                text: 'Event type',
                                                textColor: Colors.black,
                                                textSize: 14.0,
                                                textFont: 'Poppins',
                                                fontWeight: 0,
                                                mobileAlignment: 'L',
                                                desktopAlignment: 'R',
                                              ),
                                            ),
                                          ),
                                          Container(
                                            width: 150,
                                            height: 50,
                                            decoration: BoxDecoration(
                                              color: Colors.transparent,
                                            ),
                                            child: FlutterFlowDropDown(
                                              options: [
                                                FFLocalizations.of(context)
                                                    .getText(
                                                  'np2nf1i7' /* Play On! */,
                                                )
                                              ],
                                              onChanged: (val) => setState(
                                                  () => eventtypeValue = val),
                                              width: 180,
                                              height: 50,
                                              textStyle:
                                                  FlutterFlowTheme.of(context)
                                                      .bodyText1
                                                      .override(
                                                        fontFamily: 'Poppins',
                                                        color: Colors.black,
                                                      ),
                                              hintText:
                                                  FFLocalizations.of(context)
                                                      .getText(
                                                'hurdsn9k' /* Play On! */,
                                              ),
                                              fillColor: Colors.white,
                                              elevation: 2,
                                              borderColor: Colors.black,
                                              borderWidth: 0,
                                              borderRadius: 0,
                                              margin: EdgeInsetsDirectional
                                                  .fromSTEB(12, 4, 12, 4),
                                              hidesUnderline: true,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    Padding(
                      padding: EdgeInsetsDirectional.fromSTEB(10, 30, 10, 0),
                      child: SingleChildScrollView(
                        child: Column(
                          mainAxisSize: MainAxisSize.max,
                          children: [
                            Wrap(
                              spacing: 0,
                              runSpacing: 0,
                              alignment: WrapAlignment.start,
                              crossAxisAlignment: WrapCrossAlignment.start,
                              direction: Axis.horizontal,
                              runAlignment: WrapAlignment.start,
                              verticalDirection: VerticalDirection.down,
                              clipBehavior: Clip.none,
                              children: [
                                Container(
                                  width: MediaQuery.of(context).size.width,
                                  height:
                                      MediaQuery.of(context).size.height * 0.5,
                                  decoration: BoxDecoration(),
                                  child: DefaultTabController(
                                    length: 6,
                                    initialIndex: 0,
                                    child: Column(
                                      children: [
                                        TabBar(
                                          isScrollable: true,
                                          labelColor: Colors.black,
                                          labelStyle:
                                              FlutterFlowTheme.of(context)
                                                  .bodyText1,
                                          indicatorColor: Colors.black,
                                          tabs: [
                                            Tab(
                                              text: FFLocalizations.of(context)
                                                  .getText(
                                                'izxfsn8l' /* Location Detailss */,
                                              ),
                                            ),
                                            Tab(
                                              text: FFLocalizations.of(context)
                                                  .getText(
                                                '1ld52df8' /* Team */,
                                              ),
                                            ),
                                            Tab(
                                              text: FFLocalizations.of(context)
                                                  .getText(
                                                'wauwlch7' /* Fee */,
                                              ),
                                            ),
                                            Tab(
                                              text: FFLocalizations.of(context)
                                                  .getText(
                                                '2c3io4eu' /* Space */,
                                              ),
                                            ),
                                            Tab(
                                              text: FFLocalizations.of(context)
                                                  .getText(
                                                'e5h7nwwm' /* Important Dates */,
                                              ),
                                            ),
                                            Tab(
                                              text: FFLocalizations.of(context)
                                                  .getText(
                                                'yjaunzr8' /* Coordinator  */,
                                              ),
                                            ),
                                          ],
                                        ),
                                        Expanded(
                                          child: TabBarView(
                                            children: [
                                              SingleChildScrollView(
                                                child: Column(
                                                  mainAxisSize:
                                                      MainAxisSize.max,
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.center,
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.center,
                                                  children: [
                                                    Padding(
                                                      padding:
                                                          EdgeInsetsDirectional
                                                              .fromSTEB(
                                                                  0, 10, 0, 0),
                                                      child: Container(
                                                        width: MediaQuery.of(
                                                                context)
                                                            .size
                                                            .width,
                                                        decoration:
                                                            BoxDecoration(),
                                                        child:
                                                            SingleChildScrollView(
                                                          child: Column(
                                                            mainAxisSize:
                                                                MainAxisSize
                                                                    .max,
                                                            mainAxisAlignment:
                                                                MainAxisAlignment
                                                                    .center,
                                                            crossAxisAlignment:
                                                                CrossAxisAlignment
                                                                    .center,
                                                            children: [
                                                              Container(
                                                                width: 1200,
                                                                decoration:
                                                                    BoxDecoration(),
                                                                child: Column(
                                                                  mainAxisSize:
                                                                      MainAxisSize
                                                                          .max,
                                                                  crossAxisAlignment:
                                                                      CrossAxisAlignment
                                                                          .stretch,
                                                                  children: [
                                                                    Wrap(
                                                                      spacing:
                                                                          0,
                                                                      runSpacing:
                                                                          0,
                                                                      alignment:
                                                                          WrapAlignment
                                                                              .spaceBetween,
                                                                      crossAxisAlignment:
                                                                          WrapCrossAlignment
                                                                              .start,
                                                                      direction:
                                                                          Axis.horizontal,
                                                                      runAlignment:
                                                                          WrapAlignment
                                                                              .start,
                                                                      verticalDirection:
                                                                          VerticalDirection
                                                                              .down,
                                                                      clipBehavior:
                                                                          Clip.none,
                                                                      children: [
                                                                        Padding(
                                                                          padding: EdgeInsetsDirectional.fromSTEB(
                                                                              0,
                                                                              20,
                                                                              0,
                                                                              0),
                                                                          child:
                                                                              Wrap(
                                                                            spacing:
                                                                                0,
                                                                            runSpacing:
                                                                                0,
                                                                            alignment:
                                                                                WrapAlignment.start,
                                                                            crossAxisAlignment:
                                                                                WrapCrossAlignment.start,
                                                                            direction:
                                                                                Axis.horizontal,
                                                                            runAlignment:
                                                                                WrapAlignment.start,
                                                                            verticalDirection:
                                                                                VerticalDirection.down,
                                                                            clipBehavior:
                                                                                Clip.none,
                                                                            children: [
                                                                              Container(
                                                                                width: 150,
                                                                                decoration: BoxDecoration(
                                                                                  color: Colors.transparent,
                                                                                ),
                                                                                child: Padding(
                                                                                  padding: EdgeInsetsDirectional.fromSTEB(0, 15, 20, 0),
                                                                                  child: custom_widgets.OrientationBasedText(
                                                                                    width: MediaQuery.of(context).size.width,
                                                                                    height: 40,
                                                                                    text: 'Location Name',
                                                                                    textColor: Colors.black,
                                                                                    textSize: 14.0,
                                                                                    textFont: 'Poppins',
                                                                                    fontWeight: 0,
                                                                                    mobileAlignment: 'L',
                                                                                    desktopAlignment: 'R',
                                                                                  ),
                                                                                ),
                                                                              ),
                                                                              Container(
                                                                                width: 300,
                                                                                height: 50,
                                                                                decoration: BoxDecoration(
                                                                                  color: FlutterFlowTheme.of(context).tertiaryColor,
                                                                                ),
                                                                                child: TextFormField(
                                                                                  controller: locnameController,
                                                                                  obscureText: false,
                                                                                  decoration: InputDecoration(
                                                                                    hintText: FFLocalizations.of(context).getText(
                                                                                      'fgh0fokg' /* Enter a  value */,
                                                                                    ),
                                                                                    enabledBorder: OutlineInputBorder(
                                                                                      borderSide: BorderSide(
                                                                                        color: Colors.black,
                                                                                        width: 1,
                                                                                      ),
                                                                                      borderRadius: const BorderRadius.only(
                                                                                        topLeft: Radius.circular(4.0),
                                                                                        topRight: Radius.circular(4.0),
                                                                                      ),
                                                                                    ),
                                                                                    focusedBorder: OutlineInputBorder(
                                                                                      borderSide: BorderSide(
                                                                                        color: Colors.black,
                                                                                        width: 1,
                                                                                      ),
                                                                                      borderRadius: const BorderRadius.only(
                                                                                        topLeft: Radius.circular(4.0),
                                                                                        topRight: Radius.circular(4.0),
                                                                                      ),
                                                                                    ),
                                                                                    errorBorder: OutlineInputBorder(
                                                                                      borderSide: BorderSide(
                                                                                        color: Color(0x00000000),
                                                                                        width: 1,
                                                                                      ),
                                                                                      borderRadius: const BorderRadius.only(
                                                                                        topLeft: Radius.circular(4.0),
                                                                                        topRight: Radius.circular(4.0),
                                                                                      ),
                                                                                    ),
                                                                                    focusedErrorBorder: OutlineInputBorder(
                                                                                      borderSide: BorderSide(
                                                                                        color: Color(0x00000000),
                                                                                        width: 1,
                                                                                      ),
                                                                                      borderRadius: const BorderRadius.only(
                                                                                        topLeft: Radius.circular(4.0),
                                                                                        topRight: Radius.circular(4.0),
                                                                                      ),
                                                                                    ),
                                                                                    filled: true,
                                                                                    fillColor: Colors.white,
                                                                                  ),
                                                                                  style: FlutterFlowTheme.of(context).bodyText1.override(
                                                                                        fontFamily: 'Poppins',
                                                                                        color: FlutterFlowTheme.of(context).black,
                                                                                      ),
                                                                                ),
                                                                              ),
                                                                            ],
                                                                          ),
                                                                        ),
                                                                        Padding(
                                                                          padding: EdgeInsetsDirectional.fromSTEB(
                                                                              0,
                                                                              25,
                                                                              0,
                                                                              0),
                                                                          child:
                                                                              Wrap(
                                                                            spacing:
                                                                                0,
                                                                            runSpacing:
                                                                                0,
                                                                            alignment:
                                                                                WrapAlignment.start,
                                                                            crossAxisAlignment:
                                                                                WrapCrossAlignment.start,
                                                                            direction:
                                                                                Axis.horizontal,
                                                                            runAlignment:
                                                                                WrapAlignment.start,
                                                                            verticalDirection:
                                                                                VerticalDirection.down,
                                                                            clipBehavior:
                                                                                Clip.none,
                                                                            children: [
                                                                              Container(
                                                                                width: 150,
                                                                                decoration: BoxDecoration(
                                                                                  color: Colors.transparent,
                                                                                ),
                                                                                child: Padding(
                                                                                  padding: EdgeInsetsDirectional.fromSTEB(0, 15, 20, 0),
                                                                                  child: custom_widgets.OrientationBasedText(
                                                                                    width: MediaQuery.of(context).size.width,
                                                                                    height: 40,
                                                                                    text: 'Address',
                                                                                    textColor: Colors.black,
                                                                                    textSize: 14.0,
                                                                                    textFont: 'Poppins',
                                                                                    fontWeight: 0,
                                                                                    mobileAlignment: 'L',
                                                                                    desktopAlignment: 'R',
                                                                                  ),
                                                                                ),
                                                                              ),
                                                                              Container(
                                                                                width: 300,
                                                                                height: 50,
                                                                                decoration: BoxDecoration(
                                                                                  color: FlutterFlowTheme.of(context).tertiaryColor,
                                                                                ),
                                                                                child: TextFormField(
                                                                                  controller: locaddressController,
                                                                                  obscureText: false,
                                                                                  decoration: InputDecoration(
                                                                                    hintText: FFLocalizations.of(context).getText(
                                                                                      'psva9ukm' /* Enter address */,
                                                                                    ),
                                                                                    enabledBorder: OutlineInputBorder(
                                                                                      borderSide: BorderSide(
                                                                                        color: Colors.black,
                                                                                        width: 1,
                                                                                      ),
                                                                                      borderRadius: const BorderRadius.only(
                                                                                        topLeft: Radius.circular(4.0),
                                                                                        topRight: Radius.circular(4.0),
                                                                                      ),
                                                                                    ),
                                                                                    focusedBorder: OutlineInputBorder(
                                                                                      borderSide: BorderSide(
                                                                                        color: Colors.black,
                                                                                        width: 1,
                                                                                      ),
                                                                                      borderRadius: const BorderRadius.only(
                                                                                        topLeft: Radius.circular(4.0),
                                                                                        topRight: Radius.circular(4.0),
                                                                                      ),
                                                                                    ),
                                                                                    errorBorder: OutlineInputBorder(
                                                                                      borderSide: BorderSide(
                                                                                        color: Color(0x00000000),
                                                                                        width: 1,
                                                                                      ),
                                                                                      borderRadius: const BorderRadius.only(
                                                                                        topLeft: Radius.circular(4.0),
                                                                                        topRight: Radius.circular(4.0),
                                                                                      ),
                                                                                    ),
                                                                                    focusedErrorBorder: OutlineInputBorder(
                                                                                      borderSide: BorderSide(
                                                                                        color: Color(0x00000000),
                                                                                        width: 1,
                                                                                      ),
                                                                                      borderRadius: const BorderRadius.only(
                                                                                        topLeft: Radius.circular(4.0),
                                                                                        topRight: Radius.circular(4.0),
                                                                                      ),
                                                                                    ),
                                                                                    filled: true,
                                                                                    fillColor: Colors.white,
                                                                                  ),
                                                                                  style: FlutterFlowTheme.of(context).bodyText1.override(
                                                                                        fontFamily: 'Poppins',
                                                                                        color: FlutterFlowTheme.of(context).black,
                                                                                      ),
                                                                                ),
                                                                              ),
                                                                            ],
                                                                          ),
                                                                        ),
                                                                      ],
                                                                    ),
                                                                    Wrap(
                                                                      spacing:
                                                                          0,
                                                                      runSpacing:
                                                                          0,
                                                                      alignment:
                                                                          WrapAlignment
                                                                              .spaceBetween,
                                                                      crossAxisAlignment:
                                                                          WrapCrossAlignment
                                                                              .start,
                                                                      direction:
                                                                          Axis.horizontal,
                                                                      runAlignment:
                                                                          WrapAlignment
                                                                              .start,
                                                                      verticalDirection:
                                                                          VerticalDirection
                                                                              .down,
                                                                      clipBehavior:
                                                                          Clip.none,
                                                                      children: [
                                                                        Padding(
                                                                          padding: EdgeInsetsDirectional.fromSTEB(
                                                                              0,
                                                                              25,
                                                                              0,
                                                                              0),
                                                                          child:
                                                                              Wrap(
                                                                            spacing:
                                                                                0,
                                                                            runSpacing:
                                                                                0,
                                                                            alignment:
                                                                                WrapAlignment.start,
                                                                            crossAxisAlignment:
                                                                                WrapCrossAlignment.start,
                                                                            direction:
                                                                                Axis.horizontal,
                                                                            runAlignment:
                                                                                WrapAlignment.start,
                                                                            verticalDirection:
                                                                                VerticalDirection.down,
                                                                            clipBehavior:
                                                                                Clip.none,
                                                                            children: [
                                                                              Container(
                                                                                width: 150,
                                                                                decoration: BoxDecoration(
                                                                                  color: Colors.transparent,
                                                                                ),
                                                                                child: Padding(
                                                                                  padding: EdgeInsetsDirectional.fromSTEB(0, 15, 20, 0),
                                                                                  child: custom_widgets.OrientationBasedText(
                                                                                    width: MediaQuery.of(context).size.width,
                                                                                    height: 40,
                                                                                    text: 'Country',
                                                                                    textColor: Colors.black,
                                                                                    textSize: 14.0,
                                                                                    textFont: 'Poppins',
                                                                                    fontWeight: 0,
                                                                                    mobileAlignment: 'L',
                                                                                    desktopAlignment: 'R',
                                                                                  ),
                                                                                ),
                                                                              ),
                                                                              Container(
                                                                                width: 300,
                                                                                height: 50,
                                                                                decoration: BoxDecoration(
                                                                                  color: FlutterFlowTheme.of(context).tertiaryColor,
                                                                                ),
                                                                                child: FlutterFlowDropDown(
                                                                                  options: functions.getCountries()!.toList(),
                                                                                  onChanged: (val) => setState(() => loccountryValue = val),
                                                                                  width: 180,
                                                                                  height: 50,
                                                                                  textStyle: FlutterFlowTheme.of(context).bodyText1.override(
                                                                                        fontFamily: 'Poppins',
                                                                                        color: Colors.black,
                                                                                      ),
                                                                                  hintText: FFLocalizations.of(context).getText(
                                                                                    'n8y886ru' /* Select one */,
                                                                                  ),
                                                                                  fillColor: Colors.white,
                                                                                  elevation: 2,
                                                                                  borderColor: Colors.black,
                                                                                  borderWidth: 1,
                                                                                  borderRadius: 4,
                                                                                  margin: EdgeInsetsDirectional.fromSTEB(12, 4, 12, 4),
                                                                                  hidesUnderline: true,
                                                                                ),
                                                                              ),
                                                                            ],
                                                                          ),
                                                                        ),
                                                                        Padding(
                                                                          padding: EdgeInsetsDirectional.fromSTEB(
                                                                              0,
                                                                              25,
                                                                              0,
                                                                              0),
                                                                          child:
                                                                              Wrap(
                                                                            spacing:
                                                                                0,
                                                                            runSpacing:
                                                                                0,
                                                                            alignment:
                                                                                WrapAlignment.start,
                                                                            crossAxisAlignment:
                                                                                WrapCrossAlignment.start,
                                                                            direction:
                                                                                Axis.horizontal,
                                                                            runAlignment:
                                                                                WrapAlignment.start,
                                                                            verticalDirection:
                                                                                VerticalDirection.down,
                                                                            clipBehavior:
                                                                                Clip.none,
                                                                            children: [
                                                                              Container(
                                                                                width: 150,
                                                                                decoration: BoxDecoration(
                                                                                  color: Colors.transparent,
                                                                                ),
                                                                                child: Wrap(
                                                                                  spacing: 0,
                                                                                  runSpacing: 0,
                                                                                  alignment: WrapAlignment.start,
                                                                                  crossAxisAlignment: WrapCrossAlignment.start,
                                                                                  direction: Axis.vertical,
                                                                                  runAlignment: WrapAlignment.start,
                                                                                  verticalDirection: VerticalDirection.down,
                                                                                  clipBehavior: Clip.none,
                                                                                  children: [
                                                                                    Visibility(
                                                                                      visible: loccountryValue == 'United States of America',
                                                                                      child: Container(
                                                                                        width: 150,
                                                                                        decoration: BoxDecoration(
                                                                                          color: Colors.transparent,
                                                                                        ),
                                                                                        child: Text(
                                                                                          FFLocalizations.of(context).getText(
                                                                                            'bu0mjqtv' /* State */,
                                                                                          ),
                                                                                          textAlign: TextAlign.center,
                                                                                          style: FlutterFlowTheme.of(context).bodyText1.override(
                                                                                                fontFamily: 'Poppins',
                                                                                                color: Colors.black,
                                                                                              ),
                                                                                        ),
                                                                                      ),
                                                                                    ),
                                                                                    Visibility(
                                                                                      visible: loccountryValue != 'United States of America',
                                                                                      child: Container(
                                                                                        width: 150,
                                                                                        decoration: BoxDecoration(
                                                                                          color: Colors.transparent,
                                                                                        ),
                                                                                        child: Text(
                                                                                          FFLocalizations.of(context).getText(
                                                                                            'b59dkmyx' /* Province */,
                                                                                          ),
                                                                                          textAlign: TextAlign.center,
                                                                                          style: FlutterFlowTheme.of(context).bodyText1.override(
                                                                                                fontFamily: 'Poppins',
                                                                                                color: Colors.black,
                                                                                              ),
                                                                                        ),
                                                                                      ),
                                                                                    ),
                                                                                  ],
                                                                                ),
                                                                              ),
                                                                              Container(
                                                                                width: 300,
                                                                                height: 50,
                                                                                decoration: BoxDecoration(
                                                                                  color: FlutterFlowTheme.of(context).tertiaryColor,
                                                                                ),
                                                                                child: FutureBuilder<ApiCallResponse>(
                                                                                  future: GetStatesCall.call(
                                                                                    country: loccountryValue,
                                                                                  ),
                                                                                  builder: (context, snapshot) {
                                                                                    // Customize what your widget looks like when it's loading.
                                                                                    if (!snapshot.hasData) {
                                                                                      return Center(
                                                                                        child: SizedBox(
                                                                                          width: 50,
                                                                                          height: 50,
                                                                                          child: SpinKitHourGlass(
                                                                                            color: Color(0xFFFFC107),
                                                                                            size: 50,
                                                                                          ),
                                                                                        ),
                                                                                      );
                                                                                    }
                                                                                    final provinceGetStatesResponse = snapshot.data!;
                                                                                    return FlutterFlowDropDown(
                                                                                      options: (GetStatesCall.states(
                                                                                        provinceGetStatesResponse.jsonBody,
                                                                                      ) as List)
                                                                                          .map<String>((s) => s.toString())
                                                                                          .toList()
                                                                                          .toList(),
                                                                                      onChanged: (val) => setState(() => provinceValue = val),
                                                                                      width: MediaQuery.of(context).size.width,
                                                                                      height: 50,
                                                                                      textStyle: FlutterFlowTheme.of(context).bodyText1.override(
                                                                                            fontFamily: 'Poppins',
                                                                                            color: Colors.black,
                                                                                          ),
                                                                                      hintText: FFLocalizations.of(context).getText(
                                                                                        'vsux3ix8' /* Select one */,
                                                                                      ),
                                                                                      fillColor: Colors.white,
                                                                                      elevation: 2,
                                                                                      borderColor: Colors.black,
                                                                                      borderWidth: 1,
                                                                                      borderRadius: 4,
                                                                                      margin: EdgeInsetsDirectional.fromSTEB(12, 6, 12, 6),
                                                                                      hidesUnderline: true,
                                                                                    );
                                                                                  },
                                                                                ),
                                                                              ),
                                                                            ],
                                                                          ),
                                                                        ),
                                                                      ],
                                                                    ),
                                                                    Wrap(
                                                                      spacing:
                                                                          0,
                                                                      runSpacing:
                                                                          0,
                                                                      alignment:
                                                                          WrapAlignment
                                                                              .spaceBetween,
                                                                      crossAxisAlignment:
                                                                          WrapCrossAlignment
                                                                              .start,
                                                                      direction:
                                                                          Axis.horizontal,
                                                                      runAlignment:
                                                                          WrapAlignment
                                                                              .start,
                                                                      verticalDirection:
                                                                          VerticalDirection
                                                                              .down,
                                                                      clipBehavior:
                                                                          Clip.none,
                                                                      children: [
                                                                        Padding(
                                                                          padding: EdgeInsetsDirectional.fromSTEB(
                                                                              0,
                                                                              25,
                                                                              0,
                                                                              0),
                                                                          child:
                                                                              Wrap(
                                                                            spacing:
                                                                                0,
                                                                            runSpacing:
                                                                                0,
                                                                            alignment:
                                                                                WrapAlignment.start,
                                                                            crossAxisAlignment:
                                                                                WrapCrossAlignment.start,
                                                                            direction:
                                                                                Axis.horizontal,
                                                                            runAlignment:
                                                                                WrapAlignment.start,
                                                                            verticalDirection:
                                                                                VerticalDirection.down,
                                                                            clipBehavior:
                                                                                Clip.none,
                                                                            children: [
                                                                              Container(
                                                                                width: 150,
                                                                                decoration: BoxDecoration(
                                                                                  color: Colors.transparent,
                                                                                ),
                                                                                child: Padding(
                                                                                  padding: EdgeInsetsDirectional.fromSTEB(0, 15, 20, 0),
                                                                                  child: custom_widgets.OrientationBasedText(
                                                                                    width: MediaQuery.of(context).size.width,
                                                                                    height: 40,
                                                                                    text: 'City',
                                                                                    textColor: Colors.black,
                                                                                    textSize: 14.0,
                                                                                    textFont: 'Poppins',
                                                                                    fontWeight: 0,
                                                                                    mobileAlignment: 'L',
                                                                                    desktopAlignment: 'R',
                                                                                  ),
                                                                                ),
                                                                              ),
                                                                              Container(
                                                                                width: 300,
                                                                                height: 50,
                                                                                decoration: BoxDecoration(
                                                                                  color: FlutterFlowTheme.of(context).tertiaryColor,
                                                                                ),
                                                                                child: FlutterFlowDropDown(
                                                                                  options: [
                                                                                    FFLocalizations.of(context).getText(
                                                                                      '18e38y0o' /* City1 */,
                                                                                    )
                                                                                  ],
                                                                                  onChanged: (val) => setState(() => cityValue = val),
                                                                                  width: MediaQuery.of(context).size.width,
                                                                                  height: 50,
                                                                                  textStyle: FlutterFlowTheme.of(context).bodyText1.override(
                                                                                        fontFamily: 'Poppins',
                                                                                        color: Colors.black,
                                                                                      ),
                                                                                  hintText: FFLocalizations.of(context).getText(
                                                                                    '8wzjdrl4' /* Select one */,
                                                                                  ),
                                                                                  fillColor: Colors.white,
                                                                                  elevation: 2,
                                                                                  borderColor: Colors.black,
                                                                                  borderWidth: 1,
                                                                                  borderRadius: 4,
                                                                                  margin: EdgeInsetsDirectional.fromSTEB(12, 6, 12, 6),
                                                                                  hidesUnderline: true,
                                                                                ),
                                                                              ),
                                                                            ],
                                                                          ),
                                                                        ),
                                                                        Wrap(
                                                                          spacing:
                                                                              0,
                                                                          runSpacing:
                                                                              0,
                                                                          alignment:
                                                                              WrapAlignment.start,
                                                                          crossAxisAlignment:
                                                                              WrapCrossAlignment.start,
                                                                          direction:
                                                                              Axis.vertical,
                                                                          runAlignment:
                                                                              WrapAlignment.start,
                                                                          verticalDirection:
                                                                              VerticalDirection.down,
                                                                          clipBehavior:
                                                                              Clip.none,
                                                                          children: [
                                                                            Visibility(
                                                                              visible: loccountryValue == 'United States of America',
                                                                              child: Padding(
                                                                                padding: EdgeInsetsDirectional.fromSTEB(0, 15, 0, 20),
                                                                                child: Wrap(
                                                                                  spacing: 0,
                                                                                  runSpacing: 0,
                                                                                  alignment: WrapAlignment.start,
                                                                                  crossAxisAlignment: WrapCrossAlignment.center,
                                                                                  direction: Axis.horizontal,
                                                                                  runAlignment: WrapAlignment.end,
                                                                                  verticalDirection: VerticalDirection.down,
                                                                                  clipBehavior: Clip.none,
                                                                                  children: [
                                                                                    Wrap(
                                                                                      spacing: 0,
                                                                                      runSpacing: 0,
                                                                                      alignment: WrapAlignment.start,
                                                                                      crossAxisAlignment: WrapCrossAlignment.start,
                                                                                      direction: Axis.horizontal,
                                                                                      runAlignment: WrapAlignment.start,
                                                                                      verticalDirection: VerticalDirection.down,
                                                                                      clipBehavior: Clip.none,
                                                                                      children: [
                                                                                        Container(
                                                                                          width: 150,
                                                                                          decoration: BoxDecoration(
                                                                                            color: Colors.transparent,
                                                                                          ),
                                                                                          child: Text(
                                                                                            FFLocalizations.of(context).getText(
                                                                                              'yn7vosua' /* Zip  Code */,
                                                                                            ),
                                                                                            textAlign: TextAlign.center,
                                                                                            style: FlutterFlowTheme.of(context).bodyText1.override(
                                                                                                  fontFamily: 'Poppins',
                                                                                                  color: Colors.black,
                                                                                                ),
                                                                                          ),
                                                                                        ),
                                                                                      ],
                                                                                    ),
                                                                                    Wrap(
                                                                                      spacing: 0,
                                                                                      runSpacing: 0,
                                                                                      alignment: WrapAlignment.start,
                                                                                      crossAxisAlignment: WrapCrossAlignment.start,
                                                                                      direction: Axis.horizontal,
                                                                                      runAlignment: WrapAlignment.start,
                                                                                      verticalDirection: VerticalDirection.down,
                                                                                      clipBehavior: Clip.none,
                                                                                      children: [
                                                                                        Padding(
                                                                                          padding: EdgeInsetsDirectional.fromSTEB(0, 0, 1, 0),
                                                                                          child: Container(
                                                                                            width: 300,
                                                                                            height: 50,
                                                                                            decoration: BoxDecoration(
                                                                                              color: Colors.transparent,
                                                                                              border: Border.all(
                                                                                                color: Colors.black,
                                                                                              ),
                                                                                            ),
                                                                                            child: TextFormField(
                                                                                              controller: textController4,
                                                                                              obscureText: false,
                                                                                              decoration: InputDecoration(
                                                                                                hintText: FFLocalizations.of(context).getText(
                                                                                                  '05iiy98m' /* Enter your zip  code */,
                                                                                                ),
                                                                                                enabledBorder: UnderlineInputBorder(
                                                                                                  borderSide: BorderSide(
                                                                                                    color: Color(0x00000000),
                                                                                                    width: 1,
                                                                                                  ),
                                                                                                  borderRadius: const BorderRadius.only(
                                                                                                    topLeft: Radius.circular(4.0),
                                                                                                    topRight: Radius.circular(4.0),
                                                                                                  ),
                                                                                                ),
                                                                                                focusedBorder: UnderlineInputBorder(
                                                                                                  borderSide: BorderSide(
                                                                                                    color: Color(0x00000000),
                                                                                                    width: 1,
                                                                                                  ),
                                                                                                  borderRadius: const BorderRadius.only(
                                                                                                    topLeft: Radius.circular(4.0),
                                                                                                    topRight: Radius.circular(4.0),
                                                                                                  ),
                                                                                                ),
                                                                                                errorBorder: UnderlineInputBorder(
                                                                                                  borderSide: BorderSide(
                                                                                                    color: Color(0x00000000),
                                                                                                    width: 1,
                                                                                                  ),
                                                                                                  borderRadius: const BorderRadius.only(
                                                                                                    topLeft: Radius.circular(4.0),
                                                                                                    topRight: Radius.circular(4.0),
                                                                                                  ),
                                                                                                ),
                                                                                                focusedErrorBorder: UnderlineInputBorder(
                                                                                                  borderSide: BorderSide(
                                                                                                    color: Color(0x00000000),
                                                                                                    width: 1,
                                                                                                  ),
                                                                                                  borderRadius: const BorderRadius.only(
                                                                                                    topLeft: Radius.circular(4.0),
                                                                                                    topRight: Radius.circular(4.0),
                                                                                                  ),
                                                                                                ),
                                                                                                filled: true,
                                                                                                fillColor: Colors.white,
                                                                                              ),
                                                                                              style: FlutterFlowTheme.of(context).bodyText1.override(
                                                                                                    fontFamily: 'Poppins',
                                                                                                    color: Colors.black,
                                                                                                  ),
                                                                                            ),
                                                                                          ),
                                                                                        ),
                                                                                      ],
                                                                                    ),
                                                                                  ],
                                                                                ),
                                                                              ),
                                                                            ),
                                                                            Visibility(
                                                                              visible: loccountryValue != 'United States of America',
                                                                              child: Padding(
                                                                                padding: EdgeInsetsDirectional.fromSTEB(0, 15, 0, 20),
                                                                                child: Wrap(
                                                                                  spacing: 0,
                                                                                  runSpacing: 0,
                                                                                  alignment: WrapAlignment.start,
                                                                                  crossAxisAlignment: WrapCrossAlignment.center,
                                                                                  direction: Axis.horizontal,
                                                                                  runAlignment: WrapAlignment.end,
                                                                                  verticalDirection: VerticalDirection.down,
                                                                                  clipBehavior: Clip.none,
                                                                                  children: [
                                                                                    Wrap(
                                                                                      spacing: 0,
                                                                                      runSpacing: 0,
                                                                                      alignment: WrapAlignment.start,
                                                                                      crossAxisAlignment: WrapCrossAlignment.start,
                                                                                      direction: Axis.horizontal,
                                                                                      runAlignment: WrapAlignment.start,
                                                                                      verticalDirection: VerticalDirection.down,
                                                                                      clipBehavior: Clip.none,
                                                                                      children: [
                                                                                        Container(
                                                                                          width: 150,
                                                                                          decoration: BoxDecoration(
                                                                                            color: Colors.transparent,
                                                                                          ),
                                                                                          child: Text(
                                                                                            FFLocalizations.of(context).getText(
                                                                                              'c87tj8g9' /* Postal Code */,
                                                                                            ),
                                                                                            style: FlutterFlowTheme.of(context).bodyText1.override(
                                                                                                  fontFamily: 'Poppins',
                                                                                                  color: Colors.black,
                                                                                                ),
                                                                                          ),
                                                                                        ),
                                                                                      ],
                                                                                    ),
                                                                                    Wrap(
                                                                                      spacing: 0,
                                                                                      runSpacing: 0,
                                                                                      alignment: WrapAlignment.start,
                                                                                      crossAxisAlignment: WrapCrossAlignment.start,
                                                                                      direction: Axis.horizontal,
                                                                                      runAlignment: WrapAlignment.start,
                                                                                      verticalDirection: VerticalDirection.down,
                                                                                      clipBehavior: Clip.none,
                                                                                      children: [
                                                                                        Padding(
                                                                                          padding: EdgeInsetsDirectional.fromSTEB(0, 0, 1, 0),
                                                                                          child: Container(
                                                                                            width: 300,
                                                                                            height: 50,
                                                                                            decoration: BoxDecoration(
                                                                                              color: Colors.transparent,
                                                                                            ),
                                                                                            child: TextFormField(
                                                                                              controller: textController5,
                                                                                              obscureText: false,
                                                                                              decoration: InputDecoration(
                                                                                                hintText: FFLocalizations.of(context).getText(
                                                                                                  '06uqbndh' /* A1A 1A1 */,
                                                                                                ),
                                                                                                enabledBorder: OutlineInputBorder(
                                                                                                  borderSide: BorderSide(
                                                                                                    color: Colors.black,
                                                                                                    width: 1,
                                                                                                  ),
                                                                                                  borderRadius: const BorderRadius.only(
                                                                                                    topLeft: Radius.circular(4.0),
                                                                                                    topRight: Radius.circular(4.0),
                                                                                                  ),
                                                                                                ),
                                                                                                focusedBorder: OutlineInputBorder(
                                                                                                  borderSide: BorderSide(
                                                                                                    color: Colors.black,
                                                                                                    width: 1,
                                                                                                  ),
                                                                                                  borderRadius: const BorderRadius.only(
                                                                                                    topLeft: Radius.circular(4.0),
                                                                                                    topRight: Radius.circular(4.0),
                                                                                                  ),
                                                                                                ),
                                                                                                errorBorder: OutlineInputBorder(
                                                                                                  borderSide: BorderSide(
                                                                                                    color: Color(0x00000000),
                                                                                                    width: 1,
                                                                                                  ),
                                                                                                  borderRadius: const BorderRadius.only(
                                                                                                    topLeft: Radius.circular(4.0),
                                                                                                    topRight: Radius.circular(4.0),
                                                                                                  ),
                                                                                                ),
                                                                                                focusedErrorBorder: OutlineInputBorder(
                                                                                                  borderSide: BorderSide(
                                                                                                    color: Color(0x00000000),
                                                                                                    width: 1,
                                                                                                  ),
                                                                                                  borderRadius: const BorderRadius.only(
                                                                                                    topLeft: Radius.circular(4.0),
                                                                                                    topRight: Radius.circular(4.0),
                                                                                                  ),
                                                                                                ),
                                                                                                filled: true,
                                                                                                fillColor: Colors.white,
                                                                                              ),
                                                                                              style: FlutterFlowTheme.of(context).bodyText1.override(
                                                                                                    fontFamily: 'Poppins',
                                                                                                    color: Colors.black,
                                                                                                  ),
                                                                                            ),
                                                                                          ),
                                                                                        ),
                                                                                      ],
                                                                                    ),
                                                                                  ],
                                                                                ),
                                                                              ),
                                                                            ),
                                                                          ],
                                                                        ),
                                                                      ],
                                                                    ),
                                                                    Wrap(
                                                                      spacing:
                                                                          0,
                                                                      runSpacing:
                                                                          0,
                                                                      alignment:
                                                                          WrapAlignment
                                                                              .spaceBetween,
                                                                      crossAxisAlignment:
                                                                          WrapCrossAlignment
                                                                              .start,
                                                                      direction:
                                                                          Axis.horizontal,
                                                                      runAlignment:
                                                                          WrapAlignment
                                                                              .start,
                                                                      verticalDirection:
                                                                          VerticalDirection
                                                                              .down,
                                                                      clipBehavior:
                                                                          Clip.none,
                                                                      children: [
                                                                        Padding(
                                                                          padding: EdgeInsetsDirectional.fromSTEB(
                                                                              0,
                                                                              25,
                                                                              0,
                                                                              0),
                                                                          child:
                                                                              Wrap(
                                                                            spacing:
                                                                                0,
                                                                            runSpacing:
                                                                                0,
                                                                            alignment:
                                                                                WrapAlignment.start,
                                                                            crossAxisAlignment:
                                                                                WrapCrossAlignment.start,
                                                                            direction:
                                                                                Axis.horizontal,
                                                                            runAlignment:
                                                                                WrapAlignment.start,
                                                                            verticalDirection:
                                                                                VerticalDirection.down,
                                                                            clipBehavior:
                                                                                Clip.none,
                                                                            children: [
                                                                              Container(
                                                                                width: 150,
                                                                                decoration: BoxDecoration(
                                                                                  color: Colors.transparent,
                                                                                ),
                                                                                child: Padding(
                                                                                  padding: EdgeInsetsDirectional.fromSTEB(0, 15, 20, 0),
                                                                                  child: custom_widgets.OrientationBasedText(
                                                                                    width: MediaQuery.of(context).size.width,
                                                                                    height: 40,
                                                                                    text: 'Upload Site Map',
                                                                                    textColor: Colors.black,
                                                                                    textSize: 14.0,
                                                                                    textFont: 'Poppins',
                                                                                    fontWeight: 0,
                                                                                    mobileAlignment: 'L',
                                                                                    desktopAlignment: 'R',
                                                                                  ),
                                                                                ),
                                                                              ),
                                                                              Container(
                                                                                width: 300,
                                                                                decoration: BoxDecoration(
                                                                                  color: FlutterFlowTheme.of(context).tertiaryColor,
                                                                                ),
                                                                                child: Padding(
                                                                                  padding: EdgeInsetsDirectional.fromSTEB(20, 0, 20, 20),
                                                                                  child: custom_widgets.ImagePickerWidget(
                                                                                    width: 400,
                                                                                    height: 300,
                                                                                    textColor: Colors.black,
                                                                                    buttonBackground: Colors.white,
                                                                                    galleryText: 'Gallery',
                                                                                    cameraText: 'Camera',
                                                                                    clearText: 'Clear',
                                                                                    saveText: 'Save',
                                                                                  ),
                                                                                ),
                                                                              ),
                                                                            ],
                                                                          ),
                                                                        ),
                                                                        Padding(
                                                                          padding: EdgeInsetsDirectional.fromSTEB(
                                                                              0,
                                                                              25,
                                                                              0,
                                                                              0),
                                                                          child:
                                                                              Wrap(
                                                                            spacing:
                                                                                0,
                                                                            runSpacing:
                                                                                0,
                                                                            alignment:
                                                                                WrapAlignment.start,
                                                                            crossAxisAlignment:
                                                                                WrapCrossAlignment.start,
                                                                            direction:
                                                                                Axis.horizontal,
                                                                            runAlignment:
                                                                                WrapAlignment.start,
                                                                            verticalDirection:
                                                                                VerticalDirection.down,
                                                                            clipBehavior:
                                                                                Clip.none,
                                                                            children: [
                                                                              Container(
                                                                                width: 200,
                                                                                decoration: BoxDecoration(
                                                                                  color: Colors.transparent,
                                                                                ),
                                                                                child: Padding(
                                                                                  padding: EdgeInsetsDirectional.fromSTEB(0, 15, 10, 0),
                                                                                  child: custom_widgets.OrientationBasedText(
                                                                                    width: MediaQuery.of(context).size.width,
                                                                                    height: 40,
                                                                                    text: 'Display area for local partners',
                                                                                    textColor: Colors.black,
                                                                                    textSize: 14.0,
                                                                                    textFont: 'Poppins',
                                                                                    fontWeight: 0,
                                                                                    mobileAlignment: 'L',
                                                                                    desktopAlignment: 'R',
                                                                                  ),
                                                                                ),
                                                                              ),
                                                                              Container(
                                                                                width: 300,
                                                                                height: 50,
                                                                                decoration: BoxDecoration(
                                                                                  color: FlutterFlowTheme.of(context).tertiaryColor,
                                                                                ),
                                                                                child: FFButtonWidget(
                                                                                  onPressed: () {
                                                                                    print('Button pressed ...');
                                                                                  },
                                                                                  text: FFLocalizations.of(context).getText(
                                                                                    'oketaput' /* Choose a file */,
                                                                                  ),
                                                                                  options: FFButtonOptions(
                                                                                    width: 10,
                                                                                    height: 40,
                                                                                    color: Color(0xFF95A1AC),
                                                                                    textStyle: FlutterFlowTheme.of(context).subtitle2.override(
                                                                                          fontFamily: 'Poppins',
                                                                                          color: Colors.white,
                                                                                        ),
                                                                                    borderSide: BorderSide(
                                                                                      color: Colors.black,
                                                                                      width: 1,
                                                                                    ),
                                                                                  ),
                                                                                ),
                                                                              ),
                                                                            ],
                                                                          ),
                                                                        ),
                                                                      ],
                                                                    ),
                                                                  ],
                                                                ),
                                                              ),
                                                            ],
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                              SingleChildScrollView(
                                                child: Column(
                                                  mainAxisSize:
                                                      MainAxisSize.max,
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.center,
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.start,
                                                  children: [
                                                    Align(
                                                      alignment:
                                                          AlignmentDirectional(
                                                              0, 0),
                                                      child: Container(
                                                        width: MediaQuery.of(
                                                                    context)
                                                                .size
                                                                .width *
                                                            0.8,
                                                        decoration:
                                                            BoxDecoration(),
                                                        child: Wrap(
                                                          spacing: 0,
                                                          runSpacing: 0,
                                                          alignment:
                                                              WrapAlignment
                                                                  .start,
                                                          crossAxisAlignment:
                                                              WrapCrossAlignment
                                                                  .start,
                                                          direction:
                                                              Axis.horizontal,
                                                          runAlignment:
                                                              WrapAlignment
                                                                  .start,
                                                          verticalDirection:
                                                              VerticalDirection
                                                                  .down,
                                                          clipBehavior:
                                                              Clip.none,
                                                          children: [
                                                            Padding(
                                                              padding:
                                                                  EdgeInsetsDirectional
                                                                      .fromSTEB(
                                                                          0,
                                                                          20,
                                                                          0,
                                                                          0),
                                                              child: Wrap(
                                                                spacing: 0,
                                                                runSpacing: 0,
                                                                alignment:
                                                                    WrapAlignment
                                                                        .start,
                                                                crossAxisAlignment:
                                                                    WrapCrossAlignment
                                                                        .start,
                                                                direction: Axis
                                                                    .horizontal,
                                                                runAlignment:
                                                                    WrapAlignment
                                                                        .start,
                                                                verticalDirection:
                                                                    VerticalDirection
                                                                        .down,
                                                                clipBehavior:
                                                                    Clip.none,
                                                                children: [
                                                                  Container(
                                                                    width: 500,
                                                                    decoration:
                                                                        BoxDecoration(
                                                                      color: Colors
                                                                          .transparent,
                                                                    ),
                                                                    child:
                                                                        Padding(
                                                                      padding: EdgeInsetsDirectional
                                                                          .fromSTEB(
                                                                              0,
                                                                              15,
                                                                              20,
                                                                              0),
                                                                      child: custom_widgets
                                                                          .OrientationBasedText(
                                                                        width: MediaQuery.of(context)
                                                                            .size
                                                                            .width,
                                                                        height:
                                                                            40,
                                                                        text:
                                                                            'Maximum number of teams your event location can support',
                                                                        textColor:
                                                                            Colors.black,
                                                                        textSize:
                                                                            14.0,
                                                                        textFont:
                                                                            'Poppins',
                                                                        fontWeight:
                                                                            0,
                                                                        mobileAlignment:
                                                                            'L',
                                                                        desktopAlignment:
                                                                            'R',
                                                                      ),
                                                                    ),
                                                                  ),
                                                                  Container(
                                                                    width: 200,
                                                                    height: 50,
                                                                    decoration:
                                                                        BoxDecoration(
                                                                      color: FlutterFlowTheme.of(
                                                                              context)
                                                                          .tertiaryColor,
                                                                    ),
                                                                    child:
                                                                        TextFormField(
                                                                      controller:
                                                                          maxsupportteamsController,
                                                                      obscureText:
                                                                          false,
                                                                      decoration:
                                                                          InputDecoration(
                                                                        hintText:
                                                                            FFLocalizations.of(context).getText(
                                                                          'gkx0ltb4' /* Enter a  value */,
                                                                        ),
                                                                        enabledBorder:
                                                                            OutlineInputBorder(
                                                                          borderSide:
                                                                              BorderSide(
                                                                            color:
                                                                                Colors.black,
                                                                            width:
                                                                                1,
                                                                          ),
                                                                          borderRadius:
                                                                              const BorderRadius.only(
                                                                            topLeft:
                                                                                Radius.circular(4.0),
                                                                            topRight:
                                                                                Radius.circular(4.0),
                                                                          ),
                                                                        ),
                                                                        focusedBorder:
                                                                            OutlineInputBorder(
                                                                          borderSide:
                                                                              BorderSide(
                                                                            color:
                                                                                Colors.black,
                                                                            width:
                                                                                1,
                                                                          ),
                                                                          borderRadius:
                                                                              const BorderRadius.only(
                                                                            topLeft:
                                                                                Radius.circular(4.0),
                                                                            topRight:
                                                                                Radius.circular(4.0),
                                                                          ),
                                                                        ),
                                                                        errorBorder:
                                                                            OutlineInputBorder(
                                                                          borderSide:
                                                                              BorderSide(
                                                                            color:
                                                                                Color(0x00000000),
                                                                            width:
                                                                                1,
                                                                          ),
                                                                          borderRadius:
                                                                              const BorderRadius.only(
                                                                            topLeft:
                                                                                Radius.circular(4.0),
                                                                            topRight:
                                                                                Radius.circular(4.0),
                                                                          ),
                                                                        ),
                                                                        focusedErrorBorder:
                                                                            OutlineInputBorder(
                                                                          borderSide:
                                                                              BorderSide(
                                                                            color:
                                                                                Color(0x00000000),
                                                                            width:
                                                                                1,
                                                                          ),
                                                                          borderRadius:
                                                                              const BorderRadius.only(
                                                                            topLeft:
                                                                                Radius.circular(4.0),
                                                                            topRight:
                                                                                Radius.circular(4.0),
                                                                          ),
                                                                        ),
                                                                        filled:
                                                                            true,
                                                                        fillColor:
                                                                            Colors.white,
                                                                      ),
                                                                      style: FlutterFlowTheme.of(
                                                                              context)
                                                                          .bodyText1
                                                                          .override(
                                                                            fontFamily:
                                                                                'Poppins',
                                                                            color:
                                                                                FlutterFlowTheme.of(context).black,
                                                                          ),
                                                                    ),
                                                                  ),
                                                                ],
                                                              ),
                                                            ),
                                                            Padding(
                                                              padding:
                                                                  EdgeInsetsDirectional
                                                                      .fromSTEB(
                                                                          0,
                                                                          30,
                                                                          0,
                                                                          0),
                                                              child: Wrap(
                                                                spacing: 0,
                                                                runSpacing: 0,
                                                                alignment:
                                                                    WrapAlignment
                                                                        .start,
                                                                crossAxisAlignment:
                                                                    WrapCrossAlignment
                                                                        .start,
                                                                direction: Axis
                                                                    .horizontal,
                                                                runAlignment:
                                                                    WrapAlignment
                                                                        .start,
                                                                verticalDirection:
                                                                    VerticalDirection
                                                                        .down,
                                                                clipBehavior:
                                                                    Clip.none,
                                                                children: [
                                                                  Container(
                                                                    width: 500,
                                                                    decoration:
                                                                        BoxDecoration(
                                                                      color: Colors
                                                                          .transparent,
                                                                    ),
                                                                    child:
                                                                        Padding(
                                                                      padding: EdgeInsetsDirectional
                                                                          .fromSTEB(
                                                                              0,
                                                                              15,
                                                                              20,
                                                                              0),
                                                                      child: custom_widgets
                                                                          .OrientationBasedText(
                                                                        width: MediaQuery.of(context)
                                                                            .size
                                                                            .width,
                                                                        height:
                                                                            40,
                                                                        text:
                                                                            'Minimum number of players per team',
                                                                        textColor:
                                                                            Colors.black,
                                                                        textSize:
                                                                            14.0,
                                                                        textFont:
                                                                            'Poppins',
                                                                        fontWeight:
                                                                            0,
                                                                        mobileAlignment:
                                                                            'L',
                                                                        desktopAlignment:
                                                                            'R',
                                                                      ),
                                                                    ),
                                                                  ),
                                                                  Container(
                                                                    width: 200,
                                                                    height: 50,
                                                                    decoration:
                                                                        BoxDecoration(
                                                                      color: FlutterFlowTheme.of(
                                                                              context)
                                                                          .tertiaryColor,
                                                                    ),
                                                                    child:
                                                                        TextFormField(
                                                                      controller:
                                                                          minnoteamplayersController,
                                                                      obscureText:
                                                                          false,
                                                                      decoration:
                                                                          InputDecoration(
                                                                        hintText:
                                                                            FFLocalizations.of(context).getText(
                                                                          '378yutut' /* Enter a  value */,
                                                                        ),
                                                                        enabledBorder:
                                                                            OutlineInputBorder(
                                                                          borderSide:
                                                                              BorderSide(
                                                                            color:
                                                                                Colors.black,
                                                                            width:
                                                                                1,
                                                                          ),
                                                                          borderRadius:
                                                                              const BorderRadius.only(
                                                                            topLeft:
                                                                                Radius.circular(4.0),
                                                                            topRight:
                                                                                Radius.circular(4.0),
                                                                          ),
                                                                        ),
                                                                        focusedBorder:
                                                                            OutlineInputBorder(
                                                                          borderSide:
                                                                              BorderSide(
                                                                            color:
                                                                                Colors.black,
                                                                            width:
                                                                                1,
                                                                          ),
                                                                          borderRadius:
                                                                              const BorderRadius.only(
                                                                            topLeft:
                                                                                Radius.circular(4.0),
                                                                            topRight:
                                                                                Radius.circular(4.0),
                                                                          ),
                                                                        ),
                                                                        errorBorder:
                                                                            OutlineInputBorder(
                                                                          borderSide:
                                                                              BorderSide(
                                                                            color:
                                                                                Color(0x00000000),
                                                                            width:
                                                                                1,
                                                                          ),
                                                                          borderRadius:
                                                                              const BorderRadius.only(
                                                                            topLeft:
                                                                                Radius.circular(4.0),
                                                                            topRight:
                                                                                Radius.circular(4.0),
                                                                          ),
                                                                        ),
                                                                        focusedErrorBorder:
                                                                            OutlineInputBorder(
                                                                          borderSide:
                                                                              BorderSide(
                                                                            color:
                                                                                Color(0x00000000),
                                                                            width:
                                                                                1,
                                                                          ),
                                                                          borderRadius:
                                                                              const BorderRadius.only(
                                                                            topLeft:
                                                                                Radius.circular(4.0),
                                                                            topRight:
                                                                                Radius.circular(4.0),
                                                                          ),
                                                                        ),
                                                                        filled:
                                                                            true,
                                                                        fillColor:
                                                                            Colors.white,
                                                                      ),
                                                                      style: FlutterFlowTheme.of(
                                                                              context)
                                                                          .bodyText1
                                                                          .override(
                                                                            fontFamily:
                                                                                'Poppins',
                                                                            color:
                                                                                FlutterFlowTheme.of(context).black,
                                                                          ),
                                                                    ),
                                                                  ),
                                                                ],
                                                              ),
                                                            ),
                                                            Padding(
                                                              padding:
                                                                  EdgeInsetsDirectional
                                                                      .fromSTEB(
                                                                          0,
                                                                          30,
                                                                          0,
                                                                          0),
                                                              child: Wrap(
                                                                spacing: 0,
                                                                runSpacing: 0,
                                                                alignment:
                                                                    WrapAlignment
                                                                        .start,
                                                                crossAxisAlignment:
                                                                    WrapCrossAlignment
                                                                        .start,
                                                                direction: Axis
                                                                    .horizontal,
                                                                runAlignment:
                                                                    WrapAlignment
                                                                        .start,
                                                                verticalDirection:
                                                                    VerticalDirection
                                                                        .down,
                                                                clipBehavior:
                                                                    Clip.none,
                                                                children: [
                                                                  Container(
                                                                    width: 500,
                                                                    decoration:
                                                                        BoxDecoration(
                                                                      color: Colors
                                                                          .transparent,
                                                                    ),
                                                                    child:
                                                                        Padding(
                                                                      padding: EdgeInsetsDirectional
                                                                          .fromSTEB(
                                                                              0,
                                                                              15,
                                                                              20,
                                                                              0),
                                                                      child: custom_widgets
                                                                          .OrientationBasedText(
                                                                        width: MediaQuery.of(context)
                                                                            .size
                                                                            .width,
                                                                        height:
                                                                            40,
                                                                        text:
                                                                            'Maximum number of players per team',
                                                                        textColor:
                                                                            Colors.black,
                                                                        textSize:
                                                                            14.0,
                                                                        textFont:
                                                                            'Poppins',
                                                                        fontWeight:
                                                                            0,
                                                                        mobileAlignment:
                                                                            'L',
                                                                        desktopAlignment:
                                                                            'R',
                                                                      ),
                                                                    ),
                                                                  ),
                                                                  Container(
                                                                    width: 200,
                                                                    height: 50,
                                                                    decoration:
                                                                        BoxDecoration(
                                                                      color: FlutterFlowTheme.of(
                                                                              context)
                                                                          .tertiaryColor,
                                                                    ),
                                                                    child:
                                                                        TextFormField(
                                                                      controller:
                                                                          maxnoteamplayersController,
                                                                      obscureText:
                                                                          false,
                                                                      decoration:
                                                                          InputDecoration(
                                                                        hintText:
                                                                            FFLocalizations.of(context).getText(
                                                                          '5hy9ak87' /* Enter a  value */,
                                                                        ),
                                                                        enabledBorder:
                                                                            OutlineInputBorder(
                                                                          borderSide:
                                                                              BorderSide(
                                                                            color:
                                                                                Colors.black,
                                                                            width:
                                                                                1,
                                                                          ),
                                                                          borderRadius:
                                                                              const BorderRadius.only(
                                                                            topLeft:
                                                                                Radius.circular(4.0),
                                                                            topRight:
                                                                                Radius.circular(4.0),
                                                                          ),
                                                                        ),
                                                                        focusedBorder:
                                                                            OutlineInputBorder(
                                                                          borderSide:
                                                                              BorderSide(
                                                                            color:
                                                                                Colors.black,
                                                                            width:
                                                                                1,
                                                                          ),
                                                                          borderRadius:
                                                                              const BorderRadius.only(
                                                                            topLeft:
                                                                                Radius.circular(4.0),
                                                                            topRight:
                                                                                Radius.circular(4.0),
                                                                          ),
                                                                        ),
                                                                        errorBorder:
                                                                            OutlineInputBorder(
                                                                          borderSide:
                                                                              BorderSide(
                                                                            color:
                                                                                Color(0x00000000),
                                                                            width:
                                                                                1,
                                                                          ),
                                                                          borderRadius:
                                                                              const BorderRadius.only(
                                                                            topLeft:
                                                                                Radius.circular(4.0),
                                                                            topRight:
                                                                                Radius.circular(4.0),
                                                                          ),
                                                                        ),
                                                                        focusedErrorBorder:
                                                                            OutlineInputBorder(
                                                                          borderSide:
                                                                              BorderSide(
                                                                            color:
                                                                                Color(0x00000000),
                                                                            width:
                                                                                1,
                                                                          ),
                                                                          borderRadius:
                                                                              const BorderRadius.only(
                                                                            topLeft:
                                                                                Radius.circular(4.0),
                                                                            topRight:
                                                                                Radius.circular(4.0),
                                                                          ),
                                                                        ),
                                                                        filled:
                                                                            true,
                                                                        fillColor:
                                                                            Colors.white,
                                                                      ),
                                                                      style: FlutterFlowTheme.of(
                                                                              context)
                                                                          .bodyText1
                                                                          .override(
                                                                            fontFamily:
                                                                                'Poppins',
                                                                            color:
                                                                                FlutterFlowTheme.of(context).black,
                                                                          ),
                                                                    ),
                                                                  ),
                                                                ],
                                                              ),
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                              SingleChildScrollView(
                                                child: Column(
                                                  mainAxisSize:
                                                      MainAxisSize.max,
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.center,
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.start,
                                                  children: [
                                                    Align(
                                                      alignment:
                                                          AlignmentDirectional(
                                                              0, 0),
                                                      child: Container(
                                                        width: MediaQuery.of(
                                                                    context)
                                                                .size
                                                                .width *
                                                            0.8,
                                                        decoration:
                                                            BoxDecoration(),
                                                        child: Wrap(
                                                          spacing: 0,
                                                          runSpacing: 0,
                                                          alignment:
                                                              WrapAlignment
                                                                  .start,
                                                          crossAxisAlignment:
                                                              WrapCrossAlignment
                                                                  .start,
                                                          direction:
                                                              Axis.horizontal,
                                                          runAlignment:
                                                              WrapAlignment
                                                                  .start,
                                                          verticalDirection:
                                                              VerticalDirection
                                                                  .down,
                                                          clipBehavior:
                                                              Clip.none,
                                                          children: [
                                                            Padding(
                                                              padding:
                                                                  EdgeInsetsDirectional
                                                                      .fromSTEB(
                                                                          0,
                                                                          20,
                                                                          0,
                                                                          0),
                                                              child: Wrap(
                                                                spacing: 0,
                                                                runSpacing: 0,
                                                                alignment:
                                                                    WrapAlignment
                                                                        .start,
                                                                crossAxisAlignment:
                                                                    WrapCrossAlignment
                                                                        .start,
                                                                direction: Axis
                                                                    .horizontal,
                                                                runAlignment:
                                                                    WrapAlignment
                                                                        .start,
                                                                verticalDirection:
                                                                    VerticalDirection
                                                                        .down,
                                                                clipBehavior:
                                                                    Clip.none,
                                                                children: [
                                                                  Container(
                                                                    width: 500,
                                                                    decoration:
                                                                        BoxDecoration(
                                                                      color: Colors
                                                                          .transparent,
                                                                    ),
                                                                    child:
                                                                        Padding(
                                                                      padding: EdgeInsetsDirectional
                                                                          .fromSTEB(
                                                                              0,
                                                                              15,
                                                                              20,
                                                                              0),
                                                                      child: custom_widgets
                                                                          .OrientationBasedText(
                                                                        width: MediaQuery.of(context)
                                                                            .size
                                                                            .width,
                                                                        height:
                                                                            40,
                                                                        text:
                                                                            'Player Registration Fee (\$)',
                                                                        textColor:
                                                                            Colors.black,
                                                                        textSize:
                                                                            14.0,
                                                                        textFont:
                                                                            'Poppins',
                                                                        fontWeight:
                                                                            0,
                                                                        mobileAlignment:
                                                                            'L',
                                                                        desktopAlignment:
                                                                            'R',
                                                                      ),
                                                                    ),
                                                                  ),
                                                                  Container(
                                                                    width: 200,
                                                                    height: 50,
                                                                    decoration:
                                                                        BoxDecoration(
                                                                      color: FlutterFlowTheme.of(
                                                                              context)
                                                                          .tertiaryColor,
                                                                    ),
                                                                    child:
                                                                        TextFormField(
                                                                      controller:
                                                                          playerregfeeController,
                                                                      obscureText:
                                                                          false,
                                                                      decoration:
                                                                          InputDecoration(
                                                                        hintText:
                                                                            FFLocalizations.of(context).getText(
                                                                          '5pmbpvud' /* Enter a value */,
                                                                        ),
                                                                        enabledBorder:
                                                                            OutlineInputBorder(
                                                                          borderSide:
                                                                              BorderSide(
                                                                            color:
                                                                                Colors.black,
                                                                            width:
                                                                                1,
                                                                          ),
                                                                          borderRadius:
                                                                              const BorderRadius.only(
                                                                            topLeft:
                                                                                Radius.circular(4.0),
                                                                            topRight:
                                                                                Radius.circular(4.0),
                                                                          ),
                                                                        ),
                                                                        focusedBorder:
                                                                            OutlineInputBorder(
                                                                          borderSide:
                                                                              BorderSide(
                                                                            color:
                                                                                Colors.black,
                                                                            width:
                                                                                1,
                                                                          ),
                                                                          borderRadius:
                                                                              const BorderRadius.only(
                                                                            topLeft:
                                                                                Radius.circular(4.0),
                                                                            topRight:
                                                                                Radius.circular(4.0),
                                                                          ),
                                                                        ),
                                                                        errorBorder:
                                                                            OutlineInputBorder(
                                                                          borderSide:
                                                                              BorderSide(
                                                                            color:
                                                                                Color(0x00000000),
                                                                            width:
                                                                                1,
                                                                          ),
                                                                          borderRadius:
                                                                              const BorderRadius.only(
                                                                            topLeft:
                                                                                Radius.circular(4.0),
                                                                            topRight:
                                                                                Radius.circular(4.0),
                                                                          ),
                                                                        ),
                                                                        focusedErrorBorder:
                                                                            OutlineInputBorder(
                                                                          borderSide:
                                                                              BorderSide(
                                                                            color:
                                                                                Color(0x00000000),
                                                                            width:
                                                                                1,
                                                                          ),
                                                                          borderRadius:
                                                                              const BorderRadius.only(
                                                                            topLeft:
                                                                                Radius.circular(4.0),
                                                                            topRight:
                                                                                Radius.circular(4.0),
                                                                          ),
                                                                        ),
                                                                        filled:
                                                                            true,
                                                                        fillColor:
                                                                            Colors.white,
                                                                      ),
                                                                      style: FlutterFlowTheme.of(
                                                                              context)
                                                                          .bodyText1
                                                                          .override(
                                                                            fontFamily:
                                                                                'Poppins',
                                                                            color:
                                                                                FlutterFlowTheme.of(context).black,
                                                                          ),
                                                                    ),
                                                                  ),
                                                                ],
                                                              ),
                                                            ),
                                                            Padding(
                                                              padding:
                                                                  EdgeInsetsDirectional
                                                                      .fromSTEB(
                                                                          0,
                                                                          30,
                                                                          0,
                                                                          0),
                                                              child: Wrap(
                                                                spacing: 0,
                                                                runSpacing: 0,
                                                                alignment:
                                                                    WrapAlignment
                                                                        .start,
                                                                crossAxisAlignment:
                                                                    WrapCrossAlignment
                                                                        .start,
                                                                direction: Axis
                                                                    .horizontal,
                                                                runAlignment:
                                                                    WrapAlignment
                                                                        .start,
                                                                verticalDirection:
                                                                    VerticalDirection
                                                                        .down,
                                                                clipBehavior:
                                                                    Clip.none,
                                                                children: [
                                                                  Container(
                                                                    width: 500,
                                                                    decoration:
                                                                        BoxDecoration(
                                                                      color: Colors
                                                                          .transparent,
                                                                    ),
                                                                    child:
                                                                        Padding(
                                                                      padding: EdgeInsetsDirectional
                                                                          .fromSTEB(
                                                                              0,
                                                                              15,
                                                                              20,
                                                                              0),
                                                                      child: custom_widgets
                                                                          .OrientationBasedText(
                                                                        width: MediaQuery.of(context)
                                                                            .size
                                                                            .width,
                                                                        height:
                                                                            40,
                                                                        text:
                                                                            'Sales tax rate (%)',
                                                                        textColor:
                                                                            Colors.black,
                                                                        textSize:
                                                                            14.0,
                                                                        textFont:
                                                                            'Poppins',
                                                                        fontWeight:
                                                                            0,
                                                                        mobileAlignment:
                                                                            'L',
                                                                        desktopAlignment:
                                                                            'R',
                                                                      ),
                                                                    ),
                                                                  ),
                                                                  Container(
                                                                    width: 200,
                                                                    height: 50,
                                                                    decoration:
                                                                        BoxDecoration(
                                                                      color: FlutterFlowTheme.of(
                                                                              context)
                                                                          .tertiaryColor,
                                                                    ),
                                                                    child:
                                                                        TextFormField(
                                                                      controller:
                                                                          salestaxrateController,
                                                                      obscureText:
                                                                          false,
                                                                      decoration:
                                                                          InputDecoration(
                                                                        hintText:
                                                                            FFLocalizations.of(context).getText(
                                                                          'bc8u52po' /* Enter a value */,
                                                                        ),
                                                                        enabledBorder:
                                                                            OutlineInputBorder(
                                                                          borderSide:
                                                                              BorderSide(
                                                                            color:
                                                                                Colors.black,
                                                                            width:
                                                                                1,
                                                                          ),
                                                                          borderRadius:
                                                                              const BorderRadius.only(
                                                                            topLeft:
                                                                                Radius.circular(4.0),
                                                                            topRight:
                                                                                Radius.circular(4.0),
                                                                          ),
                                                                        ),
                                                                        focusedBorder:
                                                                            OutlineInputBorder(
                                                                          borderSide:
                                                                              BorderSide(
                                                                            color:
                                                                                Colors.black,
                                                                            width:
                                                                                1,
                                                                          ),
                                                                          borderRadius:
                                                                              const BorderRadius.only(
                                                                            topLeft:
                                                                                Radius.circular(4.0),
                                                                            topRight:
                                                                                Radius.circular(4.0),
                                                                          ),
                                                                        ),
                                                                        errorBorder:
                                                                            OutlineInputBorder(
                                                                          borderSide:
                                                                              BorderSide(
                                                                            color:
                                                                                Color(0x00000000),
                                                                            width:
                                                                                1,
                                                                          ),
                                                                          borderRadius:
                                                                              const BorderRadius.only(
                                                                            topLeft:
                                                                                Radius.circular(4.0),
                                                                            topRight:
                                                                                Radius.circular(4.0),
                                                                          ),
                                                                        ),
                                                                        focusedErrorBorder:
                                                                            OutlineInputBorder(
                                                                          borderSide:
                                                                              BorderSide(
                                                                            color:
                                                                                Color(0x00000000),
                                                                            width:
                                                                                1,
                                                                          ),
                                                                          borderRadius:
                                                                              const BorderRadius.only(
                                                                            topLeft:
                                                                                Radius.circular(4.0),
                                                                            topRight:
                                                                                Radius.circular(4.0),
                                                                          ),
                                                                        ),
                                                                        filled:
                                                                            true,
                                                                        fillColor:
                                                                            Colors.white,
                                                                      ),
                                                                      style: FlutterFlowTheme.of(
                                                                              context)
                                                                          .bodyText1
                                                                          .override(
                                                                            fontFamily:
                                                                                'Poppins',
                                                                            color:
                                                                                FlutterFlowTheme.of(context).black,
                                                                          ),
                                                                    ),
                                                                  ),
                                                                ],
                                                              ),
                                                            ),
                                                            Padding(
                                                              padding:
                                                                  EdgeInsetsDirectional
                                                                      .fromSTEB(
                                                                          0,
                                                                          30,
                                                                          0,
                                                                          0),
                                                              child: Wrap(
                                                                spacing: 0,
                                                                runSpacing: 0,
                                                                alignment:
                                                                    WrapAlignment
                                                                        .start,
                                                                crossAxisAlignment:
                                                                    WrapCrossAlignment
                                                                        .start,
                                                                direction: Axis
                                                                    .horizontal,
                                                                runAlignment:
                                                                    WrapAlignment
                                                                        .start,
                                                                verticalDirection:
                                                                    VerticalDirection
                                                                        .down,
                                                                clipBehavior:
                                                                    Clip.none,
                                                                children: [
                                                                  Container(
                                                                    width: 500,
                                                                    decoration:
                                                                        BoxDecoration(
                                                                      color: Colors
                                                                          .transparent,
                                                                    ),
                                                                    child:
                                                                        Padding(
                                                                      padding: EdgeInsetsDirectional
                                                                          .fromSTEB(
                                                                              0,
                                                                              15,
                                                                              20,
                                                                              0),
                                                                      child: custom_widgets
                                                                          .OrientationBasedText(
                                                                        width: MediaQuery.of(context)
                                                                            .size
                                                                            .width,
                                                                        height:
                                                                            40,
                                                                        text:
                                                                            'Sales tax rate for youth(%)',
                                                                        textColor:
                                                                            Colors.black,
                                                                        textSize:
                                                                            14.0,
                                                                        textFont:
                                                                            'Poppins',
                                                                        fontWeight:
                                                                            0,
                                                                        mobileAlignment:
                                                                            'L',
                                                                        desktopAlignment:
                                                                            'R',
                                                                      ),
                                                                    ),
                                                                  ),
                                                                  Container(
                                                                    width: 200,
                                                                    height: 50,
                                                                    decoration:
                                                                        BoxDecoration(
                                                                      color: FlutterFlowTheme.of(
                                                                              context)
                                                                          .tertiaryColor,
                                                                    ),
                                                                    child:
                                                                        TextFormField(
                                                                      controller:
                                                                          youthsalestaxrateController,
                                                                      obscureText:
                                                                          false,
                                                                      decoration:
                                                                          InputDecoration(
                                                                        hintText:
                                                                            FFLocalizations.of(context).getText(
                                                                          'e91owmfy' /* Enter a value */,
                                                                        ),
                                                                        enabledBorder:
                                                                            OutlineInputBorder(
                                                                          borderSide:
                                                                              BorderSide(
                                                                            color:
                                                                                Colors.black,
                                                                            width:
                                                                                1,
                                                                          ),
                                                                          borderRadius:
                                                                              const BorderRadius.only(
                                                                            topLeft:
                                                                                Radius.circular(4.0),
                                                                            topRight:
                                                                                Radius.circular(4.0),
                                                                          ),
                                                                        ),
                                                                        focusedBorder:
                                                                            OutlineInputBorder(
                                                                          borderSide:
                                                                              BorderSide(
                                                                            color:
                                                                                Colors.black,
                                                                            width:
                                                                                1,
                                                                          ),
                                                                          borderRadius:
                                                                              const BorderRadius.only(
                                                                            topLeft:
                                                                                Radius.circular(4.0),
                                                                            topRight:
                                                                                Radius.circular(4.0),
                                                                          ),
                                                                        ),
                                                                        errorBorder:
                                                                            OutlineInputBorder(
                                                                          borderSide:
                                                                              BorderSide(
                                                                            color:
                                                                                Color(0x00000000),
                                                                            width:
                                                                                1,
                                                                          ),
                                                                          borderRadius:
                                                                              const BorderRadius.only(
                                                                            topLeft:
                                                                                Radius.circular(4.0),
                                                                            topRight:
                                                                                Radius.circular(4.0),
                                                                          ),
                                                                        ),
                                                                        focusedErrorBorder:
                                                                            OutlineInputBorder(
                                                                          borderSide:
                                                                              BorderSide(
                                                                            color:
                                                                                Color(0x00000000),
                                                                            width:
                                                                                1,
                                                                          ),
                                                                          borderRadius:
                                                                              const BorderRadius.only(
                                                                            topLeft:
                                                                                Radius.circular(4.0),
                                                                            topRight:
                                                                                Radius.circular(4.0),
                                                                          ),
                                                                        ),
                                                                        filled:
                                                                            true,
                                                                        fillColor:
                                                                            Colors.white,
                                                                      ),
                                                                      style: FlutterFlowTheme.of(
                                                                              context)
                                                                          .bodyText1
                                                                          .override(
                                                                            fontFamily:
                                                                                'Poppins',
                                                                            color:
                                                                                FlutterFlowTheme.of(context).black,
                                                                          ),
                                                                    ),
                                                                  ),
                                                                ],
                                                              ),
                                                            ),
                                                            Padding(
                                                              padding:
                                                                  EdgeInsetsDirectional
                                                                      .fromSTEB(
                                                                          0,
                                                                          20,
                                                                          0,
                                                                          0),
                                                              child: Wrap(
                                                                spacing: 0,
                                                                runSpacing: 0,
                                                                alignment:
                                                                    WrapAlignment
                                                                        .start,
                                                                crossAxisAlignment:
                                                                    WrapCrossAlignment
                                                                        .start,
                                                                direction: Axis
                                                                    .horizontal,
                                                                runAlignment:
                                                                    WrapAlignment
                                                                        .start,
                                                                verticalDirection:
                                                                    VerticalDirection
                                                                        .down,
                                                                clipBehavior:
                                                                    Clip.none,
                                                                children: [
                                                                  Container(
                                                                    width: 500,
                                                                    decoration:
                                                                        BoxDecoration(
                                                                      color: Colors
                                                                          .transparent,
                                                                    ),
                                                                    child:
                                                                        Padding(
                                                                      padding: EdgeInsetsDirectional
                                                                          .fromSTEB(
                                                                              0,
                                                                              15,
                                                                              20,
                                                                              0),
                                                                      child: custom_widgets
                                                                          .OrientationBasedText(
                                                                        width: MediaQuery.of(context)
                                                                            .size
                                                                            .width,
                                                                        height:
                                                                            40,
                                                                        text:
                                                                            'Age of Majority (varies by province)',
                                                                        textColor:
                                                                            Colors.black,
                                                                        textSize:
                                                                            14.0,
                                                                        textFont:
                                                                            'Poppins',
                                                                        fontWeight:
                                                                            0,
                                                                        mobileAlignment:
                                                                            'L',
                                                                        desktopAlignment:
                                                                            'R',
                                                                      ),
                                                                    ),
                                                                  ),
                                                                  Container(
                                                                    width: 200,
                                                                    height: 50,
                                                                    decoration:
                                                                        BoxDecoration(
                                                                      color: FlutterFlowTheme.of(
                                                                              context)
                                                                          .tertiaryColor,
                                                                    ),
                                                                    child:
                                                                        TextFormField(
                                                                      controller:
                                                                          majorityageController,
                                                                      obscureText:
                                                                          false,
                                                                      decoration:
                                                                          InputDecoration(
                                                                        hintText:
                                                                            FFLocalizations.of(context).getText(
                                                                          'jf7polyh' /* Enter a value */,
                                                                        ),
                                                                        enabledBorder:
                                                                            OutlineInputBorder(
                                                                          borderSide:
                                                                              BorderSide(
                                                                            color:
                                                                                Colors.black,
                                                                            width:
                                                                                1,
                                                                          ),
                                                                          borderRadius:
                                                                              const BorderRadius.only(
                                                                            topLeft:
                                                                                Radius.circular(4.0),
                                                                            topRight:
                                                                                Radius.circular(4.0),
                                                                          ),
                                                                        ),
                                                                        focusedBorder:
                                                                            OutlineInputBorder(
                                                                          borderSide:
                                                                              BorderSide(
                                                                            color:
                                                                                Colors.black,
                                                                            width:
                                                                                1,
                                                                          ),
                                                                          borderRadius:
                                                                              const BorderRadius.only(
                                                                            topLeft:
                                                                                Radius.circular(4.0),
                                                                            topRight:
                                                                                Radius.circular(4.0),
                                                                          ),
                                                                        ),
                                                                        errorBorder:
                                                                            OutlineInputBorder(
                                                                          borderSide:
                                                                              BorderSide(
                                                                            color:
                                                                                Color(0x00000000),
                                                                            width:
                                                                                1,
                                                                          ),
                                                                          borderRadius:
                                                                              const BorderRadius.only(
                                                                            topLeft:
                                                                                Radius.circular(4.0),
                                                                            topRight:
                                                                                Radius.circular(4.0),
                                                                          ),
                                                                        ),
                                                                        focusedErrorBorder:
                                                                            OutlineInputBorder(
                                                                          borderSide:
                                                                              BorderSide(
                                                                            color:
                                                                                Color(0x00000000),
                                                                            width:
                                                                                1,
                                                                          ),
                                                                          borderRadius:
                                                                              const BorderRadius.only(
                                                                            topLeft:
                                                                                Radius.circular(4.0),
                                                                            topRight:
                                                                                Radius.circular(4.0),
                                                                          ),
                                                                        ),
                                                                        filled:
                                                                            true,
                                                                        fillColor:
                                                                            Colors.white,
                                                                      ),
                                                                      style: FlutterFlowTheme.of(
                                                                              context)
                                                                          .bodyText1
                                                                          .override(
                                                                            fontFamily:
                                                                                'Poppins',
                                                                            color:
                                                                                FlutterFlowTheme.of(context).black,
                                                                          ),
                                                                    ),
                                                                  ),
                                                                ],
                                                              ),
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                              SingleChildScrollView(
                                                child: Column(
                                                  mainAxisSize:
                                                      MainAxisSize.max,
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.center,
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.start,
                                                  children: [
                                                    Align(
                                                      alignment:
                                                          AlignmentDirectional(
                                                              0, 0),
                                                      child: Container(
                                                        width: MediaQuery.of(
                                                                    context)
                                                                .size
                                                                .width *
                                                            0.8,
                                                        decoration:
                                                            BoxDecoration(),
                                                        child: Wrap(
                                                          spacing: 0,
                                                          runSpacing: 0,
                                                          alignment:
                                                              WrapAlignment
                                                                  .start,
                                                          crossAxisAlignment:
                                                              WrapCrossAlignment
                                                                  .start,
                                                          direction:
                                                              Axis.horizontal,
                                                          runAlignment:
                                                              WrapAlignment
                                                                  .start,
                                                          verticalDirection:
                                                              VerticalDirection
                                                                  .down,
                                                          clipBehavior:
                                                              Clip.none,
                                                          children: [
                                                            Padding(
                                                              padding:
                                                                  EdgeInsetsDirectional
                                                                      .fromSTEB(
                                                                          0,
                                                                          20,
                                                                          0,
                                                                          0),
                                                              child: Wrap(
                                                                spacing: 0,
                                                                runSpacing: 0,
                                                                alignment:
                                                                    WrapAlignment
                                                                        .start,
                                                                crossAxisAlignment:
                                                                    WrapCrossAlignment
                                                                        .start,
                                                                direction: Axis
                                                                    .horizontal,
                                                                runAlignment:
                                                                    WrapAlignment
                                                                        .start,
                                                                verticalDirection:
                                                                    VerticalDirection
                                                                        .down,
                                                                clipBehavior:
                                                                    Clip.none,
                                                                children: [
                                                                  Container(
                                                                    width: 500,
                                                                    decoration:
                                                                        BoxDecoration(
                                                                      color: Colors
                                                                          .transparent,
                                                                    ),
                                                                    child:
                                                                        Padding(
                                                                      padding: EdgeInsetsDirectional
                                                                          .fromSTEB(
                                                                              0,
                                                                              15,
                                                                              20,
                                                                              0),
                                                                      child: custom_widgets
                                                                          .OrientationBasedText(
                                                                        width: MediaQuery.of(context)
                                                                            .size
                                                                            .width,
                                                                        height:
                                                                            40,
                                                                        text:
                                                                            'How  many 10*10 spaces will be available on rent?',
                                                                        textColor:
                                                                            Colors.black,
                                                                        textSize:
                                                                            14.0,
                                                                        textFont:
                                                                            'Poppins',
                                                                        fontWeight:
                                                                            0,
                                                                        mobileAlignment:
                                                                            'L',
                                                                        desktopAlignment:
                                                                            'R',
                                                                      ),
                                                                    ),
                                                                  ),
                                                                  Container(
                                                                    width: 200,
                                                                    height: 50,
                                                                    decoration:
                                                                        BoxDecoration(
                                                                      color: FlutterFlowTheme.of(
                                                                              context)
                                                                          .tertiaryColor,
                                                                    ),
                                                                    child:
                                                                        TextFormField(
                                                                      controller:
                                                                          avail1010rentspaceController,
                                                                      obscureText:
                                                                          false,
                                                                      decoration:
                                                                          InputDecoration(
                                                                        hintText:
                                                                            FFLocalizations.of(context).getText(
                                                                          'd7rbcj20' /* Enter a  value */,
                                                                        ),
                                                                        enabledBorder:
                                                                            OutlineInputBorder(
                                                                          borderSide:
                                                                              BorderSide(
                                                                            color:
                                                                                Colors.black,
                                                                            width:
                                                                                1,
                                                                          ),
                                                                          borderRadius:
                                                                              const BorderRadius.only(
                                                                            topLeft:
                                                                                Radius.circular(4.0),
                                                                            topRight:
                                                                                Radius.circular(4.0),
                                                                          ),
                                                                        ),
                                                                        focusedBorder:
                                                                            OutlineInputBorder(
                                                                          borderSide:
                                                                              BorderSide(
                                                                            color:
                                                                                Colors.black,
                                                                            width:
                                                                                1,
                                                                          ),
                                                                          borderRadius:
                                                                              const BorderRadius.only(
                                                                            topLeft:
                                                                                Radius.circular(4.0),
                                                                            topRight:
                                                                                Radius.circular(4.0),
                                                                          ),
                                                                        ),
                                                                        errorBorder:
                                                                            OutlineInputBorder(
                                                                          borderSide:
                                                                              BorderSide(
                                                                            color:
                                                                                Color(0x00000000),
                                                                            width:
                                                                                1,
                                                                          ),
                                                                          borderRadius:
                                                                              const BorderRadius.only(
                                                                            topLeft:
                                                                                Radius.circular(4.0),
                                                                            topRight:
                                                                                Radius.circular(4.0),
                                                                          ),
                                                                        ),
                                                                        focusedErrorBorder:
                                                                            OutlineInputBorder(
                                                                          borderSide:
                                                                              BorderSide(
                                                                            color:
                                                                                Color(0x00000000),
                                                                            width:
                                                                                1,
                                                                          ),
                                                                          borderRadius:
                                                                              const BorderRadius.only(
                                                                            topLeft:
                                                                                Radius.circular(4.0),
                                                                            topRight:
                                                                                Radius.circular(4.0),
                                                                          ),
                                                                        ),
                                                                        filled:
                                                                            true,
                                                                        fillColor:
                                                                            Colors.white,
                                                                      ),
                                                                      style: FlutterFlowTheme.of(
                                                                              context)
                                                                          .bodyText1
                                                                          .override(
                                                                            fontFamily:
                                                                                'Poppins',
                                                                            color:
                                                                                FlutterFlowTheme.of(context).black,
                                                                          ),
                                                                    ),
                                                                  ),
                                                                ],
                                                              ),
                                                            ),
                                                            Padding(
                                                              padding:
                                                                  EdgeInsetsDirectional
                                                                      .fromSTEB(
                                                                          0,
                                                                          30,
                                                                          0,
                                                                          0),
                                                              child: Wrap(
                                                                spacing: 0,
                                                                runSpacing: 0,
                                                                alignment:
                                                                    WrapAlignment
                                                                        .start,
                                                                crossAxisAlignment:
                                                                    WrapCrossAlignment
                                                                        .start,
                                                                direction: Axis
                                                                    .horizontal,
                                                                runAlignment:
                                                                    WrapAlignment
                                                                        .start,
                                                                verticalDirection:
                                                                    VerticalDirection
                                                                        .down,
                                                                clipBehavior:
                                                                    Clip.none,
                                                                children: [
                                                                  Container(
                                                                    width: 500,
                                                                    decoration:
                                                                        BoxDecoration(
                                                                      color: Colors
                                                                          .transparent,
                                                                    ),
                                                                    child:
                                                                        Padding(
                                                                      padding: EdgeInsetsDirectional
                                                                          .fromSTEB(
                                                                              0,
                                                                              15,
                                                                              20,
                                                                              0),
                                                                      child: custom_widgets
                                                                          .OrientationBasedText(
                                                                        width: MediaQuery.of(context)
                                                                            .size
                                                                            .width,
                                                                        height:
                                                                            40,
                                                                        text:
                                                                            'How  many 10*15 spaces will be available on rent?',
                                                                        textColor:
                                                                            Colors.black,
                                                                        textSize:
                                                                            14.0,
                                                                        textFont:
                                                                            'Poppins',
                                                                        fontWeight:
                                                                            0,
                                                                        mobileAlignment:
                                                                            'L',
                                                                        desktopAlignment:
                                                                            'R',
                                                                      ),
                                                                    ),
                                                                  ),
                                                                  Container(
                                                                    width: 200,
                                                                    height: 50,
                                                                    decoration:
                                                                        BoxDecoration(
                                                                      color: FlutterFlowTheme.of(
                                                                              context)
                                                                          .tertiaryColor,
                                                                    ),
                                                                    child:
                                                                        TextFormField(
                                                                      controller:
                                                                          avail1015rentspaceController,
                                                                      obscureText:
                                                                          false,
                                                                      decoration:
                                                                          InputDecoration(
                                                                        hintText:
                                                                            FFLocalizations.of(context).getText(
                                                                          'tt0yptip' /* Enter a  value */,
                                                                        ),
                                                                        enabledBorder:
                                                                            OutlineInputBorder(
                                                                          borderSide:
                                                                              BorderSide(
                                                                            color:
                                                                                Colors.black,
                                                                            width:
                                                                                1,
                                                                          ),
                                                                          borderRadius:
                                                                              const BorderRadius.only(
                                                                            topLeft:
                                                                                Radius.circular(4.0),
                                                                            topRight:
                                                                                Radius.circular(4.0),
                                                                          ),
                                                                        ),
                                                                        focusedBorder:
                                                                            OutlineInputBorder(
                                                                          borderSide:
                                                                              BorderSide(
                                                                            color:
                                                                                Colors.black,
                                                                            width:
                                                                                1,
                                                                          ),
                                                                          borderRadius:
                                                                              const BorderRadius.only(
                                                                            topLeft:
                                                                                Radius.circular(4.0),
                                                                            topRight:
                                                                                Radius.circular(4.0),
                                                                          ),
                                                                        ),
                                                                        errorBorder:
                                                                            OutlineInputBorder(
                                                                          borderSide:
                                                                              BorderSide(
                                                                            color:
                                                                                Color(0x00000000),
                                                                            width:
                                                                                1,
                                                                          ),
                                                                          borderRadius:
                                                                              const BorderRadius.only(
                                                                            topLeft:
                                                                                Radius.circular(4.0),
                                                                            topRight:
                                                                                Radius.circular(4.0),
                                                                          ),
                                                                        ),
                                                                        focusedErrorBorder:
                                                                            OutlineInputBorder(
                                                                          borderSide:
                                                                              BorderSide(
                                                                            color:
                                                                                Color(0x00000000),
                                                                            width:
                                                                                1,
                                                                          ),
                                                                          borderRadius:
                                                                              const BorderRadius.only(
                                                                            topLeft:
                                                                                Radius.circular(4.0),
                                                                            topRight:
                                                                                Radius.circular(4.0),
                                                                          ),
                                                                        ),
                                                                        filled:
                                                                            true,
                                                                        fillColor:
                                                                            Colors.white,
                                                                      ),
                                                                      style: FlutterFlowTheme.of(
                                                                              context)
                                                                          .bodyText1
                                                                          .override(
                                                                            fontFamily:
                                                                                'Poppins',
                                                                            color:
                                                                                FlutterFlowTheme.of(context).black,
                                                                          ),
                                                                    ),
                                                                  ),
                                                                ],
                                                              ),
                                                            ),
                                                            Padding(
                                                              padding:
                                                                  EdgeInsetsDirectional
                                                                      .fromSTEB(
                                                                          0,
                                                                          30,
                                                                          0,
                                                                          0),
                                                              child: Wrap(
                                                                spacing: 0,
                                                                runSpacing: 0,
                                                                alignment:
                                                                    WrapAlignment
                                                                        .start,
                                                                crossAxisAlignment:
                                                                    WrapCrossAlignment
                                                                        .start,
                                                                direction: Axis
                                                                    .horizontal,
                                                                runAlignment:
                                                                    WrapAlignment
                                                                        .start,
                                                                verticalDirection:
                                                                    VerticalDirection
                                                                        .down,
                                                                clipBehavior:
                                                                    Clip.none,
                                                                children: [
                                                                  Container(
                                                                    width: 500,
                                                                    decoration:
                                                                        BoxDecoration(
                                                                      color: Colors
                                                                          .transparent,
                                                                    ),
                                                                    child:
                                                                        Padding(
                                                                      padding: EdgeInsetsDirectional
                                                                          .fromSTEB(
                                                                              0,
                                                                              15,
                                                                              20,
                                                                              0),
                                                                      child: custom_widgets
                                                                          .OrientationBasedText(
                                                                        width: MediaQuery.of(context)
                                                                            .size
                                                                            .width,
                                                                        height:
                                                                            40,
                                                                        text:
                                                                            'How  many 20*20 spaces will be available on rent?',
                                                                        textColor:
                                                                            Colors.black,
                                                                        textSize:
                                                                            14.0,
                                                                        textFont:
                                                                            'Poppins',
                                                                        fontWeight:
                                                                            0,
                                                                        mobileAlignment:
                                                                            'L',
                                                                        desktopAlignment:
                                                                            'R',
                                                                      ),
                                                                    ),
                                                                  ),
                                                                  Container(
                                                                    width: 200,
                                                                    height: 50,
                                                                    decoration:
                                                                        BoxDecoration(
                                                                      color: FlutterFlowTheme.of(
                                                                              context)
                                                                          .tertiaryColor,
                                                                    ),
                                                                    child:
                                                                        TextFormField(
                                                                      controller:
                                                                          textController15,
                                                                      obscureText:
                                                                          false,
                                                                      decoration:
                                                                          InputDecoration(
                                                                        hintText:
                                                                            FFLocalizations.of(context).getText(
                                                                          'a9r7abca' /* Enter a  value */,
                                                                        ),
                                                                        enabledBorder:
                                                                            OutlineInputBorder(
                                                                          borderSide:
                                                                              BorderSide(
                                                                            color:
                                                                                Colors.black,
                                                                            width:
                                                                                1,
                                                                          ),
                                                                          borderRadius:
                                                                              const BorderRadius.only(
                                                                            topLeft:
                                                                                Radius.circular(4.0),
                                                                            topRight:
                                                                                Radius.circular(4.0),
                                                                          ),
                                                                        ),
                                                                        focusedBorder:
                                                                            OutlineInputBorder(
                                                                          borderSide:
                                                                              BorderSide(
                                                                            color:
                                                                                Colors.black,
                                                                            width:
                                                                                1,
                                                                          ),
                                                                          borderRadius:
                                                                              const BorderRadius.only(
                                                                            topLeft:
                                                                                Radius.circular(4.0),
                                                                            topRight:
                                                                                Radius.circular(4.0),
                                                                          ),
                                                                        ),
                                                                        errorBorder:
                                                                            OutlineInputBorder(
                                                                          borderSide:
                                                                              BorderSide(
                                                                            color:
                                                                                Color(0x00000000),
                                                                            width:
                                                                                1,
                                                                          ),
                                                                          borderRadius:
                                                                              const BorderRadius.only(
                                                                            topLeft:
                                                                                Radius.circular(4.0),
                                                                            topRight:
                                                                                Radius.circular(4.0),
                                                                          ),
                                                                        ),
                                                                        focusedErrorBorder:
                                                                            OutlineInputBorder(
                                                                          borderSide:
                                                                              BorderSide(
                                                                            color:
                                                                                Color(0x00000000),
                                                                            width:
                                                                                1,
                                                                          ),
                                                                          borderRadius:
                                                                              const BorderRadius.only(
                                                                            topLeft:
                                                                                Radius.circular(4.0),
                                                                            topRight:
                                                                                Radius.circular(4.0),
                                                                          ),
                                                                        ),
                                                                        filled:
                                                                            true,
                                                                        fillColor:
                                                                            Colors.white,
                                                                      ),
                                                                      style: FlutterFlowTheme.of(
                                                                              context)
                                                                          .bodyText1
                                                                          .override(
                                                                            fontFamily:
                                                                                'Poppins',
                                                                            color:
                                                                                FlutterFlowTheme.of(context).black,
                                                                          ),
                                                                    ),
                                                                  ),
                                                                ],
                                                              ),
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                              SingleChildScrollView(
                                                child: Column(
                                                  mainAxisSize:
                                                      MainAxisSize.max,
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.center,
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.start,
                                                  children: [
                                                    Align(
                                                      alignment:
                                                          AlignmentDirectional(
                                                              0, 0),
                                                      child: Container(
                                                        width: 1000,
                                                        decoration:
                                                            BoxDecoration(),
                                                        child: Wrap(
                                                          spacing: 0,
                                                          runSpacing: 0,
                                                          alignment:
                                                              WrapAlignment
                                                                  .spaceBetween,
                                                          crossAxisAlignment:
                                                              WrapCrossAlignment
                                                                  .start,
                                                          direction:
                                                              Axis.horizontal,
                                                          runAlignment:
                                                              WrapAlignment.end,
                                                          verticalDirection:
                                                              VerticalDirection
                                                                  .down,
                                                          clipBehavior:
                                                              Clip.none,
                                                          children: [
                                                            Padding(
                                                              padding:
                                                                  EdgeInsetsDirectional
                                                                      .fromSTEB(
                                                                          0,
                                                                          15,
                                                                          0,
                                                                          0),
                                                              child: Wrap(
                                                                spacing: 0,
                                                                runSpacing: 0,
                                                                alignment:
                                                                    WrapAlignment
                                                                        .start,
                                                                crossAxisAlignment:
                                                                    WrapCrossAlignment
                                                                        .start,
                                                                direction: Axis
                                                                    .horizontal,
                                                                runAlignment:
                                                                    WrapAlignment
                                                                        .start,
                                                                verticalDirection:
                                                                    VerticalDirection
                                                                        .down,
                                                                clipBehavior:
                                                                    Clip.none,
                                                                children: [
                                                                  Container(
                                                                    width: 200,
                                                                    decoration:
                                                                        BoxDecoration(
                                                                      color: Colors
                                                                          .transparent,
                                                                    ),
                                                                    child:
                                                                        Padding(
                                                                      padding: EdgeInsetsDirectional
                                                                          .fromSTEB(
                                                                              0,
                                                                              15,
                                                                              20,
                                                                              0),
                                                                      child: custom_widgets
                                                                          .OrientationBasedText(
                                                                        width: MediaQuery.of(context)
                                                                            .size
                                                                            .width,
                                                                        height:
                                                                            40,
                                                                        text:
                                                                            'Start Date',
                                                                        textColor:
                                                                            Colors.black,
                                                                        textSize:
                                                                            14.0,
                                                                        textFont:
                                                                            'Poppins',
                                                                        fontWeight:
                                                                            0,
                                                                        mobileAlignment:
                                                                            'L',
                                                                        desktopAlignment:
                                                                            'R',
                                                                      ),
                                                                    ),
                                                                  ),
                                                                  Wrap(
                                                                    spacing: 0,
                                                                    runSpacing:
                                                                        0,
                                                                    alignment:
                                                                        WrapAlignment
                                                                            .start,
                                                                    crossAxisAlignment:
                                                                        WrapCrossAlignment
                                                                            .start,
                                                                    direction: Axis
                                                                        .horizontal,
                                                                    runAlignment:
                                                                        WrapAlignment
                                                                            .start,
                                                                    verticalDirection:
                                                                        VerticalDirection
                                                                            .down,
                                                                    clipBehavior:
                                                                        Clip.none,
                                                                    children: [
                                                                      Padding(
                                                                        padding: EdgeInsetsDirectional.fromSTEB(
                                                                            0,
                                                                            0,
                                                                            10,
                                                                            0),
                                                                        child:
                                                                            FlutterFlowDropDown(
                                                                          options: [
                                                                            FFLocalizations.of(context).getText(
                                                                              '5e3njt20' /* 1 */,
                                                                            )
                                                                          ],
                                                                          onChanged: (val) =>
                                                                              setState(() => startdatedayValue = val),
                                                                          width:
                                                                              90,
                                                                          height:
                                                                              50,
                                                                          textStyle: FlutterFlowTheme.of(context)
                                                                              .bodyText1
                                                                              .override(
                                                                                fontFamily: 'Poppins',
                                                                                color: Colors.black,
                                                                              ),
                                                                          hintText:
                                                                              FFLocalizations.of(context).getText(
                                                                            '0a1vf7gm' /* Day */,
                                                                          ),
                                                                          fillColor:
                                                                              Colors.white,
                                                                          elevation:
                                                                              2,
                                                                          borderColor:
                                                                              Colors.black,
                                                                          borderWidth:
                                                                              0,
                                                                          borderRadius:
                                                                              5,
                                                                          margin: EdgeInsetsDirectional.fromSTEB(
                                                                              12,
                                                                              4,
                                                                              12,
                                                                              4),
                                                                          hidesUnderline:
                                                                              true,
                                                                        ),
                                                                      ),
                                                                      FlutterFlowDropDown(
                                                                        options: [
                                                                          FFLocalizations.of(context)
                                                                              .getText(
                                                                            'cspixapi' /* January */,
                                                                          ),
                                                                          FFLocalizations.of(context)
                                                                              .getText(
                                                                            'o9w0ae30' /* February */,
                                                                          ),
                                                                          FFLocalizations.of(context)
                                                                              .getText(
                                                                            'texw3tmp' /* March */,
                                                                          ),
                                                                          FFLocalizations.of(context)
                                                                              .getText(
                                                                            'vcgvh60m' /* April */,
                                                                          )
                                                                        ],
                                                                        onChanged:
                                                                            (val) =>
                                                                                setState(() => startdatemonthValue = val),
                                                                        width:
                                                                            100,
                                                                        height:
                                                                            50,
                                                                        textStyle: FlutterFlowTheme.of(context)
                                                                            .bodyText1
                                                                            .override(
                                                                              fontFamily: 'Poppins',
                                                                              color: Colors.black,
                                                                            ),
                                                                        hintText:
                                                                            FFLocalizations.of(context).getText(
                                                                          'cfuzicvu' /* Month */,
                                                                        ),
                                                                        fillColor:
                                                                            Colors.white,
                                                                        elevation:
                                                                            2,
                                                                        borderColor:
                                                                            Colors.black,
                                                                        borderWidth:
                                                                            0,
                                                                        borderRadius:
                                                                            5,
                                                                        margin: EdgeInsetsDirectional.fromSTEB(
                                                                            12,
                                                                            4,
                                                                            12,
                                                                            4),
                                                                        hidesUnderline:
                                                                            true,
                                                                      ),
                                                                      Padding(
                                                                        padding: EdgeInsetsDirectional.fromSTEB(
                                                                            10,
                                                                            0,
                                                                            0,
                                                                            0),
                                                                        child:
                                                                            FlutterFlowDropDown(
                                                                          options: [
                                                                            FFLocalizations.of(context).getText(
                                                                              'hmupcbgg' /* 1935 */,
                                                                            )
                                                                          ],
                                                                          onChanged: (val) =>
                                                                              setState(() => startdateyearValue = val),
                                                                          width:
                                                                              90,
                                                                          height:
                                                                              50,
                                                                          textStyle: FlutterFlowTheme.of(context)
                                                                              .bodyText1
                                                                              .override(
                                                                                fontFamily: 'Poppins',
                                                                                color: Colors.black,
                                                                              ),
                                                                          hintText:
                                                                              FFLocalizations.of(context).getText(
                                                                            '0wtqewl7' /* Year */,
                                                                          ),
                                                                          fillColor:
                                                                              Colors.white,
                                                                          elevation:
                                                                              2,
                                                                          borderColor:
                                                                              Colors.black,
                                                                          borderWidth:
                                                                              0,
                                                                          borderRadius:
                                                                              5,
                                                                          margin: EdgeInsetsDirectional.fromSTEB(
                                                                              12,
                                                                              4,
                                                                              12,
                                                                              4),
                                                                          hidesUnderline:
                                                                              true,
                                                                        ),
                                                                      ),
                                                                    ],
                                                                  ),
                                                                ],
                                                              ),
                                                            ),
                                                            Padding(
                                                              padding:
                                                                  EdgeInsetsDirectional
                                                                      .fromSTEB(
                                                                          0,
                                                                          15,
                                                                          0,
                                                                          0),
                                                              child: Wrap(
                                                                spacing: 0,
                                                                runSpacing: 0,
                                                                alignment:
                                                                    WrapAlignment
                                                                        .start,
                                                                crossAxisAlignment:
                                                                    WrapCrossAlignment
                                                                        .start,
                                                                direction: Axis
                                                                    .horizontal,
                                                                runAlignment:
                                                                    WrapAlignment
                                                                        .start,
                                                                verticalDirection:
                                                                    VerticalDirection
                                                                        .down,
                                                                clipBehavior:
                                                                    Clip.none,
                                                                children: [
                                                                  Container(
                                                                    width: 200,
                                                                    decoration:
                                                                        BoxDecoration(
                                                                      color: Colors
                                                                          .transparent,
                                                                    ),
                                                                    child:
                                                                        Padding(
                                                                      padding: EdgeInsetsDirectional
                                                                          .fromSTEB(
                                                                              0,
                                                                              15,
                                                                              20,
                                                                              0),
                                                                      child: custom_widgets
                                                                          .OrientationBasedText(
                                                                        width: MediaQuery.of(context)
                                                                            .size
                                                                            .width,
                                                                        height:
                                                                            40,
                                                                        text:
                                                                            'End Date',
                                                                        textColor:
                                                                            Colors.black,
                                                                        textSize:
                                                                            14.0,
                                                                        textFont:
                                                                            'Poppins',
                                                                        fontWeight:
                                                                            0,
                                                                        mobileAlignment:
                                                                            'L',
                                                                        desktopAlignment:
                                                                            'R',
                                                                      ),
                                                                    ),
                                                                  ),
                                                                  Wrap(
                                                                    spacing: 0,
                                                                    runSpacing:
                                                                        0,
                                                                    alignment:
                                                                        WrapAlignment
                                                                            .start,
                                                                    crossAxisAlignment:
                                                                        WrapCrossAlignment
                                                                            .start,
                                                                    direction: Axis
                                                                        .horizontal,
                                                                    runAlignment:
                                                                        WrapAlignment
                                                                            .start,
                                                                    verticalDirection:
                                                                        VerticalDirection
                                                                            .down,
                                                                    clipBehavior:
                                                                        Clip.none,
                                                                    children: [
                                                                      Padding(
                                                                        padding: EdgeInsetsDirectional.fromSTEB(
                                                                            0,
                                                                            0,
                                                                            10,
                                                                            0),
                                                                        child:
                                                                            FlutterFlowDropDown(
                                                                          options: [
                                                                            FFLocalizations.of(context).getText(
                                                                              'kr54yp4e' /* 1 */,
                                                                            )
                                                                          ],
                                                                          onChanged: (val) =>
                                                                              setState(() => endDateDayValue = val),
                                                                          width:
                                                                              90,
                                                                          height:
                                                                              50,
                                                                          textStyle: FlutterFlowTheme.of(context)
                                                                              .bodyText1
                                                                              .override(
                                                                                fontFamily: 'Poppins',
                                                                                color: Colors.black,
                                                                              ),
                                                                          hintText:
                                                                              FFLocalizations.of(context).getText(
                                                                            'hlgx7xxl' /* Day */,
                                                                          ),
                                                                          fillColor:
                                                                              Colors.white,
                                                                          elevation:
                                                                              2,
                                                                          borderColor:
                                                                              Colors.black,
                                                                          borderWidth:
                                                                              0,
                                                                          borderRadius:
                                                                              5,
                                                                          margin: EdgeInsetsDirectional.fromSTEB(
                                                                              12,
                                                                              4,
                                                                              12,
                                                                              4),
                                                                          hidesUnderline:
                                                                              true,
                                                                        ),
                                                                      ),
                                                                      FlutterFlowDropDown(
                                                                        options: [
                                                                          FFLocalizations.of(context)
                                                                              .getText(
                                                                            'by2gjdx1' /* April */,
                                                                          ),
                                                                          FFLocalizations.of(context)
                                                                              .getText(
                                                                            'fqu3s8nt' /* March */,
                                                                          ),
                                                                          FFLocalizations.of(context)
                                                                              .getText(
                                                                            'qnbczrbf' /* July */,
                                                                          )
                                                                        ],
                                                                        onChanged:
                                                                            (val) =>
                                                                                setState(() => endDateMonthValue = val),
                                                                        width:
                                                                            100,
                                                                        height:
                                                                            50,
                                                                        textStyle: FlutterFlowTheme.of(context)
                                                                            .bodyText1
                                                                            .override(
                                                                              fontFamily: 'Poppins',
                                                                              color: Colors.black,
                                                                            ),
                                                                        hintText:
                                                                            FFLocalizations.of(context).getText(
                                                                          'l6hfy8bn' /* Month */,
                                                                        ),
                                                                        fillColor:
                                                                            Colors.white,
                                                                        elevation:
                                                                            2,
                                                                        borderColor:
                                                                            Colors.black,
                                                                        borderWidth:
                                                                            0,
                                                                        borderRadius:
                                                                            5,
                                                                        margin: EdgeInsetsDirectional.fromSTEB(
                                                                            12,
                                                                            4,
                                                                            12,
                                                                            4),
                                                                        hidesUnderline:
                                                                            true,
                                                                      ),
                                                                      Padding(
                                                                        padding: EdgeInsetsDirectional.fromSTEB(
                                                                            10,
                                                                            0,
                                                                            0,
                                                                            0),
                                                                        child:
                                                                            FlutterFlowDropDown(
                                                                          options: [
                                                                            FFLocalizations.of(context).getText(
                                                                              'd99xog8o' /* 1935 */,
                                                                            )
                                                                          ],
                                                                          onChanged: (val) =>
                                                                              setState(() => endDateYearValue = val),
                                                                          width:
                                                                              90,
                                                                          height:
                                                                              50,
                                                                          textStyle: FlutterFlowTheme.of(context)
                                                                              .bodyText1
                                                                              .override(
                                                                                fontFamily: 'Poppins',
                                                                                color: Colors.black,
                                                                              ),
                                                                          hintText:
                                                                              FFLocalizations.of(context).getText(
                                                                            'ji7cced0' /* Year */,
                                                                          ),
                                                                          fillColor:
                                                                              Colors.white,
                                                                          elevation:
                                                                              2,
                                                                          borderColor:
                                                                              Colors.black,
                                                                          borderWidth:
                                                                              0,
                                                                          borderRadius:
                                                                              5,
                                                                          margin: EdgeInsetsDirectional.fromSTEB(
                                                                              12,
                                                                              4,
                                                                              12,
                                                                              4),
                                                                          hidesUnderline:
                                                                              true,
                                                                        ),
                                                                      ),
                                                                    ],
                                                                  ),
                                                                ],
                                                              ),
                                                            ),
                                                            Padding(
                                                              padding:
                                                                  EdgeInsetsDirectional
                                                                      .fromSTEB(
                                                                          0,
                                                                          50,
                                                                          0,
                                                                          0),
                                                              child: Wrap(
                                                                spacing: 0,
                                                                runSpacing: 0,
                                                                alignment:
                                                                    WrapAlignment
                                                                        .start,
                                                                crossAxisAlignment:
                                                                    WrapCrossAlignment
                                                                        .start,
                                                                direction: Axis
                                                                    .horizontal,
                                                                runAlignment:
                                                                    WrapAlignment
                                                                        .start,
                                                                verticalDirection:
                                                                    VerticalDirection
                                                                        .down,
                                                                clipBehavior:
                                                                    Clip.none,
                                                                children: [
                                                                  Container(
                                                                    width: 200,
                                                                    decoration:
                                                                        BoxDecoration(
                                                                      color: Colors
                                                                          .transparent,
                                                                    ),
                                                                    child:
                                                                        Padding(
                                                                      padding: EdgeInsetsDirectional
                                                                          .fromSTEB(
                                                                              0,
                                                                              15,
                                                                              20,
                                                                              0),
                                                                      child: custom_widgets
                                                                          .OrientationBasedText(
                                                                        width: MediaQuery.of(context)
                                                                            .size
                                                                            .width,
                                                                        height:
                                                                            40,
                                                                        text:
                                                                            'Registration Deadline',
                                                                        textColor:
                                                                            Colors.black,
                                                                        textSize:
                                                                            14.0,
                                                                        textFont:
                                                                            'Poppins',
                                                                        fontWeight:
                                                                            0,
                                                                        mobileAlignment:
                                                                            'L',
                                                                        desktopAlignment:
                                                                            'R',
                                                                      ),
                                                                    ),
                                                                  ),
                                                                  Wrap(
                                                                    spacing: 0,
                                                                    runSpacing:
                                                                        0,
                                                                    alignment:
                                                                        WrapAlignment
                                                                            .start,
                                                                    crossAxisAlignment:
                                                                        WrapCrossAlignment
                                                                            .start,
                                                                    direction: Axis
                                                                        .horizontal,
                                                                    runAlignment:
                                                                        WrapAlignment
                                                                            .start,
                                                                    verticalDirection:
                                                                        VerticalDirection
                                                                            .down,
                                                                    clipBehavior:
                                                                        Clip.none,
                                                                    children: [
                                                                      Padding(
                                                                        padding: EdgeInsetsDirectional.fromSTEB(
                                                                            0,
                                                                            0,
                                                                            10,
                                                                            0),
                                                                        child:
                                                                            FlutterFlowDropDown(
                                                                          options: [
                                                                            FFLocalizations.of(context).getText(
                                                                              'mbxmp030' /* 1 */,
                                                                            )
                                                                          ],
                                                                          onChanged: (val) =>
                                                                              setState(() => deadlineDayValue = val),
                                                                          width:
                                                                              90,
                                                                          height:
                                                                              50,
                                                                          textStyle: FlutterFlowTheme.of(context)
                                                                              .bodyText1
                                                                              .override(
                                                                                fontFamily: 'Poppins',
                                                                                color: Colors.black,
                                                                              ),
                                                                          hintText:
                                                                              FFLocalizations.of(context).getText(
                                                                            'khq095ea' /* Day */,
                                                                          ),
                                                                          fillColor:
                                                                              Colors.white,
                                                                          elevation:
                                                                              2,
                                                                          borderColor:
                                                                              Colors.black,
                                                                          borderWidth:
                                                                              0,
                                                                          borderRadius:
                                                                              5,
                                                                          margin: EdgeInsetsDirectional.fromSTEB(
                                                                              12,
                                                                              4,
                                                                              12,
                                                                              4),
                                                                          hidesUnderline:
                                                                              true,
                                                                        ),
                                                                      ),
                                                                      FlutterFlowDropDown(
                                                                        options: [
                                                                          FFLocalizations.of(context)
                                                                              .getText(
                                                                            'zxtq88wh' /* September */,
                                                                          ),
                                                                          FFLocalizations.of(context)
                                                                              .getText(
                                                                            'fs27m0rh' /* April */,
                                                                          ),
                                                                          FFLocalizations.of(context)
                                                                              .getText(
                                                                            '9n9iizb6' /* February */,
                                                                          )
                                                                        ],
                                                                        onChanged:
                                                                            (val) =>
                                                                                setState(() => deadlineMonthValue = val),
                                                                        width:
                                                                            100,
                                                                        height:
                                                                            50,
                                                                        textStyle: FlutterFlowTheme.of(context)
                                                                            .bodyText1
                                                                            .override(
                                                                              fontFamily: 'Poppins',
                                                                              color: Colors.black,
                                                                            ),
                                                                        hintText:
                                                                            FFLocalizations.of(context).getText(
                                                                          'iao2hpsm' /* Month */,
                                                                        ),
                                                                        fillColor:
                                                                            Colors.white,
                                                                        elevation:
                                                                            2,
                                                                        borderColor:
                                                                            Colors.black,
                                                                        borderWidth:
                                                                            0,
                                                                        borderRadius:
                                                                            5,
                                                                        margin: EdgeInsetsDirectional.fromSTEB(
                                                                            12,
                                                                            4,
                                                                            12,
                                                                            4),
                                                                        hidesUnderline:
                                                                            true,
                                                                      ),
                                                                      Padding(
                                                                        padding: EdgeInsetsDirectional.fromSTEB(
                                                                            10,
                                                                            0,
                                                                            0,
                                                                            0),
                                                                        child:
                                                                            FlutterFlowDropDown(
                                                                          options: [
                                                                            FFLocalizations.of(context).getText(
                                                                              '541e0htg' /* 1935 */,
                                                                            )
                                                                          ],
                                                                          onChanged: (val) =>
                                                                              setState(() => deadlineYearValue = val),
                                                                          width:
                                                                              90,
                                                                          height:
                                                                              50,
                                                                          textStyle: FlutterFlowTheme.of(context)
                                                                              .bodyText1
                                                                              .override(
                                                                                fontFamily: 'Poppins',
                                                                                color: Colors.black,
                                                                              ),
                                                                          hintText:
                                                                              FFLocalizations.of(context).getText(
                                                                            '97f3hd44' /* Year */,
                                                                          ),
                                                                          fillColor:
                                                                              Colors.white,
                                                                          elevation:
                                                                              2,
                                                                          borderColor:
                                                                              Colors.black,
                                                                          borderWidth:
                                                                              0,
                                                                          borderRadius:
                                                                              5,
                                                                          margin: EdgeInsetsDirectional.fromSTEB(
                                                                              12,
                                                                              4,
                                                                              12,
                                                                              4),
                                                                          hidesUnderline:
                                                                              true,
                                                                        ),
                                                                      ),
                                                                    ],
                                                                  ),
                                                                ],
                                                              ),
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                              SingleChildScrollView(
                                                child: Column(
                                                  mainAxisSize:
                                                      MainAxisSize.max,
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.center,
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.start,
                                                  children: [
                                                    Align(
                                                      alignment:
                                                          AlignmentDirectional(
                                                              0, 0),
                                                      child: Container(
                                                        width: MediaQuery.of(
                                                                context)
                                                            .size
                                                            .width,
                                                        decoration:
                                                            BoxDecoration(),
                                                        child: Column(
                                                          mainAxisSize:
                                                              MainAxisSize.max,
                                                          children: [
                                                            Wrap(
                                                              spacing: 0,
                                                              runSpacing: 0,
                                                              alignment:
                                                                  WrapAlignment
                                                                      .spaceBetween,
                                                              crossAxisAlignment:
                                                                  WrapCrossAlignment
                                                                      .start,
                                                              direction: Axis
                                                                  .horizontal,
                                                              runAlignment:
                                                                  WrapAlignment
                                                                      .end,
                                                              verticalDirection:
                                                                  VerticalDirection
                                                                      .down,
                                                              clipBehavior:
                                                                  Clip.none,
                                                              children: [
                                                                Padding(
                                                                  padding: EdgeInsetsDirectional
                                                                      .fromSTEB(
                                                                          0,
                                                                          20,
                                                                          0,
                                                                          0),
                                                                  child: Wrap(
                                                                    spacing: 0,
                                                                    runSpacing:
                                                                        0,
                                                                    alignment:
                                                                        WrapAlignment
                                                                            .start,
                                                                    crossAxisAlignment:
                                                                        WrapCrossAlignment
                                                                            .start,
                                                                    direction: Axis
                                                                        .horizontal,
                                                                    runAlignment:
                                                                        WrapAlignment
                                                                            .start,
                                                                    verticalDirection:
                                                                        VerticalDirection
                                                                            .down,
                                                                    clipBehavior:
                                                                        Clip.none,
                                                                    children: [
                                                                      Container(
                                                                        width:
                                                                            200,
                                                                        decoration:
                                                                            BoxDecoration(
                                                                          color:
                                                                              Colors.transparent,
                                                                        ),
                                                                        child:
                                                                            Padding(
                                                                          padding: EdgeInsetsDirectional.fromSTEB(
                                                                              0,
                                                                              15,
                                                                              20,
                                                                              0),
                                                                          child:
                                                                              custom_widgets.OrientationBasedText(
                                                                            width:
                                                                                MediaQuery.of(context).size.width,
                                                                            height:
                                                                                40,
                                                                            text:
                                                                                'Event Director Name',
                                                                            textColor:
                                                                                Colors.black,
                                                                            textSize:
                                                                                14.0,
                                                                            textFont:
                                                                                'Poppins',
                                                                            fontWeight:
                                                                                0,
                                                                            mobileAlignment:
                                                                                'L',
                                                                            desktopAlignment:
                                                                                'R',
                                                                          ),
                                                                        ),
                                                                      ),
                                                                      Container(
                                                                        width:
                                                                            300,
                                                                        height:
                                                                            50,
                                                                        decoration:
                                                                            BoxDecoration(
                                                                          color:
                                                                              FlutterFlowTheme.of(context).tertiaryColor,
                                                                        ),
                                                                        child: FutureBuilder<
                                                                            ApiCallResponse>(
                                                                          future:
                                                                              NGetDataCall.call(
                                                                            refreshToken:
                                                                                'c4Xf3PpdjVEKSfKuDKbSSZeNEw-7lv-r9XzNSt3RWD3bAdNBQSaxwA',
                                                                            tableName:
                                                                                'AdminUsers',
                                                                          ),
                                                                          builder:
                                                                              (context, snapshot) {
                                                                            // Customize what your widget looks like when it's loading.
                                                                            if (!snapshot.hasData) {
                                                                              return Center(
                                                                                child: SizedBox(
                                                                                  width: 50,
                                                                                  height: 50,
                                                                                  child: SpinKitHourGlass(
                                                                                    color: Color(0xFFFFC107),
                                                                                    size: 50,
                                                                                  ),
                                                                                ),
                                                                              );
                                                                            }
                                                                            final dropDownNGetDataResponse =
                                                                                snapshot.data!;
                                                                            return FlutterFlowDropDown(
                                                                              options: (getJsonField(
                                                                                dropDownNGetDataResponse.jsonBody,
                                                                                r'''$..first_name''',
                                                                              ) as List)
                                                                                  .map<String>((s) => s.toString())
                                                                                  .toList()
                                                                                  .toList(),
                                                                              onChanged: (val) => setState(() => dropDownValue1 = val),
                                                                              width: 180,
                                                                              height: 50,
                                                                              textStyle: FlutterFlowTheme.of(context).bodyText1.override(
                                                                                    fontFamily: 'Poppins',
                                                                                    color: Colors.black,
                                                                                  ),
                                                                              hintText: FFLocalizations.of(context).getText(
                                                                                'x3vg5kfg' /* Please select... */,
                                                                              ),
                                                                              fillColor: Colors.white,
                                                                              elevation: 2,
                                                                              borderColor: Colors.black,
                                                                              borderWidth: 0,
                                                                              borderRadius: 0,
                                                                              margin: EdgeInsetsDirectional.fromSTEB(12, 4, 12, 4),
                                                                              hidesUnderline: true,
                                                                            );
                                                                          },
                                                                        ),
                                                                      ),
                                                                    ],
                                                                  ),
                                                                ),
                                                                Padding(
                                                                  padding: EdgeInsetsDirectional
                                                                      .fromSTEB(
                                                                          0,
                                                                          25,
                                                                          0,
                                                                          0),
                                                                  child: Wrap(
                                                                    spacing: 0,
                                                                    runSpacing:
                                                                        0,
                                                                    alignment:
                                                                        WrapAlignment
                                                                            .start,
                                                                    crossAxisAlignment:
                                                                        WrapCrossAlignment
                                                                            .start,
                                                                    direction: Axis
                                                                        .horizontal,
                                                                    runAlignment:
                                                                        WrapAlignment
                                                                            .start,
                                                                    verticalDirection:
                                                                        VerticalDirection
                                                                            .down,
                                                                    clipBehavior:
                                                                        Clip.none,
                                                                    children: [
                                                                      Container(
                                                                        width:
                                                                            200,
                                                                        decoration:
                                                                            BoxDecoration(
                                                                          color:
                                                                              Colors.transparent,
                                                                        ),
                                                                        child:
                                                                            Padding(
                                                                          padding: EdgeInsetsDirectional.fromSTEB(
                                                                              0,
                                                                              15,
                                                                              20,
                                                                              0),
                                                                          child:
                                                                              custom_widgets.OrientationBasedText(
                                                                            width:
                                                                                MediaQuery.of(context).size.width,
                                                                            height:
                                                                                40,
                                                                            text:
                                                                                'Volunteer Coordinator Name',
                                                                            textColor:
                                                                                Colors.black,
                                                                            textSize:
                                                                                14.0,
                                                                            textFont:
                                                                                'Poppins',
                                                                            fontWeight:
                                                                                0,
                                                                            mobileAlignment:
                                                                                'L',
                                                                            desktopAlignment:
                                                                                'R',
                                                                          ),
                                                                        ),
                                                                      ),
                                                                      Container(
                                                                        width:
                                                                            300,
                                                                        height:
                                                                            50,
                                                                        decoration:
                                                                            BoxDecoration(
                                                                          color:
                                                                              FlutterFlowTheme.of(context).tertiaryColor,
                                                                        ),
                                                                        child: FutureBuilder<
                                                                            ApiCallResponse>(
                                                                          future:
                                                                              NGetDataCall.call(
                                                                            refreshToken:
                                                                                'c4Xf3PpdjVEKSfKuDKbSSZeNEw-7lv-r9XzNSt3RWD3bAdNBQSaxwA',
                                                                            tableName:
                                                                                'AdminUsers',
                                                                          ),
                                                                          builder:
                                                                              (context, snapshot) {
                                                                            // Customize what your widget looks like when it's loading.
                                                                            if (!snapshot.hasData) {
                                                                              return Center(
                                                                                child: SizedBox(
                                                                                  width: 50,
                                                                                  height: 50,
                                                                                  child: SpinKitHourGlass(
                                                                                    color: Color(0xFFFFC107),
                                                                                    size: 50,
                                                                                  ),
                                                                                ),
                                                                              );
                                                                            }
                                                                            final dropDownNGetDataResponse =
                                                                                snapshot.data!;
                                                                            return FlutterFlowDropDown(
                                                                              options: (getJsonField(
                                                                                dropDownNGetDataResponse.jsonBody,
                                                                                r'''$..first_name''',
                                                                              ) as List)
                                                                                  .map<String>((s) => s.toString())
                                                                                  .toList()
                                                                                  .toList(),
                                                                              onChanged: (val) => setState(() => dropDownValue2 = val),
                                                                              width: 180,
                                                                              height: 50,
                                                                              textStyle: FlutterFlowTheme.of(context).bodyText1.override(
                                                                                    fontFamily: 'Poppins',
                                                                                    color: Colors.black,
                                                                                  ),
                                                                              hintText: FFLocalizations.of(context).getText(
                                                                                '412hekcz' /* Please select... */,
                                                                              ),
                                                                              fillColor: Colors.white,
                                                                              elevation: 2,
                                                                              borderColor: Colors.black,
                                                                              borderWidth: 0,
                                                                              borderRadius: 0,
                                                                              margin: EdgeInsetsDirectional.fromSTEB(12, 4, 12, 4),
                                                                              hidesUnderline: true,
                                                                            );
                                                                          },
                                                                        ),
                                                                      ),
                                                                    ],
                                                                  ),
                                                                ),
                                                                Padding(
                                                                  padding: EdgeInsetsDirectional
                                                                      .fromSTEB(
                                                                          0,
                                                                          25,
                                                                          0,
                                                                          0),
                                                                  child: Wrap(
                                                                    spacing: 0,
                                                                    runSpacing:
                                                                        0,
                                                                    alignment:
                                                                        WrapAlignment
                                                                            .start,
                                                                    crossAxisAlignment:
                                                                        WrapCrossAlignment
                                                                            .start,
                                                                    direction: Axis
                                                                        .horizontal,
                                                                    runAlignment:
                                                                        WrapAlignment
                                                                            .start,
                                                                    verticalDirection:
                                                                        VerticalDirection
                                                                            .down,
                                                                    clipBehavior:
                                                                        Clip.none,
                                                                    children: [
                                                                      Container(
                                                                        width:
                                                                            200,
                                                                        decoration:
                                                                            BoxDecoration(
                                                                          color:
                                                                              Colors.transparent,
                                                                        ),
                                                                        child:
                                                                            Padding(
                                                                          padding: EdgeInsetsDirectional.fromSTEB(
                                                                              0,
                                                                              15,
                                                                              20,
                                                                              0),
                                                                          child:
                                                                              custom_widgets.OrientationBasedText(
                                                                            width:
                                                                                MediaQuery.of(context).size.width,
                                                                            height:
                                                                                40,
                                                                            text:
                                                                                ' Referee Coordinator Name',
                                                                            textColor:
                                                                                Colors.black,
                                                                            textSize:
                                                                                14.0,
                                                                            textFont:
                                                                                'Poppins',
                                                                            fontWeight:
                                                                                0,
                                                                            mobileAlignment:
                                                                                'L',
                                                                            desktopAlignment:
                                                                                'R',
                                                                          ),
                                                                        ),
                                                                      ),
                                                                      Container(
                                                                        width:
                                                                            300,
                                                                        height:
                                                                            50,
                                                                        decoration:
                                                                            BoxDecoration(
                                                                          color:
                                                                              FlutterFlowTheme.of(context).tertiaryColor,
                                                                        ),
                                                                        child: FutureBuilder<
                                                                            ApiCallResponse>(
                                                                          future:
                                                                              NGetDataCall.call(
                                                                            refreshToken:
                                                                                'c4Xf3PpdjVEKSfKuDKbSSZeNEw-7lv-r9XzNSt3RWD3bAdNBQSaxwA',
                                                                            tableName:
                                                                                'AdminUsers',
                                                                          ),
                                                                          builder:
                                                                              (context, snapshot) {
                                                                            // Customize what your widget looks like when it's loading.
                                                                            if (!snapshot.hasData) {
                                                                              return Center(
                                                                                child: SizedBox(
                                                                                  width: 50,
                                                                                  height: 50,
                                                                                  child: SpinKitHourGlass(
                                                                                    color: Color(0xFFFFC107),
                                                                                    size: 50,
                                                                                  ),
                                                                                ),
                                                                              );
                                                                            }
                                                                            final dropDownNGetDataResponse =
                                                                                snapshot.data!;
                                                                            return FlutterFlowDropDown(
                                                                              options: (getJsonField(
                                                                                dropDownNGetDataResponse.jsonBody,
                                                                                r'''$..first_name''',
                                                                              ) as List)
                                                                                  .map<String>((s) => s.toString())
                                                                                  .toList()
                                                                                  .toList(),
                                                                              onChanged: (val) => setState(() => dropDownValue3 = val),
                                                                              width: 180,
                                                                              height: 50,
                                                                              textStyle: FlutterFlowTheme.of(context).bodyText1.override(
                                                                                    fontFamily: 'Poppins',
                                                                                    color: Colors.black,
                                                                                  ),
                                                                              hintText: FFLocalizations.of(context).getText(
                                                                                'qmry9xee' /* Please select... */,
                                                                              ),
                                                                              fillColor: Colors.white,
                                                                              elevation: 2,
                                                                              borderColor: Colors.black,
                                                                              borderWidth: 0,
                                                                              borderRadius: 0,
                                                                              margin: EdgeInsetsDirectional.fromSTEB(12, 4, 12, 4),
                                                                              hidesUnderline: true,
                                                                            );
                                                                          },
                                                                        ),
                                                                      ),
                                                                    ],
                                                                  ),
                                                                ),
                                                              ],
                                                            ),
                                                            Align(
                                                              alignment:
                                                                  AlignmentDirectional(
                                                                      0, 0),
                                                              child: Container(
                                                                width: 1200,
                                                                decoration:
                                                                    BoxDecoration(),
                                                                child: custom_widgets
                                                                    .AddHotelPartnerWidget(
                                                                  width: MediaQuery.of(
                                                                          context)
                                                                      .size
                                                                      .width,
                                                                  height: 700,
                                                                ),
                                                              ),
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ),
                    Padding(
                      padding: EdgeInsetsDirectional.fromSTEB(0, 40, 0, 10),
                      child: SingleChildScrollView(
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Wrap(
                              spacing: 0,
                              runSpacing: 0,
                              alignment: WrapAlignment.start,
                              crossAxisAlignment: WrapCrossAlignment.center,
                              direction: Axis.horizontal,
                              runAlignment: WrapAlignment.start,
                              verticalDirection: VerticalDirection.down,
                              clipBehavior: Clip.none,
                              children: [
                                Wrap(
                                  spacing: 0,
                                  runSpacing: 0,
                                  alignment: WrapAlignment.start,
                                  crossAxisAlignment: WrapCrossAlignment.start,
                                  direction: Axis.horizontal,
                                  runAlignment: WrapAlignment.start,
                                  verticalDirection: VerticalDirection.down,
                                  clipBehavior: Clip.none,
                                  children: [
                                    FFButtonWidget(
                                      onPressed: () async {
                                        Navigator.pop(context);
                                      },
                                      text: FFLocalizations.of(context).getText(
                                        'msd03uyf' /* Cancel */,
                                      ),
                                      options: FFButtonOptions(
                                        width: 130,
                                        height: 40,
                                        color: Color(0xFF274078),
                                        textStyle: FlutterFlowTheme.of(context)
                                            .subtitle2
                                            .override(
                                              fontFamily: 'Poppins',
                                              color: Color(0xFFFAFAFA),
                                            ),
                                        borderSide: BorderSide(
                                          color: Color(0xFFFAFAFA),
                                          width: 1,
                                        ),
                                        borderRadius: BorderRadius.circular(40),
                                      ),
                                    ),
                                  ],
                                ),
                                Padding(
                                  padding: EdgeInsetsDirectional.fromSTEB(
                                      30, 0, 0, 0),
                                  child: Wrap(
                                    spacing: 0,
                                    runSpacing: 0,
                                    alignment: WrapAlignment.start,
                                    crossAxisAlignment:
                                        WrapCrossAlignment.start,
                                    direction: Axis.horizontal,
                                    runAlignment: WrapAlignment.start,
                                    verticalDirection: VerticalDirection.down,
                                    clipBehavior: Clip.none,
                                    children: [
                                      FFButtonWidget(
                                        onPressed: () async {
                                          apiCallOutput3 =
                                              await NCreateEventCall.call(
                                            refreshToken:
                                                'c4Xf3PpdjVEKSfKuDKbSSZeNEw-7lv-r9XzNSt3RWD3bAdNBQSaxwA',
                                            eventtype: eventtypeValue,
                                            eventname: citynameController!.text,
                                            cityname: citynameController!.text,
                                            startdate:
                                                functions.getConcatenateDate(
                                                    startdatedayValue,
                                                    startdatemonthValue,
                                                    startdateyearValue),
                                            enddate:
                                                functions.getConcatenateDate(
                                                    endDateDayValue,
                                                    endDateMonthValue,
                                                    endDateYearValue),
                                            locprovincestate: provinceValue,
                                            loccity: cityValue,
                                            loczipcode: textController4!.text,
                                            regdeadline:
                                                functions.getConcatenateDate(
                                                    deadlineDayValue,
                                                    deadlineMonthValue,
                                                    deadlineYearValue),
                                          );
                                          if ((apiCallOutput3?.succeeded ??
                                              true)) {
                                            await showDialog(
                                              context: context,
                                              builder: (alertDialogContext) {
                                                return AlertDialog(
                                                  title: Text('Succes'),
                                                  content: Text(
                                                      'Registered Succesfully'),
                                                  actions: [
                                                    TextButton(
                                                      onPressed: () =>
                                                          Navigator.pop(
                                                              alertDialogContext),
                                                      child: Text('Ok'),
                                                    ),
                                                  ],
                                                );
                                              },
                                            );
                                          } else {
                                            await showDialog(
                                              context: context,
                                              builder: (alertDialogContext) {
                                                return AlertDialog(
                                                  title: Text('Failed'),
                                                  content: Text(
                                                      'Registration Failure'),
                                                  actions: [
                                                    TextButton(
                                                      onPressed: () =>
                                                          Navigator.pop(
                                                              alertDialogContext),
                                                      child: Text('Ok'),
                                                    ),
                                                  ],
                                                );
                                              },
                                            );
                                          }

                                          setState(() {});
                                        },
                                        text:
                                            FFLocalizations.of(context).getText(
                                          'qtw7k3bo' /* Save */,
                                        ),
                                        options: FFButtonOptions(
                                          width: 130,
                                          height: 40,
                                          color: Color(0xFFFAFAFA),
                                          textStyle:
                                              FlutterFlowTheme.of(context)
                                                  .subtitle2
                                                  .override(
                                                    fontFamily: 'Poppins',
                                                    color: Color(0xFF274078),
                                                  ),
                                          borderSide: BorderSide(
                                            color: Color(0xFF274078),
                                            width: 1,
                                          ),
                                          borderRadius:
                                              BorderRadius.circular(40),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            AppNavBarWidget(),
          ],
        ),
      ),
    );
  }
}
