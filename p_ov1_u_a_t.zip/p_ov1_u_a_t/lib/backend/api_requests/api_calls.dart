import '../../flutter_flow/flutter_flow_util.dart';

import 'api_manager.dart';

export 'api_manager.dart' show ApiCallResponse;

const _kPrivateApiFunctionName = 'ffPrivateApiCall';

class GetLanguagesVerCall {
  static Future<ApiCallResponse> call() {
    return ApiManager.instance.makeApiCall(
      callName: 'GetLanguagesVer',
      apiUrl: 'https://resource.axxonet.com/playon/playonlangver.json',
      callType: ApiCallType.GET,
      headers: {},
      params: {},
      returnBody: true,
    );
  }

  static dynamic poLanguageVer(dynamic response) => getJsonField(
        response,
        r'''$''',
      );
}

class GetEventsCall {
  static Future<ApiCallResponse> call() {
    return ApiManager.instance.makeApiCall(
      callName: 'GetEvents',
      apiUrl:
          'https://script.google.com/macros/s/AKfycby59fV-vP7ZHBJVZigmGxYWthrgH4Yc3CGZ73Sg7Qu0Oo6_L_C9nwcVLseI6FfGCXCXug/exec?path=Events',
      callType: ApiCallType.GET,
      headers: {},
      params: {},
      returnBody: true,
    );
  }

  static dynamic poEvents(dynamic response) => getJsonField(
        response,
        r'''$''',
      );
  static dynamic no(dynamic response) => getJsonField(
        response,
        r'''$..No''',
      );
  static dynamic eventName(dynamic response) => getJsonField(
        response,
        r'''$..EventName''',
      );
  static dynamic startDate(dynamic response) => getJsonField(
        response,
        r'''$..StartDate''',
      );
  static dynamic endDate(dynamic response) => getJsonField(
        response,
        r'''$..EndDate''',
      );
  static dynamic region(dynamic response) => getJsonField(
        response,
        r'''$..Region''',
      );
  static dynamic province(dynamic response) => getJsonField(
        response,
        r'''$..Province''',
      );
  static dynamic city(dynamic response) => getJsonField(
        response,
        r'''$..City''',
      );
}

class GetBusinessDetailsCall {
  static Future<ApiCallResponse> call({
    String? corporationId = '862814555',
    String? lang = 'eng',
  }) {
    return ApiManager.instance.makeApiCall(
      callName: 'GetBusinessDetails',
      apiUrl:
          'https://corporations-ised-isde.api.canada.ca/api/v1/corporations/${corporationId}.json',
      callType: ApiCallType.GET,
      headers: {
        'user-key': '3f63130c390bfea0ccc445ddda53641f',
      },
      params: {
        'lang': lang,
      },
      returnBody: true,
    );
  }

  static dynamic poBusinessDetails(dynamic response) => getJsonField(
        response,
        r'''$''',
      );
  static dynamic corporationName(dynamic response) => getJsonField(
        response,
        r'''$..corporationNames..CorporationName..name''',
      );
  static dynamic incorporationDate(dynamic response) => getJsonField(
        response,
        r'''$..corporationNames..CorporationName..effectiveDate''',
      );
}

class GetEventsMetaDataCall {
  static Future<ApiCallResponse> call() {
    return ApiManager.instance.makeApiCall(
      callName: 'GetEventsMetaData',
      apiUrl:
          'https://script.google.com/macros/s/AKfycby59fV-vP7ZHBJVZigmGxYWthrgH4Yc3CGZ73Sg7Qu0Oo6_L_C9nwcVLseI6FfGCXCXug/exec?path=EventsMetaData',
      callType: ApiCallType.GET,
      headers: {},
      params: {},
      returnBody: true,
    );
  }
}

class PutPhotoToServerCall {
  static Future<ApiCallResponse> call({
    String? imagePath = '',
  }) {
    return ApiManager.instance.makeApiCall(
      callName: 'putPhotoToServer',
      apiUrl:
          'http://playon01.axx.do/webhook-test/25317d61-8197-48ee-849c-5e53bfc87434',
      callType: ApiCallType.GET,
      headers: {},
      params: {
        'imagePath': imagePath,
      },
      returnBody: true,
    );
  }
}

class GetEventsVTwoCall {
  static Future<ApiCallResponse> call() {
    return ApiManager.instance.makeApiCall(
      callName: 'GetEventsVTwo',
      apiUrl: 'https://tasks.axxonet.me/info/api/v1/play/allevents',
      callType: ApiCallType.GET,
      headers: {},
      params: {},
      returnBody: true,
    );
  }
}

class GetEventsAvailabilityMetaDataCall {
  static Future<ApiCallResponse> call() {
    return ApiManager.instance.makeApiCall(
      callName: 'GetEventsAvailabilityMetaData',
      apiUrl:
          'https://script.google.com/macros/s/AKfycby59fV-vP7ZHBJVZigmGxYWthrgH4Yc3CGZ73Sg7Qu0Oo6_L_C9nwcVLseI6FfGCXCXug/exec?path=EventsAvailabilityMetaData',
      callType: ApiCallType.GET,
      headers: {},
      params: {},
      returnBody: true,
    );
  }
}

class GetEventsAvailabilityCall {
  static Future<ApiCallResponse> call() {
    return ApiManager.instance.makeApiCall(
      callName: 'GetEventsAvailability',
      apiUrl:
          'https://script.google.com/macros/s/AKfycby59fV-vP7ZHBJVZigmGxYWthrgH4Yc3CGZ73Sg7Qu0Oo6_L_C9nwcVLseI6FfGCXCXug/exec?path=EventsAvailability',
      callType: ApiCallType.GET,
      headers: {},
      params: {},
      returnBody: true,
    );
  }

  static dynamic poEvents(dynamic response) => getJsonField(
        response,
        r'''$''',
      );
  static dynamic no(dynamic response) => getJsonField(
        response,
        r'''$..No''',
      );
  static dynamic eventName(dynamic response) => getJsonField(
        response,
        r'''$..EventName''',
      );
  static dynamic date(dynamic response) => getJsonField(
        response,
        r'''$..Date''',
      );
  static dynamic day(dynamic response) => getJsonField(
        response,
        r'''$..Day''',
      );
  static dynamic location(dynamic response) => getJsonField(
        response,
        r'''$..Location''',
      );
  static dynamic option(dynamic response) => getJsonField(
        response,
        r'''$..Option''',
      );
}

class GetTeamsMetaDataCall {
  static Future<ApiCallResponse> call() {
    return ApiManager.instance.makeApiCall(
      callName: 'GetTeamsMetaData',
      apiUrl:
          'https://script.google.com/macros/s/AKfycby59fV-vP7ZHBJVZigmGxYWthrgH4Yc3CGZ73Sg7Qu0Oo6_L_C9nwcVLseI6FfGCXCXug/exec?path=TeamsMetaData',
      callType: ApiCallType.GET,
      headers: {},
      params: {},
      returnBody: true,
    );
  }
}

class GetTeamsCall {
  static Future<ApiCallResponse> call() {
    return ApiManager.instance.makeApiCall(
      callName: 'GetTeams',
      apiUrl:
          'https://script.google.com/macros/s/AKfycby59fV-vP7ZHBJVZigmGxYWthrgH4Yc3CGZ73Sg7Qu0Oo6_L_C9nwcVLseI6FfGCXCXug/exec?path=Teams',
      callType: ApiCallType.GET,
      headers: {},
      params: {},
      returnBody: true,
    );
  }

  static dynamic poEvents(dynamic response) => getJsonField(
        response,
        r'''$''',
      );
  static dynamic no(dynamic response) => getJsonField(
        response,
        r'''$..No''',
      );
  static dynamic teamName(dynamic response) => getJsonField(
        response,
        r'''$..TeamName''',
      );
  static dynamic playersInvited(dynamic response) => getJsonField(
        response,
        r'''$..PlayersInvited''',
      );
  static dynamic playersConfirmed(dynamic response) => getJsonField(
        response,
        r'''$..PlayersConfirmed''',
      );
  static dynamic category(dynamic response) => getJsonField(
        response,
        r'''$..Category''',
      );
  static dynamic event(dynamic response) => getJsonField(
        response,
        r'''$..Event''',
      );
  static dynamic location(dynamic response) => getJsonField(
        response,
        r'''$..Location''',
      );
}

class GetPlayersMetaDataCall {
  static Future<ApiCallResponse> call() {
    return ApiManager.instance.makeApiCall(
      callName: 'GetPlayersMetaData',
      apiUrl:
          'https://script.google.com/macros/s/AKfycby59fV-vP7ZHBJVZigmGxYWthrgH4Yc3CGZ73Sg7Qu0Oo6_L_C9nwcVLseI6FfGCXCXug/exec?path=PlayersMetaData',
      callType: ApiCallType.GET,
      headers: {},
      params: {},
      returnBody: true,
    );
  }
}

class GetPlayersCall {
  static Future<ApiCallResponse> call() {
    return ApiManager.instance.makeApiCall(
      callName: 'GetPlayers',
      apiUrl:
          'https://script.google.com/macros/s/AKfycby59fV-vP7ZHBJVZigmGxYWthrgH4Yc3CGZ73Sg7Qu0Oo6_L_C9nwcVLseI6FfGCXCXug/exec?path=Players',
      callType: ApiCallType.GET,
      headers: {},
      params: {},
      returnBody: true,
    );
  }

  static dynamic poEvents(dynamic response) => getJsonField(
        response,
        r'''$''',
      );
  static dynamic no(dynamic response) => getJsonField(
        response,
        r'''$..No''',
      );
  static dynamic name(dynamic response) => getJsonField(
        response,
        r'''$..Name''',
      );
  static dynamic gender(dynamic response) => getJsonField(
        response,
        r'''$..Gender''',
      );
  static dynamic height(dynamic response) => getJsonField(
        response,
        r'''$..Height''',
      );
  static dynamic weight(dynamic response) => getJsonField(
        response,
        r'''$..Weight''',
      );
  static dynamic ballHockeySkillScore(dynamic response) => getJsonField(
        response,
        r'''$..BallHockeySkillScore''',
      );
  static dynamic iceHockeySkillScore(dynamic response) => getJsonField(
        response,
        r'''$..IceHockeySkillScore''',
      );
  static dynamic invitationStatus(dynamic response) => getJsonField(
        response,
        r'''$..InvitationStatus''',
      );
}

class GetTeamInviteMetaDataCall {
  static Future<ApiCallResponse> call() {
    return ApiManager.instance.makeApiCall(
      callName: 'GetTeamInviteMetaData',
      apiUrl:
          'https://script.google.com/macros/s/AKfycby59fV-vP7ZHBJVZigmGxYWthrgH4Yc3CGZ73Sg7Qu0Oo6_L_C9nwcVLseI6FfGCXCXug/exec?path=TeamInviteMetaData',
      callType: ApiCallType.GET,
      headers: {},
      params: {},
      returnBody: true,
    );
  }
}

class GetTeamInviteCall {
  static Future<ApiCallResponse> call() {
    return ApiManager.instance.makeApiCall(
      callName: 'GetTeamInvite',
      apiUrl:
          'https://script.google.com/macros/s/AKfycby59fV-vP7ZHBJVZigmGxYWthrgH4Yc3CGZ73Sg7Qu0Oo6_L_C9nwcVLseI6FfGCXCXug/exec?path=TeamInvite',
      callType: ApiCallType.GET,
      headers: {},
      params: {},
      returnBody: true,
    );
  }

  static dynamic poEvents(dynamic response) => getJsonField(
        response,
        r'''$''',
      );
  static dynamic no(dynamic response) => getJsonField(
        response,
        r'''$..No''',
      );
  static dynamic eventName(dynamic response) => getJsonField(
        response,
        r'''$..TeamName''',
      );
  static dynamic captain(dynamic response) => getJsonField(
        response,
        r'''$..Captain''',
      );
  static dynamic division(dynamic response) => getJsonField(
        response,
        r'''$..Division''',
      );
  static dynamic event(dynamic response) => getJsonField(
        response,
        r'''$..Event''',
      );
  static dynamic startDate(dynamic response) => getJsonField(
        response,
        r'''$..StartDate''',
      );
  static dynamic endDate(dynamic response) => getJsonField(
        response,
        r'''$..EndDate''',
      );
  static dynamic invitedDate(dynamic response) => getJsonField(
        response,
        r'''$..InvitedDate''',
      );
}

class NGetTableMetaDataCall {
  static Future<ApiCallResponse> call({
    String? refreshToken = '',
    String? tableName = '',
  }) {
    final body = '''
{
  "refreshToken": "${refreshToken}",
  "tableName": "${tableName}"
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'NGetTableMetaData',
      apiUrl: 'https://playon-uat.axx.do/api/getTableMetaData',
      callType: ApiCallType.POST,
      headers: {
        'Access-Control-Allow-Origin': '*',
      },
      params: {},
      body: body,
      bodyType: BodyType.JSON,
      returnBody: true,
    );
  }

  static dynamic data(dynamic response) => getJsonField(
        response,
        r'''$..json''',
      );
}

class NGetDataCall {
  static Future<ApiCallResponse> call({
    String? refreshToken = '',
    String? tableName = '',
  }) {
    final body = '''
{
  "refreshToken": "${refreshToken}",
  "tableName": "${tableName}"
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'NGetData',
      apiUrl: 'https://playon-uat.axx.do/api/getData',
      callType: ApiCallType.POST,
      headers: {
        'Access-Control-Allow-Origin': '*',
      },
      params: {},
      body: body,
      bodyType: BodyType.JSON,
      returnBody: true,
    );
  }

  static dynamic data(dynamic response) => getJsonField(
        response,
        r'''$..event_name''',
      );
}

class NLoginCall {
  static Future<ApiCallResponse> call({
    String? loginId = '',
    String? password = '',
    String? applicationId = '',
  }) {
    final body = '''
{
  "loginId": "${loginId}",
  "password": "${password}",
  "applicationId": "${applicationId}"
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'NLogin',
      apiUrl: 'https://app.kennarhealth.com/api/login',
      callType: ApiCallType.POST,
      headers: {},
      params: {},
      body: body,
      bodyType: BodyType.JSON,
      returnBody: true,
    );
  }

  static dynamic refreshToken(dynamic response) => getJsonField(
        response,
        r'''$..refreshToken''',
      );
  static dynamic token(dynamic response) => getJsonField(
        response,
        r'''$..token''',
      );
  static dynamic passwordChangeRequired(dynamic response) => getJsonField(
        response,
        r'''$..passwordChangeRequired''',
      );
  static dynamic lastLoginInstant(dynamic response) => getJsonField(
        response,
        r'''$..lastLoginInstant''',
      );
  static dynamic active(dynamic response) => getJsonField(
        response,
        r'''$..active''',
      );
  static dynamic verified(dynamic response) => getJsonField(
        response,
        r'''$..verified''',
      );
  static dynamic usernameStatus(dynamic response) => getJsonField(
        response,
        r'''$..usernameStatus''',
      );
}

class GetCountryStatesCall {
  static Future<ApiCallResponse> call() {
    return ApiManager.instance.makeApiCall(
      callName: 'GetCountryStates',
      apiUrl: 'https://playon-uat.axx.do/api/getCountryStates',
      callType: ApiCallType.GET,
      headers: {},
      params: {},
      returnBody: true,
    );
  }
}

class GetStatesCall {
  static Future<ApiCallResponse> call({
    String? country = 'Canada',
  }) {
    return ApiManager.instance.makeApiCall(
      callName: 'GetStates',
      apiUrl: 'https://playon-uat.axx.do/api/getStates',
      callType: ApiCallType.GET,
      headers: {},
      params: {
        'country': country,
      },
      returnBody: true,
    );
  }

  static dynamic states(dynamic response) => getJsonField(
        response,
        r'''$..json..state_name''',
      );
}

class GetCitiesCall {
  static Future<ApiCallResponse> call({
    String? country = 'Canada',
    String? state = 'Alberta',
  }) {
    return ApiManager.instance.makeApiCall(
      callName: 'GetCities',
      apiUrl: 'https://playon-uat.axx.do/api/getCities',
      callType: ApiCallType.GET,
      headers: {},
      params: {
        'country': country,
        'state': state,
      },
      returnBody: true,
    );
  }

  static dynamic cities(dynamic response) => getJsonField(
        response,
        r'''$..json..city_name''',
      );
}

class NCaptainRegistrationCall {
  static Future<ApiCallResponse> call({
    String? loggedInUserId = '',
    String? eventId = '',
    String? roleId = '',
    String? formStep = '',
    String? teamName = '',
    String? teamId = '',
    String? firstname = '',
    String? lastname = '',
    String? refreshToken = '',
  }) {
    final body = '''
{
"loggedInUserId": "${loggedInUserId}",
"eventId" : "${eventId}",
"roleId" : "${roleId}",
"formStep" : "${formStep}",
"teamName" : "${teamName}",
"teamId" : "${teamId}",
"firstname" : "${firstname}",
"lastname" : "${lastname}",
"refreshToken" : "${refreshToken}"
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'NCaptainRegistration',
      apiUrl: 'https://playon-uat.axx.do/api/captainRegister',
      callType: ApiCallType.POST,
      headers: {},
      params: {},
      body: body,
      bodyType: BodyType.JSON,
      returnBody: true,
    );
  }
}

class NRegisterUserCall {
  static Future<ApiCallResponse> call({
    String? loginId = '',
    String? password = '',
    String? applicationId = '',
    String? defaultroleid = '',
    String? city = '',
    String? firstName = '',
    String? laastName = '',
  }) {
    final body = '''
{
  "loginId": "${loginId}",
  "password": "${password}",
  "applicationId": "${applicationId}",
  "defaultroleid": "${defaultroleid}",
  "city":"${city}",
  "firstName":"${firstName}",
  "laastName":"${laastName}"
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'NRegisterUser',
      apiUrl: 'https://app.kennarhealth.com/api/registerUser',
      callType: ApiCallType.POST,
      headers: {},
      params: {},
      body: body,
      bodyType: BodyType.JSON,
      returnBody: true,
    );
  }

  static dynamic refreshToken(dynamic response) => getJsonField(
        response,
        r'''$..refreshToken''',
      );
  static dynamic token(dynamic response) => getJsonField(
        response,
        r'''$..token''',
      );
  static dynamic passwordChangeRequired(dynamic response) => getJsonField(
        response,
        r'''$..passwordChangeRequired''',
      );
  static dynamic lastLoginInstant(dynamic response) => getJsonField(
        response,
        r'''$..lastLoginInstant''',
      );
  static dynamic active(dynamic response) => getJsonField(
        response,
        r'''$..active''',
      );
  static dynamic verified(dynamic response) => getJsonField(
        response,
        r'''$..verified''',
      );
  static dynamic usernameStatus(dynamic response) => getJsonField(
        response,
        r'''$..usernameStatus''',
      );
}

class QuizbpCall {
  static Future<ApiCallResponse> call({
    String? refreshToken = '',
    String? i1 = '',
    String? i2 = '',
    String? formstep = '',
    String? type = '',
    String? starttime1 = '',
    String? starttime2 = '',
    String? starttime3 = '',
    String? endtime1 = '',
    String? endtime2 = '',
    String? endtime3 = '',
  }) {
    final body = '''
{
  "refreshToken": "${refreshToken}",
  "i1": "${i1}",
  "i2": "${i2}",
  "formstep": "${formstep}",
  "type": "${type}",
  "starttime1": "${starttime1}",
  "starttime2": "${starttime2}",
  "starttime3": "${starttime3}",
  "endtime1": "${endtime1}",
  "endtime2": "${endtime2}",
  "endtime3": "${endtime3}"
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'quizbp',
      apiUrl: 'https://app.kennarhealth.com/api/quizbp',
      callType: ApiCallType.POST,
      headers: {},
      params: {},
      body: body,
      bodyType: BodyType.JSON,
      returnBody: true,
    );
  }

  static dynamic refreshToken(dynamic response) => getJsonField(
        response,
        r'''$..refreshToken''',
      );
  static dynamic token(dynamic response) => getJsonField(
        response,
        r'''$..token''',
      );
  static dynamic passwordChangeRequired(dynamic response) => getJsonField(
        response,
        r'''$..passwordChangeRequired''',
      );
  static dynamic lastLoginInstant(dynamic response) => getJsonField(
        response,
        r'''$..lastLoginInstant''',
      );
  static dynamic active(dynamic response) => getJsonField(
        response,
        r'''$..active''',
      );
  static dynamic verified(dynamic response) => getJsonField(
        response,
        r'''$..verified''',
      );
  static dynamic usernameStatus(dynamic response) => getJsonField(
        response,
        r'''$..usernameStatus''',
      );
}

class NCreateDivisionCall {
  static Future<ApiCallResponse> call({
    String? refreshToken = '',
    String? divisiontype = '',
    String? divisionname = '',
    int? divisionstatus = 0,
    String? divisionagegroup = '',
    String? divisiondescription = '',
    String? divisiongender = '',
    String? isdivisionparent = '',
    int? parentdivisionid = 0,
    int? archivestatus = 0,
  }) {
    final body = '''
{
  "refreshToken": "${refreshToken}",
  "divisiontype": "${divisiontype}",
  "divisionname": "${divisionname}",
  "divisionagegroup": "${divisionagegroup}",
  "divisiongender": "${divisiongender}",
  "isdivisionparent": "${isdivisionparent}",
  "parentdivisionid": "${parentdivisionid}"
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'NCreateDivision',
      apiUrl: 'https://playon-uat.axx.do/api/setDivisionData',
      callType: ApiCallType.POST,
      headers: {
        'Access-Control-Allow-Origin': '*',
      },
      params: {},
      body: body,
      bodyType: BodyType.JSON,
      returnBody: true,
    );
  }

  static dynamic refreshToken(dynamic response) => getJsonField(
        response,
        r'''$..refreshToken''',
      );
  static dynamic divisiontype(dynamic response) => getJsonField(
        response,
        r'''$..divisiontype''',
      );
  static dynamic divisionname(dynamic response) => getJsonField(
        response,
        r'''$..divisionname''',
      );
  static dynamic divisionagegroup(dynamic response) => getJsonField(
        response,
        r'''$..divisionagegroup''',
      );
  static dynamic divisiondescription(dynamic response) => getJsonField(
        response,
        r'''$..divisiondescription''',
      );
  static dynamic divisiongender(dynamic response) => getJsonField(
        response,
        r'''$..divisiongender''',
      );
  static dynamic isdivisionparent(dynamic response) => getJsonField(
        response,
        r'''$..isdivisionparent''',
      );
  static dynamic parentdivisionid(dynamic response) => getJsonField(
        response,
        r'''$..parentdivisionid''',
      );
}

class NCreateEventCall {
  static Future<ApiCallResponse> call({
    String? refreshToken = '',
    String? eventtype = '',
    String? eventname = '',
    int? eventstatus = 0,
    String? cityname = '',
    String? startdate = '',
    String? enddate = '',
    String? regdeadline = '',
    String? locName = '',
    String? locAddress = '',
    String? locCountry = '',
    String? locprovincestate = '',
    String? loccity = '',
    String? loczipcode = '',
    String? locSiteMap = '',
    int? maxSupportTeams = 0,
    int? minNoTeamPlayers = 4,
    int? maxNoTeamPlayers = 9,
    String? playerRegFee = '',
    String? salesTaxRate = '',
    String? youthSalesTaxRate = '',
    String? majorityAge = '',
    String? avail1010RentSpace = '',
    String? avail1015RentSpace = '',
    String? avail2020RentSpace = '',
  }) {
    final body = '''
{
  "refreshToken": "${refreshToken}",
  "event_type": "${eventtype}",
  "event_name": "${eventname}",
  "city_name": "${cityname}",
  "start_date": "${startdate}",
  "end_date": "${enddate}",
  "reg_deadline": "${regdeadline}",
  "loc_province_state": "${locprovincestate}",
  "loc_city":"${loccity}" ,
  "loc_zipcode":"${loczipcode}"
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'NCreateEvent',
      apiUrl: 'https://playon-uat.axx.do/api/setEventData',
      callType: ApiCallType.POST,
      headers: {
        'Access-Control-Allow-Origin': '*',
      },
      params: {},
      body: body,
      bodyType: BodyType.JSON,
      returnBody: true,
    );
  }

  static dynamic refreshToken(dynamic response) => getJsonField(
        response,
        r'''$..refreshToken''',
      );
  static dynamic eventtype(dynamic response) => getJsonField(
        response,
        r'''$..eventtype''',
      );
  static dynamic eventname(dynamic response) => getJsonField(
        response,
        r'''$..eventname''',
      );
  static dynamic cityname(dynamic response) => getJsonField(
        response,
        r'''$..cityname''',
      );
  static dynamic startdate(dynamic response) => getJsonField(
        response,
        r'''$..startdate''',
      );
  static dynamic enddate(dynamic response) => getJsonField(
        response,
        r'''$..enddate''',
      );
  static dynamic regdeadline(dynamic response) => getJsonField(
        response,
        r'''$..regdeadline''',
      );
  static dynamic locprovincestate(dynamic response) => getJsonField(
        response,
        r'''$..loc_province_state''',
      );
  static dynamic loccity(dynamic response) => getJsonField(
        response,
        r'''$..loc_city''',
      );
  static dynamic loczipcode(dynamic response) => getJsonField(
        response,
        r'''$..loc_zipcode''',
      );
}

class NCurrentPageGetCall {
  static Future<ApiCallResponse> call({
    String? refreshToken = '',
  }) {
    final body = '''
{"refreshToken" : "${refreshToken}"}''';
    return ApiManager.instance.makeApiCall(
      callName: 'NCurrentPageGet',
      apiUrl: 'https://playon-uat.axx.do/api/getCurrentPage',
      callType: ApiCallType.POST,
      headers: {},
      params: {},
      body: body,
      bodyType: BodyType.JSON,
      returnBody: true,
    );
  }

  static dynamic currentPage(dynamic response) => getJsonField(
        response,
        r'''$..currentPage''',
      );
}

class NCurrentPageSetCall {
  static Future<ApiCallResponse> call({
    String? refreshToken = '',
    String? currentPage = 'Dashboard',
  }) {
    final body = '''
{
  "refreshToken": "${refreshToken}",
  "currentPage": "${currentPage}"
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'NCurrentPageSet',
      apiUrl: 'https://playon-uat.axx.do/api/setCurrentPage',
      callType: ApiCallType.POST,
      headers: {},
      params: {},
      body: body,
      bodyType: BodyType.JSON,
      returnBody: true,
    );
  }

  static dynamic currentPage(dynamic response) => getJsonField(
        response,
        r'''$..currentPage''',
      );
}

class NLogoutCall {
  static Future<ApiCallResponse> call({
    String? refreshToken = '',
  }) {
    final body = '''
{
  "refreshToken": "${refreshToken}"
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'NLogout',
      apiUrl: 'https://app.kennarhealth.com/api/logout',
      callType: ApiCallType.POST,
      headers: {},
      params: {},
      body: body,
      bodyType: BodyType.JSON,
      returnBody: true,
    );
  }
}

class BpRegistrationbCall {
  static Future<ApiCallResponse> call({
    String? refreshToken = '',
    String? organizationName = '',
    String? address = '',
    String? description = '',
    String? id = '',
    String? applicationId = '',
    String? firstName = '',
    String? title = '',
    String? email = '',
    String? phoneNo = '',
    String? extension = '',
    String? mobileNo = '',
    String? lastName = '',
    String? industryName = '',
    String? otherIndustry = '',
    String? confirmOrg = '',
    String? formstep = '',
  }) {
    final body = '''
{
  "refreshToken": "${refreshToken}",
  "organizationName": "${organizationName}",
  "address": "${address}",
  "description": "${description}",
  "id": "${id}",
  "applicationId": "${applicationId}",
  "firstName": "${firstName}",
  "title": "${title}",
  "email": "${email}",
  "phoneNo": "${phoneNo}",
  "extension": "${extension}",
  "mobileNo": "${mobileNo}",
  "lastName": "${lastName}",
  "industry_name": "${industryName}",
  "other_industry": "${otherIndustry}",
  "confirm_org": "${confirmOrg}",
  "formstep":" ${formstep}"
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'bpRegistrationb',
      apiUrl: 'https://app.kennarhealth.com/api/bpRegistration',
      callType: ApiCallType.POST,
      headers: {
        'Access-Control-Allow-Origin': '*',
      },
      params: {},
      body: body,
      bodyType: BodyType.JSON,
      returnBody: true,
    );
  }

  static dynamic refreshToken(dynamic response) => getJsonField(
        response,
        r'''$..refreshToken''',
      );
  static dynamic eventtype(dynamic response) => getJsonField(
        response,
        r'''$..eventtype''',
      );
  static dynamic eventname(dynamic response) => getJsonField(
        response,
        r'''$..eventname''',
      );
  static dynamic cityname(dynamic response) => getJsonField(
        response,
        r'''$..cityname''',
      );
  static dynamic startdate(dynamic response) => getJsonField(
        response,
        r'''$..startdate''',
      );
  static dynamic enddate(dynamic response) => getJsonField(
        response,
        r'''$..enddate''',
      );
  static dynamic regdeadline(dynamic response) => getJsonField(
        response,
        r'''$..regdeadline''',
      );
  static dynamic locprovincestate(dynamic response) => getJsonField(
        response,
        r'''$..loc_province_state''',
      );
  static dynamic loccity(dynamic response) => getJsonField(
        response,
        r'''$..loc_city''',
      );
  static dynamic loczipcode(dynamic response) => getJsonField(
        response,
        r'''$..loc_zipcode''',
      );
}

class GetDataSCall {
  static Future<ApiCallResponse> call({
    String? refreshToken = '',
    String? id = '',
    String? email = '',
    String? type = '',
    String? ids = '',
    String? roleid = '',
    String? name = '',
    String? formstep = '',
  }) {
    final body = '''
{
  "refreshToken": "${refreshToken}",
  "id": "${id}",
  "email": "${email}",
  "type": "${type}",
  "ids": "${ids}",
  "roleid": "${roleid}",
  "name": "${name}",
  "formstep": "${formstep}"
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'getDataS',
      apiUrl: 'https://app.kennarhealth.com/api/getDataS',
      callType: ApiCallType.POST,
      headers: {
        'Access-Control-Allow-Origin': '*',
      },
      params: {},
      body: body,
      bodyType: BodyType.JSON,
      returnBody: true,
    );
  }

  static dynamic refreshToken(dynamic response) => getJsonField(
        response,
        r'''$..refreshToken''',
      );
  static dynamic eventtype(dynamic response) => getJsonField(
        response,
        r'''$..eventtype''',
      );
  static dynamic eventname(dynamic response) => getJsonField(
        response,
        r'''$..eventname''',
      );
  static dynamic cityname(dynamic response) => getJsonField(
        response,
        r'''$..cityname''',
      );
  static dynamic startdate(dynamic response) => getJsonField(
        response,
        r'''$..startdate''',
      );
  static dynamic enddate(dynamic response) => getJsonField(
        response,
        r'''$..enddate''',
      );
  static dynamic regdeadline(dynamic response) => getJsonField(
        response,
        r'''$..regdeadline''',
      );
  static dynamic locprovincestate(dynamic response) => getJsonField(
        response,
        r'''$..loc_province_state''',
      );
  static dynamic loccity(dynamic response) => getJsonField(
        response,
        r'''$..loc_city''',
      );
  static dynamic loczipcode(dynamic response) => getJsonField(
        response,
        r'''$..loc_zipcode''',
      );
}

class ApiPagingParams {
  int nextPageNumber = 0;
  int numItems = 0;
  dynamic lastResponse;

  ApiPagingParams({
    required this.nextPageNumber,
    required this.numItems,
    required this.lastResponse,
  });

  @override
  String toString() =>
      'PagingParams(nextPageNumber: $nextPageNumber, numItems: $numItems, lastResponse: $lastResponse,)';
}
